module example.com/exactread

go 1.22
