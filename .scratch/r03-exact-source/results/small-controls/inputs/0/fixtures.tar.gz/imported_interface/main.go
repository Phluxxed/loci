package exactread

func Value() int { return 1 }
