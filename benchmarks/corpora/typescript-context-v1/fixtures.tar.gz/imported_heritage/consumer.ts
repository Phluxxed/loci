import { Base, type Contract } from "./types.js";
export interface ChildContract extends Contract { amount: number; }
export class Processor extends Base implements Contract {
  process(): string { return this.requestId; }
}
