export interface Contract { requestId: string; }
export class Base { requestId: string = "base"; }
