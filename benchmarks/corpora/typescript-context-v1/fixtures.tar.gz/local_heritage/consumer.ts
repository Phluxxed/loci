interface Contract { requestId: string; }
interface ChildContract extends Contract { amount: number; }
class Base { requestId: string = "base"; }
export class Processor extends Base implements Contract {
  process(): string { return this.requestId; }
}
