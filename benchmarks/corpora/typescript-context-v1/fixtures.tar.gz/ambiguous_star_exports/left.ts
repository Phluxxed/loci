export interface Payload {
  requestId: string;
  amount: number;
}
