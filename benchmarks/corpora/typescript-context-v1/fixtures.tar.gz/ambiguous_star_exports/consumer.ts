import type { Payload as ImportedPayload } from "./barrel.js";
export function processOrder(value: ImportedPayload): string {
  return value.requestId;
}
