import num from "./number.js";
export function useNumber(): number { return num(1); }
