function num(v: unknown): number { return Number(v); }
export default num;
