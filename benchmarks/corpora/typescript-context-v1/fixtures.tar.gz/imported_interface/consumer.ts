import type { Payload as ImportedPayload } from "./types.js";
export function processOrder(value: ImportedPayload): string {
  return value.requestId;
}
