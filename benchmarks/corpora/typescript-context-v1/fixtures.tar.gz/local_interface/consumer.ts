export interface Payload {
  requestId: string;
  amount: number;
}
export function processOrder(value: Payload): string {
  return value.requestId;
}
