import type { Payload } from "./types.js";
export function processOrder<Payload>(value: Payload): Payload {
  return value;
}
