export interface Payload {
  requestId: string;
  amount: number;
}
export type First = Payload;
export type Second = First;
export function processOrder(value: Second): string {
  return value.requestId;
}
