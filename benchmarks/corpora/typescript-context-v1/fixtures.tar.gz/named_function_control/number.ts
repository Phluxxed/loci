export function num(v: unknown): number { return Number(v); }
