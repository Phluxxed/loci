export const num = (v: unknown): number => Number(v);
