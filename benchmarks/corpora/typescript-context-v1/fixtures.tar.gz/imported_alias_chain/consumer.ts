import type { Second } from "./types.js";
export function processOrder(value: Second): string {
  return value.requestId;
}
