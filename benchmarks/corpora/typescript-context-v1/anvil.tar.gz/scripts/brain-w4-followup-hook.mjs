// Ordinary host observer for the fresh W4 follow-up cases; no compiler substitution.
import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { randomUUID } from 'node:crypto';
import { readFileSync, writeFileSync, realpathSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const base = '/Users/brummerv/phluxxed/brain-w4-closure-2026-09-09';
const caseNames = ['c01'];
const inputLimit = 262144;
const outputLimit = 1024 * 1024;
const timeoutMs = 28000;

export function caseRootForWorkspace(workspace) {
  const root = dirname(workspace);
  const name = root.slice((base + '/execution/').length);
  assert(caseNames.includes(name));
  assert.equal(root, join(base, 'execution', name));
  assert.equal(workspace, join(root, 'workspace'));
  return root;
}

export function validateCaseSource(root, sourceRoot) {
  assert(caseNames.includes(root.slice((base + '/execution/').length)));
  assert.equal(sourceRoot, join(base, 'runtime', 'anvil'));
}

function observe() {
  const input = readFileSync(0, 'utf8');
  assert(Buffer.byteLength(input) <= inputLimit, 'Bounded follow-up hook input exceeded');
  const lifecycle = JSON.parse(input);
  const workspace = realpathSync(lifecycle.cwd);
  const root = caseRootForWorkspace(workspace);
  const s = JSON.parse(readFileSync(join(root, 'settings.json'), 'utf8'));
  assert.equal(s.root, root);
  assert.equal(s.workspace, workspace);
  validateCaseSource(root, s.sourceRoot);
  for (const key of ['ANVIL_HOME', 'ANVIL_STATE_ROOT', 'LLM_WIKI_HOME', 'LOCI_BASE_DIR', 'LLM_WIKI_GRAPH_CACHE_DIR']) {
    assert(s.env[key].startsWith(root + '/'), 'Non-isolated state routing: ' + key);
  }
  const brain = JSON.parse(readFileSync(join(s.env.ANVIL_HOME, 'agents/codex/config.json'), 'utf8'));
  assert.equal(realpathSync(brain.brain_root), join(root, 'brain'));
  assert.equal(brain.wiki_alias, s.alias);
  assert(['SessionStart', 'UserPromptSubmit', 'PreToolUse', 'Stop'].includes(lifecycle.hook_event_name));
  assert(typeof lifecycle.session_id === 'string' && lifecycle.session_id.length > 0);
  const result = spawnSync(process.execPath, [join(s.sourceRoot, 'bin/anvil.ts'), 'codex', 'context-hook'], {
    cwd: workspace, env: { ...process.env, ...s.env }, input, encoding: 'utf8', timeout: timeoutMs, maxBuffer: outputLimit,
  });
  writeFileSync(join(root, 'captures', 'hook-' + randomUUID() + '.json'), JSON.stringify({
    at: new Date().toISOString(), lifecycle, routing: s.env, status: result.status,
    stdout: result.stdout, stderr: result.stderr, error: result.error?.message,
  }, null, 2) + '\n', { flag: 'wx', mode: 0o600 });
  if (result.stdout) process.stdout.write(result.stdout);
  if (result.stderr) process.stderr.write(result.stderr);
  process.exitCode = result.status ?? 1;
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) observe();
