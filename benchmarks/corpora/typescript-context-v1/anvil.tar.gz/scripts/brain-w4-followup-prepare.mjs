// Preparation and no-model diagnostics for the remaining conflict-closure case.
// This module never runs an acceptance turn or changes the live Brain.
import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import {
  copyFileSync, existsSync, lstatSync, mkdirSync, readdirSync, readFileSync,
  realpathSync, symlinkSync, writeFileSync,
} from 'node:fs';
import { dirname, join, normalize, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { sha, toml, withHost, fingerprint, smokeFilesystem, checkHooks } from './brain-host-smoke.mjs';
import { deniedOpenProbe } from './brain-frozen-cases.mjs';
import { gitCommitPreflight } from './brain-git-permission-probe.mjs';

const repo = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const liveBrain = '/Users/brummerv/.anvil-brain/codex';
const liveWiki = '/Users/brummerv/llm-wiki';
const python = join(liveWiki, '.venv/bin/python');
const oldIsolationRoot = '/Users/brummerv/phluxxed/brain-w41-isolated-2026-09-08';
const previousFollowupRoot = '/Users/brummerv/phluxxed/brain-w4-followup-2026-09-08';
const consumedFollowupRoot = '/Users/brummerv/phluxxed/brain-w4-followup-2026-09-09';
const consumedRecheckRoot = '/Users/brummerv/phluxxed/brain-w4-recheck-2026-09-09';
const workbench = '/Users/brummerv/phluxxed/workbench';
const hookPath = join(repo, 'scripts/brain-w4-followup-hook.mjs');
const runtimeRoot = join('/Users/brummerv/phluxxed/brain-w4-closure-2026-09-09', 'runtime');
const anvilRoot = join(runtimeRoot, 'anvil');
const wikiRoot = join(runtimeRoot, 'wiki');
const node = process.execPath;

export const base = '/Users/brummerv/phluxxed/brain-w4-closure-2026-09-09';
export const control = '/Users/brummerv/phluxxed/workbench/.scratch/brain-w4-closure-2026-09-09';
export const caseNames = Object.freeze(['c01']);
// Codex defaults to a ~2,500-token head/tail preview. Let Anvil's existing
// 16/24-KiB prompt/session envelopes reach the model without a second cut.
// Keep a positive host ceiling; do not change non-context handlers or trust.
export const contextLimitTokens = 8192;
export const contextLimits = Object.freeze({ sessionStart: contextLimitTokens, userPromptSubmit: contextLimitTokens });

export function followupHooks(command) {
  const handler = { type: 'command', command, timeout: 30 };
  const contextHandler = { ...handler, additionalContextLimit: contextLimitTokens };
  return {
    'hooks.SessionStart': [{ matcher: 'startup|resume|clear|compact', hooks: [contextHandler] }],
    'hooks.UserPromptSubmit': [{ hooks: [contextHandler] }],
    'hooks.PreToolUse': [{ matcher: '*', hooks: [handler] }],
    'hooks.Stop': [{ hooks: [handler] }],
  };
}

export const read = path => JSON.parse(readFileSync(path, 'utf8'));
export const save = (path, value) => writeFileSync(path, JSON.stringify(value, null, 2) + '\n', { flag: 'wx', mode: 0o600 });
export const hash = path => sha(readFileSync(path));
export function settings(name) {
  assert(caseNames.includes(name), 'Unknown follow-up case: ' + name);
  return read(join(base, 'execution', name, 'settings.json'));
}

function locate(command, required = true) {
  const result = spawnSync('/usr/bin/which', [command], { encoding: 'utf8' });
  if (required) assert.equal(result.status, 0, 'Cannot locate ' + command);
  if (result.status !== 0) return null;
  const launcher = result.stdout.trim();
  assert(launcher, 'Empty launcher path for ' + command);
  return { launcher, resolved: realpathSync(launcher) };
}

function runtimeAccess() {
  const codex = locate('codex');
  const instructionPaths = [
    '/Users/brummerv/.codex/AGENTS.md',
    '/Users/brummerv/.codex/AGENTS.override.md',
  ].filter(existsSync);
  return { ...codex, instructionPaths };
}

function copyTree(source, target, skip = () => false) {
  mkdirSync(target, { recursive: true });
  const files = {};
  const visit = (from, relative = '') => {
    for (const name of readdirSync(from).sort()) {
      const rel = relative ? join(relative, name) : name;
      if (skip(rel, name)) continue;
      const sourcePath = join(from, name), targetPath = join(target, rel);
      const stat = lstatSync(sourcePath);
      if (stat.isDirectory()) visit(sourcePath, rel);
      else if (stat.isFile()) {
        mkdirSync(dirname(targetPath), { recursive: true });
        const sourceHash = hash(sourcePath);
        copyFileSync(sourcePath, targetPath);
        assert.equal(hash(targetPath), sourceHash, 'Frozen source changed while copying: ' + sourcePath);
        files[targetPath] = sourceHash;
      } else assert.fail('Only regular files may be frozen: ' + sourcePath);
    }
  };
  visit(source);
  return files;
}

function copyBrain(sourceFingerprint, target) {
  for (const relative of Object.keys(sourceFingerprint)) {
    const destination = join(target, relative);
    mkdirSync(dirname(destination), { recursive: true });
    copyFileSync(join(liveBrain, relative), destination);
  }
  for (const [relative, expected] of Object.entries(sourceFingerprint)) {
    assert.equal(hash(join(target, relative)), expected, 'Brain copy changed: ' + relative);
  }
  return Object.fromEntries(Object.keys(sourceFingerprint).map(relative => [join(target, relative), hash(join(target, relative))]));
}

function wrapper(entry, source = wikiRoot) {
  return `#!${python}\nimport importlib\nfrom pathlib import Path\nimport sys\n\nSOURCE = Path(${JSON.stringify(source)})\nsys.path.insert(0, str(SOURCE))\nMODULE = importlib.import_module(${JSON.stringify(entry)})\nMODULE_PATH = Path(MODULE.__file__).resolve()\nassert MODULE_PATH.is_relative_to(SOURCE), (MODULE_PATH, SOURCE)\nraise SystemExit(MODULE.main())\n`;
}

function writeWrapper(path, entry, source) {
  writeFileSync(path, wrapper(entry, source), { flag: 'wx', mode: 0o700 });
  return { [path]: hash(path) };
}

function safeRelative(path) {
  assert(typeof path === 'string' && path.length > 0 && !path.startsWith('/'), 'Brain source must be relative');
  assert(normalize(path) === path && path !== '.' && !path.split('/').includes('..'), 'Unsafe Brain source: ' + path);
}

function loadCases() {
  const path = join(control, 'cases.json');
  const document = read(path);
  assert(document && Array.isArray(document.cases), 'Missing cases array');
  assert.deepEqual(document.cases.map(c => c?.name), caseNames, 'Expected exactly c01');
  for (const c of document.cases) {
    assert(typeof c.prompt === 'string' && c.prompt.length > 0 && Buffer.byteLength(c.prompt) <= 16384, 'Invalid prompt: ' + c.name);
    assert(Array.isArray(c.expectations) && c.expectations.every(x => typeof x === 'string'), 'Invalid expectations: ' + c.name);
    assert(Array.isArray(c.sources) && c.sources.length > 0, 'Missing Brain sources: ' + c.name);
    c.sources.forEach(safeRelative);
    if (c.fixture === undefined) assert.notEqual(c.name, 'c01', 'c01 requires its exact fixture');
    else {
      assert.equal(c.name, 'c01', 'Only c01 may have a fixture');
      safeRelative(c.fixture.page);
      for (const key of ['replace_exactly_once', 'with']) assert(typeof c.fixture[key] === 'string', 'Invalid fixture: ' + key);
    }
  }
  return { path, cases: document.cases, casesHash: hash(path) };
}

export function pathRules(s, siblings, runtime, instructions) {
  const filesystem = smokeFilesystem(s.workspace, s.brain, runtime, instructions);
  filesystem[s.brain] = s.name === 'c01' ? 'write' : 'read';
  // Explicit, case-local permission for the required ordinary Brain commit.
  // Parent write access alone leaves Git metadata protected by the host.
  if (s.name === 'c01') filesystem[join(s.brain, '.git')] = 'write';
  const denied = [
    workbench, control, oldIsolationRoot,
    previousFollowupRoot, consumedFollowupRoot, consumedRecheckRoot,
    join(repo, 'bin'), join(repo, 'src'), join(repo, 'docs'),
    join(s.root, 'captures'), join(s.root, 'settings.json'),
    ...siblings.filter(path => path !== s.root),
    join(base, 'runtime', 'anvil', 'docs'), join(base, 'runtime', 'wiki', 'docs'),
  ];
  for (const path of denied) { filesystem[path] = 'deny'; filesystem[path + '/**'] = 'deny'; }
  return filesystem;
}

function manifestFingerprint(files) {
  return sha(JSON.stringify(Object.entries(files).sort(([a], [b]) => a.localeCompare(b))));
}

function gitInit(path) {
  const result = spawnSync('git', ['init', '--quiet', path], { encoding: 'utf8' });
  assert.equal(result.status, 0, result.stderr);
}

function baselineBrain(path) {
  const env = {
    ...process.env,
    GIT_AUTHOR_NAME: 'Phluxxed', GIT_AUTHOR_EMAIL: 'tempest13@gmail.com',
    GIT_COMMITTER_NAME: 'Phluxxed', GIT_COMMITTER_EMAIL: 'tempest13@gmail.com',
  };
  const result = spawnSync('git', ['-C', path, '-c', 'user.name=Phluxxed', '-c', 'user.email=tempest13@gmail.com',
    'add', '-A'], { encoding: 'utf8', env });
  assert.equal(result.status, 0, result.stderr);
  const commit = spawnSync('git', ['-C', path, '-c', 'user.name=Phluxxed', '-c', 'user.email=tempest13@gmail.com',
    'commit', '--quiet', '-m', 'Baseline frozen Brain'], { encoding: 'utf8', env });
  assert.equal(commit.status, 0, commit.stderr);
  const remote = spawnSync('git', ['-C', path, 'remote'], { encoding: 'utf8' });
  assert.equal(remote.status, 0); assert.equal(remote.stdout.trim(), '');
  const log = spawnSync('git', ['-C', path, 'show', '-s', '--format=%H|%an <%ae>|%cn <%ce>|%s', 'HEAD'], { encoding: 'utf8' });
  assert.equal(log.status, 0, log.stderr);
  assert.match(log.stdout.trim(), /^[0-9a-f]+\|Phluxxed <tempest13@gmail\.com>\|Phluxxed <tempest13@gmail\.com>\|Baseline frozen Brain$/);
  return { commit: log.stdout.trim().split('|')[0], identity: 'Phluxxed <tempest13@gmail.com>', remote: false };
}

export async function prepare() {
  assert(!existsSync(base), 'Preparation is exclusive and refuses existing state: ' + base);
  const { path: casesPath, cases, casesHash } = loadCases();
  const runtime = runtimeAccess();
  assert(existsSync(liveBrain), 'Missing live Brain');
  assert(existsSync(join(liveWiki, 'src')), 'Missing live llm-wiki source');
  assert(existsSync(python), 'Missing llm-wiki Python environment');
  const brainSource = fingerprint(liveBrain);
  mkdirSync(base);
  mkdirSync(runtimeRoot, { recursive: true });
  const sourceFiles = {
    anvil: {
      ...copyTree(repo + '/bin', join(anvilRoot, 'bin')),
      ...copyTree(repo + '/src', join(anvilRoot, 'src')),
    },
    wiki: copyTree(join(liveWiki, 'src'), join(wikiRoot, 'src'), (_rel, name) => name === '__pycache__'),
  };
  for (const relative of ['package.json', 'package-lock.json']) {
    const destination = join(anvilRoot, relative);
    mkdirSync(dirname(destination), { recursive: true });
    const sourceHash = hash(join(repo, relative)); copyFileSync(join(repo, relative), destination);
    assert.equal(hash(destination), sourceHash, 'Frozen source changed while copying: ' + relative);
    sourceFiles.anvil[destination] = sourceHash;
  }
  symlinkSync(join(repo, 'node_modules'), join(anvilRoot, 'node_modules'), 'dir');
  const wrappers = { ...writeWrapper(join(wikiRoot, 'compiler.py'), 'llm_wiki_core.cli') };
  sourceFiles.wiki = { ...sourceFiles.wiki, ...wrappers };
  const hookCommand = [node, hookPath].map(value => "'" + value.replaceAll("'", "'\\''") + "'").join(' ');
  const host = await withHost(base, {}, async call => ({
    hooks: await call('hooks/list', { cwds: [base] }),
    config: await call('config/read', { cwd: base, includeLayers: false }),
  }));
  assert.deepEqual(host.hooks.data[0].errors, []);
  assert(!host.hooks.data[0].hooks.some(h => h.isManaged && h.enabled), 'Managed hook needs separate isolation review');
  const disabled = Object.fromEntries(host.hooks.data[0].hooks.map(h => [h.key, { enabled: false }]));
  const siblings = caseNames.map(name => join(base, 'execution', name));
  const caseRecords = [];
  for (const c of cases) {
    const root = join(base, 'execution', c.name), brain = join(root, 'brain'), workspace = join(root, 'workspace');
    for (const path of ['workspace', 'brain', 'captures', 'registry', 'anvil-home/agents/codex', 'state', 'loci', 'graph-cache']) mkdirSync(join(root, path), { recursive: true });
    const copied = copyBrain(brainSource, brain);
    let fixtureRecord;
    if (c.fixture) {
      const fixturePath = join(brain, c.fixture.page), before = readFileSync(fixturePath, 'utf8');
      assert.equal(before.split(c.fixture.replace_exactly_once).length - 1, 1, 'Fixture text is not exact once');
      writeFileSync(fixturePath, before.replace(c.fixture.replace_exactly_once, c.fixture.with));
      fixtureRecord = { page: c.fixture.page, before: sha(before), after: hash(fixturePath), operation: 'one exact paragraph replacement' };
      copied[fixturePath] = hash(fixturePath);
      save(join(root, 'captures', 'fixture.json'), fixtureRecord);
    }
    gitInit(workspace);
    symlinkSync(join(liveWiki, '.venv'), join(brain, '.venv'), 'dir');
    const git = c.name === 'c01' ? (gitInit(brain), baselineBrain(brain)) : null;
    const alias = 'anvil-brain-codex-w4-followup';
    const env = {
      ANVIL_HOME: join(root, 'anvil-home'), ANVIL_AGENT_ID: 'codex', ANVIL_STATE_ROOT: join(root, 'state'), ANVIL_BRAIN_CONTEXT: 'on',
      ANVIL_LLM_WIKI_BIN: join(wikiRoot, 'compiler.py'), LLM_WIKI_HOME: join(root, 'registry'), LOCI_BASE_DIR: join(root, 'loci'),
      LOCI_STORE_NAMESPACE: 'codex-w4-followup-' + c.name, LLM_WIKI_GRAPH_CACHE_DIR: join(root, 'graph-cache'),
      PYTHONPATH: join(wikiRoot, 'src'), PYTHONDONTWRITEBYTECODE: '1',
    };
    const wikiMcp = join(root, 'wiki-mcp.py');
    const wikiMcpFiles = writeWrapper(wikiMcp, 'llm_wiki_mcp.mcp_server', join(wikiRoot, 'src'));
    save(join(root, 'anvil-home/agents/codex/config.json'), { schema_version: 1, agent_id: 'codex', brain_root: brain, wiki_alias: alias });
    save(join(root, 'registry/registry.json'), { version: 1, wikis: { [alias]: { path: brain, created_by: 'w4-followup-preparation', registered_at: new Date().toISOString() } } });
    const s = { name: c.name, root, brain, workspace, sourceRoot: anvilRoot, wikiSourceRoot: wikiRoot, alias, env, hookCommand, hookHash: hash(hookPath), runtime: runtime.resolved };
    const servers = Object.fromEntries(Object.keys(host.config.config.mcp_servers ?? {}).map(name => [name, { enabled: false }]));
    servers.anvil = { enabled: true, command: node, args: [join(anvilRoot, 'bin/anvil.ts'), 'mcp', 'serve'], env,
      enabled_tools: ['anvil_continuity_read', 'anvil_continuity_checkpoint_task', 'anvil_brain_usage_log'] };
    servers['llm-wiki'] = { enabled: true, command: wikiMcp, args: [], env,
      enabled_tools: ['wiki_list', 'wiki_agent_manual', 'wiki_get_page', 'wiki_query', 'wiki_build_maintenance'] };
    s.overrides = {
      'hooks.state': disabled, ...followupHooks(hookCommand),
      mcp_servers: servers, plugins: Object.fromEntries(Object.keys(host.config.config.plugins ?? {}).map(name => [name, { enabled: false }])),
      'apps._default.enabled': false, default_permissions: 'w4_followup',
      'permissions.w4_followup': { description: 'Remaining isolated Brain conflict-closure diagnostic', filesystem: pathRules(s, siblings, runtime.resolved, runtime.instructionPaths), network: { enabled: true } },
      approval_policy: 'never', 'memories.use_memories': false, web_search: 'disabled', model: 'gpt-5.6-luna', model_reasoning_effort: 'max',
      service_tier: 'default', 'features.fast_mode': false, 'features.multi_agent': false, 'features.goals': false,
      'shell_environment_policy.set': { ...env, PYTHONPATH: join(wikiRoot, 'src') },
    };
    for (const app of Object.keys(host.config.config.apps ?? {})) s.overrides['apps.' + app + '.enabled'] = false;
    save(join(root, 'settings.json'), s);
    caseRecords.push({ name: c.name, promptHash: sha(c.prompt), sources: Object.fromEntries(c.sources.map(relative => [relative, hash(join(brain, relative))])), files: { ...copied, ...wikiMcpFiles }, fixture: fixtureRecord, git });
  }
  const files = { [casesPath]: casesHash, [runtime.resolved]: hash(runtime.resolved), [node]: hash(node), [python]: hash(python), [hookPath]: hash(hookPath), ...sourceFiles.anvil, ...sourceFiles.wiki };
  const settingsHashes = {};
  for (const record of caseRecords) {
    const s = settings(record.name); settingsHashes[record.name] = hash(join(s.root, 'settings.json'));
    for (const path of [join(s.root, 'settings.json'), join(s.root, 'registry/registry.json'), join(s.root, 'anvil-home/agents/codex/config.json'), join(s.root, 'wiki-mcp.py')]) files[path] = hash(path);
    Object.assign(files, record.files);
    const fixturePath = join(s.root, 'captures/fixture.json'); if (existsSync(fixturePath)) files[fixturePath] = hash(fixturePath);
  }
  const loci = locate('loci', false), lociMcp = locate('loci-mcp', false);
  if (loci) files[loci.resolved] = hash(loci.resolved);
  if (lociMcp) files[lociMcp.resolved] = hash(lociMcp.resolved);
  const prepared = {
    version: 1, base, control, caseNames, runtime: runtime.resolved, runtimeLauncher: runtime.launcher,
    casesHash, cases: caseRecords.map(({ files: _files, ...record }) => record), files,
    instructionFiles: Object.fromEntries(runtime.instructionPaths.map(path => [path, hash(path)])), settingsHashes,
    sourceRoots: { anvil: anvilRoot, wiki: wikiRoot }, sourceHashes: { anvil: sourceFiles.anvil, wiki: sourceFiles.wiki },
    sourceFingerprints: { anvil: manifestFingerprint(sourceFiles.anvil), wiki: manifestFingerprint(sourceFiles.wiki), liveBrain: sha(JSON.stringify(Object.entries(brainSource).sort())) },
    dependencies: {
      node: { executable: node, version: process.version, sha256: hash(node) },
      python: { executable: realpathSync(python), sha256: hash(python) },
      nodeModules: realpathSync(join(repo, 'node_modules')),
      loci: loci ? { launcher: loci.resolved, sha256: hash(loci.resolved) } : { status: 'not-found' },
      lociMcp: lociMcp ? { launcher: lociMcp.resolved, sha256: hash(lociMcp.resolved) } : { status: 'not-found' },
    },
    brainSourceFingerprint: brainSource, state: 'prepared-not-trusted-or-executed', modelRuns: 0,
  };
  save(join(base, 'prepared.json'), prepared);
  assert.deepEqual(fingerprint(liveBrain), brainSource, 'Live Brain changed during preparation');
  console.log(JSON.stringify({ base, control, caseNames, prepared: true, modelRuns: 0 }));
  return prepared;
}

function verifyPrepared(prepared) {
  assert.equal(prepared.base, base); assert.deepEqual(prepared.caseNames, caseNames);
  for (const [path, expected] of Object.entries(prepared.files)) assert.equal(hash(path), expected, 'Prepared input changed: ' + path);
  for (const [path, expected] of Object.entries(prepared.instructionFiles)) assert.equal(hash(path), expected, 'Instruction changed: ' + path);
  return prepared;
}

export async function inspect(name, { requireTrust = false } = {}) {
  const prepared = verifyPrepared(read(join(base, 'prepared.json')));
  const s = settings(name); assert.equal(s.sourceRoot, anvilRoot); assert.equal(s.runtime, prepared.runtime);
  const profile = s.overrides['permissions.w4_followup'];
  const result = await withHost(s.workspace, s.overrides, async call => {
    const hooks = await call('hooks/list', { cwds: [s.workspace] });
    const config = await call('config/read', { cwd: s.workspace, includeLayers: false });
    const enabled = checkHooks(hooks.data, s.hookCommand, requireTrust, contextLimits);
    const fs = config.config.permissions.w4_followup.filesystem;
    const { glob_scan_max_depth: depth, ...rules } = fs;
    assert.equal(depth, null); assert.deepEqual(rules, profile.filesystem);
    assert.equal(config.config.default_permissions, 'w4_followup'); assert.equal(config.config.approval_policy, 'never');
    assert.equal(config.config.model, 'gpt-5.6-luna'); assert.equal(config.config.model_reasoning_effort, 'max');
    assert.equal(config.config.service_tier, 'default');
    assert.equal(config.config.features.fast_mode, false); assert.equal(config.config.features.multi_agent, false); assert.equal(config.config.features.goals, false);
    // Codex adds its own browser-client verification hashes after merging env.
    // Retain this host guard unchanged; reject all other unexpected env additions.
    const { NODE_REPL_TRUSTED_BROWSER_CLIENT_SHA256S: browserHashes, ...caseEnv } = config.config.shell_environment_policy.set;
    if (browserHashes !== undefined) assert.match(browserHashes, /^[a-f0-9]{64}(,[a-f0-9]{64})*$/);
    assert.deepEqual(caseEnv, s.env);
    const active = Object.entries(config.config.mcp_servers).filter(([, value]) => value.enabled !== false).map(([key]) => key).sort();
    assert.deepEqual(active, ['anvil', 'llm-wiki']);
    for (const [server, expectedCommand, expectedArgs] of [['anvil', node, [join(anvilRoot, 'bin/anvil.ts'), 'mcp', 'serve']], ['llm-wiki', join(s.root, 'wiki-mcp.py'), []]]) {
      assert.equal(config.config.mcp_servers[server].command, expectedCommand);
      assert.deepEqual(config.config.mcp_servers[server].args, expectedArgs);
      for (const [key, value] of Object.entries(s.env)) assert.equal(config.config.mcp_servers[server].env[key], value, server + ':' + key);
    }
    assert.deepEqual(config.config.mcp_servers.anvil.enabled_tools, ['anvil_continuity_read', 'anvil_continuity_checkpoint_task', 'anvil_brain_usage_log']);
    assert.deepEqual(config.config.mcp_servers['llm-wiki'].enabled_tools, ['wiki_list', 'wiki_agent_manual', 'wiki_get_page', 'wiki_query', 'wiki_build_maintenance']);
    return { name, runtime: prepared.runtime, runtimeHash: prepared.files[prepared.runtime], sourceRoot: s.sourceRoot,
      sourceHash: prepared.sourceFingerprints.anvil, settingsHash: hash(join(s.root, 'settings.json')),
      hooks: enabled.map(h => ({ key: h.key, event: h.eventName, command: h.command, source: h.source, trust: h.trustStatus, trustStatus: h.trustStatus, additionalContextLimit: h.additionalContextLimit })),
      defaultPermissions: config.config.default_permissions, mcpServers: active, model: config.config.model,
      effort: config.config.model_reasoning_effort, hostBrowserTrustHashes: browserHashes ?? null, warnings: hooks.data[0].warnings };
  });
  return result;
}

export async function probe() {
  const prepared = verifyPrepared(read(join(base, 'prepared.json')));
  const results = [];
  for (const name of caseNames) {
    const s = settings(name);
    const targets = [join(s.root, 'captures'), join(s.root, 'settings.json'), control, join(oldIsolationRoot, 'execution', 'k01-old'), previousFollowupRoot, consumedFollowupRoot, consumedRecheckRoot];
    const controlTarget = join(s.brain, 'wiki-agent.md');
    let status = null, signal = null, stderr = null, observed = null, error = null;
    try {
      await inspect(name, { requireTrust: false });
      for (const path of [...targets, controlTarget]) assert(existsSync(path), 'Probe target must exist: ' + path);
      const flags = Object.entries(s.overrides).flatMap(([key, value]) => ['-c', key + '=' + toml(value)]);
      const run = spawnSync(prepared.runtime, ['sandbox', ...flags, '-P', 'w4_followup', '-C', s.workspace, '--', node, ...deniedOpenProbe(targets, controlTarget)], { cwd: s.workspace, encoding: 'utf8', timeout: 10000, maxBuffer: 65536 });
      status = run.status; signal = run.signal; stderr = run.stderr?.trim() ?? null;
      try { observed = JSON.parse(run.stdout); } catch {}
      error = run.error?.message ?? null;
      const passed = status === 0 && observed?.controlReadable === true && observed.results?.length === targets.length
        && observed.results.every((item, index) => item.path === targets[index] && item.denied === true && ['EACCES', 'EPERM'].includes(item.code));
      results.push({ name, passed, status, signal, observed, stderr, error, settingsHash: hash(join(s.root, 'settings.json')) });
      if (!passed) break;
    } catch (cause) {
      error = cause.message;
      results.push({ name, passed: false, status, signal, observed, stderr, error, settingsHash: hash(join(s.root, 'settings.json')) });
      break;
    }
  }
  const deniedPassed = results.length === caseNames.length && results.every(r => r.passed);
  const git = deniedPassed ? gitCommitPreflight(settings('c01'), prepared.runtime) : null;
  const proof = { base, scope: 'No-model real Codex sandbox denied-open and isolated Git commit probes', passed: deniedPassed && git?.passed === true, modelRuns: 0, git,
    results, settingsHashes: Object.fromEntries(caseNames.map(name => [name, hash(join(settings(name).root, 'settings.json'))])) };
  save(join(base, 'permission-probe-' + Date.now() + '.json'), proof);
  if (proof.passed) save(join(base, 'permission-proof.json'), proof);
  console.log(JSON.stringify(proof, null, 2));
  if (!proof.passed) process.exitCode = 1;
  return proof;
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const [mode] = process.argv.slice(2);
  const task = mode === 'prepare' ? prepare() : mode === 'inspect' ? inspect(process.argv[3]) : mode === 'probe' ? probe() : Promise.reject(new Error('Use prepare, inspect NAME or probe'));
  task.catch(error => { console.error(error.stack ?? error.message); process.exitCode = 1; });
}
