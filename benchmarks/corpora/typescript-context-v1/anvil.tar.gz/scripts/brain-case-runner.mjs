// One sequential pass over the six frozen W4 cases. No judge or automatic retry.
import assert from 'node:assert/strict';
import { spawn, spawnSync } from 'node:child_process';
import { createWriteStream, existsSync, mkdirSync, readFileSync, readdirSync, statSync, writeFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { finished } from 'node:stream/promises';
import { sha, toml, withHost } from './brain-host-smoke.mjs';
import { frozen, preflight, caseNames, keyRoot, pair, executionRoot, executionSettings, modelRevisionPath } from './brain-frozen-cases.mjs';
import { parseCaseEvents, extractCaseTranscript } from './brain-case-evidence.mjs';
import { snapshotTree, snapshotManifest, diffTrees } from './brain-case-files.mjs';

const repo = dirname(dirname(fileURLToPath(import.meta.url)));
const read = path => JSON.parse(readFileSync(path, 'utf8'));
const hash = path => sha(readFileSync(path));
const save = (path, value) => writeFileSync(path, JSON.stringify(value, null, 2) + '\n', { flag: 'wx', mode: 0o600 });
// Keep the withdrawn Astra seal intact as provenance; it cannot launch this revision.
const readyPath = join(keyRoot, 'launch-ready-luna-max.json');
const startPath = join(keyRoot, 'case-run-start.json');
const codeFiles = ['brain-frozen-cases.mjs', 'brain-frozen-case-hook.mjs', 'brain-host-smoke.mjs',
  'brain-case-runner.mjs', 'brain-case-evidence.mjs', 'brain-case-files.mjs'];
const sequence = ['k01:old', 'k01:current', 'k02:current', 'k02:old', 'k03:old', 'k03:current',
  'k04:current', 'k04:old', 'c05:current', 'c06:current:fresh', 'c06:current:exact-resume'];

export function buildCaseSequence(knowledge, operational, conditions) {
  assert.deepEqual(knowledge.map(c => c.id), ['k01', 'k02', 'k03', 'k04']);
  assert.deepEqual(operational.cases.map(c => c.id), ['c05', 'c06']);
  assert.deepEqual(conditions.sequence, sequence);
  return sequence.map(key => {
    const [id, variant, phase] = key.split(':');
    const resume = phase === 'exact-resume';
    const prompt = id.startsWith('k') ? knowledge.find(c => c.id === id).prompt
      : id === 'c05' ? operational.cases[0].prompt
        : operational.cases[1][resume ? 'resume_prompt' : 'fresh_prompt'];
    assert(typeof prompt === 'string' && prompt.length > 0 && Buffer.byteLength(prompt) <= 16384);
    const seconds = conditions.timeoutsSeconds[id.startsWith('k') ? 'knowledgeTurn'
      : id === 'c05' ? 'conflictTurn' : resume ? 'recoveryResumedTurn' : 'recoveryFreshTurn'];
    assert(Number.isInteger(seconds) && seconds > 0 && seconds <= 600);
    // No expectations, fixture explanations or report instructions enter the prompt.
    return { key, name: id + '-' + variant, label: resume ? 'resumed' : 'fresh', resume, prompt, timeoutMs: seconds * 1000 };
  });
}

export function validatePermissionProof(proof, root, fileHash = hash) {
  assert.equal(proof.root, root);
  assert.equal(proof.passed, true);
  assert.equal(proof.modelRuns, 0);
  assert.deepEqual(proof.results.map(r => r.name), ['k01-old', 'c05-current']);
  for (const r of proof.results) {
    assert.equal(r.passed, true); assert.equal(r.status, 0);
    assert.equal(r.observed.controlReadable, true);
    const targets = [keyRoot, join(root, r.name, 'captures'), join(root, r.name, 'settings.json'), join(root, 'k02-current')];
    assert.deepEqual(r.observed.results.map(x => x.path), targets);
    assert(r.observed.results.every(x => x.denied === true && ['EPERM', 'EACCES'].includes(x.code)));
    assert.equal(r.settingsHash, fileHash(join(root, r.name, 'settings.json')));
  }
  assert.deepEqual(Object.keys(proof.settingsHashes).sort(), [...caseNames].sort());
  for (const [name, expected] of Object.entries(proof.settingsHashes)) assert.equal(fileHash(join(root, name, 'settings.json')), expected, 'Permission-bound settings changed: ' + name);
}

export function estimateLunaCredits(usage) {
  const basis = { source: 'https://learn.chatgpt.com/docs/pricing', ratesAsOf: '2026-09-08',
    model: 'gpt-5.6-luna', serviceTier: 'default', ratesPerMillion: { input: 5, cachedInput: 0.5, output: 30 },
    note: 'Rate-card estimate from reported token usage, not measured account credits or subscription allowance.' };
  if (!usage || !['input_tokens', 'cached_input_tokens', 'output_tokens'].every(k => Number.isSafeInteger(usage[k]) && usage[k] >= 0)
      || usage.cached_input_tokens > usage.input_tokens || (usage.cache_write_input_tokens ?? 0) !== 0) {
    return { ...basis, status: 'unproven', credits: null, reason: 'Missing or unsupported token accounting' };
  }
  const uncached = usage.input_tokens - usage.cached_input_tokens;
  return { ...basis, status: 'estimated', credits: Math.round((uncached * 5 + usage.cached_input_tokens * 0.5 + usage.output_tokens * 30) * 1000) / 1e9 };
}

function verifyFiles(expected) {
  for (const [path, expectedHash] of Object.entries(expected)) assert.equal(hash(path), expectedHash, 'Prepared file changed: ' + path);
}

function archivedSourceHashes() {
  // Tar parsing stays read-only; no second extraction, corpus build or index run.
  // macOS tar restores AppleDouble records as metadata, not ._ source files.
  const code = "import tarfile,hashlib,json,sys\nwith tarfile.open(sys.argv[1]) as t:\n print(json.dumps({m.name:hashlib.sha256(t.extractfile(m).read()).hexdigest() for m in t.getmembers() if m.isfile() and m.name.startswith(('old/anvil/','old/wiki/','current/anvil/','current/wiki/','current/brain/')) and '/__pycache__/' not in m.name and not m.name.rsplit('/',1)[-1].startswith('._')}))";
  const r = spawnSync('/Users/brummerv/llm-wiki/.venv/bin/python', ['-c', code, join(keyRoot, 'frozen-runtime.tar.gz')], { encoding: 'utf8', timeout: 10000, maxBuffer: 1024 * 1024 });
  assert.equal(r.status, 0, r.stderr);
  return Object.fromEntries(Object.entries(JSON.parse(r.stdout)).map(([p, h]) => [join(pair, p), h]));
}

function initialTrees(root, prepared, operational) {
  const manifests = {};
  for (const name of caseNames) {
    const s = read(join(root, name, 'settings.json'));
    const brain = snapshotTree(s.brain), workspace = snapshotTree(s.workspace);
    const expected = { ...prepared.brainFiles };
    if (name === 'c05-current') {
      const fixture = operational.cases[0].fixture;
      const original = readFileSync(join(pair, 'current/brain', fixture.page), 'utf8');
      assert.equal(original.split(fixture.replace_exactly_once).length - 1, 1);
      expected[fixture.page] = sha(original.replace(fixture.replace_exactly_once, fixture.with));
    }
    assert.deepEqual(Object.keys(brain).sort(), Object.keys(expected).sort(), 'Fresh Brain file set changed: ' + name);
    for (const [p, h] of Object.entries(expected)) assert.equal(brain[p].sha256, h, 'Fresh Brain changed: ' + name + '/' + p);
    const expectedWorkspace = name === 'c06-current' ? { 'input.csv': sha(operational.cases[1].input_csv) } : {};
    assert.deepEqual(Object.keys(workspace).sort(), Object.keys(expectedWorkspace).sort(), 'Fresh workspace changed: ' + name);
    for (const [p, h] of Object.entries(expectedWorkspace)) assert.equal(workspace[p].sha256, h);
    manifests[name] = { brain: snapshotManifest(brain), workspace: snapshotManifest(workspace) };
  }
  return manifests;
}

export async function sealPreparation(root) {
  assert.equal(root, executionRoot);
  assert(!existsSync(startPath), 'Cases have already started; do not reseal or retry them.');
  assert(!existsSync(readyPath), 'Preparation is already sealed.');
  const { freeze, conditions, prepared, modelRevision, modelRevisionHash } = frozen();
  const operational = read(join(keyRoot, 'operational-cases.json'));
  const turns = buildCaseSequence(read(join(keyRoot, 'clean-author/case-prompts.json')), operational, conditions);
  const sourceHashes = archivedSourceHashes(); verifyFiles(sourceHashes);
  const hostPreflight = await preflight(root);
  validatePermissionProof(read(join(root, 'permission-proof.json')), root);
  const codeHashes = Object.fromEntries(codeFiles.map(name => [join(repo, 'scripts', name), hash(join(repo, 'scripts', name))]));
  const routingHashes = {};
  for (const variant of ['old', 'current']) routingHashes[join(pair, variant, 'compiler.py')] = hash(join(pair, variant, 'compiler.py'));
  for (const name of caseNames) {
    const s = read(join(root, name, 'settings.json'));
    for (const p of ['settings.json', 'wiki-mcp.py', 'registry/registry.json', 'anvil-home/agents/codex/config.json']) routingHashes[join(s.root, p)] = hash(join(s.root, p));
    assert(existsSync(join(s.root, 'captures/index-preparation.json')), 'Missing prepared index');
  }
  const record = { at: new Date().toISOString(), root, sourceFreeze: hash(join(keyRoot, 'freeze.json')),
    permissionProofHash: hash(join(root, 'permission-proof.json')), launchHash: hash(join(root, 'launch.json')),
    modelRevisionPath, modelRevisionHash, modelRevision, effectiveConditions: conditions, hostPreflight,
    permissionAttribution: 'Original proof and all ten settings files are unchanged. The exact allowlisted invocation revision changes only model/effort/service and disables fast mode, subagents and automatic goals; permission rules are identical. No new sandbox run is claimed.',
    codeHashes, sourceHashes, routingHashes, initialTrees: initialTrees(root, prepared, operational),
    turns: turns.map(({ prompt, ...turn }) => ({ ...turn, promptHash: sha(prompt) })),
    caseCount: freeze.caseCount, state: 'prepared-not-executed', modelRuns: 0 };
  save(readyPath, record);
  return { ready: readyPath, cases: record.caseCount, turns: turns.length,
    model: conditions.model, effort: conditions.effort, serviceTier: conditions.serviceTier, modelRuns: 0 };
}

export async function captureProcess(command, args, { input, directory, timeoutMs, idleTimeoutMs, maxBytes = 16 * 1024 * 1024 }, runtime = {}) {
  assert(Number.isInteger(timeoutMs) && timeoutMs > 0);
  assert(idleTimeoutMs === undefined || (Number.isInteger(idleTimeoutMs) && idleTimeoutMs > 0 && idleTimeoutMs < timeoutMs));
  const launch = runtime.spawn ?? spawn, killProcess = runtime.kill ?? process.kill;
  const schedule = runtime.setTimeout ?? setTimeout, cancel = runtime.clearTimeout ?? clearTimeout;
  const stdout = createWriteStream(join(directory, 'events.jsonl'), { flags: 'wx', mode: 0o600 });
  const stderr = createWriteStream(join(directory, 'stderr.txt'), { flags: 'wx', mode: 0o600 });
  // Wait for exclusive output-file creation before a process can consume a case.
  try {
    await Promise.all([new Promise((ok, fail) => { stdout.once('open', ok); stdout.once('error', fail); }),
      new Promise((ok, fail) => { stderr.once('open', ok); stderr.once('error', fail); })]);
  } catch (error) { stdout.destroy(); stderr.destroy(); throw error; }
  const child = launch(command, args, { detached: true, stdio: ['pipe', 'pipe', 'pipe'] });
  let stopped = null, bytes = 0, escalation, idleTimer;
  const kill = signal => { if (!child.pid) return; try { killProcess(-child.pid, signal); } catch (e) { if (e.code !== 'ESRCH') child.kill(signal); } };
  const stop = reason => {
    if (stopped) return;
    stopped = reason; kill('SIGTERM');
    escalation = schedule(() => kill('SIGKILL'), 1500);
  };
  const resetIdleTimeout = () => {
    if (idleTimeoutMs === undefined || stopped) return;
    cancel(idleTimer);
    idleTimer = schedule(() => stop('idle-timeout'), idleTimeoutMs);
  };
  let eventBuffer = '';
  const observeProgress = data => {
    if (idleTimeoutMs === undefined || stopped) return;
    eventBuffer += data.toString('utf8');
    let newline;
    while ((newline = eventBuffer.indexOf('\n')) >= 0) {
      const line = eventBuffer.slice(0, newline).trim();
      eventBuffer = eventBuffer.slice(newline + 1);
      try {
        const event = JSON.parse(line);
        if (event.type === 'item.completed' || event.type === 'turn.completed'
          || (event.type === 'item.updated' && event.item?.status === 'in_progress')) resetIdleTimeout();
      } catch {}
    }
  };
  const capture = (stream, data, observesProgress = false) => {
    const remaining = Math.max(0, maxBytes - bytes);
    if (remaining) stream.write(data.subarray(0, remaining));
    bytes += data.length;
    if (bytes > maxBytes) stop('capture-limit');
    else if (observesProgress) observeProgress(data);
  };
  child.stdout.on('data', data => capture(stdout, data, true));
  child.stderr.on('data', data => capture(stderr, data));
  stdout.on('error', () => stop('capture-write-error')); stderr.on('error', () => stop('capture-write-error'));
  const interrupt = () => stop('interrupted');
  process.once('SIGINT', interrupt); process.once('SIGTERM', interrupt);
  const timer = schedule(() => stop('timeout'), timeoutMs);
  resetIdleTimeout();
  child.stdin.on('error', () => {}); // An early host exit may close stdin first.
  child.stdin.end(input);
  let result;
  try {
    result = await new Promise(resolve => {
      child.once('error', error => resolve({ code: null, signal: null, error: error.message }));
      child.once('close', (code, signal) => resolve({ code, signal }));
    });
    stdout.end(); stderr.end();
    await Promise.all([finished(stdout), finished(stderr)]);
  } finally {
    cancel(timer); cancel(idleTimer); cancel(escalation);
    process.removeListener('SIGINT', interrupt); process.removeListener('SIGTERM', interrupt);
  }
  return { ...result, stopped, bytes };
}

async function captureHost(s, sessionId, previous, directory) {
  return withHost(s.workspace, s.overrides, async call => {
    const { thread } = await call('thread/read', { threadId: sessionId, includeTurns: true });
    assert.equal(thread.id, sessionId); assert.equal(thread.cwd, s.workspace);
    const items = [], cursors = new Set();
    let cursor;
    do {
      const page = await call('thread/items/list', { threadId: sessionId, limit: 100, ...(cursor ? { cursor } : {}) });
      assert(Array.isArray(page.data)); items.push(...page.data);
      assert(items.length <= 5000, 'Case item capture exceeds bound');
      cursor = page.nextCursor;
      if (cursor) { assert(!cursors.has(cursor), 'Repeated host cursor'); cursors.add(cursor); }
    } while (cursor);
    const priorTurns = new Set(previous?.turnIds ?? []);
    const currentItems = items.filter(row => !priorTurns.has(row.turnId));
    const turnIds = [...new Set(currentItems.map(row => row.turnId))];
    assert(turnIds.length === 1 && typeof turnIds[0] === 'string', 'Cannot identify one actual case turn');
    save(join(directory, 'host-items.json'), { sessionId, turnIds, items: currentItems });
    assert(typeof thread.path === 'string' && statSync(thread.path).size <= 16 * 1024 * 1024, 'Missing or oversized case transcript');
    const evidence = extractCaseTranscript(readFileSync(thread.path, 'utf8'), {
      sessionId, workspace: s.workspace, afterLine: previous?.transcriptLineCount ?? 0,
    });
    save(join(directory, 'host-context.json'), { source: thread.path, sessionId, ...evidence });
    const metadata = { id: thread.id, cwd: thread.cwd, cliVersion: thread.cliVersion, model: thread.model,
      reasoningEffort: thread.reasoningEffort, source: thread.source, modelProvider: thread.modelProvider,
      turns: thread.turns?.filter(t => turnIds.includes(t.id)) };
    save(join(directory, 'host-conditions.json'), metadata);
    return { status: evidence.status, turnIds: [...priorTurns, ...turnIds], transcriptLineCount: evidence.lineCount };
  });
}

function treesFor(s) {
  return Object.fromEntries([['workspace', s.workspace], ['brain', s.brain], ['state', s.env.ANVIL_STATE_ROOT],
    ['anvil-home', s.env.ANVIL_HOME]].map(([name, path]) => [name, snapshotTree(path)]));
}

function captureGit(s) {
  return Object.fromEntries([['workspace', s.workspace], ['brain', s.brain]].map(([name, path]) => {
    const r = spawnSync('git', ['-C', path, 'log', '-3', '--format=%H %s'], { encoding: 'utf8', timeout: 5000, maxBuffer: 8192 });
    return [name, { status: r.status, commits: r.status === 0 ? r.stdout.trim().split('\n').filter(Boolean) : [], diagnostic: r.status === 0 ? null : r.stderr.trim() }];
  }));
}

export async function runSequence(turns, execute) {
  const sessions = new Map(), results = [];
  for (const turn of turns) {
    const previous = sessions.get(turn.name);
    assert.equal(Boolean(previous), turn.resume, 'No retries or implicit session reuse');
    const result = await execute(turn, previous);
    assert(typeof result.sessionId === 'string' && result.sessionId.length > 0);
    if (turn.resume) assert.equal(result.sessionId, previous.sessionId, 'Recovery changed session');
    sessions.set(turn.name, result); results.push({ key: turn.key, ...result });
  }
  return results;
}

async function executeTurn(root, conditions, turn, previous) {
  const s = executionSettings(root, turn.name);
  const directory = join(s.root, 'captures', turn.label);
  mkdirSync(directory); // Exclusive: a consumed or partial turn cannot be overwritten.
  const before = treesFor(s), hooksBefore = new Set(readdirSync(join(s.root, 'captures')));
  save(join(directory, 'prompt.json'), { prompt: turn.prompt, sha256: sha(turn.prompt) });
  save(join(directory, 'before-files.json'), Object.fromEntries(Object.entries(before).map(([n, tree]) => [n, snapshotManifest(tree)])));
  save(join(directory, 'conditions.json'), { settings: s, frozen: conditions, previousSessionId: previous?.sessionId ?? null, gitBefore: captureGit(s) });
  const flags = Object.entries(s.overrides).flatMap(([k, v]) => ['-c', k + '=' + toml(v)]);
  const args = ['exec', ...flags, '--json', '-C', s.workspace, ...(turn.resume ? ['resume', previous.sessionId] : []), '-'];
  const processResult = await captureProcess(conditions.runtime, args, { input: turn.prompt, directory, timeoutMs: turn.timeoutMs });
  const errors = [];
  let events, host, sessionId;
  const eventText = readFileSync(join(directory, 'events.jsonl'), 'utf8');
  try { events = parseCaseEvents(eventText, { expectedSessionId: previous?.sessionId }); sessionId = events.sessionId; }
  catch (e) { errors.push(e.message); }
  if (!sessionId) {
    // Salvage only a complete first identity event for partial-run evidence capture.
    try { const first = JSON.parse(eventText.split('\n')[0]); if (first.type === 'thread.started' && typeof first.thread_id === 'string') sessionId = first.thread_id; } catch {}
  }
  if (sessionId && (!previous || previous.sessionId === sessionId)) {
    try { host = await captureHost(s, sessionId, previous, directory); } catch (e) { errors.push('Host capture: ' + e.message); }
  }
  const hookFiles = readdirSync(join(s.root, 'captures')).filter(n => n.startsWith('hook-') && n.endsWith('.json') && !hooksBefore.has(n));
  const hooks = hookFiles.map(name => ({ file: name, ...read(join(s.root, 'captures', name)) }));
  const expectedEvents = ['SessionStart', 'UserPromptSubmit', 'Stop'];
  const hooksValid = hooks.every(h => h.status === 0 && h.lifecycle.session_id === sessionId && h.lifecycle.cwd === s.workspace)
    && expectedEvents.every(name => hooks.some(h => h.lifecycle.hook_event_name === name));
  if (!hooksValid) errors.push('Missing, failed or misrouted lifecycle capture');
  save(join(directory, 'hook-observations.json'), { files: hookFiles, valid: hooksValid,
    note: 'Upstream observer output is not proof of host-delivered context.' });
  const after = treesFor(s);
  save(join(directory, 'file-changes.json'), { changes: Object.fromEntries(Object.keys(before).map(n => [n, diffTrees(before[n], after[n])])),
    after: Object.fromEntries(Object.entries(after).map(([n, tree]) => [n, snapshotManifest(tree)])), gitAfter: captureGit(s) });
  if (processResult.code !== 0 || processResult.stopped) errors.push('CLI failed or stopped: ' + JSON.stringify(processResult));
  if (!events?.completed) errors.push('No successful completed turn');
  if (host?.status !== 'captured-host-messages') errors.push('Delivered-context capture is unproven');
  const result = { sessionId: sessionId ?? null, directory, process: processResult, host, errors,
    transport: errors.length ? 'unproven' : 'captured', behaviour: 'unreviewed', usage: events?.usage ?? null,
    answers: events?.answers ?? [], turnIds: host?.turnIds ?? [], transcriptLineCount: host?.transcriptLineCount ?? 0,
    creditEstimate: estimateLunaCredits(events?.usage) };
  save(join(directory, 'result.json'), result);
  assert.equal(errors.length, 0, 'Stopped after ' + turn.key + '; inspect ' + join(directory, 'result.json'));
  return result;
}

export async function runFrozenCases(root) {
  assert.equal(root, executionRoot);
  assert(!existsSync(startPath), 'Cases already started. Preserve results; no automatic retry.');
  const sealed = read(readyPath), { conditions, prepared, modelRevisionHash } = frozen();
  assert.equal(modelRevisionHash, sealed.modelRevisionHash, 'Sealed model revision changed');
  assert.deepEqual(conditions, sealed.effectiveConditions, 'Sealed execution conditions changed');
  assert.equal(sealed.root, root);
  assert.equal(hash(join(keyRoot, 'freeze.json')), sealed.sourceFreeze);
  assert.equal(hash(join(root, 'permission-proof.json')), sealed.permissionProofHash);
  assert.equal(hash(join(root, 'launch.json')), sealed.launchHash);
  verifyFiles(sealed.codeHashes); verifyFiles(sealed.sourceHashes); verifyFiles(sealed.routingHashes);
  validatePermissionProof(read(join(root, 'permission-proof.json')), root);
  const operational = read(join(keyRoot, 'operational-cases.json'));
  assert.deepEqual(initialTrees(root, prepared, operational), sealed.initialTrees);
  const turns = buildCaseSequence(read(join(keyRoot, 'clean-author/case-prompts.json')), operational, conditions);
  assert.deepEqual(turns.map(({ prompt, ...t }) => ({ ...t, promptHash: sha(prompt) })), sealed.turns);
  await preflight(root); // Metadata/trust readback only, never another permission probe.
  save(startPath, { at: new Date().toISOString(), root, sealHash: hash(readyPath), turns: sealed.turns });
  const results = [];
  try {
    await runSequence(turns, async (turn, previous) => {
      // Detect source/config drift between paired sessions, not just at run start.
      assert.equal(frozen().modelRevisionHash, sealed.modelRevisionHash, 'Model revision changed between turns');
      verifyFiles(sealed.codeHashes); verifyFiles(sealed.sourceHashes); verifyFiles(sealed.routingHashes);
      const result = await executeTurn(root, conditions, turn, previous);
      results.push({ key: turn.key, directory: result.directory, sessionId: result.sessionId, transport: result.transport,
        usage: result.usage, creditEstimate: result.creditEstimate });
      console.error('Captured ' + turn.key + '; behaviour awaits main review.');
      return result;
    });
    const result = { at: new Date().toISOString(), state: 'captured-requires-main-review', results, automaticJudgment: false };
    save(join(keyRoot, 'case-run-result.json'), result);
    return result;
  } catch (e) {
    save(join(keyRoot, 'case-run-result.json'), { at: new Date().toISOString(), state: 'stopped-unproven', results, error: e.message, retry: 'No automatic rerun; inspect preserved partial evidence first.' });
    throw e;
  }
}
