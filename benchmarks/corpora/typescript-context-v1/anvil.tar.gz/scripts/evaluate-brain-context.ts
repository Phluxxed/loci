import { spawnSync } from "node:child_process";
import { cp, mkdir, mkdtemp, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

import { getEncoding } from "js-tiktoken";

import { buildBrainContext, type BrainContextEvent, type BrainContextResult } from "../src/brain-context/index.ts";

const ROOT = dirname(dirname(fileURLToPath(import.meta.url)));
const FIXTURES = join(ROOT, "test", "fixtures", "brain-context");
const TOKENIZER_PACKAGE_VERSION = "1.0.21";
const PAGE_FAILURES = new Map([
  ["patterns/rust.md", ["WP0-LANGUAGE-RELEVANCE", "Irrelevant Rust selection remains reproducible."]],
]);

export type BrainContextEvaluationScenario = {
  id: string;
  lifecycle_event: string;
  prompt_class: string;
  workspace_identity: string;
  expected_project_match: boolean;
  observed_project_match: boolean;
  selected_page_paths: string[];
  selection_outcome: string;
  bytes: { guidance: number; retrieved_context: number; framing: number; attempted: number; rendered: number };
  tokens: { rendered_payload: number };
  verdict: "pass" | "known_failure" | "unexpected_failure";
  issue_id?: string;
  reason?: string;
  provider_usage: { status: "observed" | "not_observed"; actual_input_tokens?: number; cached_input_tokens?: number };
};

export type BrainContextEvaluationReport = {
  schema_version: 1;
  tokenizer: { implementation: string; package_version: string; encoding: string };
  scenarios: BrainContextEvaluationScenario[];
};

type Usage = { actual_input_tokens?: number; cached_input_tokens?: number };

const SCENARIOS = [
  ["generic-unknown-project", "startup", "generic", "unknown_project", false, "unknown-project"],
  ["instruction-system-audit", "prompt_recall", "instruction-system", "anvil_redux", true, "valid-known-project"],
  ["explicit-rust-question", "prompt_recall", "rust", "anvil_redux", true, "valid-known-project"],
  ["skill-creation-repair", "prompt_recall", "skill", "anvil_redux", true, "valid-known-project"],
  ["known-anvil-workspace-startup", "startup", "workspace", "anvil_redux", true, "valid-known-project"],
  ["lifecycle-startup", "startup", "lifecycle", "anvil_redux", true, "valid-known-project"],
  ["lifecycle-resume", "resume", "lifecycle", "anvil_redux", true, "valid-known-project"],
  ["lifecycle-clear-compact", "clear_compact", "lifecycle", "anvil_redux", true, "valid-known-project"],
] as const;

function runGit(cwd: string, args: string[]): void {
  const result = spawnSync("git", args, { cwd, encoding: "utf8" });
  if (result.status !== 0) throw new Error(result.stderr);
}

async function makeRuntime(fixture: string, workspaceName = "anvil_redux", compilerPage?: string) {
  const temp = await mkdtemp(join(tmpdir(), "anvil-brain-eval-"));
  const brainRoot = join(temp, "brain");
  const cwd = join(temp, workspaceName);
  const anvilHome = join(temp, ".anvil");
  await cp(join(FIXTURES, fixture), brainRoot, { recursive: true });
  if (compilerPage) {
    await writeFile(join(brainRoot, compilerPage), `### Synthetic ${compilerPage}\n\nSynthetic evaluation page.\n`);
    await writeFile(join(brainRoot, "compiled-context.json"), JSON.stringify({
      kind: "compiled_context", contract_version: "1", wiki: { alias: "fixture-brain" },
      evidence: [{ page: compilerPage, content: "synthetic compiler evidence" }], diagnostics: [],
    }));
  }
  await mkdir(cwd, { recursive: true });
  await mkdir(join(anvilHome, "agents", "codex"), { recursive: true });
  await writeFile(join(anvilHome, "agents", "codex", "config.json"), `${JSON.stringify({
    schema_version: 1, agent_id: "codex", brain_root: brainRoot, wiki_alias: "fixture-brain",
  })}\n`);
  runGit(cwd, ["init", "-q"]);
  return { temp, cwd, options: {
    anvilHome, homeDir: temp, stateRoot: join(temp, "state"),
    env: { ANVIL_AGENT_ID: "codex", ANVIL_LLM_WIKI_BIN: join(FIXTURES, "fake-llm-wiki.mjs") },
    retrievalTimeoutMs: 2_000,
  } };
}

const tokenizer = getEncoding("o200k_base");

function usageFor(sidecar: Record<string, Usage>, id: string): BrainContextEvaluationScenario["provider_usage"] {
  const usage = sidecar[id];
  if (!usage) return { status: "not_observed" };
  for (const key of ["actual_input_tokens", "cached_input_tokens"] as const) {
    if (usage[key] !== undefined && (!Number.isSafeInteger(usage[key]) || usage[key]! < 0)) throw new Error(`Invalid ${key} for ${id}`);
  }
  return { status: "observed", ...usage };
}

function scenarioResult(id: string, lifecycle: string, promptClass: string, identity: string, expected: boolean, expectedPages: string[], forbiddenPages: string[], result: BrainContextResult, usage: BrainContextEvaluationScenario["provider_usage"]): BrainContextEvaluationScenario {
  const observation = result.recallObservation;
  const bytes = {
    guidance: observation?.bytes.guidance ?? 0,
    retrieved_context: observation?.bytes.retrieved_context ?? 0,
    framing: observation?.bytes.framing ?? 0,
    attempted: observation?.bytes.attempted ?? result.renderedBytes,
    rendered: result.renderedBytes,
  };
  const selected = result.selectedPages ?? [];
  const observed = new Set(result.selectedPages ?? []);
  const missing = expectedPages.filter((page) => !observed.has(page));
  const forbidden = forbiddenPages.find((page) => observed.has(page));
  const known = forbidden ? PAGE_FAILURES.get(forbidden) : undefined;
  const verdict = result.status !== "ready" || missing.length > 0 ? "unexpected_failure" : known ? "known_failure" : "pass";
  return {
    id, lifecycle_event: lifecycle, prompt_class: promptClass, workspace_identity: identity,
    expected_project_match: expected, observed_project_match: result.matchedProject !== undefined,
    selected_page_paths: selected, selection_outcome: observation?.selection_outcome ?? "unchanged",
    bytes, tokens: { rendered_payload: tokenizer.encode(result.markdown).length },
    verdict,
    ...(known ? { issue_id: known[0], reason: known[1] } : verdict === "unexpected_failure" ? { issue_id: "WP0-UNEXPECTED", reason: missing.length > 0 ? `Missing expected page: ${missing[0]}` : result.diagnostics[0]?.code ?? "degraded" } : {}),
    provider_usage: usage,
  };
}

export async function evaluateBrainContext(options: { usage?: Record<string, Usage> } = {}): Promise<BrainContextEvaluationReport> {
  const scenarios: BrainContextEvaluationScenario[] = [];
  for (const [id, lifecycle, promptClass, identity, expected, fixture] of SCENARIOS) {
    const compilerPage = id === "instruction-system-audit" || id === "explicit-rust-question" ? "patterns/rust.md" : undefined;
    const runtime = await makeRuntime(fixture, id === "generic-unknown-project" ? "unrelated_workspace" : "anvil_redux", compilerPage);
    try {
      const event: BrainContextEvent = lifecycle === "startup" || lifecycle === "resume" || lifecycle === "clear_compact"
        ? { type: "session_start", cwd: runtime.cwd }
        : { type: "user_prompt_submit", cwd: runtime.cwd, prompt: `${promptClass} synthetic question` };
      const expectedPages = id === "explicit-rust-question" ? ["patterns/rust.md"] : [];
      const forbiddenPages = id === "instruction-system-audit" ? ["patterns/rust.md"] : [];
      scenarios.push(scenarioResult(id, lifecycle, promptClass, identity, expected, expectedPages, forbiddenPages, await buildBrainContext(event, runtime.options), usageFor(options.usage ?? {}, id)));
    } finally { await rm(runtime.temp, { recursive: true, force: true }); }
  }
  return { schema_version: 1, tokenizer: { implementation: "js-tiktoken", package_version: TOKENIZER_PACKAGE_VERSION, encoding: "o200k_base" }, scenarios };
}

async function main(): Promise<void> {
  const report = await evaluateBrainContext();
  const unexpected = report.scenarios.filter((scenario) => scenario.verdict === "unexpected_failure");
  const outputIndex = process.argv.indexOf("--output");
  const json = `${JSON.stringify(report, null, 2)}\n`;
  if (outputIndex >= 0 && process.argv[outputIndex + 1]) await writeFile(process.argv[outputIndex + 1], json);
  else process.stdout.write(json);
  if (unexpected.length > 0) process.exitCode = 1;
}

if (import.meta.url === `file://${process.argv[1]}`) void main();
