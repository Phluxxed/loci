// Ordinary host observer for the frozen W4 cases; no compiler substitution.
import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { readFileSync, writeFileSync, realpathSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { randomUUID } from 'node:crypto';
const base = '/Users/brummerv/phluxxed/brain-w41-isolated-2026-09-08';
export function caseRootForWorkspace(workspace) {
  const root = dirname(workspace);
  const name = root.slice((base + '/execution/').length);
  assert(/^(?:k0[1-4]-(?:old|current)|c0[56]-current)$/.test(name));
  assert.equal(root, join(base, 'execution', name));
  assert.equal(workspace, join(root, 'workspace'));
  return root;
}
export function validateCaseSource(root, sourceRoot) {
  const variant = root.endsWith('-old') ? 'old' : 'current';
  assert.equal(sourceRoot, join(base, 'paired', variant, 'anvil'));
}
function observe() {
const input = readFileSync(0, 'utf8');
assert(Buffer.byteLength(input) <= 262144);
const lifecycle = JSON.parse(input);
const workspace = realpathSync(lifecycle.cwd);
const root = caseRootForWorkspace(workspace);
const s = JSON.parse(readFileSync(join(root, 'settings.json'), 'utf8'));
assert.equal(s.root, root);
assert.equal(s.workspace, workspace);
validateCaseSource(root, s.sourceRoot);
for (const key of ['ANVIL_HOME', 'ANVIL_STATE_ROOT', 'LLM_WIKI_HOME', 'LOCI_BASE_DIR', 'LLM_WIKI_GRAPH_CACHE_DIR']) assert(s.env[key].startsWith(root + '/'));
const brain = JSON.parse(readFileSync(join(s.env.ANVIL_HOME, 'agents/codex/config.json')));
assert.equal(realpathSync(brain.brain_root), join(root, 'brain'));
assert.equal(brain.wiki_alias, s.alias);
assert(['SessionStart', 'UserPromptSubmit', 'PreToolUse', 'Stop'].includes(lifecycle.hook_event_name));
assert(typeof lifecycle.session_id === 'string' && lifecycle.session_id.length > 0);
const result = spawnSync(process.execPath, [join(s.sourceRoot, 'bin/anvil.ts'), 'codex', 'context-hook'], {
  cwd: workspace, env: { ...process.env, ...s.env }, input, encoding: 'utf8', timeout: 28000, maxBuffer: 1024 * 1024,
});
writeFileSync(join(root, 'captures', 'hook-' + randomUUID() + '.json'), JSON.stringify({
  at: new Date().toISOString(), lifecycle, routing: s.env, status: result.status,
  stdout: result.stdout, stderr: result.stderr, error: result.error?.message,
}, null, 2) + '\n', { flag: 'wx', mode: 0o600 });
if (result.stdout) process.stdout.write(result.stdout);
if (result.stderr) process.stderr.write(result.stderr);
process.exitCode = result.status ?? 1;
}
if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) observe();
