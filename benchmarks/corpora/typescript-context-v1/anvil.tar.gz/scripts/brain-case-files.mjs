import {
  closeSync,
  constants,
  fstatSync,
  lstatSync,
  openSync,
  readFileSync,
  readdirSync,
  realpathSync,
} from 'node:fs';
import { createHash } from 'node:crypto';
import { join, relative, resolve, sep } from 'node:path';
import { TextDecoder } from 'node:util';

export const MAX_FILES = 3_000;
export const MAX_TOTAL_BYTES = 16 * 1024 * 1024;
export const MAX_CONTENT_BYTES = 256 * 1024;
export const MAX_DIFF_CONTENT_BYTES = 8 * 1024 * 1024;

const EXCLUDED_DIRECTORIES = new Set(['.git', '.venv', 'node_modules', '__pycache__']);
const O_NOFOLLOW = constants.O_NOFOLLOW ?? 0;
const UTF8 = new TextDecoder('utf-8', { fatal: true });

function fail(message) {
  throw new Error(message);
}

function isObject(value) {
  return value !== null && typeof value === 'object' && !Array.isArray(value);
}

function comparePaths(left, right) {
  return left < right ? -1 : left > right ? 1 : 0;
}

function posixPath(root, file) {
  return relative(root, file).split(sep).join('/');
}

function readRegularFile(path) {
  let descriptor;
  try {
    descriptor = openSync(path, constants.O_RDONLY | O_NOFOLLOW);
    const current = fstatSync(descriptor);
    if (!current.isFile()) fail(`Expected regular file at ${path}`);
    return readFileSync(descriptor);
  } catch (error) {
    if (error?.code === 'ELOOP') fail(`Unexpected symlink while reading ${path}`);
    throw error;
  } finally {
    if (descriptor !== undefined) closeSync(descriptor);
  }
}

function decodeText(bytes) {
  if (bytes.includes(0)) return undefined;
  try {
    const text = UTF8.decode(bytes);
    // Reject control-heavy payloads that happen to be valid UTF-8. Tabs,
    // line breaks, form feed and carriage returns are normal text controls.
    for (const character of text) {
      const code = character.codePointAt(0);
      if ((code < 0x09) || (code > 0x0d && code < 0x20) || code === 0x7f) return undefined;
    }
    return text;
  } catch {
    return undefined;
  }
}

function omission(reason) {
  return { reason };
}

function entryFor(bytes) {
  const entry = {
    sha256: createHash('sha256').update(bytes).digest('hex'),
    bytes: bytes.byteLength,
  };
  const text = decodeText(bytes);
  if (text === undefined) {
    entry.contentOmitted = omission('binary');
  } else if (bytes.byteLength > MAX_CONTENT_BYTES) {
    entry.contentOmitted = omission('too_large');
  } else {
    entry.content = text;
  }
  return entry;
}

function rootForSnapshot(input) {
  if (typeof input !== 'string' || input.length === 0) fail('root must be a non-empty string');
  const requested = resolve(input);
  let requestedStat;
  try {
    requestedStat = lstatSync(requested);
  } catch (error) {
    fail(`Cannot inspect snapshot root ${requested}: ${error.message}`);
  }
  if (requestedStat.isSymbolicLink()) fail(`Snapshot root must not be a symlink: ${requested}`);
  if (!requestedStat.isDirectory()) fail(`Snapshot root must be a directory: ${requested}`);
  try {
    return realpathSync(requested);
  } catch (error) {
    fail(`Cannot resolve snapshot root ${requested}: ${error.message}`);
  }
}

function addFile(files, path, root, totals) {
  const current = lstatSync(path);
  if (current.isSymbolicLink()) fail(`Unexpected symlink: ${path}`);
  if (!current.isFile()) return;

  totals.files += 1;
  if (totals.files > MAX_FILES) fail(`Snapshot exceeds ${MAX_FILES} regular files`);
  totals.bytes += current.size;
  if (totals.bytes > MAX_TOTAL_BYTES) fail(`Snapshot exceeds ${MAX_TOTAL_BYTES} bytes`);

  const bytes = readRegularFile(path);
  // A file may change between lstat and read. Re-apply the bound to the bytes
  // actually hashed, so the returned snapshot is always within the contract.
  totals.bytes += bytes.byteLength - current.size;
  if (totals.bytes > MAX_TOTAL_BYTES) fail(`Snapshot exceeds ${MAX_TOTAL_BYTES} bytes`);
  files.push([posixPath(root, path), entryFor(bytes)]);
}

function visitDirectory(directory, root, files, totals) {
  const entries = readdirSync(directory, { withFileTypes: true }).sort((left, right) => comparePaths(left.name, right.name));
  for (const child of entries) {
    const path = join(directory, child.name);
    const childStat = lstatSync(path);

    // Excluded directories are skipped, but an excluded-name symlink is still
    // an unexpected symlink unless it is the explicitly permitted .venv link.
    if (childStat.isSymbolicLink()) {
      // Do not resolve even this permitted link: an isolated Brain commonly
      // has .venv pointing at a host environment, and metadata on that target
      // is outside the requested tree.
      if (child.name === '.venv') continue;
      fail(`Unexpected symlink: ${path}`);
    }
    if (childStat.isDirectory()) {
      if (EXCLUDED_DIRECTORIES.has(child.name)) continue;
      visitDirectory(path, root, files, totals);
      continue;
    }
    addFile(files, path, root, totals);
  }
}

/**
 * Capture a deterministic, bounded map of regular files below one isolated
 * root. No symlink is followed; the only permitted symlink is a directory
 * named .venv, which is skipped.
 */
export function snapshotTree(root) {
  const resolvedRoot = rootForSnapshot(root);
  const files = [];
  visitDirectory(resolvedRoot, resolvedRoot, files, { files: 0, bytes: 0 });
  return Object.fromEntries(files.sort(([left], [right]) => comparePaths(left, right)));
}

function treeEntries(tree) {
  if (tree instanceof Map) return [...tree.entries()];
  if (isObject(tree)) return Object.entries(tree);
  fail('Snapshot tree must be an object or Map');
}

function copyOmission(value) {
  if (isObject(value)) return { ...value };
  return value;
}

function copyEntry(entry, { includeContent = false } = {}) {
  if (!isObject(entry)) fail('Snapshot entries must be objects');
  const result = {};
  if (Object.hasOwn(entry, 'sha256')) result.sha256 = entry.sha256;
  if (Object.hasOwn(entry, 'bytes')) result.bytes = entry.bytes;
  if (includeContent && typeof entry.content === 'string') result.content = entry.content;
  if (Object.hasOwn(entry, 'contentOmitted')) result.contentOmitted = copyOmission(entry.contentOmitted);
  return result;
}

/** Return the hash/size/omission manifest without retaining file contents. */
export function snapshotManifest(tree) {
  return Object.fromEntries(
    treeEntries(tree)
      .map(([path, entry]) => [path, copyEntry(entry)])
      .sort(([left], [right]) => comparePaths(left, right)),
  );
}

function changed(before, after) {
  return before?.sha256 !== after?.sha256 || before?.bytes !== after?.bytes;
}

function addDiffContent(target, source, state) {
  if (typeof source?.content !== 'string') return;
  const size = Buffer.byteLength(source.content, 'utf8');
  if (size <= state.remaining) {
    target.content = source.content;
    state.remaining -= size;
    return;
  }
  target.contentOmitted = omission('diff_budget');
}

/**
 * Compare two file maps in path order. Changed entries retain available text
 * until the separate 8 MiB diff-content budget is exhausted; omitted text is
 * marked while hashes and sizes remain available.
 */
export function diffTrees(before, after) {
  const beforeEntries = new Map(treeEntries(before));
  const afterEntries = new Map(treeEntries(after));
  const paths = [...new Set([...beforeEntries.keys(), ...afterEntries.keys()])].sort(comparePaths);
  const state = { remaining: MAX_DIFF_CONTENT_BYTES };
  const result = [];

  for (const path of paths) {
    const beforeEntry = beforeEntries.get(path) ?? null;
    const afterEntry = afterEntries.get(path) ?? null;
    if (beforeEntry !== null && afterEntry !== null && !changed(beforeEntry, afterEntry)) continue;

    const diff = {
      path,
      kind: beforeEntry === null ? 'added' : afterEntry === null ? 'deleted' : 'modified',
      before: beforeEntry === null ? null : copyEntry(beforeEntry),
      after: afterEntry === null ? null : copyEntry(afterEntry),
    };
    if (diff.before !== null) addDiffContent(diff.before, beforeEntry, state);
    if (diff.after !== null) addDiffContent(diff.after, afterEntry, state);
    result.push(diff);
  }
  return result;
}
