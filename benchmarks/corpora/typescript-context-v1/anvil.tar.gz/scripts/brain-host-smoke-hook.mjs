// Host-invoked observer: preserves the real lifecycle input and output unchanged.
import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { randomUUID } from 'node:crypto';
import { readFileSync, realpathSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';

const root = realpathSync(process.argv[2]);
assert(/^\/private\/tmp\/brain-w41-smoke\.[A-Za-z0-9]+$/.test(root));
const s = JSON.parse(readFileSync(join(root, 'settings.json'), 'utf8'));
assert.equal(s.root, root);
for (const key of ['ANVIL_HOME', 'ANVIL_STATE_ROOT', 'LLM_WIKI_HOME', 'LOCI_BASE_DIR', 'LLM_WIKI_GRAPH_CACHE_DIR']) {
  assert(s.env[key].startsWith(root + '/'), 'Non-isolated state routing: ' + key);
}
const brainConfig = JSON.parse(readFileSync(join(s.env.ANVIL_HOME, 'agents/codex/config.json'), 'utf8'));
assert.equal(realpathSync(brainConfig.brain_root), join(root, 'brain'));
assert.equal(brainConfig.wiki_alias, s.alias);
const input = readFileSync(0, 'utf8');
assert(Buffer.byteLength(input) <= 262144, 'Bounded smoke hook input exceeded');
const lifecycle = JSON.parse(input);
assert.equal(realpathSync(lifecycle.cwd), s.workspace, 'Unexpected smoke workspace');
assert(['SessionStart', 'UserPromptSubmit', 'PreToolUse', 'Stop'].includes(lifecycle.hook_event_name));
assert(typeof lifecycle.session_id === 'string' && lifecycle.session_id.length > 0);
const started = new Date().toISOString();
const result = spawnSync(process.execPath, [join(s.sourceRoot, 'bin/anvil.ts'), 'codex', 'context-hook'], {
  cwd: s.workspace, env: { ...process.env, ...s.env }, input, encoding: 'utf8', timeout: 28000, maxBuffer: 1024 * 1024,
});
// These are upstream observer artifacts, not a claim of model-visible delivery.
writeFileSync(join(root, 'captures', 'hook-' + randomUUID() + '.json'), JSON.stringify({
  started, lifecycle, routing: s.env, status: result.status,
  stdout: result.stdout, stderr: result.stderr, error: result.error?.message,
}, null, 2) + '\n', { flag: 'wx', mode: 0o600 });
if (result.stdout) process.stdout.write(result.stdout);
if (result.stderr) process.stderr.write(result.stderr);
process.exitCode = result.status ?? 1;
