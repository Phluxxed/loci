// Exactly one remaining conflict-closure diagnostic. No retry, judge or implicit run.
import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { existsSync, mkdirSync, mkdtempSync, readFileSync, readdirSync, statSync } from 'node:fs';
import { join, dirname, resolve } from 'node:path';
import { tmpdir } from 'node:os';
import { fileURLToPath } from 'node:url';
import { base, control, caseNames, read, save, hash, settings, inspect } from './brain-w4-followup-prepare.mjs';
import { toml, withHost, fingerprint } from './brain-host-smoke.mjs';
import { captureProcess, estimateLunaCredits } from './brain-case-runner.mjs';
import { parseCaseEvents, extractCaseTranscript } from './brain-case-evidence.mjs';
import { snapshotTree, snapshotManifest, diffTrees } from './brain-case-files.mjs';
const scripts = dirname(fileURLToPath(import.meta.url));
const liveBrain = '/Users/brummerv/.anvil-brain/codex';
const sealPath = join(control, 'ready.json'), startPath = join(control, 'started.json');
const dependencies = ['brain-w4-followup-run.mjs', 'brain-w4-followup-prepare.mjs', 'brain-w4-followup-hook.mjs',
  'brain-host-smoke.mjs', 'brain-case-runner.mjs', 'brain-frozen-cases.mjs', 'brain-case-evidence.mjs', 'brain-case-files.mjs', 'brain-git-permission-probe.mjs'];
// Exercise the service behind the host hook, not fabricated host lifecycle traffic.
const recallProgram = `
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { pathToFileURL } from 'node:url';
const { sourceRoot, cwd, prompt } = JSON.parse(readFileSync(0, 'utf8'));
const { createContextHarness } = await import(pathToFileURL(join(sourceRoot, 'src/brain-context/harness.ts')).href);
const harness = createContextHarness({ stateRoot: process.env.ANVIL_STATE_ROOT });
const common = { cwd, host: 'codex', sessionId: 'recall-preflight-' + process.pid, reservedBytes: 0 };
const startup = await harness.planContext({ ...common, lifecycle: 'session_start' });
const recall = await harness.planContext({ ...common, lifecycle: 'prompt', prompt });
process.stdout.write(JSON.stringify({ startup, recall }));
`;

export function recallPreflight(s, prompt, launch = spawnSync) {
  assert(typeof prompt === 'string' && prompt.length > 0 && Buffer.byteLength(prompt) <= 16384);
  const directory = mkdtempSync(join(tmpdir(), 'brain-recall-preflight-'));
  const env = { ...process.env, ...s.env, PYTHONDONTWRITEBYTECODE: '1' };
  for (const [key, folder] of Object.entries({ ANVIL_STATE_ROOT: 'state', LOCI_BASE_DIR: 'loci', LLM_WIKI_GRAPH_CACHE_DIR: 'graph-cache' })) {
    env[key] = join(directory, folder); mkdirSync(env[key]);
  }
  env.LOCI_STORE_NAMESPACE = 'recall-preflight';
  const inputPath = join(directory, 'input.json'), capturePath = join(directory, 'capture.json'), resultPath = join(directory, 'result.json');
  save(inputPath, { sourceRoot: s.sourceRoot, cwd: s.workspace, prompt });
  const result = launch(process.execPath, ['--input-type=module', '-e', recallProgram], {
    cwd: s.workspace, env, input: readFileSync(inputPath, 'utf8'), encoding: 'utf8', timeout: 30000, maxBuffer: 1024 * 1024,
  });
  save(capturePath, { status: result.status, signal: result.signal, error: result.error?.message, stdout: result.stdout, stderr: result.stderr });
  const errors = []; let envelopes;
  try {
    assert.equal(result.status, 0, 'Context service failed or timed out');
    assert(!result.error && !result.signal, 'Context service did not finish normally');
    envelopes = JSON.parse(result.stdout);
    assert.equal(envelopes.startup.status, 'ready', 'Startup did not produce a ready kernel');
    const recall = envelopes.recall;
    assert(['ready', 'partial'].includes(recall.status), 'Prompt recall is unavailable');
    assert.match(recall.receipt.snapshotDigest, /^[a-f0-9]{64}$/);
    assert.equal(recall.receipt.snapshotDigest, envelopes.startup.receipt.snapshotDigest, 'Snapshot changed during recall');
    assert(recall.receipt.compilerBudget, 'No valid compiler response reached the context service');
    assert(recall.receipt.selectedEvidence.some(e => !e.id.startsWith('kernel:') && e.byteCost > 0), 'Prompt recall contains no task evidence');
    assert(recall.receipt.selectedEvidence.some(e => e.provider === 'loci' && e.route === 'indexed_section' && e.byteCost > 0),
      'Prompt recall contains no delivered Loci indexed-section evidence; other providers do not prove section retrieval');
    assert.match(recall.markdown, /^## Brain Context$/m);
    assert(!recall.markdown.includes('## Brain Recall Diagnostic'), 'Prompt recall contains a failure diagnostic');
  } catch (error) { errors.push(error.message); }
  const report = { name: s.name, modelRuns: 0, passed: errors.length === 0, directory, errors,
    snapshotDigest: envelopes?.recall?.receipt?.snapshotDigest,
    evidence: envelopes?.recall?.receipt?.selectedEvidence,
    diagnostics: envelopes?.recall?.diagnostics,
    compilerDiagnostics: envelopes?.recall?.receipt?.compilerDiagnostics,
    boundary: 'Cold-store context-service delivery check requiring Loci indexed-section evidence, not host delivery, answer sufficiency, or behavioural acceptance.' };
  save(resultPath, report);
  return { ...report, files: Object.fromEntries([inputPath, capturePath, resultPath].map(p => [p, hash(p)])) };
}

export function readinessFiles(indexes, dependency, hashFile = hash) {
  assert.equal(indexes.modelRuns, 0); assert.equal(indexes.indexSetupPassed, true);
  assert.deepEqual(indexes.cases.map(c => c.name), caseNames);
  for (const c of indexes.cases) {
    assert.equal(c.workspace, join(base, 'execution', c.name, 'workspace'));
    assert.equal(c.lociBaseDir, join(base, 'execution', c.name, 'loci'));
    assert.equal(c.namespace, 'codex-w4-followup-' + c.name);
    assert.equal(c.graphStatus, 'healthy'); assert.deepEqual(c.verification.failed, []);
  }
  assert.equal(dependency.modelRuns, 0); assert.equal(dependency.passed, true);
  assert(dependency.files && Object.keys(dependency.files).length > 0, 'Missing dependency fingerprints');
  for (const [path, expected] of Object.entries(dependency.files)) {
    assert.equal(resolve(path), path, 'Dependency path must be absolute');
    assert.match(expected, /^[a-f0-9]{64}$/);
    assert.equal(hashFile(path), expected, 'Dependency changed: ' + path);
  }
  return { ...dependency.files };
}
export function turnsFor(cases) {
  assert.deepEqual(cases.map(c => c.name), caseNames);
  return cases.map(c => {
    assert(typeof c.prompt === 'string' && c.prompt.length > 0 && Buffer.byteLength(c.prompt) <= 16384);
    return { name: c.name, prompt: c.prompt, timeoutMs: 60 * 60 * 1000, idleTimeoutMs: 10 * 60 * 1000 };
  });
}
function trees(s) {
  return Object.fromEntries([['workspace', s.workspace], ['brain', s.brain], ['state', s.env.ANVIL_STATE_ROOT],
    ['anvil-home', s.env.ANVIL_HOME]].map(([n, p]) => [n, snapshotTree(p)]));
}
function git(s) {
  return Object.fromEntries([['workspace', s.workspace], ['brain', s.brain]].map(([name, path]) => {
    const result = spawnSync('git', ['-C', path, 'log', '-3', '--format=%H %s'], { encoding: 'utf8', timeout: 5000 });
    return [name, { status: result.status, stdout: result.stdout, stderr: result.stderr }];
  }));
}
export async function seal() {
  assert(!existsSync(startPath) && !existsSync(sealPath), 'Do not overwrite or reseal a consumed preparation');
  const proofPath = join(base, 'permission-proof.json'), proof = read(proofPath);
  assert.equal(proof.passed, true); assert.equal(proof.modelRuns, 0);
  assert.deepEqual(proof.results.map(r => r.name), caseNames);
  for (const r of proof.results) { assert.equal(r.passed, true); assert.equal(r.status, 0); }
  assert.equal(proof.git?.passed, true, 'Required isolated Git commit preflight missing or failed');
  assert.equal(proof.git.modelRuns, 0);
  assert.equal(proof.git.baseline.observed.gitWritable, false);
  assert.match(proof.git.candidate.observed.commit, /^[a-f0-9]{40}$/);
  assert.equal(proof.git.candidate.observed.clean, true);
  assert.equal(proof.git.candidate.observed.protectedDenied.length, 3);
  assert(proof.git.candidate.observed.protectedDenied.every(r => r.denied === true));
  const indexPath = join(base, 'index-readiness.json'), dependencyPath = join(base, 'dependency-readiness.json');
  const dependencyFiles = readinessFiles(read(indexPath), read(dependencyPath));
  const profiles = [];
  for (const name of caseNames) {
    const s = settings(name);
    assert.equal(proof.settingsHashes[name], hash(join(s.root, 'settings.json')));
    profiles.push(await inspect(name, { requireTrust: true }));
    assert.deepEqual(readdirSync(join(s.root, 'captures')).filter(n => n.startsWith('hook-')), [], 'Case already received lifecycle input');
  }
  const turns = turnsFor(read(join(control, 'cases.json')).cases);
  const recall = turns.map(turn => recallPreflight(settings(turn.name), turn.prompt));
  assert(recall.every(r => r.passed), 'Recall preflight failed; inspect ' + recall.filter(r => !r.passed).map(r => r.directory).join(', '));
  const files = { ...dependencyFiles, ...Object.assign({}, ...recall.map(r => r.files)), ...Object.fromEntries([...dependencies.map(n => join(scripts, n)), join(control, 'cases.json'),
    join(base, 'prepared.json'), proofPath, indexPath, dependencyPath, join(base, 'hook-trust-approval.json')].map(p => [p, hash(p)])) };
  const initial = Object.fromEntries(caseNames.map(n => [n, Object.fromEntries(Object.entries(trees(settings(n))).map(([k, t]) => [k, snapshotManifest(t)]))]));
  const record = { at: new Date().toISOString(), modelRuns: 0, kind: 'targeted-current-only-diagnostics',
    files, profiles, initial, turns, recall, approval: 'not granted by this seal' };
  save(sealPath, record);
  return { ready: true, modelRuns: 0, sealPath, next: 'Prepared for Vik to launch c01 manually.' };
}
async function captureHost(s, sessionId, directory) {
  return withHost(s.workspace, s.overrides, async call => {
    const { thread } = await call('thread/read', { threadId: sessionId, includeTurns: true });
    assert.equal(thread.id, sessionId); assert.equal(thread.cwd, s.workspace);
    const items = [], cursors = new Set(); let cursor;
    do {
      const page = await call('thread/items/list', { threadId: sessionId, limit: 100, ...(cursor ? { cursor } : {}) });
      assert(Array.isArray(page.data)); items.push(...page.data); assert(items.length <= 5000);
      cursor = page.nextCursor;
      if (cursor) { assert(!cursors.has(cursor)); cursors.add(cursor); }
    } while (cursor);
    const turnIds = [...new Set(items.map(row => row.turnId))];
    assert(turnIds.length === 1 && typeof turnIds[0] === 'string', 'Expected one fresh actual turn');
    save(join(directory, 'host-items.json'), { sessionId, turnIds, items });
    assert(typeof thread.path === 'string' && statSync(thread.path).size <= 16 * 1024 * 1024);
    const evidence = extractCaseTranscript(readFileSync(thread.path, 'utf8'), { sessionId, workspace: s.workspace });
    save(join(directory, 'host-context.json'), { source: thread.path, sessionId, ...evidence });
    save(join(directory, 'host-conditions.json'), { id: thread.id, cwd: thread.cwd, cliVersion: thread.cliVersion,
      model: thread.model, reasoningEffort: thread.reasoningEffort, source: thread.source, modelProvider: thread.modelProvider, turns: thread.turns });
    return { status: evidence.status, turnIds, transcriptLineCount: evidence.lineCount };
  });
}
async function execute(turn, runtime) {
  const s = settings(turn.name), directory = join(s.root, 'captures', 'fresh');
  mkdirSync(directory);
  const before = trees(s), hooksBefore = new Set(readdirSync(join(s.root, 'captures')));
  save(join(directory, 'prompt.json'), { prompt: turn.prompt });
  save(join(directory, 'conditions.json'), { settings: s, gitBefore: git(s) });
  save(join(directory, 'before-files.json'), Object.fromEntries(Object.entries(before).map(([n, t]) => [n, snapshotManifest(t)])));
  const args = ['exec', ...Object.entries(s.overrides).flatMap(([k, v]) => ['-c', k + '=' + toml(v)]), '--json', '-C', s.workspace, '-'];
  const processResult = await captureProcess(runtime, args, { input: turn.prompt, directory,
    timeoutMs: turn.timeoutMs, idleTimeoutMs: turn.idleTimeoutMs });
  const errors = []; let events, host, sessionId;
  const eventText = readFileSync(join(directory, 'events.jsonl'), 'utf8');
  try { events = parseCaseEvents(eventText); sessionId = events.sessionId; } catch (e) { errors.push(e.message); }
  if (!sessionId) {
    try { const first = JSON.parse(eventText.split('\n')[0]); if (first.type === 'thread.started') sessionId = first.thread_id; } catch {}
  }
  if (typeof sessionId === 'string') {
    try { host = await captureHost(s, sessionId, directory); } catch (e) { errors.push('Host capture: ' + e.message); }
  }
  const hookFiles = readdirSync(join(s.root, 'captures')).filter(n => n.startsWith('hook-') && n.endsWith('.json') && !hooksBefore.has(n));
  const hooks = hookFiles.map(n => read(join(s.root, 'captures', n)));
  const hooksValid = hooks.every(h => h.status === 0 && h.lifecycle.session_id === sessionId && h.lifecycle.cwd === s.workspace)
    && ['SessionStart', 'UserPromptSubmit', 'Stop'].every(n => hooks.some(h => h.lifecycle.hook_event_name === n));
  save(join(directory, 'hook-observations.json'), { files: hookFiles, valid: hooksValid, note: 'Upstream output is not delivered-context proof.' });
  const after = trees(s);
  save(join(directory, 'file-changes.json'), { changes: Object.fromEntries(Object.keys(before).map(n => [n, diffTrees(before[n], after[n])])),
    after: Object.fromEntries(Object.entries(after).map(([n, t]) => [n, snapshotManifest(t)])), gitAfter: git(s) });
  if (!hooksValid) errors.push('Missing, failed or misrouted lifecycle capture');
  if (processResult.code !== 0 || processResult.stopped) errors.push('CLI failed or stopped');
  if (!events?.completed || host?.status !== 'captured-host-messages') errors.push('Completed turn or delivered-context capture unproven');
  const result = { name: turn.name, sessionId, directory, process: processResult, host, errors,
    transport: errors.length ? 'unproven' : 'captured', behaviour: 'unreviewed', usage: events?.usage,
    answers: events?.answers, creditEstimate: estimateLunaCredits(events?.usage) };
  save(join(directory, 'result.json'), result);
  assert.equal(errors.length, 0, 'Stopped without retry; inspect ' + directory);
  return result;
}
export async function run(approved = false) {
  assert.equal(approved, true, 'Separate explicit Vik approval required before model execution');
  assert(!existsSync(startPath), 'Already started: no retries or continuation of consumed cases');
  const ready = read(sealPath);
  for (const [p, h] of Object.entries(ready.files)) assert.equal(hash(p), h, 'Sealed preparation changed: ' + p);
  for (const name of caseNames) {
    await inspect(name, { requireTrust: true });
    assert.deepEqual(Object.fromEntries(Object.entries(trees(settings(name))).map(([k, t]) => [k, snapshotManifest(t)])), ready.initial[name]);
  }
  const liveBefore = fingerprint(liveBrain);
  save(startPath, { at: new Date().toISOString(), approval: 'operator supplied --approved-by-vik', sealHash: hash(sealPath) });
  const results = [];
  try {
    for (const turn of ready.turns) {
      results.push(await execute(turn, read(join(base, 'prepared.json')).runtime));
      assert.deepEqual(fingerprint(liveBrain), liveBefore, 'Live Brain drift: stop before further cases');
      console.log(JSON.stringify({ finished: turn.name, transport: results.at(-1).transport, behaviour: 'unreviewed' }));
    }
  } finally {
    save(join(control, 'run-result.json'), { at: new Date().toISOString(), results, liveBrainUnchanged: JSON.stringify(fingerprint(liveBrain)) === JSON.stringify(liveBefore) });
  }
  return { captured: results.length, behaviour: 'Requires primary evidence-backed review; no automatic pass or acceptance change.' };
}
if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const [mode, approval] = process.argv.slice(2);
  (mode === 'seal' ? seal() : mode === 'run' ? run(approval === '--approved-by-vik') : Promise.reject(new Error('Use seal or run --approved-by-vik after approval')))
    .then(r => console.log(JSON.stringify(r))).catch(e => { console.error(e.stack); process.exitCode = 1; });
}
