const MAX_BYTES = 16 * 1024 * 1024;
const MAX_ROWS = 20_000;

function fail(message) { throw new Error(message); }

function object(value) {
  return value !== null && typeof value === 'object' && !Array.isArray(value);
}

function jsonl(text) {
  if (typeof text !== 'string') fail('Evidence must be JSONL text');
  if (Buffer.byteLength(text, 'utf8') > MAX_BYTES) fail('Evidence exceeds 16 MiB limit');
  const lines = text.split('\n');
  if (lines.at(-1) === '') lines.pop();
  if (lines.length > MAX_ROWS) fail('Evidence exceeds 20000 row limit');
  return lines.map((line, index) => {
    let value;
    try { value = JSON.parse(line); }
    catch { fail(`Malformed JSONL at line ${index + 1}`); }
    if (!object(value)) fail(`Malformed event at line ${index + 1}`);
    return { line: index + 1, value };
  });
}

function expectedId(expectedSessionId) {
  if (expectedSessionId !== undefined && (typeof expectedSessionId !== 'string' || !expectedSessionId)) {
    fail('expectedSessionId must be a non-empty string');
  }
}

function hookFragment(text) {
  return text.startsWith('## Anvil Work Context\n') || text.startsWith('## Brain Context\n')
    || (text.startsWith('Warning: truncated output') && text.includes('\n## Brain Context\n'));
}

function selected(payload, fields) {
  const result = {};
  for (const [source, target = source] of fields) {
    if (Object.hasOwn(payload, source)) result[target] = payload[source];
  }
  return result;
}

const SESSION_FIELDS = [
  ['base_instructions', 'baseInstructions'], ['instructions'], ['cli_version', 'cliVersion'],
  ['source'], ['model'], ['model_provider', 'modelProvider'], ['model_version', 'modelVersion'],
];

const TURN_CONDITION_FIELDS = [
  ['model'], ['model_provider'], ['model_version'], ['effort'], ['reasoning_effort'],
  ['token_budget'], ['context_window'], ['max_output_tokens'], ['max_output_chars'],
  ['base_instructions'], ['instructions'], ['developer_instructions'], ['user_instructions'],
  ['approval_policy'], ['sandbox_policy'], ['permission_profile'], ['filesystem'], ['cwd'],
  ['session_id'], ['thread_id'], ['turn_id'],
];

/** Parse a bounded CLI --json event capture without judging any answer text. */
export function parseCaseEvents(text, { expectedSessionId } = {}) {
  expectedId(expectedSessionId);
  const rows = jsonl(text);
  const ids = new Set();
  const items = [];
  const answers = [];
  const errors = [];
  const completed = [];

  for (const { line, value } of rows) {
    if (value.type === 'thread.started' && typeof value.thread_id === 'string' && value.thread_id) {
      ids.add(value.thread_id);
    }
    if (object(value.item)) {
      const observed = { line, event: value.type, item: value.item };
      items.push(observed);
      if (value.item.type === 'agent_message') answers.push(observed);
      if (value.item.type === 'error') errors.push(observed);
    }
    if (value.type === 'turn.completed') completed.push({ line, usage: value.usage });
    if (value.type === 'turn.failed' || value.type === 'error') fail(`CLI reported ${value.type} at line ${line}`);
  }
  if (ids.size !== 1) fail(ids.size ? 'Multiple distinct thread IDs in event capture' : 'Missing CLI session ID');
  const [sessionId] = ids;
  if (expectedSessionId !== undefined && sessionId !== expectedSessionId) fail('Event capture used a different session');
  if (completed.length !== 1) fail('Event capture must contain exactly one turn.completed');

  return { sessionId, completed: true, errors, usage: completed[0].usage, items, answers };
}

/** Extract only actual host-transcript evidence for one already-known session. */
export function extractCaseTranscript(text, { sessionId, workspace, afterLine = 0 } = {}) {
  if (typeof sessionId !== 'string' || !sessionId) fail('sessionId must be a non-empty string');
  if (typeof workspace !== 'string' || !workspace) fail('workspace must be a non-empty string');
  if (!Number.isSafeInteger(afterLine) || afterLine < 0) fail('afterLine must be a non-negative safe integer');

  const rows = jsonl(text);
  if (afterLine > rows.length) fail('afterLine exceeds transcript line count');
  const first = rows[0]?.value;
  if (first?.type !== 'session_meta' || !object(first.payload)) fail('Missing host session metadata');

  let session;
  const turnContexts = [];
  const developerMessages = [];
  for (const { line, value } of rows) {
    if (value.type === 'session_meta') {
      if (!object(value.payload) || value.payload.id !== sessionId) fail('Wrong host session');
      if (value.payload.cwd !== workspace) fail('Wrong host workspace');
      if (!session) session = { line, id: value.payload.id, cwd: value.payload.cwd, ...selected(value.payload, SESSION_FIELDS) };
      continue;
    }
    if (line <= afterLine) continue;
    if (value.type === 'turn_context' && object(value.payload)) {
      turnContexts.push({ line, conditions: selected(value.payload, TURN_CONDITION_FIELDS) });
      continue;
    }
    const message = value.payload;
    if (value.type !== 'response_item' || !object(message) || message.type !== 'message' || message.role !== 'developer'
      || !Array.isArray(message.content)) continue;
    message.content.forEach((part, index) => {
      if (object(part) && part.type === 'input_text' && typeof part.text === 'string') {
        developerMessages.push({ line, part: index, text: part.text });
      }
    });
  }
  const deliveredContext = developerMessages.filter(({ text }) => hookFragment(text));
  return {
    lineCount: rows.length,
    session,
    turnContexts,
    developerMessages,
    deliveredContext,
    status: deliveredContext.length ? 'captured-host-messages' : 'unproven',
  };
}
