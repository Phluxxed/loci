// Bounded preparation/capture route for the six frozen W4 cases. No model judge.
import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { existsSync, mkdirSync, readFileSync, writeFileSync, copyFileSync, realpathSync, symlinkSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { sha, withHost, checkHooks, smokeFilesystem, toml } from './brain-host-smoke.mjs';
const repo = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const keyRoot = '/Users/brummerv/phluxxed/workbench/.scratch/brain-w41-preparation-2026-09-07';
// Persistent isolated siblings of the repos: no answer keys or repo instructions
// become ancestors of an execution workspace, and terminal handoffs survive /tmp cleanup.
export const isolationRoot = '/Users/brummerv/phluxxed/brain-w41-isolated-2026-09-08';
export const executionRoot = join(isolationRoot, 'execution');
const pair = join(isolationRoot, 'paired');
const read = p => JSON.parse(readFileSync(p, 'utf8'));
const save = (p, x) => writeFileSync(p, JSON.stringify(x, null, 2) + '\n', { flag: 'wx', mode: 0o600 });
const caseNames = ['k01-old', 'k01-current', 'k02-old', 'k02-current', 'k03-old', 'k03-current', 'k04-old', 'k04-current', 'c05-current', 'c06-current'];
const hash = p => sha(readFileSync(p));
export const modelRevisionPath = join(keyRoot, 'execution-model-revision-luna-max.json');
export const lunaOverrides = Object.freeze({ model: 'gpt-5.6-luna', model_reasoning_effort: 'max',
  service_tier: 'default', 'features.fast_mode': false, 'features.multi_agent': false, 'features.goals': false });
export function applyExecutionOverrides(settings, overrides) {
  assert.deepEqual(overrides, lunaOverrides, 'Only the approved Luna/max execution override is allowed');
  assert.equal(settings.overrides.model, 'gpt-6-astra', 'Unexpected baseline model');
  assert.equal(settings.overrides.model_reasoning_effort, 'high', 'Unexpected baseline effort');
  return { ...settings, overrides: { ...settings.overrides, ...overrides } };
}
function frozen() {
  const f = read(join(keyRoot, 'freeze.json'));
  for (const [p, h] of Object.entries(f.files)) assert.equal(hash(join(keyRoot, p)), h, 'Frozen input changed: ' + p);
  const original = read(join(keyRoot, 'execution-conditions.json'));
  const revision = read(modelRevisionPath);
  assert.equal(revision.version, 1); assert.equal(revision.profile, 'luna-max');
  assert.equal(revision.sourceFreezeHash, hash(join(keyRoot, 'freeze.json')));
  assert.equal(revision.sourceConditionsHash, hash(join(keyRoot, 'execution-conditions.json')));
  assert.equal(revision.previousSealHash, hash(join(keyRoot, 'launch-ready.json')));
  assert.equal(original.model, 'gpt-6-astra'); assert.equal(original.effort, 'high');
  assert.deepEqual(revision.overrides, lunaOverrides, 'Unapproved execution revision');
  return { freeze: f, modelRevision: revision, modelRevisionHash: hash(modelRevisionPath),
    conditions: { ...original, model: lunaOverrides.model, effort: lunaOverrides.model_reasoning_effort,
      serviceTier: lunaOverrides.service_tier, fastMode: false, multiAgent: false, automaticGoals: false },
    prepared: read(join(pair, 'prepared.json')) };
}
export function executionSettings(root, name) {
  assert.equal(root, executionRoot); assert(caseNames.includes(name));
  return applyExecutionOverrides(read(join(root, name, 'settings.json')), frozen().modelRevision.overrides);
}
export function executionFilesystem(s, siblings, runtime, instructions) {
  const fs = smokeFilesystem(s.workspace, s.brain, runtime, instructions);
  fs[s.brain] = s.name.startsWith('k') ? 'read' : 'write';
  const denied = [keyRoot, join(repo, 'docs/plans/evidence'), join(s.root, 'captures'), join(s.root, 'settings.json'),
    ...siblings.filter(p => p !== s.root), ...['old', 'current'].flatMap(v => [join(pair, v, 'brain'), join(pair, v, 'captures'), join(pair, v, 'anvil/docs')])];
  for (const p of denied) { fs[p] = 'deny'; fs[p + '/**'] = 'deny'; }
  return fs;
}
async function prepare(root) {
  const { freeze, conditions, prepared } = frozen();
  assert(!existsSync(join(root, 'launch.json')), 'Refuse to overwrite launch preparation');
  const base = await withHost(root, {}, async call => ({ hooks: await call('hooks/list', { cwds: [root] }), config: await call('config/read', { cwd: root, includeLayers: false }) }));
  assert.deepEqual(base.hooks.data[0].errors, []);
  assert(!base.hooks.data[0].hooks.some(h => h.isManaged && h.enabled), 'Managed hook needs separate isolation review');
  const disabled = Object.fromEntries(base.hooks.data[0].hooks.map(h => [h.key, { enabled: false }]));
  const hook = join(repo, 'scripts/brain-frozen-case-hook.mjs');
  const hookCommand = [process.execPath, hook].map(p => "'" + p.replaceAll("'", "'\\''") + "'").join(' ');
  const handler = { type: 'command', command: hookCommand, timeout: 30 };
  const siblings = caseNames.map(n => join(root, n));
  const op = read(join(keyRoot, 'operational-cases.json'));
  for (const name of caseNames) {
    const variant = name.endsWith('-old') ? 'old' : 'current';
    const active = join(root, name);
    for (const p of ['workspace', 'brain', 'captures', 'registry', 'anvil-home/agents/codex', 'state', 'loci', 'graph-cache']) mkdirSync(join(active, p), { recursive: true });
    for (const [p, h] of Object.entries(prepared.brainFiles)) {
      const src = join(pair, 'current/brain', p);
      assert.equal(hash(src), h);
      mkdirSync(dirname(join(active, 'brain', p)), { recursive: true });
      copyFileSync(src, join(active, 'brain', p));
    }
    if (name === 'c05-current') {
      const f = op.cases[0].fixture;
      const p = join(active, 'brain', f.page);
      const before = readFileSync(p, 'utf8');
      assert.equal(before.split(f.replace_exactly_once).length - 1, 1);
      writeFileSync(p, before.replace(f.replace_exactly_once, f.with));
      save(join(active, 'captures/fixture.json'), { page: f.page, before: sha(before), after: hash(p), operation: 'one exact frozen paragraph replacement; immutable sources/history retained' });
    }
    if (name === 'c06-current') writeFileSync(join(active, 'workspace/input.csv'), op.cases[1].input_csv, { flag: 'wx' });
    symlinkSync('/Users/brummerv/llm-wiki/.venv', join(active, 'brain/.venv'), 'dir');
    const git = spawnSync('git', ['init', '--quiet', join(active, 'workspace')], { encoding: 'utf8' }); assert.equal(git.status, 0, git.stderr);
    if (!name.startsWith('k')) { const b = spawnSync('git', ['init', '--quiet', join(active, 'brain')], { encoding: 'utf8' }); assert.equal(b.status, 0, b.stderr); }
    const alias = 'anvil-brain-codex-w41-case';
    const env = { ANVIL_HOME: join(active, 'anvil-home'), ANVIL_AGENT_ID: 'codex', ANVIL_STATE_ROOT: join(active, 'state'), ANVIL_BRAIN_CONTEXT: 'on',
      ANVIL_LLM_WIKI_BIN: join(pair, variant, 'compiler.py'), LLM_WIKI_HOME: join(active, 'registry'), LOCI_BASE_DIR: join(active, 'loci'),
      LOCI_STORE_NAMESPACE: 'codex-w41-cases', LLM_WIKI_GRAPH_CACHE_DIR: join(active, 'graph-cache'), PYTHONDONTWRITEBYTECODE: '1' };
    save(join(active, 'anvil-home/agents/codex/config.json'), { schema_version: 1, agent_id: 'codex', brain_root: join(active, 'brain'), wiki_alias: alias });
    save(join(active, 'registry/registry.json'), { version: 1, wikis: { [alias]: { path: join(active, 'brain'), created_by: 'w41-frozen-case-preparation', registered_at: freeze.frozenAt } } });
    const mcp = join(active, 'wiki-mcp.py');
    writeFileSync(mcp, '#!/Users/brummerv/llm-wiki/.venv/bin/python\nimport sys\nsys.path.insert(0, ' + JSON.stringify(join(pair, variant, 'wiki/src')) + ')\nfrom llm_wiki_mcp.mcp_server import main\nmain()\n', { flag: 'wx', mode: 0o700 });
    const sourceRoot = join(pair, variant, 'anvil');
    const s = { name, root: active, brain: join(active, 'brain'), workspace: join(active, 'workspace'), sourceRoot, alias, env, hookCommand, hookHash: hash(hook) };
    const servers = Object.fromEntries(Object.keys(base.config.config.mcp_servers ?? {}).map(k => [k, { enabled: false }]));
    servers.anvil = { enabled: true, command: process.execPath, args: [join(sourceRoot, 'bin/anvil.ts'), 'mcp', 'serve'], env, enabled_tools: ['anvil_continuity_read', 'anvil_continuity_checkpoint_task', 'anvil_brain_usage_log'] };
    servers['llm-wiki'] = { enabled: true, command: mcp, args: [], env, enabled_tools: ['wiki_list', 'wiki_agent_manual', 'wiki_get_page', 'wiki_query', 'wiki_build_maintenance'] };
    s.overrides = { 'hooks.state': disabled, 'hooks.SessionStart': [{ matcher: 'startup|resume|clear|compact', hooks: [handler] }],
      'hooks.UserPromptSubmit': [{ hooks: [handler] }], 'hooks.PreToolUse': [{ matcher: '*', hooks: [handler] }], 'hooks.Stop': [{ hooks: [handler] }],
      mcp_servers: servers, plugins: Object.fromEntries(Object.keys(base.config.config.plugins ?? {}).map(k => [k, { enabled: false }])),
      'apps._default.enabled': false, default_permissions: 'w41_cases', 'permissions.w41_cases': { description: 'One frozen isolated Brain case', filesystem: executionFilesystem(s, siblings, conditions.runtime, Object.keys(conditions.instructionFiles)), network: { enabled: true } },
      approval_policy: 'never', 'memories.use_memories': false, web_search: 'disabled', model: conditions.model, model_reasoning_effort: conditions.effort };
    save(join(active, 'settings.json'), s);
  }
  save(join(root, 'launch.json'), { root, caseNames, hookCommand, hookHash: hash(hook), sourceFreeze: hash(join(keyRoot, 'freeze.json')), state: 'prepared-not-trusted-or-executed' });
  console.log(JSON.stringify({ root, caseSessions: caseNames.length, modelRuns: 0, next: 'inspect normal hook trust and permissions before execution' }));
}
async function inspect(root, requireTrust = false, name = 'c05-current') {
  const { conditions } = frozen();
  const launch = read(join(root, 'launch.json'));
  assert.equal(hash(join(repo, 'scripts/brain-frozen-case-hook.mjs')), launch.hookHash);
  assert.deepEqual(launch.caseNames, caseNames);
  assert.equal(launch.sourceFreeze, hash(join(keyRoot, 'freeze.json')));
  assert(caseNames.includes(name));
  const s = executionSettings(root, name);
  assert.equal(s.root, join(root, name)); assert.equal(s.workspace, join(s.root, 'workspace'));
  assert.equal(s.brain, join(s.root, 'brain')); assert.equal(s.hookCommand, launch.hookCommand);
  assert.equal(s.hookHash, launch.observerRevision?.previousHash ?? launch.hookHash, 'Unexpected observer preparation history');
  assert.equal(s.sourceRoot, join(pair, name.endsWith('-old') ? 'old' : 'current', 'anvil'));
  const expectedFilesystem = executionFilesystem(s, caseNames.map(n => join(root, n)), conditions.runtime, Object.keys(conditions.instructionFiles));
  assert.deepEqual(s.overrides['permissions.w41_cases'].filesystem, expectedFilesystem);
  const result = await withHost(s.workspace, s.overrides, async call => {
    const hooks = await call('hooks/list', { cwds: [s.workspace] });
    const config = await call('config/read', { cwd: s.workspace, includeLayers: false });
    const enabled = checkHooks(hooks.data, s.hookCommand, requireTrust);
    assert.deepEqual(enabled.map(h => h.key).sort(), ['pre_tool_use', 'session_start', 'stop', 'user_prompt_submit'].map(e => '/<session-flags>/config.toml:' + e + ':0:0').sort());
    assert.equal(config.config.model, conditions.model); assert.equal(config.config.model_reasoning_effort, conditions.effort);
    assert.equal(config.config.service_tier, conditions.serviceTier);
    assert.equal(config.config.features.fast_mode, false);
    assert.equal(config.config.features.multi_agent, false);
    assert.equal(config.config.features.goals, false);
    const fs = config.config.permissions.w41_cases.filesystem;
    const { glob_scan_max_depth: scanDepth, ...pathRules } = fs;
    assert.equal(scanDepth, null, 'Do not alter the native glob scan depth');
    assert.deepEqual(pathRules, expectedFilesystem);
    assert.equal(config.config.default_permissions, 'w41_cases');
    assert.equal(config.config.approval_policy, 'never');
    assert.deepEqual(Object.entries(config.config.mcp_servers).filter(([, v]) => v.enabled !== false).map(([k]) => k).sort(), ['anvil', 'llm-wiki']);
    for (const name of ['anvil', 'llm-wiki']) for (const [k, v] of Object.entries(s.env)) assert.equal(config.config.mcp_servers[name].env[k], v);
    return { name, hooks: enabled.map(h => ({ key: h.key, event: h.eventName, command: h.command, trust: h.trustStatus })), model: config.config.model, effort: config.config.model_reasoning_effort,
      serviceTier: config.config.service_tier, fastMode: config.config.features.fast_mode,
      multiAgent: config.config.features.multi_agent, automaticGoals: config.config.features.goals,
      keyRootDenied: fs[keyRoot] === 'deny', warnings: hooks.data[0].warnings };
  });
  return result;
}
export function deniedOpenProbe(targets, control) {
  // Open/close only: no answer-key content or directory entries are read.
  return ['-e', `const fs=require('node:fs');const x=JSON.parse(process.argv[1]);
    const fd=fs.openSync(x.control,'r');fs.closeSync(fd);
    const results=x.targets.map(path=>{try{const f=fs.openSync(path,'r');fs.closeSync(f);return {path,denied:false};}catch(e){return {path,denied:['EACCES','EPERM'].includes(e.code),code:e.code};}});
    console.log(JSON.stringify({controlReadable:true,results}));process.exitCode=results.every(r=>r.denied)?0:1;`, JSON.stringify({ targets, control })];
}
async function preflight(root) {
  const { conditions, prepared } = frozen();
  assert.equal(hash(conditions.runtime), conditions.runtimeSha256, 'Frozen Codex runtime changed');
  for (const [p, h] of Object.entries(conditions.instructionFiles)) assert.equal(hash(p), h, 'Frozen instructions changed: ' + p);
  assert.equal(process.version, conditions.dependencies.node);
  assert.equal(hash(conditions.dependencies.lociLauncher), conditions.dependencies.lociLauncherSha256);
  for (const [p, h] of Object.entries(conditions.dependencies.lociFiles)) assert.equal(hash(join(conditions.dependencies.lociRoot, p)), h, 'Frozen Loci source changed: ' + p);
  for (const type of ['anvil', 'wiki']) for (const [p, h] of Object.entries(prepared.variants.current[type + 'Files'])) assert.equal(hash(join(pair, 'current', type, p)), h, 'Frozen current source changed: ' + p);
  const profiles = [];
  for (const name of caseNames) profiles.push(await inspect(root, true, name));
  return { root, profiles, frozenInputsVerified: true, modelRuns: 0 };
}
async function probe(root) {
  const verified = await preflight(root);
  const { conditions } = frozen();
  const results = [];
  // Knowledge and operational permissions differ only in their Brain write rule.
  for (const name of ['k01-old', 'c05-current']) {
    const s = read(join(root, name, 'settings.json'));
    const targets = [keyRoot, join(s.root, 'captures'), join(s.root, 'settings.json'), join(root, 'k02-current')];
    for (const p of targets) assert(existsSync(p), 'Probe target must exist: ' + p);
    const flags = Object.entries(s.overrides).flatMap(([k, v]) => ['-c', k + '=' + toml(v)]);
    const r = spawnSync(conditions.runtime, ['sandbox', ...flags, '-P', 'w41_cases', '-C', s.workspace, '--', process.execPath, ...deniedOpenProbe(targets, join(s.brain, 'self-model/i-am-rowan.md'))], { cwd: s.workspace, encoding: 'utf8', timeout: 10000, maxBuffer: 65536 });
    let observed = null; try { observed = JSON.parse(r.stdout); } catch {}
    const passed = r.status === 0 && observed?.controlReadable === true && observed.results?.length === targets.length && observed.results.every((x, i) => x.path === targets[i] && x.denied === true);
    results.push({ name, passed, status: r.status, signal: r.signal, observed, stderr: r.stderr, error: r.error?.message, settingsHash: hash(join(s.root, 'settings.json')) });
    if (!passed) break; // No repeated nested-sandbox failures or acceptance fallback.
  }
  const proof = { ...verified, at: new Date().toISOString(), scope: 'No-model real Codex sandbox denied-open probe; no lifecycle or acceptance case', results, passed: results.length === 2 && results.every(r => r.passed) };
  save(join(root, 'permission-probe-' + Date.now() + '.json'), proof);
  if (proof.passed) save(join(root, 'permission-proof.json'), { ...proof, settingsHashes: Object.fromEntries(caseNames.map(n => [n, hash(join(root, n, 'settings.json'))])) });
  console.log(JSON.stringify({ root, passed: proof.passed, results, modelRuns: 0 }, null, 2));
  if (!proof.passed) process.exitCode = 1;
}
export { frozen, preflight, caseNames, keyRoot, pair };
async function main() {
  const [mode, supplied] = process.argv.slice(2);
  const root = realpathSync(supplied);
  assert.equal(root, executionRoot, 'Use the restored persistent W4.1 execution root');
  if (mode === 'prepare') await prepare(root);
  else if (mode === 'inspect') console.log(JSON.stringify(await inspect(root), null, 2));
  else if (mode === 'preflight') {
    const result = await preflight(root);
    const evidence = join(root, 'preflight-' + Date.now() + '.json');
    save(evidence, result);
    console.log(JSON.stringify({ root, evidence, profiles: result.profiles.length, frozenInputsVerified: true, modelRuns: 0 }, null, 2));
  }
  else if (mode === 'probe') await probe(root);
  else if (mode === 'seal' || mode === 'run') {
    const runner = await import('./brain-case-runner.mjs');
    console.log(JSON.stringify(await (mode === 'seal' ? runner.sealPreparation(root) : runner.runFrozenCases(root)), null, 2));
  }
  else throw new Error('Use prepare, inspect, preflight, probe, seal or run. Run consumes the frozen acceptance cases.');
}
if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  main().catch(error => { console.error(error.stack ?? error.message); process.exitCode = 1; });
}
