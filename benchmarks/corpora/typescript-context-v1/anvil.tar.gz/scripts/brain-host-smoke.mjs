// One disposable W4.1 host-path smoke. Not the acceptance-case runner.
import assert from 'node:assert/strict';
import { spawn, spawnSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { createWriteStream, existsSync, lstatSync, mkdirSync, readFileSync, realpathSync, statSync, writeFileSync, copyFileSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createInterface } from 'node:readline';
import { finished } from 'node:stream/promises';

const sourceRoot = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const liveBrain = '/Users/brummerv/.anvil-brain/codex';
const node = process.execPath;
const wikiBin = '/Users/brummerv/llm-wiki/.venv/bin/llm-wiki';
const wikiMcp = '/Users/brummerv/llm-wiki/.venv/bin/llm-wiki-mcp';
export const sha = value => createHash('sha256').update(value).digest('hex');
export const toml = value => {
  if (Array.isArray(value)) return '[' + value.map(toml).join(',') + ']';
  if (value !== null && typeof value === 'object') return '{' + Object.entries(value).map(([k, v]) => JSON.stringify(k) + '=' + toml(v)).join(',') + '}';
  assert(['string', 'boolean', 'number'].includes(typeof value));
  return JSON.stringify(value);
};
const flags = config => Object.entries(config).flatMap(([key, value]) => ['-c', key + '=' + toml(value)]);
const save = (path, value) => writeFileSync(path, JSON.stringify(value, null, 2) + '\n', { flag: 'wx', mode: 0o600 });

function codexRuntime() {
  const located = spawnSync('/usr/bin/which', ['codex'], { encoding: 'utf8' });
  assert.equal(located.status, 0, 'Cannot locate the Codex runtime');
  return realpathSync(located.stdout.trim());
}

// The reviewed policy permits the resolved binary, not its launcher symlink chain.
export const spawnCodex = (args, options) => spawn(codexRuntime(), args, options);

export async function withHost(cwd, overrides, use) {
  const child = spawnCodex(['app-server', '--stdio', ...flags(overrides)], { cwd, stdio: ['pipe', 'pipe', 'pipe'] });
  const pending = new Map();
  let sequence = 0;
  let stderr = '';
  child.stderr.on('data', chunk => { stderr = (stderr + chunk).slice(-8000); });
  const lines = createInterface({ input: child.stdout });
  const fail = error => { for (const p of pending.values()) p.reject(error); pending.clear(); };
  child.on('error', fail);
  child.on('exit', code => fail(new Error('Host metadata process exited: ' + code + ' ' + stderr)));
  lines.on('line', line => {
    try {
      const message = JSON.parse(line);
      const waiter = pending.get(message.id);
      if (!waiter) return;
      pending.delete(message.id);
      message.error ? waiter.reject(new Error(JSON.stringify(message.error))) : waiter.resolve(message.result);
    } catch (error) { fail(error); }
  });
  const call = (method, params) => new Promise((resolveResult, reject) => {
    const id = ++sequence;
    pending.set(id, { resolve: resolveResult, reject });
    child.stdin.write(JSON.stringify({ id, method, params }) + '\n');
  });
  const timer = setTimeout(() => { fail(new Error('Host metadata timeout')); child.kill('SIGTERM'); }, 20000);
  try {
    await call('initialize', { clientInfo: { name: 'brain-w41-smoke', version: '1' }, capabilities: { experimentalApi: true } });
    child.stdin.write(JSON.stringify({ method: 'initialized' }) + '\n');
    return await use(call);
  } finally { clearTimeout(timer); child.stdin.end(); child.kill('SIGTERM'); }
}

function filesAt(root) {
  const result = spawnSync('git', ['ls-files', '-z', '--cached', '--others', '--exclude-standard'], { cwd: root, encoding: 'utf8' });
  assert.equal(result.status, 0, result.stderr);
  return [...new Set(result.stdout.split('\0').filter(Boolean))].sort().filter(p => existsSync(join(root, p)) && p !== 'wiki.html');
}
export function fingerprint(root) {
  return Object.fromEntries(filesAt(root).map(p => {
    assert(lstatSync(join(root, p)).isFile(), 'No symlinks/special files in Brain capture: ' + p);
    return [p, sha(readFileSync(join(root, p)))];
  }));
}
export function checkedRoot(value) {
  const root = realpathSync(value);
  assert(/^\/private\/tmp\/brain-w41-smoke\.[A-Za-z0-9]+$/.test(root), 'Use the dedicated mktemp smoke root');
  return root;
}
export function settings(root) { return JSON.parse(readFileSync(join(checkedRoot(root), 'settings.json'), 'utf8')); }

export function smokeFilesystem(workspace, brain, runtimePath, instructionPaths) {
  const denied = ['/Users/brummerv/.claude', '/Users/brummerv/Downloads', '/Users/brummerv/claude-otel', '/Users/brummerv/improvements', '/Users/brummerv/work', '/Users/brummerv/.anvil', '/Users/brummerv/.anvil-brain'];
  const filesystem = { ':minimal': 'read', '/': 'read', [workspace]: 'write', [brain]: 'write' };
  for (const path of denied) { filesystem[path] = 'deny'; filesystem[path + '/**'] = 'deny'; }
  // Keep credentials and session stores denied, with exact read-only exceptions.
  // A descendant deny glob would also match the executable and defeat reopening it.
  filesystem['/Users/brummerv/.codex'] = 'deny';
  for (const path of [runtimePath, ...instructionPaths]) filesystem[path] = 'read';
  return filesystem;
}

function installedFilesystem(workspace, brain) {
  const runtimePath = codexRuntime();
  const instructionPaths = ['/Users/brummerv/.codex/AGENTS.md', '/Users/brummerv/.codex/AGENTS.override.md'].filter(existsSync);
  return smokeFilesystem(workspace, brain, runtimePath, instructionPaths);
}

export function checkHooks(entries, command, requireTrust = true, contextLimits = {}) {
  assert.equal(entries.length, 1);
  assert.deepEqual(entries[0].errors, []);
  const enabled = entries[0].hooks.filter(h => h.enabled);
  assert.equal(enabled.length, 4, 'Unexpected enabled hooks; refuse model execution');
  assert.deepEqual(enabled.map(h => h.eventName).sort(), ['preToolUse', 'sessionStart', 'stop', 'userPromptSubmit']);
  for (const hook of enabled) {
    assert.equal(hook.command, command, 'Live or unexpected hook');
    assert.equal(hook.source, 'sessionFlags');
    assert.equal(hook.additionalContextLimit, contextLimits[hook.eventName] ?? null,
      'Unexpected host context limit: ' + hook.eventName);
    if (requireTrust) assert.equal(hook.trustStatus, 'trusted', 'Review this exact test hook through normal Codex trust: ' + hook.key);
  }
  return enabled;
}

async function inspect(s, requireTrust) {
  return withHost(s.workspace, s.overrides, async call => {
    const hooks = await call('hooks/list', { cwds: [s.workspace] });
    const config = await call('config/read', { cwd: s.workspace, includeLayers: false });
    const enabled = checkHooks(hooks.data, s.hookCommand, requireTrust);
    const servers = config.config.mcp_servers;
    assert.deepEqual(Object.entries(servers).filter(([, v]) => v.enabled !== false).map(([k]) => k).sort(), ['anvil', 'llm-wiki']);
    for (const name of ['anvil', 'llm-wiki']) {
      for (const [key, value] of Object.entries(s.env)) assert.equal(servers[name].env[key], value, 'Wrong MCP routing: ' + name + ':' + key);
    }
    assert.equal(config.config.default_permissions, 'w41_smoke');
    const { glob_scan_max_depth: globDepth, ...filesystem } = config.config.permissions.w41_smoke.filesystem;
    assert(globDepth == null, 'Unexpected glob expansion setting');
    assert.deepEqual(filesystem, installedFilesystem(s.workspace, s.brain), 'Smoke filesystem differs from the reviewed runtime-aware policy');
    return { hooks: enabled, warnings: hooks.data[0].warnings, model: config.config.model, effort: config.config.model_reasoning_effort, permissions: config.config.permissions.w41_smoke };
  });
}

async function prepare(root) {
  root = checkedRoot(root);
  assert(!existsSync(join(root, 'settings.json')), 'Preparation must not overwrite a run');
  const workspace = join(root, 'workspace');
  const brain = join(root, 'brain');
  for (const dir of [workspace, brain, join(root, 'captures'), join(root, 'registry'), join(root, 'anvil-home', 'agents', 'codex')]) mkdirSync(dir, { recursive: true });
  const before = fingerprint(liveBrain);
  for (const p of Object.keys(before)) { mkdirSync(dirname(join(brain, p)), { recursive: true }); copyFileSync(join(liveBrain, p), join(brain, p)); }
  assert.deepEqual(fingerprint(liveBrain), before, 'Brain changed during copy; stop and choose a stable snapshot');
  const init = spawnSync('git', ['init', '--quiet', workspace], { encoding: 'utf8' });
  assert.equal(init.status, 0, init.stderr);
  const alias = 'anvil-brain-codex-w41-smoke';
  const env = {
    ANVIL_HOME: join(root, 'anvil-home'), ANVIL_AGENT_ID: 'codex', ANVIL_STATE_ROOT: join(root, 'state'), ANVIL_BRAIN_CONTEXT: 'on',
    ANVIL_LLM_WIKI_BIN: wikiBin, LLM_WIKI_HOME: join(root, 'registry'), LOCI_BASE_DIR: join(root, 'loci'),
    LOCI_STORE_NAMESPACE: 'codex-w41-smoke', LLM_WIKI_GRAPH_CACHE_DIR: join(root, 'graph-cache'),
  };
  save(join(env.ANVIL_HOME, 'agents', 'codex', 'config.json'), { schema_version: 1, agent_id: 'codex', brain_root: brain, wiki_alias: alias });
  save(join(env.LLM_WIKI_HOME, 'registry.json'), { version: 1, wikis: { [alias]: { path: brain, created_by: 'w41-isolated-smoke', registered_at: new Date().toISOString() } } });
  const host = await withHost(workspace, {}, async call => ({
    hooks: await call('hooks/list', { cwds: [workspace] }),
    config: await call('config/read', { cwd: workspace, includeLayers: false }),
  }));
  const originalHooks = host.hooks.data[0];
  assert.deepEqual(originalHooks.errors, []);
  assert(!originalHooks.hooks.some(h => h.isManaged && h.enabled), 'Managed hook needs explicit isolation review');
  const disabled = Object.fromEntries(originalHooks.hooks.map(h => [h.key, { enabled: false }]));
  const wrapper = join(sourceRoot, 'scripts', 'brain-host-smoke-hook.mjs');
  const hookCommand = [node, wrapper, root].map(x => "'" + x.replaceAll("'", "'\\''") + "'").join(' ');
  const handler = { type: 'command', command: hookCommand, timeout: 30 };
  const servers = Object.fromEntries(Object.keys(host.config.config.mcp_servers ?? {}).map(k => [k, { enabled: false }]));
  servers.anvil = { enabled: true, command: join(sourceRoot, 'bin/anvil.ts'), args: ['mcp', 'serve'], env,
    enabled_tools: ['anvil_continuity_read', 'anvil_continuity_checkpoint_task', 'anvil_brain_usage_log'] };
  servers['llm-wiki'] = { enabled: true, command: wikiMcp, args: [], env,
    enabled_tools: ['wiki_agent_manual', 'wiki_get_page', 'wiki_list'] };
  const filesystem = installedFilesystem(workspace, brain);
  const overrides = {
    'hooks.state': disabled,
    'hooks.SessionStart': [{ matcher: 'startup|resume|clear|compact', hooks: [handler] }],
    'hooks.UserPromptSubmit': [{ hooks: [handler] }],
    'hooks.PreToolUse': [{ matcher: '*', hooks: [handler] }],
    'hooks.Stop': [{ hooks: [handler] }],
    mcp_servers: servers,
    plugins: Object.fromEntries(Object.keys(host.config.config.plugins ?? {}).map(k => [k, { enabled: false }])),
    'apps._default.enabled': false,
    default_permissions: 'w41_smoke',
    'permissions.w41_smoke': { description: 'One isolated Brain host smoke', filesystem, network: { enabled: true } },
    approval_policy: 'never',
    'memories.use_memories': false,
    web_search: 'disabled',
  };
  const s = { version: 1, root, workspace, brain, alias, env, overrides, hookCommand, sourceRoot, wrapperHash: sha(readFileSync(wrapper)), brainBefore: before };
  save(join(root, 'settings.json'), s);
  save(join(root, 'preflight.json'), await inspect(s, false));
  console.log(JSON.stringify({ root, prepared: true, next: 'Review exact hooks in preflight.json, then use normal host trust before run.' }));
}

export function deliveredContext(transcript, id, workspace) {
  const rows = transcript.trimEnd().split('\n').map(JSON.parse);
  assert.equal(rows[0]?.type, 'session_meta', 'Missing host session metadata');
  assert.equal(rows[0].payload.id, id, 'Wrong host session');
  assert.equal(rows[0].payload.cwd, workspace, 'Wrong host workspace');
  return rows.flatMap((row, index) => {
    const message = row.payload;
    if (row.type !== 'response_item' || message?.type !== 'message' || message.role !== 'developer') return [];
    return message.content.flatMap((content, part) => {
      const text = content.text;
      if (content.type !== 'input_text' || typeof text !== 'string') return [];
      const hookText = text.startsWith('## Anvil Work Context\n') || text.startsWith('## Brain Context\n')
        || (text.startsWith('Warning: truncated output') && text.includes('\n## Brain Context\n'));
      return hookText ? [{ line: index + 1, part, text }] : [];
    });
  });
}

export async function capture(s, id, label) {
  return withHost(s.workspace, s.overrides, async call => {
    const metadata = await call('thread/read', { threadId: id, includeTurns: false });
    assert.equal(metadata.thread.cwd, s.workspace);
    const items = [];
    let cursor;
    do {
      const page = await call('thread/items/list', { threadId: id, limit: 100, ...(cursor ? { cursor } : {}) });
      assert(Array.isArray(page.data)); items.push(...page.data); cursor = page.nextCursor;
      assert(items.length <= 500, 'Smoke capture exceeds bounded item limit');
    } while (cursor);
    save(join(s.root, 'captures', label + '-host-items.json'), { metadata: metadata.thread, items });
    // The item API omits injected hook messages in this CLI. Keep only the actual
    // Brain-bearing developer fragments from this exact session's host transcript.
    const source = metadata.thread.path;
    assert(typeof source === 'string' && statSync(source).size <= 8 * 1024 * 1024, 'Missing or oversized host transcript');
    const messages = deliveredContext(readFileSync(source, 'utf8'), id, s.workspace);
    save(join(s.root, 'captures', label + '-delivered-context.json'), { source, sessionId: id, messages,
      status: messages.length ? 'captured-host-messages' : 'unproven' });
    return { itemCount: items.length, hookPromptCount: items.filter(x => (x.item ?? x).type === 'hookPrompt').length,
      deliveredContextCount: messages.length };
  });
}

async function cli(s, label, id) {
  const path = join(s.root, 'captures', label + '-events.jsonl');
  assert(!existsSync(path), 'Refuse to overwrite captured run');
  const prompt = id
    ? 'Resume the transport smoke. Append exactly resumption-confirmed on a new line in smoke-action.txt without replacing its prior contents. Report what action this session performed before resumption. Do not launch agents/models, inspect unrelated paths, or modify Brain.'
    : `This is an isolated transport smoke, not a Brain evaluation or maintenance task. Read self-model/i-am-rowan.md using wiki_get_page from the registered alias ${s.alias}. Then use apply_patch to create smoke-action.txt containing the name you use here from supplied context and the page heading. Do not read unrelated paths, launch agents/models, or change Brain. Report the performed action briefly.`;
  save(join(s.root, 'captures', label + '-prompt.json'), { prompt });
  const args = ['exec', ...flags(s.overrides), '--json', '-C', s.workspace,
    ...(id ? ['resume', id] : []), prompt];
  const child = spawnCodex(args, { cwd: s.workspace, stdio: ['ignore', 'pipe', 'pipe'] });
  const out = createWriteStream(path, { flags: 'wx', mode: 0o600 });
  const err = createWriteStream(join(s.root, 'captures', label + '-stderr.txt'), { flags: 'wx', mode: 0o600 });
  child.stdout.pipe(out); child.stderr.pipe(err);
  const timeout = setTimeout(() => child.kill('SIGTERM'), 180000);
  const code = await new Promise((resolveExit, reject) => { child.on('error', reject); child.on('exit', resolveExit); });
  clearTimeout(timeout);
  await Promise.all([finished(out), finished(err)]);
  if (code !== 0) {
    const stderrPath = join(s.root, 'captures', label + '-stderr.txt');
    throw new Error(`CLI smoke failed (exit ${code}). Captured stderr: ${stderrPath}\n${readFileSync(stderrPath, 'utf8').slice(-4000)}`);
  }
  const events = readFileSync(path, 'utf8').trim().split('\n').map(JSON.parse);
  const thread = events.find(e => e.type === 'thread.started')?.thread_id;
  assert(typeof thread === 'string', 'Missing actual CLI session ID');
  if (id) assert.equal(thread, id, 'Resume used a different session');
  assert(events.some(e => e.type === 'turn.completed'), 'No completed turn');
  assert(!events.some(e => e.type === 'turn.failed' || e.type === 'error'), 'CLI reported an error');
  return { id: thread, capture: await capture(s, thread, label) };
}

async function run(root) {
  const s = settings(root);
  assert.equal(sha(readFileSync(join(sourceRoot, 'scripts/brain-host-smoke-hook.mjs'))), s.wrapperHash, 'Wrapper changed since preparation');
  await inspect(s, true); // Fail closed before any lifecycle/model session.
  const liveBefore = fingerprint(liveBrain);
  save(join(s.root, 'run-start.json'), { at: new Date().toISOString(), cli: spawnSync(codexRuntime(), ['--version'], { encoding: 'utf8' }).stdout.trim(),
    liveBrainBefore: liveBefore, frozenCopyPreparedEarlier: true });
  const fresh = await cli(s, 'fresh');
  save(join(s.root, 'fresh-result.json'), fresh);
  assert(existsSync(join(s.workspace, 'smoke-action.txt')), 'Missing actual artifact');
  const freshText = readFileSync(join(s.workspace, 'smoke-action.txt'), 'utf8');
  const resumed = await cli(s, 'resumed', fresh.id);
  const resumedText = readFileSync(join(s.workspace, 'smoke-action.txt'), 'utf8');
  assert(resumedText.startsWith(freshText) && resumedText.includes('resumption-confirmed'), 'Resume did not preserve and append');
  assert.deepEqual(fingerprint(liveBrain), liveBefore, 'Protected live Brain changed during smoke; do not claim isolation');
  save(join(s.root, 'smoke-result.json'), { fresh, resumed, freshText, resumedText, liveBrainUnchanged: true,
    verdict: 'requires-main-capture-review', scope: 'Transport only; not W4.1 completion or Brain acceptance.' });
  console.log(JSON.stringify({ root: s.root, session: fresh.id, result: 'Captured; main must review host context fidelity.' }));
}

export function sandboxDiagnosticCommands(launcher, runtime, instructionPath) {
  return [
    { name: 'system-executable', command: ['/usr/bin/true'] },
    { name: 'resolved-codex-executable', command: [runtime, '--version'] },
    { name: 'codex-launcher-symlink', command: [launcher, '--version'] },
    { name: 'global-instructions-readable', command: [node, '-e', "require('node:fs').readFileSync(process.argv[1]);", instructionPath] },
  ];
}

async function diagnose(root) {
  const s = settings(root);
  await inspect(s, false);
  const located = spawnSync('/usr/bin/which', ['codex'], { encoding: 'utf8' });
  assert.equal(located.status, 0, 'Cannot locate Codex');
  const launcher = located.stdout.trim();
  const runtime = realpathSync(launcher);
  const results = sandboxDiagnosticCommands(launcher, runtime, '/Users/brummerv/.codex/AGENTS.md').map(({ name, command }) => {
    // Same prepared permission profile; no model, lifecycle call, or policy relaxation.
    const result = spawnSync(launcher, ['sandbox', ...flags(s.overrides), '-P', 'w41_smoke', '-C', s.workspace, '--', ...command],
      { cwd: s.workspace, encoding: 'utf8', timeout: 10000, maxBuffer: 65536 });
    return { name, command, status: result.status, signal: result.signal,
      stdout: result.stdout?.trim(), stderr: result.stderr?.trim(), ...(result.error ? { error: result.error.message } : {}) };
  });
  console.log(JSON.stringify({ scope: 'No-model executable-access diagnostic; smoke captures unchanged', results }, null, 2));
  if (results.some(result => result.status !== 0)) process.exitCode = 1;
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const [mode, root] = process.argv.slice(2);
  if (mode === 'prepare') await prepare(root);
  else if (mode === 'inspect') console.log(JSON.stringify(await inspect(settings(root), false), null, 2));
  else if (mode === 'run') await run(root);
  else if (mode === 'diagnose') await diagnose(root);
  else throw new Error('Usage: brain-host-smoke.mjs prepare|inspect|run|diagnose <dedicated-mktemp-root>');
}
