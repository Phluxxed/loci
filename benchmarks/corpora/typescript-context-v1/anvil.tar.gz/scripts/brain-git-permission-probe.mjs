// Exercise Git in a disposable sibling of the case environment, never its Brain.
import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { mkdtempSync, mkdirSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { toml } from './brain-host-smoke.mjs';

export function gitProbeOverrides(settings, paths, allowGit) {
  const overrides = structuredClone(settings.overrides);
  const rules = overrides['permissions.w4_followup'].filesystem;
  assert.equal(rules[settings.brain], 'write');
  assert.equal(rules[join(settings.brain, '.git')], 'write');
  delete rules[settings.workspace];
  delete rules[settings.brain];
  delete rules[join(settings.brain, '.git')];
  rules[paths.workspace] = 'write';
  rules[paths.brain] = 'write';
  if (allowGit) rules[join(paths.brain, '.git')] = 'write';
  return overrides;
}

const program = `
import assert from 'node:assert/strict';
import { accessSync, constants, openSync, closeSync, writeFileSync, readFileSync } from 'node:fs';
import { spawnSync } from 'node:child_process';
import { join } from 'node:path';
const { brain, workspace, allowGit } = JSON.parse(process.argv[1]);
let gitWritable = false;
try { accessSync(join(brain, '.git'), constants.W_OK); gitWritable = true; } catch {}
if (!allowGit) {
  assert.equal(gitWritable, false, 'Baseline must demonstrate the former Git protection');
  console.log(JSON.stringify({ gitWritable }));
} else {
  assert.equal(gitWritable, true, 'Explicit isolated Git grant is not effective');
  const protectedPaths = [join(workspace, '.git/index'), join(brain, '.codex/protected'), join(brain, '.agents/protected')];
  const protectedDenied = protectedPaths.map(path => {
    const before = readFileSync(path);
    let denied = false, code = null;
    try { closeSync(openSync(path, 'r+')); } catch (error) { code = error.code; denied = ['EACCES', 'EPERM'].includes(code); }
    assert(denied, 'Unexpected write access to protected path: ' + path);
    assert.deepEqual(readFileSync(path), before);
    return { path, denied, code };
  });
  const env = { ...process.env, GIT_AUTHOR_NAME: 'Brain Sandbox Probe', GIT_AUTHOR_EMAIL: 'sandbox-probe@example.invalid',
    GIT_COMMITTER_NAME: 'Brain Sandbox Probe', GIT_COMMITTER_EMAIL: 'sandbox-probe@example.invalid' };
  const git = (...args) => {
    const result = spawnSync('git', ['-C', brain, '-c', 'core.hooksPath=/dev/null', '-c', 'commit.gpgsign=false', ...args], { encoding: 'utf8', env });
    assert.equal(result.status, 0, result.stderr);
    return result.stdout.trim();
  };
  writeFileSync(join(brain, 'commit-proof.txt'), 'isolated ordinary Git commit proof\\n', { flag: 'wx' });
  git('add', '--', 'commit-proof.txt');
  git('commit', '--quiet', '-m', 'Disposable Git permission proof');
  const commit = git('rev-parse', 'HEAD');
  assert.match(commit, /^[a-f0-9]{40}$/);
  assert.equal(git('show', 'HEAD:commit-proof.txt'), 'isolated ordinary Git commit proof');
  assert.equal(git('ls-files'), 'commit-proof.txt');
  assert.equal(git('remote'), '');
  assert.equal(git('status', '--porcelain'), '');
  console.log(JSON.stringify({ gitWritable, commit, clean: true, protectedDenied }));
}
`;

export function checkGitProbe(result, allowGit) {
  let observed = null, error = result.error?.message ?? null;
  try {
    assert.equal(result.status, 0, result.stderr || 'Sandbox did not complete');
    assert(!result.signal && !result.error);
    observed = JSON.parse(result.stdout);
    assert.equal(observed.gitWritable, allowGit);
    if (allowGit) {
      assert.match(observed.commit, /^[a-f0-9]{40}$/);
      assert.equal(observed.clean, true);
      assert.equal(observed.protectedDenied.length, 3);
      assert(observed.protectedDenied.every(r => r.denied && ['EACCES', 'EPERM'].includes(r.code)));
    }
  } catch (cause) { error = cause.message; }
  return { passed: error === null, status: result.status, signal: result.signal, observed, stderr: result.stderr, error };
}

export function gitCommitPreflight(settings, runtime, launch = spawnSync) {
  const directory = mkdtempSync(join(tmpdir(), 'brain-git-permission-'));
  const paths = { brain: join(directory, 'brain'), workspace: join(directory, 'workspace') };
  for (const path of Object.values(paths)) {
    mkdirSync(path);
    const result = spawnSync('git', ['init', '--quiet', path], { encoding: 'utf8' });
    assert.equal(result.status, 0, result.stderr);
  }
  // Fixtures are private to this probe. They are never copied to the model case.
  const emptyIndex = spawnSync('git', ['-C', paths.workspace, 'read-tree', '--empty'], { encoding: 'utf8' });
  assert.equal(emptyIndex.status, 0, emptyIndex.stderr);
  for (const folder of ['.codex', '.agents']) {
    mkdirSync(join(paths.brain, folder));
    writeFileSync(join(paths.brain, folder, 'protected'), 'protected fixture\n');
  }
  writeFileSync(join(paths.brain, '.git/info/exclude'), '.codex/\n.agents/\n');
  const execute = allowGit => {
    const overrides = gitProbeOverrides(settings, paths, allowGit);
    const flags = Object.entries(overrides).flatMap(([key, value]) => ['-c', key + '=' + toml(value)]);
    return checkGitProbe(launch(runtime, ['sandbox', ...flags, '-P', 'w4_followup', '-C', paths.workspace, '--',
      process.execPath, '--input-type=module', '-e', program, JSON.stringify({ ...paths, allowGit })], {
      cwd: paths.workspace, encoding: 'utf8', timeout: 15000, maxBuffer: 65536,
    }), allowGit);
  };
  const baseline = execute(false);
  const candidate = baseline.passed ? execute(true) : null;
  return { passed: baseline.passed && candidate?.passed === true, modelRuns: 0, directory, baseline, candidate,
    boundary: 'Disposable path-equivalent sandbox proof: only Brain Git metadata is newly writable; workspace Git and Brain agent/config directories remain protected. No model case or live Brain changed.' };
}
