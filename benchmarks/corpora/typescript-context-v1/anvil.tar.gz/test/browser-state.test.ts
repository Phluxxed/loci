import assert from "node:assert/strict";
import { mkdtemp, mkdir, readFile, rm, stat, symlink, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { test } from "node:test";

import {
  BROWSERLESS_BASE_IMAGE,
  BrowserConfigurationError,
  ensureBrowserState,
  readBrowserState,
  removeBrowserState,
} from "../src/browser/index.ts";

test("readBrowserState reports missing state without creating directories", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-browser-state-missing-"));
  try {
    const anvilHome = join(temp, ".anvil");
    const state = await readBrowserState(anvilHome);
    assert.deepEqual(state, { kind: "missing" });
    await assert.rejects(stat(anvilHome));
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("ensureBrowserState creates user-only config and secrets with stable local defaults", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-browser-state-create-"));
  try {
    const anvilHome = join(temp, ".anvil");
    const tokens = ["a".repeat(64), "b".repeat(64)];
    const created = await ensureBrowserState({ anvilHome, randomToken: () => tokens.shift()! });

    assert.equal(created.config.base_image, BROWSERLESS_BASE_IMAGE);
    assert.deepEqual(created.config.local, { host_port: 48131 });
    assert.deepEqual(created.config.corporate, { host_port: 48132, status: "unconfigured" });
    assert.equal(created.secrets.local_token, "a".repeat(64));
    assert.equal(created.secrets.corporate_token, "b".repeat(64));
    assert.doesNotMatch(await readFile(created.paths.config, "utf8"), /a{64}|b{64}/);
    assert.equal((await stat(created.paths.root)).mode & 0o777, 0o700);
    assert.equal((await stat(created.paths.config)).mode & 0o777, 0o600);
    assert.equal((await stat(created.paths.secrets)).mode & 0o777, 0o600);
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("ensureBrowserState is idempotent and configures corporate metadata without certificate bodies", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-browser-state-idempotent-"));
  try {
    const anvilHome = join(temp, ".anvil");
    const initial = await ensureBrowserState({
      anvilHome,
      randomToken: (() => {
        const values = ["c".repeat(64), "d".repeat(64)];
        return () => values.shift()!;
      })(),
    });
    const updated = await ensureBrowserState({
      anvilHome,
      randomToken: () => {
        throw new Error("tokens should be preserved");
      },
      corporate: {
        imageRef: "anvil/browserless-corporate:ca-test-base-test",
        installedCaPath: join(anvilHome, "browser", "certs", "corporate-root.crt"),
        fingerprint: "A1".repeat(32),
        source: {
          kind: "keychain",
          label: "Test Corporate Root CA",
          keychain: "/tmp/test-system.keychain",
        },
      },
    });

    assert.deepEqual(updated.secrets, initial.secrets);
    assert.equal(updated.config.corporate.status, "configured");
    assert.equal(updated.config.corporate.image_ref, "anvil/browserless-corporate:ca-test-base-test");
    assert.equal(updated.config.corporate.ca_fingerprint, "A1".repeat(32));
    assert.doesNotMatch(await readFile(updated.paths.config, "utf8"), /BEGIN CERTIFICATE|local_token|corporate_token/);
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("browser state refuses malformed files and symlinked roots", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-browser-state-unsafe-"));
  try {
    const anvilHome = join(temp, ".anvil");
    await mkdir(join(anvilHome, "browser"), { recursive: true });
    await writeFile(join(anvilHome, "browser", "config.json"), "{}\n", "utf8");
    await writeFile(join(anvilHome, "browser", "secrets.json"), "{}\n", "utf8");
    const malformed = await readBrowserState(anvilHome);
    assert.equal(malformed.kind, "invalid");
    await assert.rejects(
      ensureBrowserState({ anvilHome }),
      (error: unknown) => error instanceof BrowserConfigurationError && error.code === "BROWSER_STATE_INVALID",
    );

    const unsafeHome = join(temp, "unsafe-home");
    await symlink(join(temp, "outside"), unsafeHome);
    await assert.rejects(
      ensureBrowserState({ anvilHome: unsafeHome }),
      (error: unknown) => error instanceof BrowserConfigurationError && error.code === "BROWSER_STATE_INVALID",
    );
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("browser state accepts only explicit digest-pinned base-image upgrades", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-browser-state-upgrade-"));
  try {
    const anvilHome = join(temp, ".anvil");
    const upgradedImage = `ghcr.io/browserless/chromium@sha256:${"1".repeat(64)}`;
    const upgraded = await ensureBrowserState({
      anvilHome,
      baseImage: upgradedImage,
      randomToken: (() => {
        const values = ["e".repeat(64), "f".repeat(64)];
        return () => values.shift()!;
      })(),
    });
    assert.equal(upgraded.config.base_image, upgradedImage);

    await assert.rejects(
      ensureBrowserState({ anvilHome, baseImage: "ghcr.io/browserless/chromium:latest" }),
      (error: unknown) => error instanceof BrowserConfigurationError && error.code === "UNPINNED_IMAGE",
    );
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("removeBrowserState deletes only valid non-symlinked Browser Eyes state", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-browser-state-remove-"));
  try {
    const anvilHome = join(temp, ".anvil");
    const created = await ensureBrowserState({
      anvilHome,
      randomToken: (() => {
        const values = ["1".repeat(64), "2".repeat(64)];
        return () => values.shift()!;
      })(),
    });
    assert.equal(await removeBrowserState(anvilHome), true);
    await assert.rejects(stat(created.paths.root));
    assert.equal(await removeBrowserState(anvilHome), false);
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});
