import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { execFileSync } from "node:child_process";
import { mkdir, mkdtemp, readFile, realpath, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join, resolve } from "node:path";
import { afterEach, test } from "node:test";
import { runInNewContext } from "node:vm";
import { deriveTaskCreation } from "../src/manifest/task-creation.ts";

import {
  buildManifestHumanView,
  createObjectiveFile,
  discoverObjectives,
  startManifestViewServer,
  type Task,
  validateObjective,
} from "../src/manifest/index.ts";

const roots: string[] = [];

afterEach(async () => {
  await Promise.all(roots.splice(0).map((root) => rm(root, { recursive: true, force: true })));
});

async function gitRepository(): Promise<string> {
  const root = await mkdtemp(join(tmpdir(), "manifest-view-"));
  roots.push(root);
  execFileSync("git", ["init", "-q"], { cwd: root });
  return root;
}

const objective = {
  id: "obj_11111111111111111111111111111111",
  title: "Manifest V2",
  outcome: "Vik and Rowan see the same graph.",
  details: "W5 Human view.",
  phase: "implementation",
  implementation: {
    sequence: [["W5"]],
    stages: [{
      id: "W5",
      label: "Existing Human frontend compatibility",
      detail: "The retained graph and Implementation panel use the same Objective.",
      coverage: "Human frontend",
      exit: "The complete retained interface is visible at wide and narrow widths.",
      primary: { concepts: [], nodes: ["task_44444444444444444444444444444444"] },
      supporting: { concepts: [], nodes: [] },
      slices: [{
        id: "W5.1",
        label: "Restore the full Implementation panel",
        coverage: "Delivery stages, slices, and graph ownership",
        acceptance: "Coverage, acceptance, stage exit, and plan overview are visible.",
        mapsTo: { concepts: [], nodes: ["task_44444444444444444444444444444444"] },
      }],
    }],
    scenario: ["Open the same Objective through the retained Human frontend."],
  },
  workstreams: [{
    id: "ws_22222222222222222222222222222222",
    title: "Human frontend",
    outcome: "The existing interface renders current graph facts.",
    details: "Preserve the interaction model.",
    tasks: [
      {
        id: "task_33333333333333333333333333333333",
        title: "Connect data",
        outcome: "The frontend consumes the current Objective.",
        details: "",
        completionCriteria: ["The Human view is injected safely."],
        dependencies: [],
        externalBlocker: null,
        completion: {
          evidence: [{
            criterion: "The Human view is injected safely.",
            summary: "The Human view contract passed.",
            references: ["test/manifest-view.test.ts"],
          }],
        },
        discontinued: null,
      },
      {
        id: "task_44444444444444444444444444444444",
        title: "Verify browser",
        outcome: "Wide and narrow layouts work.",
        details: "",
        completionCriteria: ["Browser checks pass."],
        dependencies: ["task_33333333333333333333333333333333"],
        externalBlocker: null,
        completion: null,
        discontinued: null,
      },
    ],
  }],
} as const;

// Only the phase shell is mounted here; graph cards are checked in the browser.
function executeHumanInterfaceScript(html: string, preferences: {
  savedSurface?: string;
  search?: string;
  sessionEntries?: readonly (readonly [string, string])[];
} = {}) {
  const projected = JSON.parse(html.match(/<script id="manifest-human-view" type="application\/json">([\s\S]*?)<\/script>/)![1]!);
  const target = JSON.parse(html.match(/<script id="manifest-target" type="application\/json">([\s\S]*?)<\/script>/)![1]!);
  // Deliberately exercise the defensive null-projection path. The ordinary
  // graph-backed panel is covered by manifest-default-panel and browser checks.
  const humanJson = JSON.stringify({ ...projected, implementation: null });
  const source = html.match(/<script id="manifest-implementation-view">([\s\S]*?)<\/script>/)![1]!;
  type Element = {
    className: string; textContent: string; disabled: boolean;
    dataset: Record<string, string>; attributes: Record<string, string>;
    parentElement: Element | null; children: Element[];
    setAttribute(name: string, value: string): void;
    addEventListener(name: string, listener: () => void): void;
    append(child: Element): void; prepend(child: Element): void;
    querySelector(selector: string): Element | null;
    querySelectorAll(selector: string): Element[]; click(): void;
  };
  const element = (): Element => {
    let onClick = () => {};
    const result: Element = {
      className: "", textContent: "", disabled: false, dataset: {}, attributes: {},
      parentElement: null, children: [],
      setAttribute(name, value) { this.attributes[name] = value; },
      addEventListener(name, listener) { if (name === "click") onClick = listener; },
      append(child) { child.parentElement = this; this.children.push(child); },
      prepend(child) { child.parentElement = this; this.children.unshift(child); },
      querySelector(selector) {
        if (selector === '[data-manifest-objectives-link]') {
          return this.children.find((child) => child.dataset.manifestObjectivesLink !== undefined) ?? null;
        }
        return null;
      },
      querySelectorAll(selector) {
        return selector === "[data-manifest-surface-choice]" ? this.children : [];
      },
      click() { if (!this.disabled) onClick(); },
    };
    return result;
  };
  const title = element();
  const controls = element();
  const humanElement = { textContent: humanJson };
  const targetElement = { textContent: JSON.stringify(target) };
  const root = {
    querySelector: (selector: string) => selector === ".lg-title" ? title : null,
    querySelectorAll: () => [],
  };
  const documentElement = { dataset: {} as Record<string, string>, style: { setProperty() {} } };
  const session = new Map<string, string>();
  for (const [key, value] of preferences.sessionEntries ?? []) session.set(key, value);
  if (preferences.savedSurface) session.set(
    'manifest-human-surface-v2::' + JSON.stringify([target.repository, target.objectiveId]),
    preferences.savedSurface,
  );
  runInNewContext(source, {
    document: {
      documentElement,
      getElementById: (id: string) => id === "manifest-human-view" ? humanElement : id === "manifest-target" ? targetElement : id === "root" ? root : null,
      createElement: element,
      addEventListener() {},
      querySelector: (selector: string) => selector === ".lg-title" ? title : selector === ".lg-ctl" ? controls : null,
      querySelectorAll: () => [],
    },
    location: { search: preferences.search ?? "" },
    sessionStorage: {
      getItem: (key: string) => session.get(key) ?? null,
      setItem: (key: string, value: string) => session.set(key, value),
    },
    MutationObserver: class { observe() {} },
    window: { addEventListener() {} },
    URLSearchParams,
  });
  return { title, controls, documentElement, humanElement, humanJson, target, session };
}

function qualifiedObjectiveUrl(serverUrl: string, repository: string, id: string): string {
  const url = new URL(`/objectives/${encodeURIComponent(id)}`, serverUrl);
  url.searchParams.set("repository", repository);
  return url.href;
}

const referenceTask = (
  id: string,
  title: string,
  options: {
    tasks?: readonly unknown[];
    completionCriteria?: string[];
    completion?: unknown;
    discontinued?: { reason: string } | null;
  } = {},
) => ({
  id,
  title,
  outcome: `${title} outcome`,
  details: "",
  completionCriteria: options.completionCriteria ?? [],
  dependencies: [],
  externalBlocker: null,
  completion: options.completion ?? null,
  discontinued: options.discontinued ?? null,
  tasks: [...(options.tasks ?? [])],
});

const referenceGraph = {
  id: "obj_aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
  title: "Display references",
  outcome: "Canonical display references stay derived.",
  details: "",
  phase: "planning" as const,
  workstreams: [
    {
      id: "ws_bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb",
      title: "First stream",
      outcome: "The first Workstream is addressable.",
      details: "",
      tasks: [referenceTask(
        "task_11111111111111111111111111111111",
        "First task",
      )],
    },
    {
      id: "ws_cccccccccccccccccccccccccccccccc",
      title: "Second stream",
      outcome: "The second Workstream contains recursive Work.",
      details: "",
      tasks: [
        referenceTask("task_22222222222222222222222222222222", "First sibling"),
        referenceTask("task_33333333333333333333333333333333", "Completed sibling", {
          completionCriteria: ["Completed sibling criterion"],
          completion: {
            evidence: [{
              criterion: "Completed sibling criterion",
              summary: "The sibling is complete.",
              references: ["test/manifest-view.test.ts"],
            }],
          },
        }),
        referenceTask("task_44444444444444444444444444444444", "Discontinued sibling", {
          discontinued: { reason: "No longer required." },
        }),
        referenceTask("task_55555555555555555555555555555555", "Fourth sibling"),
        referenceTask("task_66666666666666666666666666666666", "Nested parent", {
          tasks: [
            referenceTask("task_77777777777777777777777777777777", "Nested child", {
              tasks: [referenceTask("task_88888888888888888888888888888888", "Deep child")],
            }),
            referenceTask("task_99999999999999999999999999999999", "Second nested child"),
          ],
        }),
      ],
    },
  ],
} as const;

function referenceMap(view: ReturnType<typeof buildManifestHumanView>): Map<string, string | undefined> {
  return new Map(view.graph.nodes.map((node) => [node.label, node.reference]));
}

test("Task creation history is display metadata, not execution state", () => {
  const validated = validateObjective(objective);
  assert.equal(validated.valid, true);
  if (!validated.valid) return;
  const ordinary = buildManifestHumanView(validated.graph);
  const marked = buildManifestHumanView(validated.graph, undefined, {
    task_33333333333333333333333333333333: "planning",
    task_44444444444444444444444444444444: "implementation",
  });
  const planned = marked.graph.nodes.find((node) => node.id === "task_33333333333333333333333333333333")!;
  const added = marked.graph.nodes.find((node) => node.id === "task_44444444444444444444444444444444")!;
  assert.equal(planned.creationPhase, "planning");
  assert.equal(added.creationPhase, "implementation");
  assert.match(added.sublabel, /^Next · Added during Implementation$/);
  assert.match(added.planningSublabel, /^Recursively fully decomposed · Added during Implementation$/);
  assert.match(String(added.data["Creation phase"]), /Added during Implementation/);
  assert.match(String(ordinary.graph.nodes.find((node) => node.id === added.id)!.data["Creation phase"]), /Unknown/);
  assert.deepEqual(marked.progress, ordinary.progress);
  assert.deepEqual(marked.available, ordinary.available);
  assert.deepEqual(marked.graph.edges, ordinary.graph.edges);
});

test("the Brain view marks the known Implementation additions including the approved history repair", async () => {
  const stored = JSON.parse(await readFile(resolve(
    "test/fixtures/manifest-brain-view.json",
  ), "utf8"));
  const validated = validateObjective(stored);
  assert.equal(validated.valid, true);
  if (!validated.valid) return;
  const ordinary = buildManifestHumanView(validated.graph);
  const fixtureRoot = await mkdtemp(join(tmpdir(), "manifest-creation-fixture-"));
  roots.push(fixtureRoot);
  const human = buildManifestHumanView(validated.graph, undefined,
    await deriveTaskCreation(fixtureRoot, validated.graph));
  assert.deepEqual(human.graph.nodes.filter((node) => node.creationPhase === "implementation")
    .map((node) => node.reference), [
    "W2.2", "W2.4", "W2.5", "W2.5.1", "W2.5.2", "W2.5.3",
    "W2.6", "W2.6.1", "W2.6.2", "W2.6.3", "W2.8",
  ]);
  assert.equal(human.graph.nodes.find((node) => node.reference === "W2.1")!.creationPhase, "unknown");
  assert.equal(human.graph.nodes.find((node) => node.reference === "W2.7.1")!.creationPhase, "unknown");
  assert.deepEqual(human.progress, ordinary.progress);
  assert.deepEqual(human.available, ordinary.available);
  assert.deepEqual(human.graph.edges, ordinary.graph.edges);
});

test("Human references follow canonical Workstream and recursive Task order", () => {
  const validated = validateObjective(referenceGraph);
  assert.equal(validated.valid, true);
  if (!validated.valid) return;
  const before = structuredClone(validated.graph);

  const human = buildManifestHumanView(validated.graph);

  assert.deepEqual([...referenceMap(human).entries()], [
    ["Display references", undefined],
    ["First stream", "W1"],
    ["First task", "W1.1"],
    ["Second stream", "W2"],
    ["First sibling", "W2.1"],
    ["Completed sibling", "W2.2"],
    ["Discontinued sibling", "W2.3"],
    ["Fourth sibling", "W2.4"],
    ["Nested parent", "W2.5"],
    ["Nested child", "W2.5.1"],
    ["Deep child", "W2.5.1.1"],
    ["Second nested child", "W2.5.2"],
  ]);
  assert.deepEqual(validated.graph, before);
  for (const node of human.graph.nodes) {
    if (node.reference) assert.equal(node.data.Reference, node.reference);
  }
  assert.deepEqual(
    referenceMap(buildManifestHumanView({ ...validated.graph, phase: "implementation" })),
    referenceMap(human),
  );
});

test("reference derivation recomputes after reordering, insertion, and reparenting while IDs stay stable", () => {
  const validated = validateObjective(referenceGraph);
  assert.equal(validated.valid, true);
  if (!validated.valid) return;
  const before = structuredClone(validated.graph);
  const initial = buildManifestHumanView(validated.graph);
  const idsBefore = new Map(initial.graph.nodes.map((node) => [node.label, node.id]));

  const changed = structuredClone(validated.graph);
  const firstWorkstream = changed.workstreams.shift()!;
  changed.workstreams.push(firstWorkstream);
  const secondWorkstream = changed.workstreams[0]!;
  const nestedParent = secondWorkstream.tasks[4]!;
  const movedChild = nestedParent.tasks.shift()!;
  secondWorkstream.tasks.push(movedChild);
  const inserted = {
    ...structuredClone(secondWorkstream.tasks[0]!),
    id: "task_00000000000000000000000000000000" as Task["id"],
    title: "Inserted sibling",
  };
  secondWorkstream.tasks.splice(4, 0, inserted);

  const changedValidation = validateObjective(changed);
  assert.equal(changedValidation.valid, true);
  if (!changedValidation.valid) return;
  const after = buildManifestHumanView(changedValidation.graph);
  const idsAfter = new Map(after.graph.nodes.map((node) => [node.label, node.id]));
  for (const [label, id] of idsBefore) assert.equal(idsAfter.get(label), id, `${label} keeps its Stable Graph Identity`);
  assert.equal(idsAfter.get("Inserted sibling"), "task_00000000000000000000000000000000");
  assert.deepEqual([...referenceMap(after).entries()], [
    ["Display references", undefined],
    ["Second stream", "W1"],
    ["First sibling", "W1.1"],
    ["Completed sibling", "W1.2"],
    ["Discontinued sibling", "W1.3"],
    ["Fourth sibling", "W1.4"],
    ["Inserted sibling", "W1.5"],
    ["Nested parent", "W1.6"],
    ["Second nested child", "W1.6.1"],
    ["Nested child", "W1.7"],
    ["Deep child", "W1.7.1"],
    ["First stream", "W2"],
    ["First task", "W2.1"],
  ]);
  assert.deepEqual(validated.graph, before);
});

test("phase presentation follows canonical availability even without a panel projection", async () => {
  const repository = await gitRepository();
  const server = await startManifestViewServer({ repository, port: 0 });
  try {
    for (const phase of ["implementation", "planning"] as const) {
      const candidate = { ...objective, phase, implementation: undefined };
      const validated = validateObjective(candidate);
      assert.equal(validated.valid, true);
      if (!validated.valid) return;
      // Each phase uses an independent canonical fixture, never a browser mutation.
      const graph = { ...validated.graph, id: (phase === "planning"
        ? "obj_aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" : objective.id) as typeof validated.graph.id };
      await createObjectiveFile(repository, graph);
      const response = await fetch(qualifiedObjectiveUrl(server.url, repository, graph.id));
      assert.equal(response.status, 200);
      const html = await response.text();
      const ui = executeHumanInterfaceScript(html);
      assert.equal(JSON.parse(ui.humanJson).implementation, null);
      assert.equal(ui.documentElement.dataset.manifestSurface, phase);
      assert.equal(ui.title.textContent, objective.title + " · " + (phase === "implementation" ? "Implementation" : "Planning"));
      const buttons = ui.controls.children[0]!.children;
      assert.deepEqual(buttons.map((item) => item.dataset.manifestSurfaceChoice), phase === "planning"
        ? ["planning"] : ["planning", "implementation"]);
      if (phase === "planning") {
        for (const preferences of [
          { savedSurface: "implementation" },
          { search: "?manifest-surface=implementation" },
          { savedSurface: "implementation", search: "?surface=plan&manifest-surface=implementation" },
        ]) {
          const restored = executeHumanInterfaceScript(html, preferences);
          assert.equal(restored.documentElement.dataset.manifestSurface, "planning");
          assert.equal(restored.controls.children[0]!.children.length, 1);
        }
      }
      for (const target of phase === "planning" ? ["planning"] : ["planning", "implementation", "planning", "implementation"]) {
        const button = buttons.find((item) => item.dataset.manifestSurfaceChoice === target)!;
        assert.equal(button.disabled, false);
        button.click();
        assert.equal(ui.documentElement.dataset.manifestSurface, target);
        assert.equal(ui.title.textContent, objective.title + " · " + (target === "implementation" ? "Implementation" : "Planning"));
        assert.equal(button.attributes["aria-pressed"], "true");
        assert.equal(ui.humanElement.textContent, ui.humanJson);
      }
      assert.equal((await (await fetch(server.url + "/api/objectives/" + graph.id)).json()).objective.phase, phase);
    }
  } finally {
    await server.close();
  }
});

test("saved Human surface state is isolated by the qualified repository target", async () => {
  const firstRepository = await gitRepository();
  const secondRepository = await gitRepository();
  const validated = validateObjective(objective);
  assert.equal(validated.valid, true);
  if (!validated.valid) return;
  await createObjectiveFile(firstRepository, { ...validated.graph, title: "First repository graph" });
  await createObjectiveFile(secondRepository, { ...validated.graph, title: "Second repository graph" });
  const server = await startManifestViewServer({ repository: firstRepository, port: 0 });
  try {
    const firstHtml = await fetch(qualifiedObjectiveUrl(server.url, firstRepository, validated.graph.id))
      .then((response) => response.text());
    const secondHtml = await fetch(qualifiedObjectiveUrl(server.url, secondRepository, validated.graph.id))
      .then((response) => response.text());
    const firstUi = executeHumanInterfaceScript(firstHtml, { savedSurface: "planning" });
    assert.equal(firstUi.documentElement.dataset.manifestSurface, "planning");
    const oldObjectiveOnlyKey = "manifest-human-surface-v1::" + validated.graph.id;
    const secondUi = executeHumanInterfaceScript(secondHtml, {
      sessionEntries: [
        ...firstUi.session.entries(),
        [oldObjectiveOnlyKey, "planning"],
      ],
    });
    assert.equal(secondUi.documentElement.dataset.manifestSurface, "implementation");
    assert.notEqual(firstUi.target.repository, secondUi.target.repository);
    assert.equal(firstUi.target.objectiveId, secondUi.target.objectiveId);
  } finally {
    await server.close();
  }
});

test("the Human panel derives execution state from mapped graph Work", () => {
  const validated = validateObjective(objective);
  assert.equal(validated.valid, true);
  if (!validated.valid) return;
  const currentTaskId = validated.graph.workstreams[0]!.tasks[1]!.id;

  const human = buildManifestHumanView(validated.graph, currentTaskId);
  assert.equal(human.implementation?.currentStage, "W5");
  assert.equal(human.implementation?.currentSlice, "W5.1");
  assert.equal(human.implementation?.stages[0]?.status, "current");
  assert.equal(human.implementation?.stages[0]?.slices[0]?.status, "active");
  const taskNodes = human.graph.nodes.filter((node) => node.kind === "task");
  assert.deepEqual(taskNodes.map((node) => node.sublabel), ["Complete", "Current"]);
  assert.equal(taskNodes.every((node) => !node.sublabel.startsWith("Task ·")), true);
  assert.equal(human.graph.nodes.every((node) => node.decomposed), true);
});

test("Planning presentation keeps undecomposed Work in semantic entity colours", () => {
  const validated = validateObjective({ ...objective, phase: "planning", implementation: undefined });
  assert.equal(validated.valid, true);
  if (!validated.valid) return;

  const human = buildManifestHumanView(validated.graph);
  assert.equal(human.objective.phase, "planning");
  assert.equal(human.graph.nodes.every((node) => !node.decomposed), true);
  assert.deepEqual(
    [...new Set(human.graph.nodes.map((node) => node.kind))],
    ["objective", "workstream", "task"],
  );
  assert.equal(human.graph.nodes.every((node) =>
    !node.planningSublabel.toLowerCase().startsWith(node.kind)), true);
});

test("Planning decomposition rolls up only through accepted leaf Task subtrees", () => {
  const candidate = structuredClone(objective) as any;
  candidate.phase = "planning";
  delete candidate.implementation;
  candidate.workstreams[0].tasks = [
    {
      ...candidate.workstreams[0].tasks[0],
      completion: null,
      completionCriteria: [],
      tasks: [
        {
          ...candidate.workstreams[0].tasks[0],
          id: "task_55555555555555555555555555555555",
          decompositionComplete: true,
          completion: null,
          dependencies: [],
        },
        {
          ...candidate.workstreams[0].tasks[1],
          id: "task_66666666666666666666666666666666",
          decompositionComplete: true,
          dependencies: [],
        },
      ],
    },
    {
      ...candidate.workstreams[0].tasks[1],
      decompositionComplete: false,
      dependencies: [],
    },
  ];
  const validated = validateObjective(candidate);
  assert.equal(validated.valid, true);
  if (!validated.valid) return;

  const human = buildManifestHumanView(validated.graph);
  const states = Object.fromEntries(human.graph.nodes.map((node) => [node.label, node.decomposed]));
  assert.equal(states["Connect data"], true);
  assert.equal(states["Verify browser"], false);
  assert.equal(states["Human frontend"], false);
  assert.equal(states["Manifest V2"], false);

  candidate.workstreams[0].tasks[1].decompositionComplete = true;
  const complete = validateObjective(candidate);
  assert.equal(complete.valid, true);
  if (!complete.valid) return;
  assert.equal(buildManifestHumanView(complete.graph).graph.nodes.every((node) => node.decomposed), true);
});

test("the pinned Objective preserves the corrected Rings product decomposition", async () => {
  const stored = JSON.parse(await readFile(resolve(
    "test/fixtures/manifest-rings-view.json",
  ), "utf8"));
  const validated = validateObjective(stored);
  assert.equal(validated.valid, true);
  if (!validated.valid) return;

  assert.deepEqual(validated.graph.workstreams.map((workstream) => workstream.title), [
    "Manifest interfaces",
    "Manifest Work System",
  ]);
  const tasks = validated.graph.workstreams.flatMap((workstream) => flattenTasks(workstream.tasks));
  assert.equal(tasks.length, 91);
  assert.equal(tasks.filter((task) => task.tasks.length === 0).length, 66);
  assert.equal(tasks.filter((task) => task.completion !== null).length, 43);
  assert.equal(tasks.filter((task) => task.discontinued !== null).length, 22);
  assert.equal(tasks.reduce((count, task) => count + task.dependencies.length, 0), 10);
  const currentTaskId = "task_7345390c2317075921e5d7ea31fab63a" as Task["id"];
  const implementation = buildManifestHumanView(validated.graph, currentTaskId).implementation;
  assert.equal(implementation?.currentStage, "W5");
  assert.equal(implementation?.currentSlice, "W5.4");
  assert.deepEqual(
    implementation?.stages.filter((stage) => stage.status === "current").map((stage) => stage.id),
    ["W5"],
  );
  assert.equal(implementation?.stages.find((stage) => stage.id === "W4")?.status, "complete");
  assert.deepEqual(validated.graph.implementation?.sequence, [["G"], ["W1"], ["W2"], ["W3"], ["W4", "W5"], ["W6"]]);
  assert.equal(validated.graph.implementation?.stages.find((stage) => stage.id === "W5")?.slices.length, 4);
  assert.deepEqual(
    Object.fromEntries(validated.graph.implementation?.stages.find((stage) => stage.id === "W3")?.slices
      .map((slice) => [slice.id, slice.mapsTo.concepts]) ?? []),
    {
      "W3.1": ["M.1.1.2.1", "M.1.2.2"],
      "W3.2": ["M.1.1.2.1", "M.1.2.2"],
      "W3.3": ["M.1.1.1.1", "M.1.2.2"],
      "W3.4": ["M.1.1.1.3", "M.1.2.2"],
    },
  );
  assert.deepEqual(
    Object.fromEntries(validated.graph.implementation?.stages.find((stage) => stage.id === "W5")?.slices
      .filter((slice) => slice.mapsTo.concepts.length > 0)
      .map((slice) => [slice.id, slice.mapsTo.concepts]) ?? []),
    {
      "W5.1": ["M.1.1.2.2", "M.1.1.2.4"],
      "W5.2": ["M.1.1.1.1", "M.1.1.2.2"],
      "W5.3": ["M.1.1"],
    },
  );
  assert.doesNotMatch(JSON.stringify(validated.graph.implementation), /SQLite|proposal|binding|doctor|rollout/i);
  const originalLabels = [
    validated.graph.title,
    ...validated.graph.workstreams.flatMap((workstream) => [
      workstream.title,
      ...originalTaskLabels(workstream.tasks),
    ]),
  ];
  assert.equal(originalLabels.length, 88);
  assert.equal(
    createHash("sha256").update(JSON.stringify(originalLabels)).digest("hex"),
    "32ade6cb92c371a32a4d58a5d127c1c44bc1f60b2bbf88e70d8dde42f95907d3",
  );
  const workstreamByTask = new Map(validated.graph.workstreams.flatMap((workstream) =>
    flattenTasks(workstream.tasks).map((task) => [task.id, workstream.id] as const)
  ));
  assert.equal(tasks.some((task) => task.dependencies.some((dependency) =>
    workstreamByTask.get(dependency) !== workstreamByTask.get(task.id)
  )), false);
  assert.deepEqual(
    validated.graph.workstreams[0]!.tasks[0]!.tasks[0]!.tasks.map((task) => task.title),
    ["Work structure awareness", "Work state awareness", "Work explanation", "Work history awareness", "Highlight Tasks added during Implementation"],
  );
  assert.equal(
    validated.graph.workstreams[1]!.tasks[0]!.tasks[2]!.tasks[3]!.tasks[0]!.title,
    "Outcome clarity",
  );
});

test("slice presentation resolves graph nodes and bounds visible requires edges to lit endpoints", async () => {
  const stored = JSON.parse(await readFile(resolve(
    "test/fixtures/manifest-rings-view.json",
  ), "utf8"));
  const validated = validateObjective(stored);
  assert.equal(validated.valid, true);
  if (!validated.valid) return;

  const human = buildManifestHumanView(validated.graph);
  const implementation = human.implementation;
  const w31 = implementation?.stages.find((stage) => stage.id === "W3")?.slices
    .find((slice) => slice.id === "W3.1");
  assert.ok(w31);
  assert.deepEqual(w31.mappedNodeIds, [
    "task_034d33ec712bf7e920466f097225f01b",
    "task_9672db9f5285b6396fd43d0fadbb1289",
  ]);
  assert.deepEqual(w31.visibleDependencyEdgeIds, []);

  const graphNodeIds = new Set(human.graph.nodes.map((node) => node.id));
  const dependencyEdges = human.graph.edges.filter((edge) => edge.kind === "dependency");
  for (const stage of implementation?.stages ?? []) {
    const stageMappedNodeIds = [...new Set(stage.slices.flatMap((slice) => slice.mappedNodeIds))];
    assert.deepEqual(stage.mappedNodeIds, stageMappedNodeIds, `${stage.id} aggregates every slice mapping`);
    const stageLit = new Set(stage.mappedNodeIds);
    assert.deepEqual(
      [...stage.visibleDependencyEdgeIds].sort(),
      dependencyEdges
        .filter((edge) => stageLit.has(edge.source) && stageLit.has(edge.target))
        .map((edge) => edge.id)
        .sort(),
      `${stage.id} exposes requires edges only when both aggregate endpoints are lit`,
    );
    for (const slice of stage.slices) {
      assert.notEqual(slice.mappedNodeIds.length, 0, `${slice.id} must illuminate mapped graph Work`);
      assert.equal(slice.mappedNodeIds.every((id) => graphNodeIds.has(id)), true, `${slice.id} maps only to graph nodes`);
      const lit = new Set(slice.mappedNodeIds);
      assert.deepEqual(
        [...slice.visibleDependencyEdgeIds].sort(),
        dependencyEdges
          .filter((edge) => lit.has(edge.source) && lit.has(edge.target))
          .map((edge) => edge.id)
          .sort(),
        `${slice.id} exposes requires edges only when both endpoints are lit`,
      );
    }
  }

  const asset = await readFile(resolve("docs/manifest-objective.html"), "utf8");
  assert.match(asset, /\.react-flow__edge\.impl-edge-hidden\s*\{\s*display:\s*none/);
  assert.match(asset, /\.react-flow \.react-flow__edges\s*\{[^}]*z-index:\s*0/s);
  assert.match(asset, /\.manifest-card:not\(\.node--detail\)\s*\{[^}]*width:\s*300px;[^}]*padding:\s*14px 16px;[^}]*background:\s*var\(--surface\);[^}]*border:\s*1px solid var\(--manifest-card-color\);/s);
  assert.match(asset, /\.manifest-card__kind\s*\{[^}]*font-family:\s*var\(--sans\);[^}]*font-size:\s*9px;[^}]*font-weight:\s*600;[^}]*letter-spacing:\s*0\.16em;[^}]*line-height:\s*normal;/s);
  assert.match(asset, /\.manifest-card__title\s*\{[^}]*font-family:\s*var\(--mono\);[^}]*font-size:\s*13\.5px;[^}]*font-weight:\s*400;[^}]*line-height:\s*1\.25;[^}]*word-break:\s*normal;/s);
  assert.match(asset, /\.manifest-card__support\s*\{[^}]*grid-column: 1; grid-row: 3;/);
  assert.match(asset, /html\[data-manifest-surface="planning"\] \.manifest-card__support--implementation\s*\{\s*visibility:\s*hidden/s);
  assert.match(asset, /html\[data-manifest-surface="implementation"\] \.manifest-card__support--planning\s*\{\s*visibility:\s*hidden/s);
  assert.match(asset, /\.manifest-card__children\s*\{[^}]*color:\s*var\(--manifest-card-color\) !important/s);
  assert.match(asset, /\.node__count \.chev\s*\{[^}]*color:\s*inherit/s);
  assert.match(asset, /\.implementation-owner__discontinued\s*\{[^}]*background:\s*var\(--red\)/s);
  assert.match(asset, /\.manifest-card:not\(\.node--detail\)\s*\{[^}]*display:\s*grid;[^}]*grid-template-columns:\s*minmax\(0, 1fr\)/s);
  assert.match(asset, /\.manifest-card__legacy-badge\s*\{\s*display:\s*none/s);
  assert.match(asset, /\.manifest-card__title-row > \.dot\s*\{\s*display:\s*none/s);
  assert.match(asset, /\.manifest-card\[data-manifest-kind="objective"\]\s*\{\s*--manifest-kind-color:\s*var\(--blue\)/s);
  assert.match(asset, /\.manifest-card\[data-manifest-kind="workstream"\]\s*\{\s*--manifest-kind-color:\s*var\(--teal\)/s);
  assert.match(asset, /\.manifest-card\[data-manifest-kind="task"\]\s*\{\s*--manifest-kind-color:\s*var\(--red\)/s);
  assert.match(asset, /html\[data-manifest-surface="implementation"\] \.manifest-card__kind\s*\{\s*color:\s*var\(--manifest-kind-color\)/s);
  assert.match(asset, /html\[data-manifest-surface="planning"\] \.manifest-card__kind\s*\{\s*color:\s*var\(--planning-color\)/s);
  assert.match(asset, /\.implementation-step__marker\s*\{[^}]*color:\s*var\(--implementation-color\)/s);
  assert.match(asset, /\.implementation-step\[data-progress-status="upcoming"\] \.implementation-step__progress\s*\{\s*color:\s*var\(--text-dim\)/s);
  assert.doesNotMatch(asset, /\.implementation-step\[data-progress-status="upcoming"\]\s*\{\s*--implementation-color:\s*var\(--text-dim\)/s);
  assert.match(asset, /\.react-flow__edgelabel-renderer\s*\{[^}]*z-index:\s*0/s);
  assert.match(asset, /\.react-flow__nodes\s*\{[^}]*z-index:\s*1/s);
});

test("stored panel execution state is rejected", async () => {
  const stored = JSON.parse(await readFile(resolve(
    "test/fixtures/manifest-rings-view.json",
  ), "utf8"));
  stored.implementation.currentStage = "W5";
  stored.implementation.currentSlice = "W5.4";
  stored.implementation.stages[4].status = "current";
  stored.implementation.stages[4].slices[3].status = "active";

  const validated = validateObjective(stored);
  assert.equal(validated.valid, false);
  if (validated.valid) return;
  assert.equal(validated.problems.some((problem) =>
    problem.path === "$.implementation" && problem.message.includes("currentStage")), true);
  assert.equal(validated.problems.some((problem) =>
    problem.path.includes("$.implementation.stages") && problem.message.includes("status")), true);
});

test("every implementation slice maps to a graph surface that exists", async () => {
  const stored = JSON.parse(await readFile(resolve(
    "test/fixtures/manifest-rings-view.json",
  ), "utf8"));
  const slice = stored.implementation.stages[3].slices[0];
  slice.mapsTo = { concepts: ["M.999"], nodes: [] };

  const validated = validateObjective(stored);
  assert.equal(validated.valid, false);
  if (validated.valid) return;
  assert.equal(validated.problems.some((problem) =>
    problem.path.endsWith(".mapsTo") && /does not match a graph surface/.test(problem.message)
  ), true);
});

function flattenTasks(tasks: readonly Task[]): Task[] {
  return tasks.flatMap((task) => [task, ...flattenTasks(task.tasks)]);
}

function originalTaskLabels(tasks: readonly Task[]): string[] {
  return tasks.flatMap((task) => task.id === "task_50ae242f681cb1c6f3140576eeff7611" || /^Added by (?:the )?accepted/.test(task.details)
    ? []
    : [task.title, ...originalTaskLabels(task.tasks)]);
}

test("the Human asset is an inert template, not a stale Objective", async () => {
  const template = await readFile(resolve("docs/manifest-objective.html"), "utf8");
  assert.doesNotMatch(template, /Manifest V2 · accepted definition/);
  assert.doesNotMatch(template, /2026-09-01-g5-accepted/);
  assert.match(template, /Run manifest inside a Git worktree/);
  assert.match(
    template,
    /\.implementation-step\[data-progress-status="complete"\][\s\S]*?color: var\(--implementation-color\)/,
  );
  assert.match(
    template,
    /\.implementation-step\[data-progress-status="partial"\][\s\S]*?color: var\(--implementation-color\)/,
  );
  assert.match(
    template,
    /\.implementation-step\[data-progress-status="upcoming"\] \.implementation-step__progress\s*\{\s*color: var\(--text-dim\)/,
  );
});

test("status wording dims only Upcoming while assigned stage colours remain visible", async () => {
  const template = await readFile(resolve("docs/manifest-objective.html"), "utf8");
  const repository = await gitRepository();
  const validated = validateObjective(objective);
  assert.equal(validated.valid, true);
  if (!validated.valid) return;
  await createObjectiveFile(repository, validated.graph);
  const server = await startManifestViewServer({ repository, host: "127.0.0.1", port: 0 });
  try {
    const html = await fetch(qualifiedObjectiveUrl(server.url, repository, validated.graph.id)).then((response) => response.text());
    const source = html.match(/<script id="manifest-implementation-view">([\s\S]*?)<\/script>/)![1]!;
    const statusElementCode = source.match(/  const statusElement = \(className, status\) => \{[\s\S]*?\n  \};/)?.[0];
    assert.ok(statusElementCode);
    const rendered = runInNewContext(
      `${statusElementCode}
       JSON.stringify([statusElement("implementation-gate__status", "upcoming"), statusElement("plan-stage__status", "active")])`,
      {
        create: (tag: string, className: string, text?: string) => ({
          tag,
          className,
          text: text ?? "",
          children: [] as unknown[],
          append(...children: unknown[]) { this.children.push(...children); },
        }),
        statusLabel: (status: string) => status === "upcoming" ? "○ Upcoming" : "● Active",
      },
    );
    assert.deepEqual(JSON.parse(rendered), [
      {
        tag: "span",
        className: "implementation-gate__status",
        text: "",
        children: [
          { tag: "span", className: "implementation-gate__status-marker", text: "○ ", children: [] },
          { tag: "span", className: "implementation-gate__status-label", text: "Upcoming", children: [] },
        ],
      },
      {
        tag: "span",
        className: "plan-stage__status",
        text: "",
        children: [
          { tag: "span", className: "plan-stage__status-marker", text: "● ", children: [] },
          { tag: "span", className: "plan-stage__status-label", text: "Active", children: [] },
        ],
      },
    ]);
    for (const call of [
      "implementation-gate__status",
      "plan-item__status",
    ]) {
      assert.match(source, new RegExp(`statusElement\\('(?:${call})'`));
    }
    assert.match(source, /create\('span', 'implementation-step__progress', stage\.status\)/);
    assert.match(source, /create\('span', '', stage\.status\)/);
    assert.match(source, /create\('span', 'plan-stage__status', stage\.status\)/);

    assert.match(template, /\.implementation-gate__id\s*\{[^}]*color:\s*var\(--impl-gate\)/s);
    assert.doesNotMatch(template, /\.implementation-gate\[data-gate-status="upcoming"\] \.implementation-gate__id\s*\{/);
    assert.match(template, /\.implementation-gate\[data-gate-status="upcoming"\] \.implementation-gate__status-label\s*\{\s*color:\s*var\(--text-dim\)/s);
    assert.match(template, /\.implementation-step__marker\s*\{[^}]*color:\s*var\(--implementation-color\)/s);
    assert.match(template, /\.implementation-step__progress\s*\{[^}]*color:\s*var\(--implementation-color\)/s);
    assert.match(template, /\.implementation-step\[data-progress-status="upcoming"\] \.implementation-step__progress\s*\{\s*color:\s*var\(--text-dim\)/s);
    assert.match(template, /\.implementation-gate-lane__heading strong\s*\{\s*color:\s*var\(--impl-gate\)/s);
    assert.match(template, /\.implementation-stage-section\[data-stage-status="upcoming"\] \.implementation-gate-lane__stage-status\s*\{\s*color:\s*var\(--text-dim\)/s);
    assert.match(template, /\.plan-stage\s*\{[^}]*border:\s*1px solid color-mix\(in srgb, var\(--stage-color\)/s);
    assert.doesNotMatch(template, /--stage-status-color|--impl-stage-status/);
    assert.match(template, /\.plan-stage__id\s*\{\s*color:\s*var\(--stage-color\)/s);
    assert.match(template, /\.plan-stage__status\s*\{\s*color:\s*var\(--stage-color\)/s);
    assert.match(template, /\.plan-stage\[data-stage-status="upcoming"\] \.plan-stage__status\s*\{\s*color:\s*var\(--text-dim\)/s);
    assert.match(template, /\.plan-overview__flow-step span\s*\{\s*color:\s*var\(--stage-color\)/s);
    assert.match(template, /\.plan-overview__flow-step\[data-stage-status="upcoming"\] span\s*\{\s*color:\s*var\(--text-dim\)/s);
    assert.match(template, /\.plan-item__id\s*\{\s*color:\s*var\(--stage-color\)/s);
    assert.match(template, /\.plan-item\[data-item-status="upcoming"\] \.plan-item__status-label\s*\{\s*color:\s*var\(--text-dim\)/s);
  } finally {
    await server.close();
  }
});

test("Human view projects graph structure, dependencies, and derived execution state", () => {
  const validated = validateObjective(objective);
  assert.equal(validated.valid, true);
  if (!validated.valid) return;
  const currentTaskId = validated.graph.workstreams[0]!.tasks[0]!.id;

  const human = buildManifestHumanView(validated.graph, currentTaskId);

  assert.deepEqual(human.objective, {
    id: validated.graph.id,
    title: "Manifest V2",
    outcome: "Vik and Rowan see the same graph.",
    phase: "implementation",
  });
  assert.deepEqual(human.graph.nodes.map((node) => node.id), [
    validated.graph.id,
    validated.graph.workstreams[0]!.id,
    ...validated.graph.workstreams[0]!.tasks.map((task) => task.id),
  ]);
  assert.deepEqual(human.graph.edges.map((edge) => edge.kind), ["structure", "structure", "structure", "dependency"]);
  assert.equal(human.current?.id, currentTaskId);
  assert.equal(human.next?.task.id, validated.graph.workstreams[0]!.tasks[1]!.id);
  assert.deepEqual(human.available.map((task) => task.id), [validated.graph.workstreams[0]!.tasks[1]!.id]);
  assert.equal(human.graph.nodes.find((node) => node.id === currentTaskId)?.state, "current");
  assert.equal(human.graph.nodes.find((node) => node.id === human.next?.task.id)?.state, "next");
  assert.equal(human.implementation?.currentSlice, null);
});

test("Lens sizing uses the longest phase sublabel while Human JSON keeps both labels", async () => {
  const repository = await gitRepository();
  const validated = validateObjective(objective);
  assert.equal(validated.valid, true);
  if (!validated.valid) return;
  await createObjectiveFile(repository, validated.graph);
  const server = await startManifestViewServer({ repository, host: "127.0.0.1", port: 0 });
  try {
    const html = await (await fetch(qualifiedObjectiveUrl(server.url, repository, validated.graph.id))).text();
    const human = JSON.parse(html.match(/<script id="manifest-human-view" type="application\/json">([\s\S]*?)<\/script>/)![1]!);
    const lens = JSON.parse(html.match(/<script id="lens-data" type="application\/json">([\s\S]*?)<\/script>/)![1]!);
    const humanTask = human.graph.nodes.find((node: { id: string }) => node.id === validated.graph.workstreams[0]!.tasks[1]!.id)!;
    const lensTask = lens.nodes.find((node: { id: string }) => node.id === humanTask.id)!;
    assert.equal(humanTask.sublabel, "Next");
    assert.equal(humanTask.planningSublabel, "Recursively fully decomposed");
    assert.equal(lensTask.sublabel, humanTask.planningSublabel);
    assert.notEqual(lensTask.sublabel, humanTask.sublabel);
  } finally {
    await server.close();
  }
});

test("view server serves the existing Human interface with safely injected live data", async () => {
  const repository = await gitRepository();
  const validated = validateObjective(objective);
  assert.equal(validated.valid, true);
  if (!validated.valid) return;
  await createObjectiveFile(repository, validated.graph);
  const server = await startManifestViewServer({ repository, host: "127.0.0.1", port: 0 });
  try {
    const response = await fetch(qualifiedObjectiveUrl(server.url, repository, validated.graph.id));
    const html = await response.text();
    assert.equal(response.status, 200);
    assert.match(html, /\.react-flow__/);
    assert.match(html, /id="manifest-human-view" type="application\/json"/);
    assert.match(html, /Vik and Rowan see the same graph/);
    assert.match(html, /manifest-plan-overview/);
    assert.match(html, /implementation-gate-lane__detail/);
    assert.match(html, /implementation-owner/);
    assert.match(html, /Restore the full Implementation panel/);
    assert.match(html, /Coverage, acceptance, stage exit, and plan overview are visible/);
    assert.match(html, /const accent = plan && own\.primary\s*\? match === 'primary' && filter !== 'all' \? stageColor\(filter\) : stageColor\(own\.primary\)\s*: semanticColors\[node\.kind\]/);
    assert.match(html, /button\.style\.setProperty\('--implementation-color', stageColor\(stage\.id\)\)/);
    assert.doesNotMatch(html, /button\.style\.setProperty\('--implementation-color', statusColor\(stage\)\)/);
    assert.match(html, /const normalizeSharedCard = rendered =>/);
    assert.match(html, /const displayCode = id => semanticNodes\.get\(id\)\?\.reference \|\| id/);
    assert.match(html, /manifest-card__reference/);
    assert.match(html, /kindLabel\.textContent = kindText \+ ' · '/);
    assert.match(html, /\.manifest-card__kind,\s*\.detail__eyebrow\s*\{[^}]*justify-content: flex-start/);
    assert.match(html, /"data-manifest-node-id":Ae\.id/);
    assert.match(html, /normalizeReferenceLabel\(kindLabel, node\)/);
    assert.match(html, /card\.classList\.add\('manifest-card', 'node--' \+ node\.kind\)/);
    assert.match(html, /kindLabel\.classList\.add\('manifest-card__kind'\)/);
    assert.match(html, /title\.classList\.add\('manifest-card__title'\)/);
    assert.match(html, /implementationSupport\.classList\.add\('manifest-card__support', 'manifest-card__support--implementation'\)/);
    assert.match(html, /create\('div', 'node__sub manifest-card__support manifest-card__support--planning', node\.planningSublabel\)/);
    assert.match(html, /const normalizeSharedCards = \(\) =>/);
    assert.match(html, /card\.dataset\.manifestCardNormalized = 'true'/);
    assert.match(html, /const sharedCardClassObserver = new MutationObserver/);
    assert.match(html, /attributeFilter: \['class'\]/);
    assert.match(html, /kindLabel\.dataset\.manifestSlot = 'kind'/);
    assert.match(html, /title\.dataset\.manifestSlot = 'title'/);
    assert.match(html, /children\.dataset\.manifestSlot = 'children'/);
    assert.doesNotMatch(html, /manifest-task-creation-style/);
    assert.doesNotMatch(html, /manifest-card__creation/);
    assert.doesNotMatch(html, /restorePlanningSurface|manifestPlanningEyebrow|manifestImplementationText/);
    const liveStateKey = html.match(/manifestLiveStateKey=("(?:\\.|[^"])*")/)?.[1];
    assert.ok(liveStateKey);
    assert.equal(JSON.parse(liveStateKey), `manifest-map-live-state-v3::${JSON.stringify([await realpath(repository), validated.graph.id])}`);
    assert.match(html, /nodesConnectable:!1,minZoom:\.05,maxZoom:2,zoomOnDoubleClick:!1/);
    assert.match(html, /let Te=\(\)=>\{\}/);
    assert.doesNotMatch(html, /\[\.\.\.Ve,Sn\.id\]/);
    assert.match(html, /const selectManifestWork=event=>\{/);
    assert.match(html, /toggleDetail&&k==="node"&&S\.length===1&&S\[0\]===id\?\[\]:\[id\]/);
    assert.match(html, /window\.addEventListener\("manifest-work-selection",selectManifestWork\)/);
    assert.match(html, /onClick:\(\)=>C\(\[\]\)/);
    assert.match(html, /const positionDetailPanel = \(\) =>/);
    assert.match(html, /detail\.style\.top = Math\.max\(0, flowRect\.top - appRect\.top\) \+ 'px'/);
    assert.match(html, /detail\.style\.height = Math\.max\(0, flowRect\.height\) \+ 'px'/);
    assert.match(html, /const renderedEdges = new Map/);
    assert.match(html, /const kind = rendered\.textContent\.trim\(\) === 'requires' \? 'dependency' : 'structure'/);
    assert.match(html, /const rendered = renderedEdges\.get\(edge\.id\)/);
    assert.doesNotMatch(html, /human\.graph\.edges\.forEach\(\(edge, index\)/);
    assert.match(html, /return new Set\(\[\.\.\.mapped, \.\.\.mapped\.flatMap\(workAncestors\)\]\)/);
    assert.match(html, /edge\.kind === 'structure'/);
    assert.match(html, /button\.dataset\.ancestorContext = String\(workAncestors\(selectedItem\)\.includes\(slice\.id\)\)/);
    const contextCode = html.match(/  const structureParents = [\s\S]*?(?=  const matchFor =)/)?.[0];
    assert.ok(contextCode);
    const selection = { mappedNodeIds: ["child"] };
    const contextResult = runInNewContext(contextCode + "JSON.stringify([...highlightedNodeIds()])", {
      human: { graph: { edges: [
        { kind: "structure", source: "objective", target: "stream" },
        { kind: "structure", source: "stream", target: "parent" },
        { kind: "structure", source: "parent", target: "child" },
        { kind: "structure", source: "parent", target: "sibling" },
        { kind: "dependency", source: "sibling", target: "child" },
      ] } },
      nodes: new Map([
        ["objective", { kind: "objective" }],
        ["stream", { kind: "workstream" }],
        ["parent", { kind: "task" }],
      ]),
      selectedSlice: () => selection,
      selectedStage: () => null,
    });
    assert.deepEqual(JSON.parse(contextResult), ["child", "parent", "stream", "objective"]);
    assert.deepEqual(selection.mappedNodeIds, ["child"], "ancestor context must not mutate completion coverage");
    assert.match(html, /replaceQuery\(\{ stream: id, item: null, surface: null \}\)/);
    assert.match(html, /const colorEdgeForTarget = \(rendered, edge, target\) =>/);
    assert.match(html, /path\.style\.strokeDasharray = edge\.kind === 'dependency' \? '6 5' : 'none'/);
    assert.match(html, /const edgeStage = filter !== 'all' && matchFor\(target\) === 'primary' \? filter : ownership\.get\(target\.id\)\.primary/);
    assert.match(html, /const graphComplete = node\.state === 'complete'/);
    assert.match(html, /const graphDiscontinued = node\.state === 'discontinued'/);
    assert.match(html, /const complete = graphComplete \|\| presentationComplete/);
    assert.match(html, /create\('span', 'implementation-owner__discontinued', '×'\)/);
    assert.match(html, /markerEnd:S\?\.kind==="dependency"\?\{type:Z6\.ArrowClosed,color:y\}:C,style:\{stroke:y,strokeWidth:1\.5\}/);
    assert.doesNotMatch(html, /strokeDasharray:S\?\.kind==="dependency"/);
    assert.doesNotMatch(html, /Action proposal|durable continuation checkpoint/);
    assert.match(html, /manifest-surface-switch/);
    assert.match(html, /const targetKey = JSON\.stringify\(\[target\.repository, target\.objectiveId\]\)/);
    assert.match(html, /const surfaceKey = 'manifest-human-surface-v2::' \+ targetKey/);
    assert.match(html, /const stateKey = 'manifest-map-implementation-view-v6::' \+ targetKey/);
    assert.match(html, /sessionStorage\.setItem\(surfaceKey, nextSurface\)/);
    assert.match(html, /surface = nextSurface/);
    assert.match(html, /applySurface\(\)/);
    assert.doesNotMatch(html, /sessionStorage\.setItem\(surfaceKey, nextSurface\); \} catch \{\}\s*location\.reload\(\)/);
    assert.match(html, /let surfaceNavigation = null/);
    assert.match(html, /if \(surfaceNavigation\.parentElement !== controls\) controls\.prepend\(surfaceNavigation\)/);
    assert.doesNotMatch(html, /viewport\.style\.transform =|rememberImplementationFrame/);
    assert.match(html, /title\.textContent = human\.objective\.title \+ ' · ' \+ implementationLabel/);
    assert.doesNotMatch(html, /card\.style\.removeProperty\('--implementation-color'\)|card\.style\.removeProperty\('border-color'\)/);
    assert.doesNotMatch(html, /const clearImplementationDetails|\.implementation-detail'\)\.forEach\(element => element\.remove/);
    assert.match(html, /normalizeSharedCards\(\);\s*buildShell\(\);\s*applySurface\(\)/);
    assert.doesNotMatch(html, /applySurface = \(\) => \{[^}]*normalizeSharedCards\(\)/s);
    assert.match(html, /html\[data-manifest-surface="planning"\] \.manifest-view-shell,\s*html\[data-manifest-surface="planning"\] \.manifest-panel-toggle \{ display: none !important; \}/);
    assert.doesNotMatch(html, /html\[data-manifest-surface="planning"\] \.manifest-view-shell \{ visibility: hidden !important; \}/);
    assert.doesNotMatch(html, /--manifest-implementation-rail-(?:width|height)|\.manifest-view-shell \+ #root|graphRoot\.before\(shell\)/);
    assert.match(html, /\.manifest-view-shell \{\s*position: absolute;\s*z-index: 10;\s*inset: 0 auto 0 0;/);
    assert.match(html, /flow\.append\(shell\)/);
    assert.match(html, /panelToggle\.hidden = !visible/);
    assert.match(html, /shell\.hidden = !visible \|\| panelCollapsed/);
    assert.match(html, /const label = panelCollapsed \? 'Show progress' : 'Hide progress'/);
    assert.match(html, /plan: projectionKey, panelCollapsed/);
    assert.match(html, /html\[data-manifest-surface="planning"\] \.implementation-detail \{ display: none; \}/);
    assert.match(html, /\.manifest-card:not\(\.node--detail\) \{[^}]*border: 1px solid var\(--manifest-card-color\);[^}]*box-shadow: 0 0 0 4px color-mix\(in srgb, var\(--manifest-card-color\) 8%, transparent\);/s);
    assert.doesNotMatch(html, /\.react-flow__node > \.node:not\(\.node--detail\)/);
    assert.doesNotMatch(html, /box-shadow: inset 3px 0 0 var\(--implementation-color\)/);
    assert.doesNotMatch(html, /fetch\([^)]*(?:surface|phase)[^)]*\)/);
    assert.match(html, /objective: '#7aa2f7'/);
    assert.match(html, /workstream: '#34e2c9'/);
    assert.match(html, /task: '#ff5c57'/);
    assert.match(html, /node\?\.decomposed \? '#ffffff'/);
    assert.doesNotMatch(html, /rendered\.style\.removeProperty\('--implementation-color'\)/);
    assert.match(html, /path\.style\.strokeDasharray = edge\.kind === 'dependency' \? '6 5' : 'none'/);
    assert.match(html, /document\.documentElement\.dataset\.manifestSurface = surface/);

    const api = await fetch(`${server.url}/api/objectives/${validated.graph.id}`).then((result) => result.json());
    assert.equal(api.objective.id, validated.graph.id);
    assert.equal(api.graph.nodes.length, 4);
  } finally {
    await server.close();
  }
});

test("served selection derives the full structural lineage and shares graph/sidebar routing", async () => {
  const repository = await gitRepository();
  const validated = validateObjective(objective);
  assert.equal(validated.valid, true);
  if (!validated.valid) return;
  await createObjectiveFile(repository, validated.graph);
  const server = await startManifestViewServer({ repository, host: "127.0.0.1", port: 0 });
  try {
    const html = await fetch(qualifiedObjectiveUrl(server.url, repository, validated.graph.id)).then((response) => response.text());
    const source = html.match(/<script id="manifest-implementation-view">([\s\S]*?)<\/script>/)![1]!;
    assert.match(source, /const workAncestors = id =>/);
    assert.match(source, /const taskAncestors = id =>/);
    assert.match(source, /const highlightedNodeIds = \(\) =>/);
    assert.match(source, /\.flatMap\(workAncestors\)/);
    assert.match(source, /const selectWork = \(id, toggleDetail = false\) =>/);

    const contextCode = source.match(/  const structureParents = [\s\S]*?(?=  const matchFor =)/)?.[0];
    assert.ok(contextCode);
    const contextResult = runInNewContext(
      contextCode + `JSON.stringify({
        nested: workAncestors("child"),
        nestedTasks: taskAncestors("child"),
        topLevel: workAncestors("top"),
        topLevelTasks: taskAncestors("top"),
        highlighted: [...highlightedNodeIds()],
        coverage: selectedSlice().mappedNodeIds,
      })`,
      {
        human: { graph: { edges: [
          { kind: "structure", source: "objective", target: "stream" },
          { kind: "structure", source: "stream", target: "top" },
          { kind: "structure", source: "stream", target: "parent" },
          { kind: "structure", source: "parent", target: "child" },
          { kind: "structure", source: "parent", target: "sibling" },
          { kind: "dependency", source: "sibling", target: "child" },
        ] } },
        nodes: new Map([
          ["objective", { kind: "objective" }],
          ["stream", { kind: "workstream" }],
          ["top", { kind: "task" }],
          ["parent", { kind: "task" }],
          ["child", { kind: "task" }],
          ["sibling", { kind: "task" }],
        ]),
        selectedSlice: () => ({ mappedNodeIds: ["child"] }),
        selectedStage: () => null,
      },
    );
    assert.deepEqual(JSON.parse(contextResult), {
      nested: ["parent", "stream", "objective"],
      nestedTasks: ["parent"],
      topLevel: ["stream", "objective"],
      topLevelTasks: [],
      highlighted: ["child", "parent", "stream", "objective"],
      coverage: ["child"],
    });

    const handlerCode = source.match(/  const setItem = id => \{[\s\S]*?(?=  const makeStep = stage =>)/)?.[0];
    assert.ok(handlerCode);
    const handlerResult = runInNewContext(
      `let filter = "all"; let selectedItem = null; let selectedId = null;
       const calls = []; const events = [];
       const slices = new Map([["child", { stageId: "W2" }]]);
       const stages = new Map([["W2", {}]]);
       const nodes = new Map([
         ["objective", { kind: "objective" }],
         ["child", { kind: "task" }],
         ["unmapped", { kind: "task" }],
       ]);
       const ownership = new Map([["unmapped", { primary: "W2" }]]);
       const replaceQuery = changes => calls.push(["query", changes]);
       const updateControls = () => calls.push(["update"]);
       const save = () => calls.push(["save"]);
       const workAncestors = id => id === "child" || id === "unmapped" ? ["W2", "objective"] : id === "W2" ? ["objective"] : [];
       const CustomEvent = class { constructor(type, init) { this.type = type; this.detail = init.detail; } };
       const window = { dispatchEvent: event => events.push({ type: event.type, detail: event.detail }) };
       ${handlerCode}
       selectWork("child");
       const fromGraph = { filter, selectedItem, selectedId, calls: calls.slice(), events: events.slice() };
       calls.length = 0; events.length = 0;
       selectedItem = null; selectedId = null; filter = "all";
       selectWork("W2");
       const fromSidebarStage = { filter, selectedItem, selectedId, calls: calls.slice(), events: events.slice() };
       calls.length = 0; events.length = 0;
       selectedItem = null; selectedId = null; filter = "W2";
       selectWork("objective");
       const fromObjective = { filter, selectedItem, selectedId, calls: calls.slice(), events: events.slice() };
       calls.length = 0; events.length = 0;
       selectedItem = null; selectedId = null; filter = "all";
       selectWork("unmapped");
       JSON.stringify({ fromGraph, fromSidebarStage, fromObjective, fromUnmapped: { filter, selectedItem, selectedId, calls, events } })`,
      { Map },
    );
    const handlers = JSON.parse(handlerResult);
    assert.deepEqual(handlers.fromGraph, {
      filter: "W2",
      selectedItem: "child",
      selectedId: "child",
      calls: [["query", { stream: "W2", item: "child", surface: null }], ["update"]],
      events: [{ type: "manifest-work-selection", detail: { id: "child", ancestors: ["W2", "objective"] } }],
    });
    assert.deepEqual(handlers.fromSidebarStage, {
      filter: "W2",
      selectedItem: null,
      selectedId: null,
      calls: [["query", { stream: "W2", item: null, surface: null }], ["update"]],
      events: [{ type: "manifest-work-selection", detail: { id: "W2", ancestors: ["objective"] } }],
    });
    assert.deepEqual(handlers.fromObjective, {
      filter: "all",
      selectedItem: null,
      selectedId: "objective",
      calls: [["query", { stream: "all", item: null, surface: null }], ["update"]],
      events: [{ type: "manifest-work-selection", detail: { id: "objective", ancestors: [] } }],
    });
    assert.deepEqual(handlers.fromUnmapped, {
      filter: "W2",
      selectedItem: null,
      selectedId: "unmapped",
      calls: [["query", { stream: "W2", item: null, surface: null }], ["update"]],
      events: [{ type: "manifest-work-selection", detail: { id: "unmapped", ancestors: ["W2", "objective"] } }],
    });

    assert.match(source, /button\.addEventListener\('click', \(\) => selectWork\(slice\.id\)\)/);
    assert.match(source, /button\.addEventListener\('click', \(\) => selectWork\(stage\.id\)\)/);
    assert.match(source, /all\.addEventListener\('click', \(\) => selectWork\('all'\)\)/);
    assert.match(source, /if \(id && nodes\.has\(id\)\) \{[\s\S]*?selectWork\(id, true\)/);
    assert.doesNotMatch(source, /surface === 'implementation'[\s\S]{0,120}selectWork\(id\)/);

    const nativeListenerBody = html.match(
      /const selectManifestWork=event=>\{([\s\S]*?)\};window\.addEventListener\("manifest-work-selection",selectManifestWork\)/,
    )?.[1];
    assert.ok(nativeListenerBody);
    const nativeCalls: unknown[] = [];
    const nativeListener = runInNewContext(
      `const selectManifestWork = event => {${nativeListenerBody}}; selectManifestWork;`,
      {
        C: (value: unknown) => nativeCalls.push(["selection", value]),
        g: (update: (previous: Set<string>) => Set<string>) => nativeCalls.push(["expansion", [...update(new Set(["unrelated"]))]]),
        hm: {
          objective: {}, stream: {}, parent: {}, child: {}, sibling: {}, "new-descendant": {},
        },
        S: [],
        k: "node",
      },
    ) as (event: { detail: { id: string | null; ancestors: string[] } }) => void;
    nativeListener({ detail: { id: "child", ancestors: ["parent", "stream", "objective"] } });
    nativeListener({ detail: { id: "objective", ancestors: [] } });
    nativeListener({ detail: { id: null, ancestors: [] } });
    assert.deepEqual(JSON.parse(JSON.stringify(nativeCalls)), [
      ["selection", ["child"]],
      ["expansion", ["unrelated", "parent", "stream", "objective"]],
      ["selection", ["objective"]],
      ["expansion", ["unrelated"]],
      ["selection", []],
      ["expansion", ["unrelated"]],
    ], "native projection expands only supplied structural ancestors and never fits the viewport");
    const selectionFor = (selected: string[], mode: "node" | "panel", toggleDetail: boolean) => {
      const calls: unknown[] = [];
      const listener = runInNewContext(
        `const selectManifestWork = event => {${nativeListenerBody}}; selectManifestWork;`,
        {
          C: (value: unknown) => calls.push(value),
          g: () => {},
          hm: { child: {}, sibling: {} },
          S: selected,
          k: mode,
        },
      ) as (event: { detail: { id: string; ancestors: string[]; toggleDetail: boolean } }) => void;
      listener({ detail: { id: "child", ancestors: [], toggleDetail } });
      return JSON.parse(JSON.stringify(calls[0]));
    };
    assert.deepEqual(selectionFor([], "node", true), ["child"], "a graph-card click opens its detail");
    assert.deepEqual(selectionFor(["child"], "node", true), [], "a second graph-card click closes its detail");
    assert.deepEqual(selectionFor([], "node", true), ["child"], "a later graph-card click reopens its detail");
    assert.deepEqual(selectionFor(["child"], "panel", true), ["child"], "panel-mode card clicks retain their selection");
    assert.doesNotMatch(nativeListenerBody, /fitView|setViewport|viewport/);
  } finally {
    await server.close();
  }
});

test("repository index keeps multiple and invalid Objective files visible", async () => {
  const repository = await gitRepository();
  const validated = validateObjective(objective);
  assert.equal(validated.valid, true);
  if (!validated.valid) return;
  await createObjectiveFile(repository, validated.graph);
  const second = validateObjective({
    ...validated.graph,
    id: "obj_99999999999999999999999999999999",
    title: "Second Objective",
  });
  assert.equal(second.valid, true);
  if (!second.valid) return;
  await createObjectiveFile(repository, second.graph);
  const objectives = join(repository, ".manifest", "objectives");
  await mkdir(objectives, { recursive: true });
  await writeFile(join(objectives, "obj_88888888888888888888888888888888.json"), "{ invalid", "utf8");

  const server = await startManifestViewServer({ repository, host: "127.0.0.1", port: 0 });
  try {
    const html = await fetch(new URL("/objectives", server.url)).then((response) => response.text());
    assert.match(html, /data-testid="manifest-objectives-landing"/);
    assert.match(html, /fetch\("\/api\/discovery"/);
    const discovered = await fetch(new URL("/api/discovery", server.url)).then((response) => response.json()) as {
      repositories: Array<{ objectives: Array<{ valid: boolean; objective?: { title: string } }> }>;
    };
    const entries = discovered.repositories.flatMap((item) => item.objectives);
    assert.equal(entries.filter((item) => item.valid && item.objective?.title === "Manifest V2").length, 1);
    assert.equal(entries.filter((item) => item.valid && item.objective?.title === "Second Objective").length, 1);
    assert.equal(entries.some((item) => !item.valid), true);
  } finally {
    await server.close();
  }
});

test("Manifest fails on a port collision instead of moving to another service port", async () => {
  const repository = await gitRepository();
  const first = await startManifestViewServer({ repository, host: "127.0.0.1", port: 0 });
  try {
    const occupiedPort = Number(new URL(first.url).port);
    await assert.rejects(
      startManifestViewServer({ repository, host: "127.0.0.1", port: occupiedPort }),
      (error: NodeJS.ErrnoException) => error.code === "EADDRINUSE",
    );
  } finally {
    await first.close();
  }
});

test("Objective data cannot break out of its JSON or title containers", async () => {
  const repository = await gitRepository();
  const validated = validateObjective({
    ...objective,
    id: "obj_77777777777777777777777777777777",
    title: "</title><script>window.bad = true</script>",
    outcome: "</script><script>window.worse = true</script>",
  });
  assert.equal(validated.valid, true);
  if (!validated.valid) return;
  await createObjectiveFile(repository, validated.graph);
  const server = await startManifestViewServer({ repository, host: "127.0.0.1", port: 0 });
  try {
    const html = await fetch(qualifiedObjectiveUrl(server.url, repository, validated.graph.id)).then((response) => response.text());
    assert.doesNotMatch(html, /<script>window\.(?:bad|worse)/);
    assert.match(html, /\\u003c\/script>/);
    assert.match(html, /&lt;\/title&gt;/);
  } finally {
    await server.close();
  }
});


test("completed Objectives derive their listing status and open Complete on All while preserving explicit links", async () => {
  const repository = await gitRepository();
  const completed = structuredClone(objective);
  const validated = validateObjective({ ...completed, workstreams: completed.workstreams.map(stream => ({
    ...stream, tasks: stream.tasks.map(task => ({ ...task, completion: { evidence: task.completionCriteria.map(criterion => ({
      criterion, summary: "Verified completion fixture.", references: ["test/manifest-view.test.ts"],
    })) } })),
  })) });
  assert.equal(validated.valid, true);
  if (!validated.valid) return;
  await createObjectiveFile(repository, validated.graph);
  const entries = await discoverObjectives(repository);
  assert.equal(entries[0]?.valid && entries[0].objective.complete, true);
  assert.equal(entries[0]?.valid && entries[0].objective.phase, "implementation");
  const human = buildManifestHumanView(validated.graph);
  assert.equal(human.progress.complete, true);
  assert.match(human.graph.nodes[0]!.sublabel, /Objective · Complete/);
  const server = await startManifestViewServer({ repository, port: 0 });
  try {
    const html = await fetch(qualifiedObjectiveUrl(server.url, repository, validated.graph.id)).then(r => r.text());
    const ui = executeHumanInterfaceScript(html, { savedSurface: "planning" });
    assert.equal(ui.documentElement.dataset.manifestSurface, "implementation");
    assert.equal(ui.title.textContent, "Manifest V2 · Complete");
    const planning = executeHumanInterfaceScript(html, { search: "?manifest-surface=planning" });
    assert.equal(planning.documentElement.dataset.manifestSurface, "planning");
    const source = html.match(/<script id="manifest-implementation-view">([\s\S]*?)<\/script>/)![1]!;
    const selection = source.match(/  const fallbackStage = [\s\S]*?(?=  const appendDefinition =)/)![0];
    const stage = { id: "W1", status: "complete", slices: [{ id: "W1.1", status: "complete", stageId: "W1" }] };
    const run = (complete: boolean, search: string) => JSON.parse(runInNewContext(selection +
      "JSON.stringify({ filter, selectedItem, panelCollapsed })", {
      objectiveComplete: complete, planStages: [stage], plan: { currentStage: "W1", currentSlice: "W1.1" },
      human: { graph: { nodes: [] } },
      stages: new Map([[stage.id, stage]]), slices: new Map([["W1.1", stage.slices[0]]]), targetKey: "target",
      requested: new URLSearchParams(search), sessionStorage: { getItem: () => JSON.stringify({
        plan: "W1.1", filter: "W1", item: "W1.1", panelCollapsed: true,
      }) },
    }));
    assert.deepEqual(run(true, ""), { filter: "all", selectedItem: null, panelCollapsed: true });
    assert.deepEqual(run(true, "stream=W1&item=W1.1"), { filter: "W1", selectedItem: "W1.1", panelCollapsed: true });
    assert.deepEqual(run(false, ""), { filter: "W1", selectedItem: "W1.1", panelCollapsed: true });
    const currentStage = { id: "W2", status: "upcoming", slices: [{ id: "W2.1", stageId: "W2", status: "upcoming", mappedNodeIds: ["next-task"] }] };
    const dashboard = (plan: object, search = "stream=current") => JSON.parse(runInNewContext(selection +
      "JSON.stringify({ filter, selectedItem })", {
      objectiveComplete: false, planStages: [stage, currentStage], plan,
      human: { graph: { nodes: [{ id: "next-task", kind: "task", state: "next" }] } },
      stages: new Map([[stage.id, stage], [currentStage.id, currentStage]]),
      slices: new Map([["W1.1", stage.slices[0]], ["W2.1", currentStage.slices[0]]]), targetKey: "target",
      requested: new URLSearchParams(search), sessionStorage: { getItem: () => JSON.stringify({
        plan: "no-current-work", filter: "W1", item: "W1.1",
      }) },
    }));
    assert.deepEqual(dashboard({}), { filter: "W2", selectedItem: "W2.1" });
    assert.deepEqual(dashboard({ currentStage: "W1", currentSlice: "W1.1" }), { filter: "W1", selectedItem: "W1.1" });
    assert.deepEqual(dashboard({}, "stream=W1&item=W1.1"), { filter: "W1", selectedItem: "W1.1" });
    const landing = await fetch(new URL("/objectives", server.url)).then(r => r.text());
    assert.match(landing, /&stream=current&manifest-surface=implementation/);
  } finally { await server.close(); }
});
