import assert from "node:assert/strict";
import { test } from "node:test";

import {
  BrowserConfigurationError,
  desiredCodexBrowserRegistrations,
  installCodexBrowserRegistrations,
  readCodexBrowserRegistrationStatus,
  uninstallCodexBrowserRegistrations,
  validateCodexBrowserRegistrations,
} from "../src/browser/index.ts";
import type { BrowserCommandRunner } from "../src/browser/index.ts";

type StoredRegistration = {
  name: string;
  enabled: boolean;
  disabled_reason: string | null;
  enabled_tools: string[] | null;
  disabled_tools: string[] | null;
  startup_timeout_sec: number | null;
  tool_timeout_sec: number | null;
  transport: {
    type: "stdio";
    command: string;
    args: string[];
    env: Record<string, string> | null;
    env_vars: string[];
    cwd: string | null;
  };
};

function storedRegistration(
  name: string,
  command: string,
  args: string[] = [],
  overrides: Partial<Omit<StoredRegistration, "name" | "transport">> = {},
): StoredRegistration {
  return {
    name,
    enabled: true,
    disabled_reason: null,
    enabled_tools: null,
    disabled_tools: null,
    startup_timeout_sec: null,
    tool_timeout_sec: null,
    transport: { type: "stdio", command, args, env: null, env_vars: [], cwd: null },
    ...overrides,
  };
}

function codexRegistryFake(initial: StoredRegistration[] = [], failAddName?: string): {
  run: BrowserCommandRunner;
  registry: Map<string, StoredRegistration>;
  calls: string[][];
} {
  const registry = new Map(initial.map((entry) => [entry.name, structuredClone(entry)]));
  const calls: string[][] = [];
  const run: BrowserCommandRunner = async (command, args) => {
    assert.equal(command, "codex");
    calls.push(args);
    if (args[0] !== "mcp") return { status: 1, stdout: "", stderr: "unexpected command" };
    const action = args[1];
    const name = args[2];
    if (!name) return { status: 1, stdout: "", stderr: "missing name" };
    if (action === "get") {
      const entry = registry.get(name);
      return entry
        ? { status: 0, stdout: JSON.stringify(entry), stderr: "" }
        : { status: 1, stdout: "", stderr: `Error: No MCP server named '${name}' found.` };
    }
    if (action === "remove") {
      registry.delete(name);
      return { status: 0, stdout: "", stderr: "" };
    }
    if (action === "add") {
      if (name === failAddName) return { status: 1, stdout: "", stderr: "simulated add failure" };
      const separator = args.indexOf("--");
      if (separator < 0 || !args[separator + 1]) return { status: 1, stdout: "", stderr: "missing stdio command" };
      registry.set(name, {
        name,
        enabled: true,
        disabled_reason: null,
        enabled_tools: null,
        disabled_tools: null,
        startup_timeout_sec: null,
        tool_timeout_sec: null,
        transport: {
          type: "stdio",
          command: args[separator + 1],
          args: args.slice(separator + 2),
          env: null,
          env_vars: [],
          cwd: null,
        },
      });
      return { status: 0, stdout: "", stderr: "" };
    }
    return { status: 1, stdout: "", stderr: "unexpected action" };
  };
  return { run, registry, calls };
}

test("desired Codex registrations expose separate local and corporate namespaces", () => {
  const desired = desiredCodexBrowserRegistrations("/opt/anvil/bin/anvil.ts");

  assert.deepEqual(desired, [
    {
      name: "agent-browser",
      command: "/opt/anvil/bin/anvil.ts",
      args: ["browser", "mcp", "serve", "--network-mode", "local"],
    },
    {
      name: "agent-browser-corporate",
      command: "/opt/anvil/bin/anvil.ts",
      args: ["browser", "mcp", "serve", "--network-mode", "corporate"],
    },
  ]);
});

test("Codex registration install is idempotent and verifies both entries", async () => {
  const desired = desiredCodexBrowserRegistrations("/opt/anvil/bin/anvil.ts");
  const existing = desired.map((entry) => storedRegistration(entry.name, entry.command, entry.args));
  const fake = codexRegistryFake(existing);

  const result = await installCodexBrowserRegistrations({ anvilCommand: "/opt/anvil/bin/anvil.ts", run: fake.run });

  assert.equal(result.changed, false);
  assert.deepEqual(result.status, { local: "matches", corporate: "matches" });
  assert.equal(fake.calls.some((args) => args[1] === "add" || args[1] === "remove"), false);
});

test("Codex registration install restores the prior wrapper when the second add fails", async () => {
  const prior = storedRegistration("agent-browser", "/Users/test/.local/bin/old-wrapper");
  const fake = codexRegistryFake([prior], "agent-browser-corporate");

  await assert.rejects(
    installCodexBrowserRegistrations({ anvilCommand: "/opt/anvil/bin/anvil.ts", run: fake.run }),
    (error: unknown) => error instanceof BrowserConfigurationError && error.code === "CODEX_REGISTRATION_DRIFT",
  );

  assert.deepEqual(fake.registry.get("agent-browser"), prior);
  assert.equal(fake.registry.has("agent-browser-corporate"), false);
});

test("Codex registration status is read-only and reports drift without mutating it", async () => {
  const fake = codexRegistryFake([
    storedRegistration("agent-browser", "/tmp/not-anvil"),
  ]);

  const status = await readCodexBrowserRegistrationStatus({ anvilCommand: "/opt/anvil/bin/anvil.ts", run: fake.run });
  assert.deepEqual(status, { local: "drifted", corporate: "missing" });
  assert.equal(fake.calls.every((args) => args[1] === "get"), true);
});

test("Codex uninstall removes only exact Anvil-owned entries", async () => {
  const desired = desiredCodexBrowserRegistrations("/opt/anvil/bin/anvil.ts");
  const fake = codexRegistryFake(desired.map((entry) => storedRegistration(entry.name, entry.command, entry.args)));
  await uninstallCodexBrowserRegistrations({ anvilCommand: "/opt/anvil/bin/anvil.ts", run: fake.run });
  assert.equal(fake.registry.size, 0);

  const drifted = codexRegistryFake([
    storedRegistration("agent-browser", "/tmp/not-anvil"),
  ]);
  await assert.rejects(
    uninstallCodexBrowserRegistrations({ anvilCommand: "/opt/anvil/bin/anvil.ts", run: drifted.run }),
    (error: unknown) => error instanceof BrowserConfigurationError && error.code === "CODEX_REGISTRATION_DRIFT",
  );
  assert.equal(drifted.registry.has("agent-browser"), true);
});

test("Codex registration preflight rejects metadata Anvil cannot restore before mutation", async () => {
  const prior = storedRegistration("agent-browser", "/Users/test/.local/bin/old-wrapper", [], {
    startup_timeout_sec: 45,
  });
  const fake = codexRegistryFake([prior]);

  await assert.rejects(
    validateCodexBrowserRegistrations({ anvilCommand: "/opt/anvil/bin/anvil.ts", run: fake.run }),
    (error: unknown) => error instanceof BrowserConfigurationError && error.code === "CODEX_REGISTRATION_DRIFT",
  );
  assert.equal(fake.calls.every((args) => args[1] === "get"), true);
  assert.deepEqual(fake.registry.get("agent-browser"), prior);
});

test("Codex registration reads do not mistake an unsupported CLI for a missing entry", async () => {
  const run: BrowserCommandRunner = async () => ({
    status: 2,
    stdout: "",
    stderr: "error: unknown option '--json'",
  });

  await assert.rejects(
    readCodexBrowserRegistrationStatus({ anvilCommand: "/opt/anvil/bin/anvil.ts", run }),
    (error: unknown) => error instanceof BrowserConfigurationError && error.code === "CODEX_REGISTRATION_DRIFT",
  );
});
