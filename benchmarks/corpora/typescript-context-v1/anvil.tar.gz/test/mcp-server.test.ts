import assert from "node:assert/strict";
import { execFileSync } from "node:child_process";
import { mkdir, mkdtemp, readFile, realpath, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join, resolve } from "node:path";
import { test } from "node:test";

import { Client } from "@modelcontextprotocol/client";
import { StdioClientTransport } from "@modelcontextprotocol/client/stdio";
import { bindWorkContext } from "../src/work-context/index.ts";
import { deriveContinuityPaths, recordContinuityEvent } from "../src/continuity/index.ts";
import {
  manifestChangeOutputSchema,
  manifestCreateOutputSchema,
  manifestInquireOutputSchema,
  manifestOrientOutputSchema,
} from "../src/mcp/manifest.ts";
import {
  brainSetupOutputSchema,
  brainUsageLogOutputSchema,
  brainUsageMetricsOutputSchema,
  brainUsageReadOutputSchema,
  continuityCheckpointTaskOutputSchema,
  continuityReadOutputSchema,
  continuityRecordEventOutputSchema,
  sessionBootstrapOutputSchema,
  skillInvocationAuditSampleOutputSchema,
  skillInvocationLogOutputSchema,
  skillInvocationReadOutputSchema,
  workContextReadOutputSchema,
} from "../src/mcp/tools.ts";

const anvilBin = resolve("bin/anvil.ts");
const expectedToolNames = [
  "anvil_brain_setup",
  "anvil_brain_usage_log",
  "anvil_brain_usage_metrics",
  "anvil_brain_usage_read",
  "anvil_continuity_checkpoint_task",
  "anvil_continuity_promote_event",
  "anvil_continuity_read",
  "anvil_continuity_record_event",
  "anvil_continuity_retire_projection_item",
  "anvil_manifest_change",
  "anvil_manifest_create",
  "anvil_manifest_inquire",
  "anvil_manifest_orient",
  "anvil_session_bootstrap",
  "anvil_skill_invocation_audit_sample",
  "anvil_skill_invocation_log",
  "anvil_skill_invocation_read",
  "anvil_tool_result_health",
  "anvil_tool_result_manifest",
  "anvil_tool_result_read_slice",
  "anvil_tool_result_search",
  "anvil_work_context_read",
] as const;

function childEnv(extra: Record<string, string>): Record<string, string> {
  const env: Record<string, string> = {};
  for (const [key, value] of Object.entries(process.env)) {
    if (value !== undefined) env[key] = value;
  }
  return { ...env, ...extra };
}

test("anvil mcp serve exposes Anvil tools over stdio", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-mcp-server-"));
  const client = new Client({ name: "anvil-test-client", version: "0.0.0" });
  try {
    const repo = join(temp, "repo");
    const stateRoot = join(temp, "state");
    await mkdir(repo, { recursive: true });
    execFileSync("git", ["init", "-q"], { cwd: repo });

    const transport = new StdioClientTransport({
      command: process.execPath,
      args: ["bin/anvil.ts", "mcp", "serve"],
      cwd: resolve("."),
      env: childEnv({ ANVIL_STATE_ROOT: stateRoot }),
      stderr: "pipe",
    });

    await client.connect(transport);

    const instructions = client.getInstructions() ?? "";
    assert.match(instructions, /turn the Brain on/i);
    assert.match(instructions, /dry_run mode/i);
    assert.match(instructions, /plan_hash and acknowledgement_token/i);
    assert.match(instructions, /Codex, Claude, or another local agent host/i);
    assert.match(instructions, /anvil_brain_usage_log/i);
    assert.match(instructions, /automatic recall events remain prompt-hook-owned/i);
    assert.match(instructions, /anvil_skill_invocation_log/i);
    assert.match(instructions, /operational evidence, not continuity/i);
    assert.match(instructions, /current main agent acts as Brain Steward/i);
    assert.match(instructions, /standard Brain Steward workflow in the target Brain's wiki-agent\.md/i);
    assert.match(instructions, /llm-wiki's read-only maintenance proposal/i);
    assert.match(instructions, /read and obey that manual/i);
    assert.doesNotMatch(instructions, /installed Brain Steward skill/i);
    assert.doesNotMatch(instructions, /handoff|queue|Stop.*Steward child/i);
    assert.doesNotMatch(instructions, /never author Brain outside/i);

    const tools = await client.listTools();
    assert.deepEqual(
      tools.tools.map((tool) => tool.name).sort(),
      [...expectedToolNames],
    );
    const missingOutputSchemas = tools.tools.filter((tool) => tool.outputSchema === undefined).map((tool) => tool.name);
    assert.deepEqual(
      missingOutputSchemas,
      [],
      `Anvil MCP tools missing outputSchema: ${missingOutputSchemas.join(", ")}`,
    );
    for (const tool of tools.tools) {
      assert.equal(typeof tool.outputSchema, "object", `${tool.name} outputSchema must be an object`);
    }
    for (const name of ["anvil_manifest_orient", "anvil_manifest_inquire"] as const) {
      const tool = tools.tools.find((candidate) => candidate.name === name);
      assert.equal(tool?.annotations?.readOnlyHint, true);
      assert.equal(tool?.annotations?.destructiveHint, false);
      assert.equal(tool?.annotations?.idempotentHint, true);
      assert.equal(tool?.annotations?.openWorldHint, false);
    }
    for (const name of ["anvil_manifest_create", "anvil_manifest_change"] as const) {
      const tool = tools.tools.find((candidate) => candidate.name === name);
      assert.equal(tool?.annotations?.readOnlyHint, false);
      assert.equal(tool?.annotations?.destructiveHint, false);
      assert.equal(tool?.annotations?.idempotentHint, false);
      assert.equal(tool?.annotations?.openWorldHint, false);
    }
    for (const name of [
      "anvil_manifest_create",
      "anvil_manifest_orient",
      "anvil_manifest_inquire",
      "anvil_manifest_change",
    ] as const) {
      const tool = tools.tools.find((candidate) => candidate.name === name);
      const input = tool?.inputSchema as { additionalProperties?: boolean; properties?: Record<string, unknown> };
      const output = tool?.outputSchema as { additionalProperties?: boolean };
      assert.equal(input.additionalProperties, false, `${name} input must be closed`);
      assert.equal(output.additionalProperties, false, `${name} output must be closed`);
      assert.equal("repository" in (input.properties ?? {}), true);
      assert.equal("bindingId" in (input.properties ?? {}), false);
      assert.equal("stateRoot" in (input.properties ?? {}), false);
    }
    const bootstrapTool = tools.tools.find((tool) => tool.name === "anvil_session_bootstrap");
    assert.equal(bootstrapTool?.annotations?.readOnlyHint, true);
    assert.equal(bootstrapTool?.annotations?.destructiveHint, false);
    assert.equal(bootstrapTool?.annotations?.idempotentHint, true);
    assert.equal(bootstrapTool?.annotations?.openWorldHint, false);
    const workContextTool = tools.tools.find((tool) => tool.name === "anvil_work_context_read");
    assert.equal(workContextTool?.annotations?.readOnlyHint, true);
    assert.equal(workContextTool?.annotations?.destructiveHint, false);
    assert.equal(workContextTool?.annotations?.idempotentHint, true);
    assert.equal(workContextTool?.annotations?.openWorldHint, false);
    const workContextOutputSchema = workContextTool?.outputSchema as {
      type?: string;
      required?: string[];
      additionalProperties?: boolean;
      properties?: { binding?: { additionalProperties?: boolean; required?: string[] } };
    };
    assert.equal(workContextOutputSchema.type, "object");
    assert.equal(workContextOutputSchema.additionalProperties, false);
    assert.equal(workContextOutputSchema.required?.includes("binding"), true);
    assert.equal(workContextOutputSchema.properties?.binding?.additionalProperties, false);
    assert.equal(workContextOutputSchema.properties?.binding?.required?.includes("id"), true);
    const brainSetupTool = tools.tools.find((tool) => tool.name === "anvil_brain_setup");
    assert.equal(brainSetupTool?.annotations?.readOnlyHint, false);
    assert.equal(brainSetupTool?.annotations?.destructiveHint, false);
    assert.equal(brainSetupTool?.annotations?.idempotentHint, false);
    assert.equal(brainSetupTool?.annotations?.openWorldHint, false);
    const brainUsageLogTool = tools.tools.find((tool) => tool.name === "anvil_brain_usage_log");
    const brainUsageReadTool = tools.tools.find((tool) => tool.name === "anvil_brain_usage_read");
    const brainUsageMetricsTool = tools.tools.find((tool) => tool.name === "anvil_brain_usage_metrics");
    assert.equal(brainUsageLogTool?.annotations?.readOnlyHint, false);
    assert.equal(brainUsageLogTool?.annotations?.destructiveHint, false);
    assert.equal(brainUsageLogTool?.annotations?.idempotentHint, false);
    assert.equal(brainUsageLogTool?.annotations?.openWorldHint, false);
    assert.equal(brainUsageReadTool?.annotations?.readOnlyHint, true);
    assert.equal(brainUsageReadTool?.annotations?.idempotentHint, true);
    assert.equal(brainUsageMetricsTool?.annotations?.readOnlyHint, true);
    assert.equal(brainUsageMetricsTool?.annotations?.idempotentHint, true);
    const skillInvocationLogTool = tools.tools.find((tool) => tool.name === "anvil_skill_invocation_log");
    const skillInvocationAuditTool = tools.tools.find((tool) => tool.name === "anvil_skill_invocation_audit_sample");
    const skillInvocationReadTool = tools.tools.find((tool) => tool.name === "anvil_skill_invocation_read");
    assert.equal(skillInvocationLogTool?.annotations?.readOnlyHint, false);
    assert.equal(skillInvocationLogTool?.annotations?.destructiveHint, false);
    assert.equal(skillInvocationLogTool?.annotations?.idempotentHint, false);
    assert.equal(skillInvocationLogTool?.annotations?.openWorldHint, false);
    assert.equal(skillInvocationReadTool?.annotations?.readOnlyHint, true);
    assert.equal(skillInvocationReadTool?.annotations?.destructiveHint, false);
    assert.equal(skillInvocationReadTool?.annotations?.idempotentHint, true);
    assert.equal(skillInvocationReadTool?.annotations?.openWorldHint, false);
    assert.equal(skillInvocationAuditTool?.annotations?.readOnlyHint, true);
    assert.equal(skillInvocationAuditTool?.annotations?.destructiveHint, false);
    assert.equal(skillInvocationAuditTool?.annotations?.idempotentHint, true);
    assert.equal(skillInvocationAuditTool?.annotations?.openWorldHint, false);
    const skillLogProperties =
      (skillInvocationLogTool?.inputSchema as { properties?: Record<string, unknown> } | undefined)?.properties ?? {};
    assert.equal("bindingId" in skillLogProperties, true);
    assert.equal("cwd" in skillLogProperties, false);
    assert.equal("stateRoot" in skillLogProperties, false);
    assert.deepEqual(
      ((skillLogProperties.outcome as { enum?: string[] } | undefined)?.enum ?? []).sort(),
      ["false_positive", "missed", "used"],
    );
    const skillLogRequired =
      (skillInvocationLogTool?.inputSchema as { required?: string[] } | undefined)?.required ?? [];
    assert.equal(skillLogRequired.includes("outcome"), true);
    assert.equal(skillLogRequired.includes("reason"), true);
    const logProperties = (brainUsageLogTool?.inputSchema as { properties?: Record<string, unknown> } | undefined)?.properties ?? {};
    assert.equal("bindingId" in logProperties, true);
    assert.equal("cwd" in logProperties, false);
    assert.equal("stateRoot" in logProperties, false);
    assert.equal("promptRaw" in logProperties, false);
    assert.equal("promptExcerpt" in logProperties, false);
    assert.deepEqual(
      ((logProperties.event as { enum?: string[] } | undefined)?.enum ?? []).sort(),
      ["blocked", "consulted", "eval_failed", "missed_update", "not_needed", "stale", "updated", "used", "wrong"],
    );
    const promoteTool = tools.tools.find((tool) => tool.name === "anvil_continuity_promote_event");
    const checkpointTool = tools.tools.find((tool) => tool.name === "anvil_continuity_checkpoint_task");
    const recordTool = tools.tools.find((tool) => tool.name === "anvil_continuity_record_event");
    const retireTool = tools.tools.find((tool) => tool.name === "anvil_continuity_retire_projection_item");
    for (const tool of [recordTool, checkpointTool, promoteTool, retireTool]) {
      const properties =
        (tool?.inputSchema as { properties?: Record<string, unknown> } | undefined)?.properties ?? {};
      assert.equal("bindingId" in properties, true);
      assert.equal("cwd" in properties, false);
      assert.equal("stateRoot" in properties, false);
    }
    assert.match(promoteTool?.description ?? "", /hygiene pass/i);
    assert.match(checkpointTool?.description ?? "", /singular active task/i);
    assert.equal(checkpointTool?.annotations?.idempotentHint, true);
    assert.match(retireTool?.description ?? "", /stale/i);

    const manifestCreated = manifestCreateOutputSchema.parse((await client.callTool({
      name: "anvil_manifest_create",
      arguments: {
        repository: repo,
        title: "Manifest MCP",
        outcome: "The agent and Human use the same graph.",
      },
    })).structuredContent);
    assert.equal(manifestCreated.view.phase, "planning");

    const manifestChanged = manifestChangeOutputSchema.parse((await client.callTool({
      name: "anvil_manifest_change",
      arguments: {
        repository: repo,
        objectiveId: manifestCreated.objectiveId,
        change: {
          addWorkstreams: [{ ref: "delivery", title: "Delivery", outcome: "Ship the graph.", after: null }],
          addTasks: [{
            ref: "mcp",
            workstream: "@delivery",
            title: "Expose MCP",
            outcome: "Rowan can operate on the graph.",
            decompositionComplete: true,
            completionCriteria: ["All four tools work over stdio."],
            after: null,
          }],
          update: [{ id: manifestCreated.objectiveId, set: { phase: "implementation" } }],
        },
      },
    })).structuredContent);
    assert.equal(manifestChanged.applied, true);
    assert.equal(manifestChanged.created?.length, 2);
    const taskId = manifestChanged.created?.find((item) => item.ref === "mcp")?.id;
    assert.match(taskId ?? "", /^task_/);

    const manifestOriented = manifestOrientOutputSchema.parse((await client.callTool({
      name: "anvil_manifest_orient",
      arguments: { repository: repo, objectiveId: manifestCreated.objectiveId, currentTaskId: taskId },
    })).structuredContent);
    assert.equal(manifestOriented.view.current?.id, taskId);
    assert.equal(manifestOriented.view.phase, "implementation");

    const manifestInquired = manifestInquireOutputSchema.parse((await client.callTool({
      name: "anvil_manifest_inquire",
      arguments: { repository: repo, objectiveId: manifestCreated.objectiveId, id: taskId },
    })).structuredContent);
    assert.equal(manifestInquired.result.outcome, "found");
    if (manifestInquired.result.outcome === "found") {
      assert.equal(manifestInquired.result.entity.id, taskId);
      assert.equal(manifestInquired.result.entity.decompositionComplete, true);
    }

    const read = await client.callTool({
      name: "anvil_continuity_read",
      arguments: { cwd: repo, includeEvents: true },
    });
    const output = continuityReadOutputSchema.parse(read.structuredContent);
    assert.equal(output.current.kind, "missing");
    assert.equal(output.events?.kind, "missing");

    const { binding } = await bindWorkContext({
      host: "codex",
      sessionId: "session-stdio-inspect",
      cwd: repo,
      lifecycle: "SessionStart:startup",
      stateRoot,
    });
    const inspected = await client.callTool({
      name: "anvil_work_context_read",
      arguments: { bindingId: binding.id },
    });
    const inspectedOutput = workContextReadOutputSchema.parse(inspected.structuredContent);
    assert.equal(inspectedOutput.binding.id, binding.id);
    assert.equal(inspectedOutput.binding.host, "codex");
    assert.equal("session_id" in inspectedOutput.binding, false);
    assert.equal(inspectedOutput.binding.collaboration_space.root, await realpath(repo));

    const checkpointed = await client.callTool({
      name: "anvil_continuity_checkpoint_task",
      arguments: {
        bindingId: binding.id,
        checkpointId: "stdio-active-task-1",
        task: {
          state: "active",
          summary: "Restore active-task Continuity.",
          nextStep: "Start a new SessionStart consumer.",
        },
      },
    });
    const checkpointOutput = continuityCheckpointTaskOutputSchema.parse(checkpointed.structuredContent);
    assert.equal(checkpointOutput.frame.active_task?.summary, "Restore active-task Continuity.");
    assert.match(checkpointOutput.rendered, /Start a new SessionStart consumer/);

    const rejectedInspection = await client.callTool({
      name: "anvil_work_context_read",
      arguments: { bindingId: "wctx_00000000000000000000000000000000" },
    });
    assert.equal(rejectedInspection.isError, true);
    assert.equal(
      (rejectedInspection.structuredContent as { error: { code: string } }).error.code,
      "WORK_CONTEXT_NOT_BOUND",
    );
    assert.match(rejectedInspection.content[0]?.type === "text" ? rejectedInspection.content[0].text : "", /WORK_CONTEXT_NOT_BOUND/);

    const bootstrap = await client.callTool({
      name: "anvil_session_bootstrap",
      arguments: { cwd: repo, agentId: "codex", anvilHome: join(temp, ".anvil"), mode: "local_full" },
    });
    const bootstrapOutput = sessionBootstrapOutputSchema.parse(bootstrap.structuredContent);
    assert.equal(bootstrapOutput.brain.setup_required, true);
    assert.equal(bootstrapOutput.brain.agent_id_status, "configured");
    assert.deepEqual(bootstrapOutput.loci.suggested_calls, []);
    assert.equal(
      bootstrapOutput.suggested_next_calls.some((call) => call.tool === "loci_index"),
      false,
    );

    const setup = await client.callTool({
      name: "anvil_brain_setup",
      arguments: { agentId: "codex", anvilHome: join(temp, ".anvil"), brainRoot: join(temp, ".anvil-brain", "codex") },
    });
    const setupOutput = brainSetupOutputSchema.parse(setup.structuredContent);
    assert.equal(setupOutput.status, "planned");
    assert.match(setupOutput.plan_hash, /^[a-f0-9]{64}$/);

    const logged = await client.callTool({
      name: "anvil_brain_usage_log",
      arguments: {
        bindingId: binding.id,
        event: "used",
        trigger: "The stdio MCP contract reused the Brain usage journal.",
        mcpCallId: "stdio-call-1",
      },
    });
    const loggedOutput = brainUsageLogOutputSchema.parse(logged.structuredContent);
    assert.equal(loggedOutput.record.event, "used");
    assert.equal(loggedOutput.record.mcp_call_id, "stdio-call-1");

    const metrics = await client.callTool({
      name: "anvil_brain_usage_metrics",
      arguments: { cwd: repo },
    });
    const metricsOutput = brainUsageMetricsOutputSchema.parse(metrics.structuredContent);
    assert.equal(metricsOutput.kind, "ok");
    assert.equal(metricsOutput.total, 1);
    assert.equal(metricsOutput.coverage.total, 1);

    const usage = await client.callTool({
      name: "anvil_brain_usage_read",
      arguments: { cwd: repo, limit: 1 },
    });
    const usageOutput = brainUsageReadOutputSchema.parse(usage.structuredContent);
    assert.equal(usageOutput.kind, "ok");
    assert.equal(usageOutput.total, 1);
    assert.deepEqual(usageOutput.items.map((item) => item.event), ["used"]);

    const skillLogged = await client.callTool({
      name: "anvil_skill_invocation_log",
      arguments: {
        bindingId: binding.id,
        skill: "agent-skills:using-agent-skills",
        trigger: "The stdio MCP contract selected the skill workflow.",
        outcome: "used",
        reason: "The skill selected the implementation and verification workflows.",
      },
    });
    const skillLoggedOutput = skillInvocationLogOutputSchema.parse(skillLogged.structuredContent);
    assert.equal(skillLoggedOutput.record.skill, "agent-skills:using-agent-skills");
    assert.equal(skillLoggedOutput.record.outcome, "used");
    assert.equal(skillLoggedOutput.record.host, "codex");
    assert.equal(skillLoggedOutput.record.session_id, "session-stdio-inspect");

    const skillInvocations = await client.callTool({
      name: "anvil_skill_invocation_read",
      arguments: { cwd: repo, limit: 1 },
    });
    const skillInvocationsOutput = skillInvocationReadOutputSchema.parse(skillInvocations.structuredContent);
    assert.equal(skillInvocationsOutput.kind, "ok");
    assert.equal(skillInvocationsOutput.total, 1);
    assert.deepEqual(skillInvocationsOutput.items.map((item) => item.skill), ["agent-skills:using-agent-skills"]);

    const skillAudit = await client.callTool({
      name: "anvil_skill_invocation_audit_sample",
      arguments: { cwd: repo, seed: "2026-W29", size: 1 },
    });
    const skillAuditOutput = skillInvocationAuditSampleOutputSchema.parse(skillAudit.structuredContent);
    assert.equal(skillAuditOutput.kind, "ok");
    assert.equal(skillAuditOutput.eligible, 1);
    assert.equal(skillAuditOutput.items.length, 1);
  } finally {
    await client.close();
    await rm(temp, { recursive: true, force: true });
  }
});

test("stdio Continuity mutation cannot be redirected from improvements into anvil_redux", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-mcp-routing-regression-"));
  const client = new Client({ name: "anvil-routing-regression", version: "0.0.0" });
  try {
    const improvements = join(temp, "improvements");
    const anvilRedux = join(temp, "anvil_redux");
    const stateRoot = join(temp, "state");
    await mkdir(improvements, { recursive: true });
    await mkdir(anvilRedux, { recursive: true });
    const improvementsBinding = await bindWorkContext({
      host: "codex",
      sessionId: "session-stdio-improvements",
      cwd: improvements,
      lifecycle: "SessionStart:startup",
      stateRoot,
    });
    const anvilBinding = await bindWorkContext({
      host: "codex",
      sessionId: "session-stdio-anvil",
      cwd: anvilRedux,
      lifecycle: "SessionStart:startup",
      stateRoot,
    });
    const improvementsPaths = deriveContinuityPaths({
      stateRoot,
      workspace: improvementsBinding.binding.collaboration_space,
    });
    const anvilPaths = deriveContinuityPaths({
      stateRoot,
      workspace: anvilBinding.binding.collaboration_space,
    });
    await recordContinuityEvent({
      binding: anvilBinding.binding,
      stateRoot,
      event: {
        type: "decision",
        status: "active",
        summary: "Existing Anvil partition sentinel.",
        supersedes: [],
        resolves: [],
        related_events: [],
      },
      id: () => "evt_anvil_sentinel",
    });
    const anvilBefore = await readFile(anvilPaths.eventsPath, "utf8");

    const transport = new StdioClientTransport({
      command: process.execPath,
      args: ["bin/anvil.ts", "mcp", "serve"],
      cwd: resolve("."),
      env: childEnv({ ANVIL_STATE_ROOT: stateRoot }),
      stderr: "pipe",
    });
    await client.connect(transport);

    const valid = await client.callTool({
      name: "anvil_continuity_record_event",
      arguments: {
        bindingId: improvementsBinding.binding.id,
        event: { type: "decision", summary: "Improvements work stays in improvements." },
      },
    });
    assert.equal(valid.isError, undefined);
    const validOutput = continuityRecordEventOutputSchema.parse(valid.structuredContent);
    assert.equal(validOutput.workspace.root, await realpath(improvements));
    assert.equal(validOutput.binding.id, improvementsBinding.binding.id);
    const improvementsAfterValid = await readFile(improvementsPaths.eventsPath, "utf8");
    assert.match(improvementsAfterValid, /Improvements work stays in improvements/);
    assert.equal(await readFile(anvilPaths.eventsPath, "utf8"), anvilBefore);

    const rejected = await client.callTool({
      name: "anvil_continuity_record_event",
      arguments: {
        bindingId: improvementsBinding.binding.id,
        cwd: anvilRedux,
        stateRoot,
        event: { type: "decision", summary: "Attempted Anvil override." },
      },
    });
    assert.equal(rejected.isError, true);
    assert.equal(
      (rejected.structuredContent as { error: { code: string } }).error.code,
      "WORK_CONTEXT_MISMATCH",
    );
    assert.equal(await readFile(improvementsPaths.eventsPath, "utf8"), improvementsAfterValid);
    assert.equal(await readFile(anvilPaths.eventsPath, "utf8"), anvilBefore);

    const secondSession = await client.callTool({
      name: "anvil_continuity_record_event",
      arguments: {
        bindingId: anvilBinding.binding.id,
        event: { type: "decision", summary: "Anvil session stays isolated." },
      },
    });
    assert.equal(secondSession.isError, undefined);
    assert.equal(await readFile(improvementsPaths.eventsPath, "utf8"), improvementsAfterValid);
    assert.match(await readFile(anvilPaths.eventsPath, "utf8"), /Anvil session stays isolated/);
  } finally {
    await client.close();
    await rm(temp, { recursive: true, force: true });
  }
});

test("anvil mcp executable starts from another repo cwd", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-mcp-cross-repo-"));
  const client = new Client({ name: "anvil-cross-repo-test-client", version: "0.0.0" });
  try {
    const otherRepo = join(temp, "llm-wiki-like");
    const stateRoot = join(temp, "state");
    await mkdir(otherRepo, { recursive: true });

    const transport = new StdioClientTransport({
      command: anvilBin,
      args: ["mcp", "serve"],
      cwd: otherRepo,
      env: childEnv({ ANVIL_AGENT_ID: "codex", ANVIL_STATE_ROOT: stateRoot }),
      stderr: "pipe",
    });

    await client.connect(transport);

    const tools = await client.listTools();
    assert.ok(tools.tools.some((tool) => tool.name === "anvil_continuity_record_event"));
    assert.ok(tools.tools.some((tool) => tool.name === "anvil_session_bootstrap"));

    const bootstrap = await client.callTool({
      name: "anvil_session_bootstrap",
      arguments: { cwd: otherRepo, agentId: "codex", anvilHome: join(temp, ".anvil") },
    });
    const output = sessionBootstrapOutputSchema.parse(bootstrap.structuredContent);
    assert.equal(output.workspace.cwd, otherRepo);
    assert.equal(output.workspace.project_id_guess, "llm-wiki-like");
  } finally {
    await client.close();
    await rm(temp, { recursive: true, force: true });
  }
});
