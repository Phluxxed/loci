import test from 'node:test';
import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { executionFilesystem, deniedOpenProbe } from '../scripts/brain-frozen-cases.mjs';
import { caseRootForWorkspace, validateCaseSource } from '../scripts/brain-frozen-case-hook.mjs';

const keyRoot = '/Users/brummerv/phluxxed/workbench/.scratch/brain-w41-preparation-2026-09-07';
const sample = name => ({ name, root: '/private/tmp/brain-w41-execution.test/' + name,
  workspace: '/private/tmp/brain-w41-execution.test/' + name + '/workspace',
  brain: '/private/tmp/brain-w41-execution.test/' + name + '/brain' });
const runtime = '/Users/brummerv/.codex/packages/test/bin/codex';
const instructions = ['/Users/brummerv/.codex/AGENTS.md'];

test('observer accepts only declared persistent case workspaces and their matching source variant', () => {
  const base = '/Users/brummerv/phluxxed/brain-w41-isolated-2026-09-08';
  for (const name of ['k01-old', 'k04-current', 'c05-current', 'c06-current']) {
    const root = caseRootForWorkspace(base + '/execution/' + name + '/workspace');
    const variant = name.endsWith('-old') ? 'old' : 'current';
    validateCaseSource(root, base + '/paired/' + variant + '/anvil');
    assert.throws(() => validateCaseSource(root, base + '/paired/' + (variant === 'old' ? 'current' : 'old') + '/anvil'));
  }
  for (const path of ['/private/tmp/brain-w41-execution.old/k01-old/workspace',
    base + '/execution/k05-old/workspace', base + '/execution/k01-old/other',
    '/unrelated/execution/k01-old/workspace']) assert.throws(() => caseRootForWorkspace(path));
});

test('knowledge sessions cannot write Brain or read keys, own captures or sibling results', () => {
  const s = sample('k01-old'); const other = sample('k01-current');
  const p = executionFilesystem(s, [s.root, other.root], runtime, instructions);
  assert.equal(p[s.brain], 'read'); assert.equal(p[s.workspace], 'write');
  for (const denied of [keyRoot, s.root + '/captures', s.root + '/settings.json', other.root]) {
    assert.equal(p[denied], 'deny'); assert.equal(p[denied + '/**'], 'deny');
  }
});
test('operational sessions can maintain only their isolated Brain, preserving live-state restrictions', () => {
  const s = sample('c05-current');
  const p = executionFilesystem(s, [s.root], runtime, instructions);
  assert.equal(p[s.brain], 'write');
  for (const root of ['/Users/brummerv/.anvil-brain', '/Users/brummerv/.anvil', '/Users/brummerv/.claude', '/Users/brummerv/work']) {
    assert.equal(p[root], 'deny'); assert.equal(p[root + '/**'], 'deny');
  }
  assert.equal(p['/Users/brummerv/.codex'], 'deny');
  assert.equal(p[runtime], 'read'); assert.equal(p[instructions[0]], 'read');
  assert.equal(p[keyRoot], 'deny');
});

test('restored profiles protect persistent paired inputs without depending on deleted temporary roots', () => {
  const base = '/Users/brummerv/phluxxed/brain-w41-isolated-2026-09-08';
  const s = { name: 'k01-old', root: base + '/execution/k01-old',
    workspace: base + '/execution/k01-old/workspace', brain: base + '/execution/k01-old/brain' };
  const p = executionFilesystem(s, [s.root, base + '/execution/k01-current'], runtime, instructions);
  for (const variant of ['old', 'current']) for (const leaf of ['brain', 'captures', 'anvil/docs']) {
    const target = base + '/paired/' + variant + '/' + leaf;
    assert.equal(p[target], 'deny');
    assert.equal(p[target + '/**'], 'deny');
  }
  assert(!Object.keys(p).some(path => path.startsWith('/private/tmp/brain-w41-')));
});

test('permission probe fails closed when a protected target can be opened', () => {
  const control = fileURLToPath(import.meta.url);
  const r = spawnSync(process.execPath, deniedOpenProbe([control], control), { encoding: 'utf8' });
  assert.equal(r.status, 1);
  assert.deepEqual(JSON.parse(r.stdout), { controlReadable: true, results: [{ path: control, denied: false }] });
  assert(!r.stdout.includes('import test'), 'Probe must never print target contents');
});

test('missing paths and failed sandbox controls are not claimed as access denial', () => {
  const control = fileURLToPath(import.meta.url);
  const missing = control + '/not-a-file';
  const r = spawnSync(process.execPath, deniedOpenProbe([missing], control), { encoding: 'utf8' });
  assert.equal(r.status, 1);
  assert.equal(JSON.parse(r.stdout).results[0].denied, false);
  const noControl = spawnSync(process.execPath, deniedOpenProbe([control], missing), { encoding: 'utf8' });
  assert.notEqual(noControl.status, 0);
  assert.equal(noControl.stdout, '');
});
