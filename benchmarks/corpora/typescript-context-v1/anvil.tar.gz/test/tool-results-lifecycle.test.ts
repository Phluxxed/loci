import assert from "node:assert/strict";
import { mkdir, mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { test } from "node:test";

import {
  captureCommandResult,
  readToolResultHealth,
  readToolResultManifest,
  ToolResultError,
} from "../src/tool-results/index.ts";
import { bindWorkContext } from "../src/work-context/index.ts";

const createdAt = "2026-08-24T00:00:00.000Z";
const expiredAt = "2026-08-25T00:00:00.000Z";

test("expired artefacts are distinct from missing results and cleanup is automatic", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-tool-result-expiry-"));
  try {
    const repo = join(temp, "repo");
    const stateRoot = join(temp, "state");
    await mkdir(repo, { recursive: true });
    const { binding } = await bindWorkContext({
      host: "codex",
      sessionId: "session_tool_result_expiry",
      cwd: repo,
      lifecycle: "SessionStart:startup",
      stateRoot,
      now: () => createdAt,
      maxAgeMs: 3 * 24 * 60 * 60 * 1_000,
    });
    const capture = () =>
      captureCommandResult({
        argv: [process.execPath, "-e", 'process.stdout.write("E".repeat(5_000))'],
        producer: "test",
        binding,
        stateRoot,
        now: () => createdAt,
      });
    const expiredOnRead = await capture();
    const expiredOnCleanup = await capture();

    await assert.rejects(
      readToolResultManifest({
        binding,
        resultId: expiredOnRead.result_id,
        stateRoot,
        now: () => expiredAt,
      }),
      (error: unknown) => error instanceof ToolResultError && error.code === "TOOL_RESULT_EXPIRED",
    );
    const health = await readToolResultHealth({ binding, stateRoot, now: () => expiredAt });
    assert.deepEqual(health.cleanup, { removed_artefacts: 1, removed_bytes: 5_000 });
    assert.deepEqual(health.usage, { artefacts: 0, total_bytes: 0, corrupt_entries: 0 });
    await assert.rejects(
      readToolResultManifest({
        binding,
        resultId: expiredOnCleanup.result_id,
        stateRoot,
        now: () => expiredAt,
      }),
      (error: unknown) => error instanceof ToolResultError && error.code === "TOOL_RESULT_NOT_FOUND",
    );
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("digest corruption is rejected instead of returning altered evidence", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-tool-result-corrupt-"));
  try {
    const repo = join(temp, "repo");
    const stateRoot = join(temp, "state");
    await mkdir(repo, { recursive: true });
    const { binding } = await bindWorkContext({
      host: "codex",
      sessionId: "session_tool_result_corrupt",
      cwd: repo,
      lifecycle: "SessionStart:startup",
      stateRoot,
    });
    const receipt = await captureCommandResult({
      argv: [process.execPath, "-e", 'process.stdout.write("C".repeat(5_000))'],
      producer: "build",
      binding,
      stateRoot,
    });
    assert.equal(receipt.completeness, "complete_artefact_backed");

    // Filesystem mutation is deliberate fault injection; retrieval remains through the public service.
    const payloadPath = join(
      stateRoot,
      "tool-results",
      "results",
      binding.collaboration_space.key,
      receipt.result_id,
      "payload.txt",
    );
    const payload = await readFile(payloadPath);
    payload[0] = payload[0] === 0x43 ? 0x44 : 0x43;
    await writeFile(payloadPath, payload);

    await assert.rejects(
      readToolResultManifest({ binding, resultId: receipt.result_id, stateRoot }),
      (error: unknown) => error instanceof ToolResultError && error.code === "TOOL_RESULT_CORRUPT",
    );
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("unsupported command output fails explicitly and publishes no result", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-tool-result-binary-"));
  try {
    const repo = join(temp, "repo");
    const stateRoot = join(temp, "state");
    await mkdir(repo, { recursive: true });
    const { binding } = await bindWorkContext({
      host: "codex",
      sessionId: "session_tool_result_binary",
      cwd: repo,
      lifecycle: "SessionStart:startup",
      stateRoot,
    });
    await assert.rejects(
      captureCommandResult({
        argv: [process.execPath, "-e", "process.stdout.write(Buffer.from([0xff]))"],
        producer: "build",
        binding,
        stateRoot,
      }),
      (error: unknown) => error instanceof ToolResultError && error.code === "TOOL_RESULT_UNSUPPORTED_CONTENT",
    );
    const health = await readToolResultHealth({ binding, stateRoot });
    assert.deepEqual(health.usage, { artefacts: 0, total_bytes: 0, corrupt_entries: 0 });
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("capture overflow fails explicitly and leaves no published artefact", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-tool-result-overflow-"));
  try {
    const repo = join(temp, "repo");
    const stateRoot = join(temp, "state");
    await mkdir(repo, { recursive: true });
    const { binding } = await bindWorkContext({
      host: "codex",
      sessionId: "session_tool_result_overflow",
      cwd: repo,
      lifecycle: "SessionStart:startup",
      stateRoot,
    });
    const fixture = [
      'const chunk = "O".repeat(1024 * 1024);',
      "for (let index = 0; index < 65; index += 1) process.stdout.write(chunk);",
    ].join("\n");
    await assert.rejects(
      captureCommandResult({
        argv: [process.execPath, "-e", fixture],
        producer: "test",
        binding,
        stateRoot,
      }),
      (error: unknown) => error instanceof ToolResultError && error.code === "TOOL_RESULT_CAPTURE_OVERFLOW",
    );
    const health = await readToolResultHealth({ binding, stateRoot });
    assert.deepEqual(health.usage, { artefacts: 0, total_bytes: 0, corrupt_entries: 0 });
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("publication failure cannot expose a partial successful result", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-tool-result-publication-"));
  try {
    const repo = join(temp, "repo");
    const stateRoot = join(temp, "state");
    await mkdir(repo, { recursive: true });
    const { binding } = await bindWorkContext({
      host: "codex",
      sessionId: "session_tool_result_publication",
      cwd: repo,
      lifecycle: "SessionStart:startup",
      stateRoot,
    });
    // Deliberately block the atomic workspace publication target with a file.
    const resultsRoot = join(stateRoot, "tool-results", "results");
    await mkdir(resultsRoot, { recursive: true });
    await writeFile(join(resultsRoot, binding.collaboration_space.key), "publication fault\n", "utf8");

    await assert.rejects(
      captureCommandResult({
        argv: [process.execPath, "-e", 'process.stdout.write("P".repeat(5_000))'],
        producer: "build",
        binding,
        stateRoot,
      }),
      (error: unknown) => error instanceof ToolResultError && error.code === "TOOL_RESULT_CAPTURE_FAILED",
    );
    const health = await readToolResultHealth({ binding, stateRoot });
    assert.deepEqual(health.usage, { artefacts: 0, total_bytes: 0, corrupt_entries: 0 });
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});
