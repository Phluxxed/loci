import assert from "node:assert/strict";
import { cp, mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { test } from "node:test";
import { fileURLToPath } from "node:url";

import { BrainContextError } from "../src/brain-context/manifest.ts";
import { retrieveBrainContext, type BrainRetrievalResult } from "../src/brain-context/retrieve.ts";
import { renderCompilerPromptEvidenceContext, renderDegradedBrainContext } from "../src/brain-context/render.ts";

const fixtures = fileURLToPath(new URL("./fixtures/brain-context/", import.meta.url));

test("a zero-byte diagnostic allowance cannot emit a stray newline", () => {
  const result = renderDegradedBrainContext({
    code: "BRAIN_CONTEXT_BUDGET_VIOLATION", message: "No room.", recovery: "Reduce reserved context.",
  }, undefined, 0, "recall");
  assert.equal(result.markdown, "");
  assert.equal(result.renderedBytes, 0);
});

test("the closed compiler delivery profile agrees with the actual Anvil renderer", async () => {
  // Paired with llm-wiki tests/fixtures/anvil-prompt-delivery-v1.json. Keep the
  // fixture identical when changing either side of this versioned contract.
  const fixture = JSON.parse(await readFile(join(fixtures, "anvil-prompt-delivery-v1.json"), "utf8"));
  for (const item of fixture.cases) {
    const rendered = renderCompilerPromptEvidenceContext({
      contractVersion: item.contract_version,
      query: { projectResolution: item.project_resolution, temporal: item.temporal },
      evidence: item.evidence,
      diagnostics: item.diagnostics,
    } as BrainRetrievalResult);
    assert.equal(rendered.renderedBytes, item.expected.markdown_bytes, item.name);
    assert.equal(Buffer.byteLength(rendered.markdown, "utf8"), rendered.renderedBytes);
  }
});

test("delivery-budget negotiation rejects an older compiler that ignores the requested allowance", async () => {
  const root = await mkdtemp(join(tmpdir(), "anvil-delivery-budget-"));
  try {
    await cp(join(fixtures, "valid-known-project"), root, { recursive: true });
    const behavior = JSON.parse(await readFile(join(root, "fake-llm-wiki.json"), "utf8"));
    await writeFile(join(root, "fake-llm-wiki.json"), JSON.stringify({ ...behavior, omit_delivery_budget: true }));
    await assert.rejects(() => retrieveBrainContext({
      brainRoot: root, wikiAlias: "fixture-brain", seeds: [], question: "next",
      targetBytes: 1_000, hardBytes: 20_000, maxDeliveryBytes: 4_000,
      env: { ANVIL_LLM_WIKI_BIN: join(fixtures, "fake-llm-wiki.mjs") },
    }), (error) => error instanceof BrainContextError && error.code === "BRAIN_CONTEXT_BUDGET_VIOLATION");
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

test("delivery-budget negotiation verifies the rendered size, not just the compiler's claimed count", async () => {
  const root = await mkdtemp(join(tmpdir(), "anvil-delivery-accounting-"));
  try {
    await cp(join(fixtures, "valid-known-project"), root, { recursive: true });
    const input = {
      brainRoot: root, wikiAlias: "fixture-brain", seeds: [], question: "next",
      targetBytes: 1_000, hardBytes: 20_000, maxDeliveryBytes: 4_000,
      env: { ANVIL_LLM_WIKI_BIN: join(fixtures, "fake-llm-wiki.mjs") },
    };
    const result = await retrieveBrainContext(input);
    assert.equal(result.budget.limits.maxDeliveryBytes, 4_000);
    assert.equal(result.budget.limits.deliveryFormat, "anvil_prompt_evidence_v1");
    assert.equal(result.budget.deliveryBytes, renderCompilerPromptEvidenceContext(result).renderedBytes);
    for (const delivery_bytes of [0, 4_001]) {
      await writeFile(join(root, "fake-llm-wiki.json"), JSON.stringify({
        mode: "success", delivery_budget_override: { delivery_bytes },
      }));
      await assert.rejects(() => retrieveBrainContext(input),
        (error) => error instanceof BrainContextError && error.code === "BRAIN_CONTEXT_BUDGET_VIOLATION");
    }
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});
