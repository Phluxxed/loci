import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import { access, mkdir, mkdtemp, readFile, realpath, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join, resolve } from "node:path";
import { test } from "node:test";

import {
  checkpointActiveTaskOutputSchema,
  checkpointActiveTask as checkpointBoundActiveTask,
  deriveContinuityPaths,
  gitWorkspaceRef,
  initWorkspace,
  MAX_ACTIVE_DECISIONS,
  promoteContinuityEventOutputSchema,
  promoteContinuityEvent as promoteBoundContinuityEvent,
  readContinuityOutputSchema,
  readContinuity,
  recordContinuityEventOutputSchema,
  recordContinuityEvent as recordBoundContinuityEvent,
  retireContinuityProjectionItemOutputSchema,
  retireContinuityProjectionItem as retireBoundContinuityProjectionItem,
  resolveContinuityWorkspace,
  updateCurrent,
} from "../src/continuity/index.ts";
import type {
  CheckpointActiveTaskInput,
  CurrentFrameInput,
  EventInput,
  PromoteContinuityEventInput,
  RecordContinuityEventInput,
  RetireContinuityProjectionItemInput,
} from "../src/continuity/index.ts";
import { bindWorkContext, WorkContextError } from "../src/work-context/index.ts";
import type { WorkContextBinding } from "../src/work-context/index.ts";

const testBindings = new Map<string, WorkContextBinding>();

async function testBinding(cwd: string | undefined, stateRoot: string | undefined): Promise<WorkContextBinding> {
  assert.ok(cwd, "test mutation cwd is required");
  assert.ok(stateRoot, "test mutation stateRoot is required");
  const key = `${stateRoot}\0${cwd}`;
  const existing = testBindings.get(key);
  if (existing) return existing;
  const { binding } = await bindWorkContext({
    host: "test",
    sessionId: `session-${testBindings.size}`,
    cwd,
    lifecycle: "test",
    stateRoot,
  });
  testBindings.set(key, binding);
  return binding;
}

type LegacyRecordInput = Omit<RecordContinuityEventInput, "binding"> & { cwd?: string };
type LegacyCheckpointInput = Omit<CheckpointActiveTaskInput, "binding"> & { cwd?: string };
type LegacyPromoteInput = Omit<PromoteContinuityEventInput, "binding"> & { cwd?: string };
type LegacyRetireInput = Omit<RetireContinuityProjectionItemInput, "binding"> & { cwd?: string };

async function recordContinuityEvent(input: LegacyRecordInput) {
  const { cwd, ...boundInput } = input;
  return recordBoundContinuityEvent({
    ...boundInput,
    binding: await testBinding(cwd, input.stateRoot),
  });
}

async function checkpointActiveTask(input: LegacyCheckpointInput) {
  const { cwd, ...boundInput } = input;
  return checkpointBoundActiveTask({
    ...boundInput,
    binding: await testBinding(cwd, input.stateRoot),
  });
}

async function promoteContinuityEvent(input: LegacyPromoteInput) {
  const { cwd, ...boundInput } = input;
  return promoteBoundContinuityEvent({
    ...boundInput,
    binding: await testBinding(cwd, input.stateRoot),
  });
}

async function retireContinuityProjectionItem(input: LegacyRetireInput) {
  const { cwd, ...boundInput } = input;
  return retireBoundContinuityProjectionItem({
    ...boundInput,
    binding: await testBinding(cwd, input.stateRoot),
  });
}

function sampleFrameInput(overrides: Partial<CurrentFrameInput> = {}): CurrentFrameInput {
  return {
    operating_mode: "service-test",
    intent: "Keep continuity service behavior explicit.",
    quality_bar: ["Continuity is not truth."],
    permission_envelope: {
      default: "follow current instruction",
      allowed_without_approval: ["read continuity state"],
      requires_approval: ["delete continuity history"],
    },
    active_decisions: [],
    open_questions: [],
    next_actions: [],
    continuity_notes: [],
    ...overrides,
  };
}

function sampleEventInput(overrides: Partial<EventInput> = {}): EventInput {
  return {
    type: "decision",
    status: "active",
    summary: "Continuity service records typed events.",
    supersedes: [],
    resolves: [],
    related_events: [],
    ...overrides,
  };
}

function runGit(args: string[], cwd: string): void {
  const result = spawnSync("git", args, { cwd, encoding: "utf8" });
  assert.equal(result.status, 0, result.stderr);
}

test("resolveContinuityWorkspace uses the git root and explicit state root", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-continuity-service-resolve-"));
  try {
    const repo = join(temp, "repo");
    const nested = join(repo, "src", "nested");
    const stateRoot = join(temp, "state");
    await mkdir(nested, { recursive: true });
    runGit(["init"], repo);

    const paths = resolveContinuityWorkspace({ cwd: nested, stateRoot });
    const realRepo = await realpath(repo);

    assert.equal(paths.workspace.root, realRepo);
    assert.equal(paths.stateRoot, resolve(stateRoot));
    assert.equal(
      paths.currentPath,
      deriveContinuityPaths({ stateRoot: resolve(stateRoot), workspace: gitWorkspaceRef(realRepo) }).currentPath,
    );
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("bound Continuity mutation derives workspace and provenance only from Work Context", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-continuity-bound-record-"));
  try {
    const workspace = join(temp, "improvements");
    const stateRoot = join(temp, "state");
    await mkdir(workspace, { recursive: true });
    const { binding } = await bindWorkContext({
      host: "codex",
      sessionId: "session-bound-record",
      cwd: workspace,
      lifecycle: "SessionStart:startup",
      stateRoot,
      now: () => "2026-07-16T00:00:00.000Z",
    });

    const result = await recordBoundContinuityEvent({
      binding,
      stateRoot,
      bindingNow: () => "2026-07-16T00:01:00.000Z",
      event: sampleEventInput({ summary: "Bound event stays in improvements." }),
      source: {
        kind: "codex_mcp",
        host: "spoofed-host",
        cwd: join(temp, "anvil_redux"),
        session_id: "spoofed-session",
        turn_id: "turn-1",
      },
      now: () => "2026-07-16T00:01:00.000Z",
      id: () => "evt_bound_improvements",
    });

    assert.equal(result.workspace.root, await realpath(workspace));
    assert.equal(result.event.source.host, "codex");
    assert.equal(result.event.source.cwd, await realpath(workspace));
    assert.equal(result.event.source.session_id, "session-bound-record");
    assert.equal(result.event.source.turn_id, "turn-1");
    assert.equal(result.binding.id, binding.id);
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("bound Continuity promotion cannot resolve an event from another partition", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-continuity-bound-isolation-"));
  try {
    const improvements = join(temp, "improvements");
    const anvilRedux = join(temp, "anvil_redux");
    const stateRoot = join(temp, "state");
    await mkdir(improvements, { recursive: true });
    await mkdir(anvilRedux, { recursive: true });
    const improvementsBinding = await bindWorkContext({
      host: "codex",
      sessionId: "session-improvements",
      cwd: improvements,
      lifecycle: "SessionStart:startup",
      stateRoot,
    });
    const anvilBinding = await bindWorkContext({
      host: "codex",
      sessionId: "session-anvil",
      cwd: anvilRedux,
      lifecycle: "SessionStart:startup",
      stateRoot,
    });
    const improvementsPaths = deriveContinuityPaths({
      stateRoot,
      workspace: improvementsBinding.binding.collaboration_space,
    });
    await initWorkspace(improvementsPaths, sampleFrameInput());
    const anvilEvent = await recordBoundContinuityEvent({
      binding: anvilBinding.binding,
      stateRoot,
      event: sampleEventInput({ summary: "Anvil-only event." }),
      id: () => "evt_anvil_only",
    });
    const anvilBefore = await readFile(anvilEvent.paths.eventsPath, "utf8");

    await assert.rejects(
      () =>
        promoteBoundContinuityEvent({
          binding: improvementsBinding.binding,
          stateRoot,
          eventId: "evt_anvil_only",
          target: "active_decisions",
        }),
      /EVENT_NOT_FOUND/,
    );

    assert.equal(await readFile(anvilEvent.paths.eventsPath, "utf8"), anvilBefore);
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("stale Work Context rejects Continuity mutation before any partition write", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-continuity-bound-stale-"));
  try {
    const workspace = join(temp, "workspace");
    const stateRoot = join(temp, "state");
    await mkdir(workspace, { recursive: true });
    const { binding } = await bindWorkContext({
      host: "codex",
      sessionId: "session-stale-zero-write",
      cwd: workspace,
      lifecycle: "SessionStart:startup",
      stateRoot,
      now: () => "2026-07-16T00:00:00.000Z",
      maxAgeMs: 1_000,
    });

    await assert.rejects(
      () =>
        recordBoundContinuityEvent({
          binding,
          stateRoot,
          bindingNow: () => "2026-07-16T00:00:02.000Z",
          event: sampleEventInput(),
        }),
      (error: unknown) => error instanceof WorkContextError && error.code === "WORK_CONTEXT_STALE",
    );
    await assert.rejects(() => access(join(stateRoot, "continuity")));
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("readContinuity returns current frame and optional bounded events", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-continuity-service-read-"));
  try {
    const repo = join(temp, "repo");
    const stateRoot = join(temp, "state");
    await mkdir(repo, { recursive: true });
    runGit(["init"], repo);

    const paths = resolveContinuityWorkspace({ cwd: repo, stateRoot });
    await initWorkspace(paths, sampleFrameInput(), { now: () => "2026-06-03T00:00:00.000Z" });
    await recordContinuityEvent({
      cwd: repo,
      stateRoot,
      event: sampleEventInput({ summary: "First service event." }),
      source: { kind: "test", description: "service read test" },
      now: () => "2026-06-03T00:01:00.000Z",
      id: () => "evt_service_1",
    });

    const result = readContinuityOutputSchema.parse(
      await readContinuity({ cwd: repo, stateRoot, includeEvents: true, eventLimit: 1 }),
    );

    assert.equal(result.workspace.root, await realpath(repo));
    assert.equal(result.current.kind, "ok");
    assert.match(result.current.rendered, /## Anvil Continuity Frame/);
    assert.equal(result.events?.kind, "ok");
    if (result.events?.kind !== "ok") throw new Error("Expected events");
    assert.equal(result.events.items.length, 1);
    assert.equal(result.events.items[0].id, "evt_service_1");
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("readContinuity output schema preserves malformed current and event states", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-continuity-service-malformed-"));
  try {
    const repo = join(temp, "repo");
    const stateRoot = join(temp, "state");
    await mkdir(repo, { recursive: true });
    runGit(["init"], repo);
    const paths = resolveContinuityWorkspace({ cwd: repo, stateRoot });
    await mkdir(paths.workspaceDir, { recursive: true });
    await writeFile(paths.currentPath, "{}\n", "utf8");
    await writeFile(paths.eventsPath, "{not-json}\n", "utf8");

    const result = readContinuityOutputSchema.parse(
      await readContinuity({ cwd: repo, stateRoot, includeEvents: true }),
    );
    assert.equal(result.current.kind, "malformed");
    assert.equal(result.events?.kind, "malformed");
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("recordContinuityEvent reports whether it bootstrapped missing continuity", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-continuity-service-record-"));
  try {
    const repo = join(temp, "repo");
    const stateRoot = join(temp, "state");
    await mkdir(repo, { recursive: true });
    runGit(["init"], repo);

    const first = recordContinuityEventOutputSchema.parse(await recordContinuityEvent({
      cwd: repo,
      stateRoot,
      event: sampleEventInput({ summary: "First event bootstraps from service." }),
      source: { kind: "test", description: "bootstrap check" },
      now: () => "2026-06-03T00:00:00.000Z",
      id: () => "evt_service_bootstrap",
    }));

    assert.equal(first.currentFrameInitialized, true);

    const second = recordContinuityEventOutputSchema.parse(await recordContinuityEvent({
      cwd: repo,
      stateRoot,
      event: sampleEventInput({ summary: "Second event does not bootstrap." }),
      source: { kind: "test", description: "bootstrap check" },
      now: () => "2026-06-03T00:01:00.000Z",
      id: () => "evt_service_second",
    }));

    assert.equal(second.currentFrameInitialized, false);
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("checkpointActiveTask atomically sets, retries, recovers, replaces, and clears the active task", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-continuity-active-task-"));
  try {
    const repo = join(temp, "repo");
    const stateRoot = join(temp, "state");
    await mkdir(repo, { recursive: true });
    runGit(["init"], repo);
    const paths = resolveContinuityWorkspace({ cwd: repo, stateRoot });
    await initWorkspace(paths, sampleFrameInput(), { now: () => "2026-08-22T00:00:00.000Z" });

    await assert.rejects(
      () => checkpointActiveTask({
        cwd: repo,
        stateRoot,
        checkpointId: "invalid-active-task",
        task: {
          state: "active",
          summary: "Invalid task must not leave event history behind.",
          nextStep: "x".repeat(501),
        },
      }),
      /task next step must contain between 1 and 500 characters/,
    );
    const afterInvalid = await readContinuity({ cwd: repo, stateRoot, includeEvents: true, eventLimit: 10 });
    assert.equal(afterInvalid.events?.kind, "ok");
    if (afterInvalid.events?.kind !== "ok") throw new Error("Expected initialized event log");
    assert.equal(afterInvalid.events.total, 0, "invalid checkpoint must be rejected before event append");

    const firstInput = {
      cwd: repo,
      stateRoot,
      checkpointId: "active-task-1",
      task: {
        state: "active" as const,
        summary: "Restore active-task Continuity.",
        nextStep: "Wire the checkpoint through SessionStart.",
        details: "Approved by Vik after the regression diagnosis.",
      },
      source: { kind: "test", description: "active task checkpoint" },
      now: () => "2026-08-22T00:01:00.000Z",
    };
    const first = checkpointActiveTaskOutputSchema.parse(await checkpointActiveTask(firstInput));
    assert.equal(first.changed, true);
    assert.equal(first.frame.version, 2);
    assert.equal(first.frame.active_task?.summary, "Restore active-task Continuity.");
    assert.match(first.rendered, /Active task:/);
    assert.match(first.rendered, /Wire the checkpoint through SessionStart/);

    const retry = checkpointActiveTaskOutputSchema.parse(await checkpointActiveTask(firstInput));
    assert.equal(retry.changed, false);
    assert.equal(retry.event.id, first.event.id);

    await updateCurrent(paths, sampleFrameInput(), { now: () => "2026-08-22T00:02:00.000Z" });
    const recovered = checkpointActiveTaskOutputSchema.parse(await checkpointActiveTask(firstInput));
    assert.equal(recovered.changed, true);
    assert.equal(recovered.frame.active_task?.event_id, first.event.id);

    const waiting = checkpointActiveTaskOutputSchema.parse(await checkpointActiveTask({
      cwd: repo,
      stateRoot,
      checkpointId: "active-task-2",
      task: {
        state: "waiting",
        summary: "Verify active-task Continuity in a refreshed host.",
        nextStep: "Reload Codex and inspect the injected task.",
      },
      source: { kind: "test", description: "replace active task" },
      now: () => "2026-08-22T00:03:00.000Z",
    }));
    assert.equal(waiting.frame.active_task?.state, "waiting");
    assert.deepEqual(waiting.event.supersedes, [first.event.id]);

    const clearedInput = {
      cwd: repo,
      stateRoot,
      checkpointId: "active-task-3",
      task: { state: "clear" as const, outcome: "Active-task Continuity is verified." },
      source: { kind: "test", description: "clear active task" },
      now: () => "2026-08-22T00:04:00.000Z",
    };
    const cleared = checkpointActiveTaskOutputSchema.parse(await checkpointActiveTask(clearedInput));
    assert.equal(cleared.changed, true);
    assert.equal(cleared.frame.active_task, null);
    assert.deepEqual(cleared.event.resolves, [waiting.event.id]);
    const clearedRetry = checkpointActiveTaskOutputSchema.parse(await checkpointActiveTask(clearedInput));
    assert.equal(clearedRetry.changed, false);

    const read = await readContinuity({ cwd: repo, stateRoot, includeEvents: true, eventLimit: 10 });
    assert.equal(read.events?.kind, "ok");
    if (read.events?.kind !== "ok") throw new Error("Expected active-task events");
    assert.equal(read.events.total, 3, "retry and recovery must not duplicate checkpoint events");
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("promoteContinuityEvent projects an existing event into current frame with lineage", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-continuity-service-promote-"));
  try {
    const repo = join(temp, "repo");
    const stateRoot = join(temp, "state");
    await mkdir(repo, { recursive: true });
    runGit(["init"], repo);

    const paths = resolveContinuityWorkspace({ cwd: repo, stateRoot });
    await initWorkspace(paths, sampleFrameInput(), { now: () => "2026-06-03T00:00:00.000Z" });
    await recordContinuityEvent({
      cwd: repo,
      stateRoot,
      event: sampleEventInput({ summary: "MCP writes should go through typed continuity events." }),
      source: { kind: "test", description: "promotion check" },
      now: () => "2026-06-03T00:01:00.000Z",
      id: () => "evt_promote_decision",
    });

    const promoted = promoteContinuityEventOutputSchema.parse(await promoteContinuityEvent({
      cwd: repo,
      stateRoot,
      eventId: "evt_promote_decision",
      target: "active_decisions",
      now: () => "2026-06-03T00:02:00.000Z",
    }));

    assert.equal(promoted.changed, true);
    assert.equal(promoted.frame.active_decisions.length, 1);
    assert.equal(promoted.frame.active_decisions[0].event_id, "evt_promote_decision");
    assert.equal(promoted.frame.active_decisions[0].recorded_at, "2026-06-03T00:01:00.000Z");
    assert.equal(promoted.frame.active_decisions[0].summary, "MCP writes should go through typed continuity events.");

    const duplicate = promoteContinuityEventOutputSchema.parse(await promoteContinuityEvent({
      cwd: repo,
      stateRoot,
      eventId: "evt_promote_decision",
      target: "active_decisions",
    }));

    assert.equal(duplicate.changed, false);
    assert.equal(duplicate.frame.active_decisions.length, 1);
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("concurrent promotions preserve all compact-frame updates", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-continuity-service-promote-concurrent-"));
  try {
    const repo = join(temp, "repo");
    const stateRoot = join(temp, "state");
    await mkdir(repo, { recursive: true });
    runGit(["init"], repo);

    const paths = resolveContinuityWorkspace({ cwd: repo, stateRoot });
    await initWorkspace(paths, sampleFrameInput(), { now: () => "2026-06-03T00:00:00.000Z" });

    const eventIds = Array.from({ length: MAX_ACTIVE_DECISIONS }, (_, index) => `evt_concurrent_decision_${index}`);
    for (const [index, eventId] of eventIds.entries()) {
      await recordContinuityEvent({
        cwd: repo,
        stateRoot,
        event: sampleEventInput({ summary: `Concurrent decision ${index}.` }),
        source: { kind: "test", description: "concurrent promotion setup" },
        id: () => eventId,
      });
    }

    await Promise.all(
      eventIds.map((eventId, index) =>
        promoteContinuityEvent({
          cwd: repo,
          stateRoot,
          eventId,
          target: "active_decisions",
          now: () => `2026-06-03T00:01:0${index}.000Z`,
        }),
      ),
    );

    const result = await readContinuity({ cwd: repo, stateRoot });
    assert.equal(result.current.kind, "ok");
    if (result.current.kind !== "ok") throw new Error("Expected current frame");
    assert.deepEqual(
      result.current.frame.active_decisions.map((item) => item.event_id).sort(),
      [...eventIds].sort(),
    );
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("concurrent retirement and promotion leave current state valid and merged", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-continuity-service-retire-promote-concurrent-"));
  try {
    const repo = join(temp, "repo");
    const stateRoot = join(temp, "state");
    await mkdir(repo, { recursive: true });
    runGit(["init"], repo);

    const paths = resolveContinuityWorkspace({ cwd: repo, stateRoot });
    await initWorkspace(paths, sampleFrameInput(), { now: () => "2026-06-03T00:00:00.000Z" });
    await recordContinuityEvent({
      cwd: repo,
      stateRoot,
      event: sampleEventInput({ summary: "Decision to retire during concurrent write." }),
      source: { kind: "test", description: "concurrent retire setup" },
      id: () => "evt_concurrent_retire",
    });
    await recordContinuityEvent({
      cwd: repo,
      stateRoot,
      event: sampleEventInput({ summary: "Decision to promote during concurrent write." }),
      source: { kind: "test", description: "concurrent promote setup" },
      id: () => "evt_concurrent_promote",
    });
    await recordContinuityEvent({
      cwd: repo,
      stateRoot,
      event: sampleEventInput({
        type: "correction",
        summary: "Retire stale concurrent decision.",
      }),
      source: { kind: "test", description: "concurrent correction setup" },
      id: () => "evt_concurrent_correction",
    });
    await promoteContinuityEvent({
      cwd: repo,
      stateRoot,
      eventId: "evt_concurrent_retire",
      target: "active_decisions",
    });

    await Promise.all([
      retireContinuityProjectionItem({
        cwd: repo,
        stateRoot,
        target: "active_decisions",
        eventId: "evt_concurrent_retire",
        correctionEventId: "evt_concurrent_correction",
      }),
      promoteContinuityEvent({
        cwd: repo,
        stateRoot,
        eventId: "evt_concurrent_promote",
        target: "active_decisions",
      }),
    ]);

    const result = await readContinuity({ cwd: repo, stateRoot });
    assert.equal(result.current.kind, "ok");
    if (result.current.kind !== "ok") throw new Error("Expected current frame");
    assert.equal(result.current.frame.active_decisions.length, 1);
    assert.equal(result.current.frame.active_decisions[0].event_id, "evt_concurrent_promote");
    assert.equal(result.current.frame.active_decisions[0].summary, "Decision to promote during concurrent write.");
    assert.match(result.current.frame.active_decisions[0].recorded_at ?? "", /^\d{4}-\d{2}-\d{2}T/);
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("promoteContinuityEvent refuses missing events and incompatible targets", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-continuity-service-promote-refuse-"));
  try {
    const repo = join(temp, "repo");
    const stateRoot = join(temp, "state");
    await mkdir(repo, { recursive: true });
    runGit(["init"], repo);

    const paths = resolveContinuityWorkspace({ cwd: repo, stateRoot });
    await initWorkspace(paths, sampleFrameInput(), { now: () => "2026-06-03T00:00:00.000Z" });
    await recordContinuityEvent({
      cwd: repo,
      stateRoot,
      event: sampleEventInput({ summary: "A decision should not become a next action." }),
      source: { kind: "test", description: "promotion refusal check" },
      id: () => "evt_promote_wrong_target",
    });

    await assert.rejects(
      () =>
        promoteContinuityEvent({
          cwd: repo,
          stateRoot,
          eventId: "evt_missing",
          target: "active_decisions",
        }),
      /EVENT_NOT_FOUND/,
    );

    await assert.rejects(
      () =>
        promoteContinuityEvent({
          cwd: repo,
          stateRoot,
          eventId: "evt_promote_wrong_target",
          target: "next_actions",
        }),
      /VALIDATION_ERROR/,
    );
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("promoteContinuityEvent requires active status for active compact-frame targets", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-continuity-service-promote-status-"));
  try {
    const repo = join(temp, "repo");
    const stateRoot = join(temp, "state");
    await mkdir(repo, { recursive: true });
    runGit(["init"], repo);

    const paths = resolveContinuityWorkspace({ cwd: repo, stateRoot });
    await initWorkspace(paths, sampleFrameInput(), { now: () => "2026-06-03T00:00:00.000Z" });

    const statuses = ["resolved", "superseded", "deferred"] as const;
    for (const status of statuses) {
      const eventId = `evt_promote_${status}`;
      await recordContinuityEvent({
        cwd: repo,
        stateRoot,
        event: sampleEventInput({
          status,
          summary: `Inactive ${status} decision should not enter active decisions.`,
        }),
        source: { kind: "test", description: "promotion status check" },
        id: () => eventId,
      });

      await assert.rejects(
        () =>
          promoteContinuityEvent({
            cwd: repo,
            stateRoot,
            eventId,
            target: "active_decisions",
          }),
        (error: unknown) =>
          error instanceof Error &&
          error.message.includes(eventId) &&
          error.message.includes(status) &&
          error.message.includes("active_decisions"),
      );

      const notePromotion = await promoteContinuityEvent({
        cwd: repo,
        stateRoot,
        eventId,
        target: "continuity_notes",
      });
      assert.equal(notePromotion.changed, true);
    }

    const result = await readContinuity({ cwd: repo, stateRoot });
    assert.equal(result.current.kind, "ok");
    if (result.current.kind !== "ok") throw new Error("Expected current frame");
    assert.deepEqual(result.current.frame.active_decisions, []);
    assert.equal(result.current.frame.continuity_notes.length, statuses.length);
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("promoteContinuityEvent enforces projection caps", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-continuity-service-promote-cap-"));
  try {
    const repo = join(temp, "repo");
    const stateRoot = join(temp, "state");
    await mkdir(repo, { recursive: true });
    runGit(["init"], repo);

    const paths = resolveContinuityWorkspace({ cwd: repo, stateRoot });
    await initWorkspace(paths, sampleFrameInput(), { now: () => "2026-06-03T00:00:00.000Z" });
    await updateCurrent(paths, sampleFrameInput({
      active_decisions: Array.from({ length: MAX_ACTIVE_DECISIONS }, (_, index) => ({
        event_id: `evt_existing_${index}`,
        summary: `Existing decision ${index}`,
      })),
    }));
    await recordContinuityEvent({
      cwd: repo,
      stateRoot,
      event: sampleEventInput({ summary: "This decision would exceed the projection cap." }),
      source: { kind: "test", description: "promotion cap check" },
      id: () => "evt_promote_over_cap",
    });

    await assert.rejects(
      () =>
        promoteContinuityEvent({
          cwd: repo,
          stateRoot,
          eventId: "evt_promote_over_cap",
          target: "active_decisions",
        }),
      /PROJECTION_LIMIT_EXCEEDED/,
    );
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("retireContinuityProjectionItem removes event-linked projection items with correction lineage", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-continuity-service-retire-event-"));
  try {
    const repo = join(temp, "repo");
    const stateRoot = join(temp, "state");
    await mkdir(repo, { recursive: true });
    runGit(["init"], repo);

    const paths = resolveContinuityWorkspace({ cwd: repo, stateRoot });
    await initWorkspace(paths, sampleFrameInput(), { now: () => "2026-06-03T00:00:00.000Z" });
    await recordContinuityEvent({
      cwd: repo,
      stateRoot,
      event: sampleEventInput({ summary: "Temporary decision should be projected." }),
      source: { kind: "test", description: "retire projection check" },
      id: () => "evt_retire_decision",
    });
    await promoteContinuityEvent({
      cwd: repo,
      stateRoot,
      eventId: "evt_retire_decision",
      target: "active_decisions",
    });
    await recordContinuityEvent({
      cwd: repo,
      stateRoot,
      event: sampleEventInput({
        type: "correction",
        summary: "Temporary decision should leave the compact frame.",
      }),
      source: { kind: "test", description: "retire projection check" },
      id: () => "evt_retire_correction",
    });

    const retired = retireContinuityProjectionItemOutputSchema.parse(await retireContinuityProjectionItem({
      cwd: repo,
      stateRoot,
      target: "active_decisions",
      eventId: "evt_retire_decision",
      correctionEventId: "evt_retire_correction",
      now: () => "2026-06-03T00:02:00.000Z",
    }));

    assert.equal(retired.changed, true);
    assert.equal(retired.removedItem?.summary, "Temporary decision should be projected.");
    assert.equal(retired.correctionEvent?.id, "evt_retire_correction");
    assert.deepEqual(retired.frame.active_decisions, []);

    const duplicate = retireContinuityProjectionItemOutputSchema.parse(await retireContinuityProjectionItem({
      cwd: repo,
      stateRoot,
      target: "active_decisions",
      eventId: "evt_retire_decision",
      correctionEventId: "evt_retire_correction",
    }));

    assert.equal(duplicate.changed, false);
    assert.equal(duplicate.removedItem, undefined);
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("retireContinuityProjectionItem removes unlinked bootstrap items by exact summary", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-continuity-service-retire-unlinked-"));
  try {
    const repo = join(temp, "repo");
    const stateRoot = join(temp, "state");
    await mkdir(repo, { recursive: true });
    runGit(["init"], repo);

    const paths = resolveContinuityWorkspace({ cwd: repo, stateRoot });
    await initWorkspace(
      paths,
      sampleFrameInput({
        active_decisions: [{ summary: "Bootstrap decision without event id." }],
        continuity_notes: ["Bootstrap note without event id."],
      }),
      { now: () => "2026-06-03T00:00:00.000Z" },
    );

    const retiredDecision = await retireContinuityProjectionItem({
      cwd: repo,
      stateRoot,
      target: "active_decisions",
      summary: "Bootstrap decision without event id.",
    });

    assert.equal(retiredDecision.changed, true);
    assert.deepEqual(retiredDecision.frame.active_decisions, []);

    const retiredNote = await retireContinuityProjectionItem({
      cwd: repo,
      stateRoot,
      target: "continuity_notes",
      summary: "Bootstrap note without event id.",
    });

    assert.equal(retiredNote.changed, true);
    assert.deepEqual(retiredNote.frame.continuity_notes, []);
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("retireContinuityProjectionItem rejects ambiguous selectors and event-linked removals without correction events", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-continuity-service-retire-refuse-"));
  try {
    const repo = join(temp, "repo");
    const stateRoot = join(temp, "state");
    await mkdir(repo, { recursive: true });
    runGit(["init"], repo);

    const paths = resolveContinuityWorkspace({ cwd: repo, stateRoot });
    await initWorkspace(paths, sampleFrameInput(), { now: () => "2026-06-03T00:00:00.000Z" });
    await recordContinuityEvent({
      cwd: repo,
      stateRoot,
      event: sampleEventInput({ summary: "Decision requiring correction lineage." }),
      source: { kind: "test", description: "retire projection refusal check" },
      id: () => "evt_retire_requires_correction",
    });
    await promoteContinuityEvent({
      cwd: repo,
      stateRoot,
      eventId: "evt_retire_requires_correction",
      target: "active_decisions",
    });

    await assert.rejects(
      () =>
        retireContinuityProjectionItem({
          cwd: repo,
          stateRoot,
          target: "active_decisions",
          eventId: "evt_retire_requires_correction",
          summary: "Decision requiring correction lineage.",
        }),
      /VALIDATION_ERROR/,
    );

    await assert.rejects(
      () =>
        retireContinuityProjectionItem({
          cwd: repo,
          stateRoot,
          target: "active_decisions",
          eventId: "evt_retire_requires_correction",
        }),
      /VALIDATION_ERROR/,
    );

    await recordContinuityEvent({
      cwd: repo,
      stateRoot,
      event: sampleEventInput({ summary: "Not a correction event." }),
      source: { kind: "test", description: "retire projection refusal check" },
      id: () => "evt_retire_not_correction",
    });

    await assert.rejects(
      () =>
        retireContinuityProjectionItem({
          cwd: repo,
          stateRoot,
          target: "active_decisions",
          eventId: "evt_retire_requires_correction",
          correctionEventId: "evt_retire_not_correction",
        }),
      /VALIDATION_ERROR/,
    );
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});
