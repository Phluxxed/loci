import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import { mkdir, mkdtemp, readFile, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join, resolve } from "node:path";
import { test } from "node:test";

import { Client } from "@modelcontextprotocol/client";
import { StdioClientTransport } from "@modelcontextprotocol/client/stdio";
import { bindWorkContext } from "../src/work-context/index.ts";

const anvilBin = resolve("bin/anvil.ts");

function childEnv(extra: Record<string, string>): Record<string, string> {
  const env: Record<string, string> = {};
  for (const [key, value] of Object.entries(process.env)) {
    if (value !== undefined) env[key] = value;
  }
  return { ...env, ...extra };
}

test("verbose command result stays compact and remains exactly retrievable without rerun", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-tool-result-"));
  const client = new Client({ name: "anvil-tool-result-test", version: "0.0.0" });
  try {
    const repo = join(temp, "repo");
    const stateRoot = join(temp, "state");
    const counter = join(temp, "runs.txt");
    const sessionId = "session_tool_result_test";
    await mkdir(repo, { recursive: true });
    const { binding } = await bindWorkContext({
      host: "codex",
      sessionId,
      cwd: repo,
      lifecycle: "SessionStart:startup",
      stateRoot,
    });

    const sentinel = "SENTINEL_BEYOND_INLINE_LIMIT";
    const fixture = [
      'const fs = require("node:fs");',
      'fs.appendFileSync(process.argv[1], "run\\n");',
      'process.stdout.write("A".repeat(20_000));',
      `process.stderr.write(${JSON.stringify(sentinel)});`,
      "process.exitCode = 7;",
    ].join("\n");
    const capture = spawnSync(
      process.execPath,
      [anvilBin, "tool-result", "capture", "--producer", "test", "--", process.execPath, "-e", fixture, counter],
      {
        cwd: repo,
        env: childEnv({ ANVIL_STATE_ROOT: stateRoot, CODEX_SESSION_ID: sessionId }),
        encoding: "utf8",
      },
    );

    assert.equal(capture.status, 7, capture.stderr);
    assert.ok(Buffer.byteLength(capture.stdout) <= 4 * 1024, "capture receipt must stay within 4 KiB");
    const receipt = JSON.parse(capture.stdout) as {
      schema_version: number;
      result_id: string;
      status: string;
      completeness: string;
      summary: { exit_code: number; producer: string };
      artefact: { byte_count: number; sha256: string };
    };
    assert.equal(receipt.schema_version, 1);
    assert.match(receipt.result_id, /^tr_[a-f0-9]{32}$/);
    assert.equal(receipt.status, "failed");
    assert.equal(receipt.completeness, "complete_artefact_backed");
    assert.deepEqual(receipt.summary, { exit_code: 7, producer: "test" });
    assert.equal(receipt.artefact.byte_count, 20_000 + Buffer.byteLength(sentinel));
    assert.match(receipt.artefact.sha256, /^[a-f0-9]{64}$/);

    const transport = new StdioClientTransport({
      command: process.execPath,
      args: [anvilBin, "mcp", "serve"],
      cwd: resolve("."),
      env: childEnv({ ANVIL_STATE_ROOT: stateRoot }),
      stderr: "pipe",
    });
    await client.connect(transport);

    const tools = await client.listTools();
    for (const name of ["anvil_tool_result_manifest", "anvil_tool_result_search", "anvil_tool_result_read_slice"]) {
      const tool = tools.tools.find((candidate) => candidate.name === name);
      assert.ok(tool, `${name} must be installed`);
      assert.equal(typeof tool.outputSchema, "object", `${name} must declare outputSchema`);
      assert.equal(tool.annotations?.readOnlyHint, true);
      assert.equal(tool.annotations?.idempotentHint, true);
    }

    const search = await client.callTool({
      name: "anvil_tool_result_search",
      arguments: { bindingId: binding.id, resultId: receipt.result_id, query: sentinel },
    });
    assert.equal(search.isError, undefined);
    const searchResult = search.structuredContent as {
      coverage: { complete: boolean; inspected_bytes: number; total_bytes: number };
      matches: Array<{ byte_start: number; byte_end: number }>;
    };
    assert.equal(searchResult.coverage.complete, true);
    assert.equal(searchResult.coverage.inspected_bytes, receipt.artefact.byte_count);
    assert.equal(searchResult.coverage.total_bytes, receipt.artefact.byte_count);
    assert.equal(searchResult.matches.length, 1);

    const absent = await client.callTool({
      name: "anvil_tool_result_search",
      arguments: { bindingId: binding.id, resultId: receipt.result_id, query: "DELIBERATELY_ABSENT" },
    });
    assert.equal(absent.isError, undefined);
    assert.deepEqual((absent.structuredContent as { matches: unknown[] }).matches, []);
    assert.deepEqual(
      (absent.structuredContent as { coverage: unknown }).coverage,
      {
        complete: true,
        inspected_bytes: receipt.artefact.byte_count,
        total_bytes: receipt.artefact.byte_count,
      },
    );

    const match = searchResult.matches[0];
    const slice = await client.callTool({
      name: "anvil_tool_result_read_slice",
      arguments: {
        bindingId: binding.id,
        resultId: receipt.result_id,
        byteStart: match.byte_start,
        byteLength: match.byte_end - match.byte_start,
      },
    });
    assert.equal(slice.isError, undefined);
    assert.equal((slice.structuredContent as { text: string }).text, sentinel);
    assert.equal(await readFile(counter, "utf8"), "run\n", "retrieval must not rerun the producer");

    const { binding: otherBinding } = await bindWorkContext({
      host: "codex",
      sessionId: "session_tool_result_other",
      cwd: repo,
      lifecycle: "SessionStart:startup",
      stateRoot,
    });
    const unauthorized = await client.callTool({
      name: "anvil_tool_result_manifest",
      arguments: { bindingId: otherBinding.id, resultId: receipt.result_id },
    });
    assert.equal(unauthorized.isError, true);
    assert.equal(
      (unauthorized.structuredContent as { error: { code: string } }).error.code,
      "TOOL_RESULT_UNAUTHORIZED",
    );
  } finally {
    await client.close().catch(() => undefined);
    await rm(temp, { recursive: true, force: true });
  }
});

test("small command result stays inline without creating an artefact", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-tool-result-inline-"));
  const client = new Client({ name: "anvil-tool-result-inline-test", version: "0.0.0" });
  try {
    const repo = join(temp, "repo");
    const stateRoot = join(temp, "state");
    const sessionId = "session_tool_result_inline";
    await mkdir(repo, { recursive: true });
    const { binding } = await bindWorkContext({
      host: "codex",
      sessionId,
      cwd: repo,
      lifecycle: "SessionStart:startup",
      stateRoot,
    });
    const capture = spawnSync(
      process.execPath,
      [anvilBin, "tool-result", "capture", "--producer", "git", "--", process.execPath, "-e", 'process.stdout.write("clean\\n")'],
      {
        cwd: repo,
        env: childEnv({ ANVIL_STATE_ROOT: stateRoot, CODEX_SESSION_ID: sessionId }),
        encoding: "utf8",
      },
    );
    assert.equal(capture.status, 0, capture.stderr);
    assert.ok(Buffer.byteLength(capture.stdout) <= 4 * 1024);
    const receipt = JSON.parse(capture.stdout) as {
      status: string;
      completeness: string;
      inline?: { content_type: string; byte_count: number; sha256: string; text: string };
      artefact?: unknown;
    };
    assert.equal(receipt.status, "succeeded");
    assert.equal(receipt.completeness, "complete_inline");
    assert.deepEqual(receipt.inline, {
      content_type: "text/plain; charset=utf-8",
      byte_count: 6,
      sha256: "2e22da2ab13713309ac75219e525b8e06ed02f3f1963b8feef203fa25827f93d",
      text: "clean\n",
    });
    assert.equal(receipt.artefact, undefined);

    const transport = new StdioClientTransport({
      command: process.execPath,
      args: [anvilBin, "mcp", "serve"],
      cwd: resolve("."),
      env: childEnv({ ANVIL_STATE_ROOT: stateRoot }),
      stderr: "pipe",
    });
    await client.connect(transport);
    const health = await client.callTool({
      name: "anvil_tool_result_health",
      arguments: { bindingId: binding.id },
    });
    assert.equal(health.isError, undefined);
    assert.deepEqual((health.structuredContent as { usage: { artefacts: number; total_bytes: number } }).usage, {
      artefacts: 0,
      total_bytes: 0,
      corrupt_entries: 0,
    });
  } finally {
    await client.close().catch(() => undefined);
    await rm(temp, { recursive: true, force: true });
  }
});
