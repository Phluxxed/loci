import test from 'node:test';
import assert from 'node:assert/strict';
import { caseRootForWorkspace, validateCaseSource } from '../scripts/brain-w4-followup-hook.mjs';

const base = '/Users/brummerv/phluxxed/brain-w4-closure-2026-09-09';
const source = base + '/runtime/anvil';

test('observer accepts the exact fresh c01 workspace and shared current source', () => {
  const root = base + '/execution/c01';
  const workspace = root + '/workspace';
  assert.equal(caseRootForWorkspace(workspace), root);
  validateCaseSource(root, source);
});

test('observer rejects old roots, siblings, traversal, and malformed workspaces', () => {
  for (const workspace of [
    '/Users/brummerv/phluxxed/brain-w4-followup-2026-09-08/execution/p01/workspace',
    '/Users/brummerv/phluxxed/brain-w4-followup-2026-09-09/execution/p01/workspace',
    '/Users/brummerv/phluxxed/brain-w41-isolated-2026-09-08/execution/k01-old/workspace',
    '/private/tmp/brain-w41-execution.test/k01-old/workspace',
    base + '/execution/p01/workspace',
    base + '/execution/p02/workspace',
    base + '/execution/r01/workspace',
    base + '/execution/p01/other',
    base + '/execution/p01/workspace/child',
    base + '/execution/p01/workspace/../workspace',
  ]) assert.throws(() => caseRootForWorkspace(workspace));
});

test('observer rejects a source root other than the exact current runtime', () => {
  const root = base + '/execution/c01';
  for (const wrong of [
    base + '/runtime/wiki',
    base + '/runtime/anvil/../wiki',
    '/Users/brummerv/phluxxed/brain-w41-isolated-2026-09-08/paired/current/anvil',
  ]) assert.throws(() => validateCaseSource(root, wrong));
});
