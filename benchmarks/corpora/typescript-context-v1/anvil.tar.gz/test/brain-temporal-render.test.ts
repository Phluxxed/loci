import assert from "node:assert/strict";
import { test } from "node:test";
import { renderCompilerPromptEvidenceContext } from "../src/brain-context/render.ts";
import type { BrainRetrievalResult } from "../src/brain-context/retrieve.ts";

test("the delivered context names temporal scope and unresolved authority without evidence", () => {
  const temporal = { view: "current", request_time: "2026-09-06T12:00:00Z", known_at: "2026-09-06T12:00:00Z", world_at: "2026-09-06T12:00:00Z" };
  const rendered = renderCompilerPromptEvidenceContext({
    contractVersion: "3", query: { temporal }, evidence: [], diagnostics: [
      { code: "TEMPORAL_CONFLICT", message: "Deploy mode remains contested.", provider: "temporal", details: {} },
      { code: "TEMPORAL_HISTORY_INVALID", message: "Mode history is invalid.", provider: "temporal", details: {} },
    ],
  } as unknown as BrainRetrievalResult);
  assert.match(rendered.markdown, /BRAIN_TEMPORAL_UNCERTAIN/);
  assert.match(rendered.markdown, /Deploy mode remains contested/);
  assert.match(rendered.markdown, /BRAIN_TEMPORAL_HISTORY_INVALID/);
  assert.match(rendered.markdown, /do not choose a settled winner/);
  assert.match(rendered.markdown, /"view":"current"/);
  assert.match(rendered.markdown, /"known_at":"2026-09-06T12:00:00Z"/);
  assert.equal(rendered.renderedBytes, Buffer.byteLength(rendered.markdown));
});

test("transition and date-free lineage scope survive the delivered route", () => {
  for (const temporal of [
    { view: "transition", request_time: "2026-09-06T12:00:00Z", transition: { from: "2026-07-01", to: "2026-09-01" } },
    { view: "lineage", request_time: "2026-09-06T12:00:00Z" },
  ]) {
    const rendered = renderCompilerPromptEvidenceContext({
      contractVersion: "3", query: { temporal }, evidence: [], diagnostics: [],
    } as unknown as BrainRetrievalResult);
    assert.match(rendered.markdown, new RegExp(`"view":"${temporal.view}"`));
    assert.doesNotMatch(rendered.markdown, /world_at/);
    if (temporal.transition) assert.match(rendered.markdown, /"transition":\{"from":"2026-07-01","to":"2026-09-01"\}/);
  }
});
