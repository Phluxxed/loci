import assert from "node:assert/strict";
import { join, resolve } from "node:path";
import { test } from "node:test";

import {
  AnvilConfigError,
  defaultBrainRoot,
  defaultWikiAlias,
  resolveAgentIdentity,
  resolveAnvilHome,
  resolveBrainRoot,
  validateAgentId,
} from "../src/config/index.ts";

test("resolveAgentIdentity reports missing identity when no runtime or caller id exists", () => {
  const result = resolveAgentIdentity({ env: {} });

  assert.equal(result.status, "missing");
  assert.equal(result.resolvedAgentId, undefined);
  assert.equal(result.runtimeAgentId, undefined);
});

test("resolveAgentIdentity uses ANVIL_AGENT_ID as the configured runtime identity", () => {
  const result = resolveAgentIdentity({ env: { ANVIL_AGENT_ID: "codex" } });

  assert.equal(result.status, "configured");
  assert.equal(result.resolvedAgentId, "codex");
  assert.equal(result.runtimeAgentId, "codex");
});

test("resolveAgentIdentity accepts matching caller and runtime identities", () => {
  const result = resolveAgentIdentity({ agentId: "codex", env: { ANVIL_AGENT_ID: "codex" } });

  assert.equal(result.status, "input_matches_runtime");
  assert.equal(result.resolvedAgentId, "codex");
});

test("resolveAgentIdentity reports mismatched caller and runtime identities without guessing", () => {
  const result = resolveAgentIdentity({ agentId: "claude", env: { ANVIL_AGENT_ID: "codex" } });

  assert.equal(result.status, "mismatch");
  assert.equal(result.resolvedAgentId, undefined);
  assert.equal(result.runtimeAgentId, "codex");
  assert.equal(result.requestedAgentId, "claude");
});

test("validateAgentId rejects unsafe or unnormalised identifiers", () => {
  for (const value of ["", "Codex", "codex beta", "../codex", "codex/", "codex.", "x".repeat(65)]) {
    assert.throws(() => validateAgentId(value), AnvilConfigError);
  }

  assert.equal(validateAgentId("codex_beta-1"), "codex_beta-1");
});

test("resolveAnvilHome derives a user-level config root outside repo-local continuity state", () => {
  const homeDir = resolve("/tmp/anvil-home-test");

  assert.equal(resolveAnvilHome({ env: {}, homeDir }), join(homeDir, ".anvil"));
  assert.equal(resolveAnvilHome({ env: { ANVIL_HOME: "~/custom-anvil" }, homeDir }), join(homeDir, "custom-anvil"));
  assert.equal(resolveAnvilHome({ anvilHome: "/var/tmp/anvil", env: {}, homeDir }), "/var/tmp/anvil");
});

test("resolveBrainRoot derives the default agent-scoped Brain root and accepts safe overrides", () => {
  const homeDir = resolve("/tmp/anvil-brain-test");

  assert.equal(defaultBrainRoot("codex", homeDir), join(homeDir, ".anvil-brain", "codex"));
  assert.equal(defaultWikiAlias("codex"), "anvil-brain-codex");
  assert.equal(resolveBrainRoot({ agentId: "codex", homeDir }), join(homeDir, ".anvil-brain", "codex"));
  assert.equal(resolveBrainRoot({ agentId: "codex", brainRoot: "~/brain/codex", homeDir }), join(homeDir, "brain", "codex"));
});

test("path resolution rejects null bytes and empty overrides", () => {
  assert.throws(() => resolveAnvilHome({ anvilHome: "" }), AnvilConfigError);
  assert.throws(() => resolveAnvilHome({ env: { ANVIL_HOME: "bad\0path" } }), AnvilConfigError);
  assert.throws(() => resolveBrainRoot({ agentId: "codex", brainRoot: "" }), AnvilConfigError);
  assert.throws(() => resolveBrainRoot({ agentId: "codex", brainRoot: "bad\0path" }), AnvilConfigError);
});

test("path resolution rejects relative paths and traversal segments", () => {
  assert.throws(() => resolveAnvilHome({ anvilHome: "relative-anvil" }), AnvilConfigError);
  assert.throws(() => resolveBrainRoot({ agentId: "codex", brainRoot: "../brain" }), AnvilConfigError);
  assert.throws(() => resolveBrainRoot({ agentId: "codex", brainRoot: "~/../brain" }), AnvilConfigError);
});
