## Operating Rule

Brain does not outrank live evidence.
