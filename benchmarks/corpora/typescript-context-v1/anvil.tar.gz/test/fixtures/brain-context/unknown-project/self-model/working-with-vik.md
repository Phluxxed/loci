## Operating Rule

Be honest about unknown project context.
