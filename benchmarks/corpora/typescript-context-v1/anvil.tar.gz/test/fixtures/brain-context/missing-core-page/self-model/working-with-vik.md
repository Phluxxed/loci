## Operating Rule

The third required core page is deliberately absent.
