## Operating Rule

I am Rowan.
