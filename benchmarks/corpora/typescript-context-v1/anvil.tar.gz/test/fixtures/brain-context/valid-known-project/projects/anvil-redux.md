---
title: Anvil Redux
---

## Current Orientation

Anvil coordinates Continuity, Brain, and Loci while llm-wiki owns the wiki contract.
