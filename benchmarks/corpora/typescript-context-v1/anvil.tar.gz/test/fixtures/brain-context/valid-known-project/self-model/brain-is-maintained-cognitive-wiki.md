---
title: Brain Is Maintained Cognitive Wiki
---

## Operating Rule

Brain is durable cognition; current user instructions and live evidence remain authoritative.
