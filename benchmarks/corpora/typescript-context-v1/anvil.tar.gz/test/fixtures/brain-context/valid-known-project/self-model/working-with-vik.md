---
title: Working With Vik
---

## Operating Rule

Work from live evidence, preserve uncertainty, and keep changes bounded.
