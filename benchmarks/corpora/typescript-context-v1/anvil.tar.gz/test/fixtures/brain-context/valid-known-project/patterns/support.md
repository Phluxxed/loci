---
title: Supporting Context
---

## Durable Pattern

Prefer deterministic project anchors before retrieval-derived supporting context.
