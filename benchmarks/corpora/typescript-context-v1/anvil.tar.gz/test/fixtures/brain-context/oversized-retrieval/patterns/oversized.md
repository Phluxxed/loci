## Durable Pattern

This retrieval result is deliberately much larger than the fixture manifest's hard output budget. The same durable sentence repeats so truncation is deterministic and easy to inspect.

This retrieval result is deliberately much larger than the fixture manifest's hard output budget. The same durable sentence repeats so truncation is deterministic and easy to inspect.

This retrieval result is deliberately much larger than the fixture manifest's hard output budget. The same durable sentence repeats so truncation is deterministic and easy to inspect.

This retrieval result is deliberately much larger than the fixture manifest's hard output budget. The same durable sentence repeats so truncation is deterministic and easy to inspect.

This retrieval result is deliberately much larger than the fixture manifest's hard output budget. The same durable sentence repeats so truncation is deterministic and easy to inspect.

This retrieval result is deliberately much larger than the fixture manifest's hard output budget. The same durable sentence repeats so truncation is deterministic and easy to inspect.

This retrieval result is deliberately much larger than the fixture manifest's hard output budget. The same durable sentence repeats so truncation is deterministic and easy to inspect.

This retrieval result is deliberately much larger than the fixture manifest's hard output budget. The same durable sentence repeats so truncation is deterministic and easy to inspect.
