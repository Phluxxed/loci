## Current Orientation

Anvil owns the final output cap.
