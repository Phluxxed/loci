## Operating Rule

Brain is durable cognition.
