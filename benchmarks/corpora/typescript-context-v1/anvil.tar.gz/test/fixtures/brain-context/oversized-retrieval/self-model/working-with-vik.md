## Operating Rule

Keep context bounded.
