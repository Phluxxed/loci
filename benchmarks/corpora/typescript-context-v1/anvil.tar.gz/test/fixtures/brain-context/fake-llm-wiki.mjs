#!/usr/bin/env node

import { createHash } from "node:crypto";
import { cp, mkdir, readFile, writeFile } from "node:fs/promises";
import { join } from "node:path";
import { renderCompilerPromptEvidenceContext } from "../../../src/brain-context/render.ts";

const args = process.argv.slice(2);
const wikiIndex = args.indexOf("--wiki");
if (args[0] === "publish-snapshot") {
  const aliasIndex = args.indexOf("--alias");
  const outputIndex = args.indexOf("--output-root");
  if (wikiIndex < 0 || aliasIndex < 0 || outputIndex < 0) process.exit(64);
  const wikiRoot = args[wikiIndex + 1];
  const alias = args[aliasIndex + 1];
  const outputRoot = args[outputIndex + 1];
  const behavior = JSON.parse(await readFile(join(wikiRoot, "fake-llm-wiki.json"), "utf8"));
  if (behavior.snapshot_publish_failure === true) process.exit(70);
  const digest = createHash("sha256").update(`${alias}:fixture-snapshot-v1`).digest("hex");
  const snapshotWikiRoot = join(outputRoot, alias, "snapshots", digest, "wiki");
  await mkdir(snapshotWikiRoot, { recursive: true });
  await cp(wikiRoot, snapshotWikiRoot, { recursive: true, force: true });
  const receipt = {
    contract_version: "1",
    alias,
    digest,
    snapshot_wiki_root: snapshotWikiRoot,
    status: "published",
  };
  await writeFile(join(outputRoot, alias, "current.json"), `${JSON.stringify(receipt)}\n`);
  process.stdout.write(`${JSON.stringify(receipt)}\n`);
  process.exit(0);
}
if (args[0] === "resolve-snapshot") {
  const aliasIndex = args.indexOf("--alias");
  const outputIndex = args.indexOf("--output-root");
  if (aliasIndex < 0 || outputIndex < 0) process.exit(64);
  const alias = args[aliasIndex + 1];
  const receipt = JSON.parse(await readFile(join(args[outputIndex + 1], alias, "current.json"), "utf8"));
  process.stdout.write(`${JSON.stringify({ ...receipt, status: "last_known_good" })}\n`);
  process.exit(0);
}
if (args[0] === "compile-kernel") {
  const aliasIndex = args.indexOf("--alias");
  const outputIndex = args.indexOf("--output-root");
  if (aliasIndex < 0 || outputIndex < 0) process.exit(64);
  const alias = args[aliasIndex + 1];
  const outputRoot = args[outputIndex + 1];
  const receipt = JSON.parse(await readFile(join(outputRoot, alias, "current.json"), "utf8"));
  const wikiRoot = receipt.snapshot_wiki_root;
  const behavior = JSON.parse(await readFile(join(wikiRoot, "fake-llm-wiki.json"), "utf8"));
  const sources = args.flatMap((value, index) => value === "--source" ? [JSON.parse(args[index + 1])] : []);
  const fixture = JSON.parse(await readFile(join(wikiRoot, behavior.output ?? "compiled-context.json"), "utf8"));
  const kernelQuestion = "Provide the durable identity, collaboration, and current-project orientation required at session start.";
  const override = behavior.content_by_question?.[kernelQuestion];
  const firstContent = typeof override === "string" ? override : (fixture.evidence?.[0]?.content ?? "");
  const evidence = sources.map((source, index) => {
    const content = index === 0 ? firstContent : "";
    return {
      id: `kernel:${index}`,
      provider: "snapshot_section",
      route: "explicit_ordered_source",
      page: source.page,
      source: `snapshot:${alias}:${receipt.digest}:${source.page}`,
      locator: { role: source.role, source_index: index, section: source.section },
      content,
      roles: [source.role],
      authored_state: "authored",
      derived_flags: [],
      authority_signals: ["immutable_snapshot", "exact_section_match"],
      selection_reasons: ["explicit_source", "source_order"],
      byte_cost: Buffer.byteLength(content, "utf8"),
      truncated: false,
      atomic: true,
    };
  });
  const contentBytes = evidence.reduce((total, item) => total + item.byte_cost, 0);
  if (contentBytes > 4096) {
    process.stderr.write(`${JSON.stringify({ error: { code: "KERNEL_CONTENT_CEILING_EXCEEDED" } })}\n`);
    process.exit(2);
  }
  const diagnostics = contentBytes > 3072 ? [{
    code: "KERNEL_TARGET_EXCEEDED",
    message: "Mandatory kernel sections exceed the target UTF-8 content size",
    provider: "snapshot_section",
    details: { content_bytes: contentBytes, target_content_bytes: 3072, max_content_bytes: 4096 },
  }] : [];
  process.stdout.write(`${JSON.stringify({
    kind: "collaboration_kernel_projection",
    contract_version: "1",
    wiki: { alias, digest: receipt.digest, snapshot_status: "current" },
    projection: { selection: "explicit_ordered_sources", sources, mandatory_sections: true },
    evidence,
    omissions: [],
    coverage: { required_roles: sources.map(item => item.role), covered_roles: sources.map(item => item.role), uncovered_roles: [] },
    budget: { limits: { target_content_bytes: 3072, max_content_bytes: 4096 }, content_bytes: contentBytes, target_exceeded: contentBytes > 3072, accounting: "utf-8" },
    stop: { reason: "all_sources_projected", sufficient: true, detail: "Every explicit mandatory source section was projected in caller order" },
    continuation: null,
    diagnostics,
    reporting: { omissions: { total: 0, returned: 0 }, diagnostics: { total: diagnostics.length, returned: diagnostics.length } },
  })}\n`);
  process.exit(0);
}
const questionIndex = args.indexOf("--question");
if (args[0] !== "compile-context" || wikiIndex < 0 || !args[wikiIndex + 1] || questionIndex < 0) {
  process.stderr.write("fake llm-wiki received invalid arguments\n");
  process.exit(64);
}

const wikiRoot = args[wikiIndex + 1];
const behaviorPath = join(wikiRoot, "fake-llm-wiki.json");
const behavior = JSON.parse(await readFile(behaviorPath, "utf8"));
const kernelQuestion = "Provide the durable identity, collaboration, and current-project orientation required at session start.";
const isKernelRequest = args[questionIndex + 1] === kernelQuestion;
if ((behavior.strict_kernel_expectations === true || !isKernelRequest) && behavior.expected_question !== undefined && args[questionIndex + 1] !== behavior.expected_question) {
  process.stderr.write("fake llm-wiki received an unexpected question\n");
  process.exit(66);
}
const receivedSeeds = args.flatMap((value, index) =>
  value === "--seed" && args[index + 1] ? [args[index + 1]] : [],
);

function temporalFromArgs() {
  const viewIndex = args.indexOf("--temporal-view");
  const requestTimeIndex = args.indexOf("--request-time");
  if (viewIndex < 0 || requestTimeIndex < 0) return undefined;
  const temporal = {
    view: args[viewIndex + 1],
    request_time: args[requestTimeIndex + 1],
  };
  const worldAtIndex = args.indexOf("--world-at");
  const knownAtIndex = args.indexOf("--known-at");
  const transitionFromIndex = args.indexOf("--transition-from");
  const transitionToIndex = args.indexOf("--transition-to");
  if (worldAtIndex >= 0) temporal.world_at = args[worldAtIndex + 1];
  if (knownAtIndex >= 0) temporal.known_at = args[knownAtIndex + 1];
  if (transitionFromIndex >= 0 || transitionToIndex >= 0) {
    temporal.transition = {
      from: args[transitionFromIndex + 1],
      to: args[transitionToIndex + 1],
    };
  }
  return temporal;
}

function compiledContextFixture(value) {
  if (value?.kind !== "compiled_context") return value;
  const evidence = (value.evidence ?? []).map((item, index) => ({
    id: `fixture:${index}`,
    provider: "fixture",
    route: "fixture",
    page: null,
    source: null,
    locator: {},
    content: "",
    roles: ["answer"],
    authored_state: "current",
    derived_flags: [],
    authority_signals: [],
    selection_reasons: ["fixture"],
    byte_cost: 1,
    truncated: false,
    atomic: false,
    ...item,
  }));
  const evidenceBytes = evidence.reduce((total, item) => total + item.byte_cost, 0);
  const budget = value.budget ?? {
    limits: {
      target_bytes: Number(args[args.indexOf("--target-bytes") + 1]),
      max_bytes: Number(args[args.indexOf("--max-bytes") + 1]),
      target_items: Number(args[args.indexOf("--target-items") + 1]),
      max_items: Number(args[args.indexOf("--max-items") + 1]),
      max_estimated_tokens: null,
    },
    target_exceeded_for_coverage: false,
    evidence_bytes: evidenceBytes,
    envelope_bytes: 0,
    items: evidence.length,
    estimated_tokens: Math.ceil(evidenceBytes / 4),
  };
  if (args.includes("--max-content-bytes")) {
    budget.limits = {
      ...budget.limits,
      max_content_bytes: Number(args[args.indexOf("--max-content-bytes") + 1]),
    };
    budget.content_bytes = evidence.reduce(
      (total, item) => total + Buffer.byteLength(item.content, "utf8"),
      0,
    );
  }
  return {
    ...value,
    wiki: {
      alias: "fixture-brain",
      schema_version: "1",
      runtime_contract: "2",
      ...(value.wiki ?? {}),
    },
    query: behavior.preserve_query_identity === true
      ? value.query
      : {
          shapes: ["lookup"],
          state_view: "current",
          resolved_seeds: receivedSeeds,
          ...(temporalFromArgs() ? { temporal: temporalFromArgs() } : {}),
          ...(value.query ?? {}),
          question: args[questionIndex + 1],
        },
    evidence,
    omissions: value.omissions ?? [],
    coverage: value.coverage ?? {
      required_roles: ["answer"],
      covered_roles: evidence.length > 0 ? ["answer"] : [],
      uncovered_roles: evidence.length > 0 ? [] : ["answer"],
    },
    budget,
    stop: value.stop ?? {
      reason: evidence.length > 0 ? "sufficient" : "no_evidence",
      sufficient: evidence.length > 0,
      detail: evidence.length > 0 ? "All required roles covered" : "No evidence available",
    },
    continuation: value.continuation ?? null,
    diagnostics: value.diagnostics ?? [],
    reporting: value.reporting ?? {
      omissions: { total: 0, returned: 0 },
      diagnostics: { total: (value.diagnostics ?? []).length, returned: (value.diagnostics ?? []).length },
    },
  };
}
if (
  (behavior.strict_kernel_expectations === true || !isKernelRequest) &&
  behavior.expected_seeds !== undefined &&
  JSON.stringify(receivedSeeds) !== JSON.stringify(behavior.expected_seeds)
) {
  process.stderr.write("fake llm-wiki received unexpected seeds\n");
  process.exit(67);
}
const targetBytesIndex = args.indexOf("--target-bytes");
const maxBytesIndex = args.indexOf("--max-bytes");
const maxContentBytesIndex = args.indexOf("--max-content-bytes");
if (
  (behavior.strict_kernel_expectations === true || !isKernelRequest) &&
  behavior.expected_target_bytes !== undefined &&
  args[targetBytesIndex + 1] !== String(behavior.expected_target_bytes)
) {
  process.stderr.write("fake llm-wiki received an unexpected target byte allowance\n");
  process.exit(68);
}
if (
  (behavior.strict_kernel_expectations === true || !isKernelRequest) &&
  behavior.expected_max_bytes !== undefined &&
  args[maxBytesIndex + 1] !== String(behavior.expected_max_bytes)
) {
  process.stderr.write("fake llm-wiki received an unexpected hard byte allowance\n");
  process.exit(69);
}
if (
  (behavior.strict_kernel_expectations === true || !isKernelRequest) &&
  behavior.expected_max_content_bytes !== undefined &&
  args[maxContentBytesIndex + 1] !== String(behavior.expected_max_content_bytes)
) {
  process.stderr.write("fake llm-wiki received an unexpected content byte allowance\n");
  process.exit(72);
}
if (behavior.failure_questions?.includes(args[questionIndex + 1])) {
  process.stderr.write("fake llm-wiki question-specific failure\n");
  process.exit(71);
}

switch (behavior.mode) {
  case "success":
    {
      const fixture = compiledContextFixture(
        JSON.parse(await readFile(join(wikiRoot, behavior.output ?? "compiled-context.json"), "utf8")),
      );
      const contentOverride = behavior.content_by_question?.[args[questionIndex + 1]];
      if (typeof contentOverride === "string" && fixture.evidence?.[0]) {
        fixture.evidence[0].content = contentOverride;
        if (fixture.budget.content_bytes !== undefined) {
          fixture.budget.content_bytes = fixture.evidence.reduce(
            (total, item) => total + Buffer.byteLength(item.content, "utf8"),
            0,
          );
        }
      }
      if (args.includes("--max-delivery-bytes") && behavior.omit_delivery_budget !== true) {
        fixture.budget.limits.max_delivery_bytes = Number(args[args.indexOf("--max-delivery-bytes") + 1]);
        fixture.budget.limits.delivery_format = args[args.indexOf("--delivery-format") + 1];
        fixture.budget.delivery_bytes = renderCompilerPromptEvidenceContext({
          contractVersion: fixture.contract_version,
          query: {
            projectResolution: fixture.query?.project_resolution,
            ...(fixture.query?.temporal ? { temporal: fixture.query.temporal } : {}),
          },
          evidence: fixture.evidence,
          diagnostics: fixture.diagnostics,
        }).renderedBytes;
        if (behavior.delivery_budget_override) {
          Object.assign(fixture.budget, behavior.delivery_budget_override);
        }
      }
    process.stdout.write(
      `${JSON.stringify(fixture)}\n`,
    );
    }
    break;
  case "malformed":
    process.stdout.write("{not-json");
    break;
  case "failure":
    process.stderr.write("fake llm-wiki retrieval failed\n");
    process.exit(behavior.exit_code ?? 1);
    break;
  case "timeout":
    await new Promise((resolve) => setTimeout(resolve, behavior.delay_ms ?? 5_000));
    process.stdout.write("{}\n");
    break;
  default:
    process.stderr.write("fake llm-wiki behavior is invalid\n");
    process.exit(65);
}
