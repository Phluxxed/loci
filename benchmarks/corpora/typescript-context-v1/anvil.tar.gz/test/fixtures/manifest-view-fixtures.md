# Manifest view regression fixtures

These fixtures pin the existing view assertions independently of mutable live
Objectives and local Git history.

- `manifest-rings-view.json`: Manifest graph at `4f386b9`, with the accepted
  Implementation-addition marker Task from the 2026-09-08 working tree. This
  preserves the tested 91-Task decomposition before the later launcher Task.
- `manifest-brain-view.json`: Brain graph at `4f386b9`, with explicit creation
  notes on the three W2.6 children whose Implementation origin previously came
  from Git history. The test supplies an empty temporary directory so future
  history cannot alter its result. Git-based creation detection has separate
  temporary-repository tests in `manifest-task-creation.test.ts`.

These are test inputs, not active Objective stores or current delivery records.
