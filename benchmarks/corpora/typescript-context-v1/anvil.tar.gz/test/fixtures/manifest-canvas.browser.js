// Evaluate in Agent Browser on any rendered Manifest graph.
// Only visible DOM controls and browser geometry are used.
(async () => {
  const PREFIX = '[manifest-canvas]';
  const EDGE_EPSILON = 0.75;
  const NODE_EPSILON = 0.25;
  const KEYS = ['left', 'top', 'right', 'bottom', 'width', 'height'];
  const fail = (message, detail = '') => {
    throw new Error(`${PREFIX} ${message}${detail ? ` (${detail})` : ''}`);
  };
  const frame = () => new Promise(resolve => requestAnimationFrame(resolve));
  const round = value => Math.round(value * 1000) / 1000;
  const rect = element => {
    if (!element) fail('Tried to measure a missing element');
    const box = element.getBoundingClientRect();
    return Object.fromEntries(KEYS.map(key => [key, box[key]]));
  };
  const visible = element => {
    if (!element) return false;
    const style = getComputedStyle(element);
    const box = element.getBoundingClientRect();
    return style.display !== 'none' && style.visibility !== 'hidden'
      && Number(style.opacity) !== 0 && box.width > 0 && box.height > 0;
  };
  const need = (selector, context = document) => {
    const element = context.querySelector(selector);
    if (!element) fail(`Expected ${selector} to be mounted`);
    return element;
  };
  const currentSurface = () => {
    const value = document.documentElement.dataset.manifestSurface
      || document.documentElement.dataset.manifestView;
    if (value !== 'planning' && value !== 'implementation') {
      fail(`Expected planning or implementation surface, got ${String(value)}`);
    }
    return value;
  };
  const dom = () => ({
    app: need('.lg-app'),
    flow: need('.lg-flow'),
    canvas: need('.react-flow'),
    viewport: need('.react-flow__viewport'),
    head: need('.lg-head'),
    hint: document.querySelector('.lg-hint'),
  });
  const toggle = () => document.querySelector('[data-manifest-panel-toggle]');
  const expanded = () => {
    const button = toggle();
    if (!button) return null;
    const value = button.getAttribute('aria-expanded');
    if (value !== 'true' && value !== 'false') {
      fail(`Panel toggle must expose aria-expanded=true|false, got ${String(value)}`);
    }
    return value === 'true';
  };
  const waitFor = async (description, predicate, limit = 120) => {
    let lastError;
    for (let i = 0; i < limit; i += 1) {
      try {
        if (predicate()) return;
      } catch (error) {
        lastError = error;
      }
      await frame();
    }
    fail(`Timed out waiting for ${description}`, lastError?.message || '');
  };
  const geometrySignature = () => {
    const flow = document.querySelector('.lg-flow');
    const canvas = document.querySelector('.react-flow');
    const viewport = document.querySelector('.react-flow__viewport');
    if (!flow || !canvas || !viewport) return null;
    const measured = element => KEYS.map(key => round(rect(element)[key]));
    return JSON.stringify({
      flow: measured(flow),
      canvas: measured(canvas),
      transform: viewport.style.transform,
      nodes: [...flow.querySelectorAll('.react-flow__node[data-id]')]
        .map(node => [node.getAttribute('data-id'), measured(node)])
        .sort(([left], [right]) => String(left).localeCompare(String(right))),
    });
  };
  const settle = async description => {
    let previous = null;
    let stable = 0;
    for (let i = 0; i < 120; i += 1) {
      await frame();
      const next = geometrySignature();
      stable = next !== null && next === previous ? stable + 1 : 0;
      if (stable >= 2) return;
      previous = next;
    }
    fail(`Layout did not settle after ${description}`);
  };
  const sameRect = (expected, actual, label, epsilon = EDGE_EPSILON) => {
    for (const key of KEYS) {
      if (Math.abs(expected[key] - actual[key]) > epsilon) {
        fail(`${label} changed at ${key}`, `${expected[key]} -> ${actual[key]}`);
      }
    }
  };

  const assertLayout = (label, expectedFlow = null) => {
    const elements = dom();
    if (!visible(elements.app) || !visible(elements.head)) {
      fail(`${label}: app or top chrome is hidden`);
    }
    if (elements.hint && !visible(elements.hint)) {
      fail(`${label}: mounted .lg-hint is hidden`);
    }
    if (!visible(elements.flow) || !visible(elements.canvas)) {
      fail(`${label}: flow or canvas is hidden`);
    }
    const app = rect(elements.app);
    const flow = rect(elements.flow);
    const canvas = rect(elements.canvas);
    const head = rect(elements.head);
    const hint = elements.hint && visible(elements.hint) ? rect(elements.hint) : null;
    const top = hint?.bottom ?? head.bottom;
    if (Math.abs(flow.left - app.left) > EDGE_EPSILON
      || Math.abs(flow.right - app.right) > EDGE_EPSILON
      || Math.abs(flow.bottom - app.bottom) > EDGE_EPSILON) {
      fail(`${label}: .lg-flow leaves an app edge`, JSON.stringify({ app, flow }));
    }
    if (Math.abs(flow.top - top) > EDGE_EPSILON) {
      fail(`${label}: .lg-flow does not start below visible chrome`, JSON.stringify({
        flowTop: flow.top, headBottom: head.bottom, hintBottom: hint?.bottom ?? null,
      }));
    }
    sameRect(flow, canvas, `${label}: .react-flow`);
    if (expectedFlow) sameRect(expectedFlow, flow, `${label}: flow`);
    return {
      ...elements,
      appRect: app,
      flowRect: flow,
      canvasRect: canvas,
      headRect: head,
      hintRect: hint,
    };
  };

  const assertSurface = (expected, label) => {
    if (currentSurface() !== expected) fail(`${label}: surface is not ${expected}`);
    const elements = assertLayout(label);
    const shell = [...document.querySelectorAll('.manifest-view-shell')]
      .find(candidate => elements.flow.contains(candidate));
    const button = toggle();
    if (expected === 'planning') {
      if (shell && visible(shell)) fail(`${label}: planning shows the progress panel`);
      if (button && visible(button)) fail(`${label}: planning shows the panel toggle`);
      return elements;
    }
    if (!button || !visible(button)) fail(`${label}: panel cannot be reopened`);
    if (!elements.flow.contains(button)) fail(`${label}: panel toggle escaped .lg-flow`);
    if (expanded() === false) {
      if (shell && visible(shell)) fail(`${label}: collapsed implementation panel is visible`);
      return elements;
    }
    if (!shell || !visible(shell)) fail(`${label}: implementation overlay is missing`);
    const overlay = rect(shell);
    if (overlay.left < elements.flowRect.left - EDGE_EPSILON
      || overlay.top < elements.flowRect.top - EDGE_EPSILON
      || overlay.right > elements.flowRect.right + EDGE_EPSILON
      || overlay.bottom > elements.flowRect.bottom + EDGE_EPSILON
      || Math.abs(overlay.left - elements.flowRect.left) > EDGE_EPSILON
      || Math.abs(overlay.top - elements.flowRect.top) > EDGE_EPSILON
      || Math.abs(overlay.bottom - elements.flowRect.bottom) > EDGE_EPSILON) {
      fail(`${label}: overlay is not a left-side flow overlay`, JSON.stringify({
        flow: elements.flowRect, overlay,
      }));
    }
    const position = getComputedStyle(shell).position;
    if (position !== 'absolute' && position !== 'fixed') {
      fail(`${label}: overlay participates in canvas layout`, position);
    }
    return elements;
  };

  const nodeState = () => {
    const elements = new Map();
    const rectangles = new Map();
    for (const node of document.querySelectorAll('.react-flow__node[data-id]')) {
      const id = node.getAttribute('data-id');
      if (!id) fail('A mounted graph node is missing data-id');
      if (elements.has(id)) fail(`Duplicate mounted graph node ${id}`);
      elements.set(id, node);
      rectangles.set(id, rect(node));
    }
    return { elements, rectangles, ids: [...elements.keys()].sort() };
  };
  const selectionState = () => ({
    html: document.documentElement.dataset.manifestSelection || null,
    selected: [...document.querySelectorAll('.react-flow__node[data-id]')]
      .filter(node => node.classList.contains('selected'))
      .map(node => node.getAttribute('data-id')).sort(),
    detail: [...document.querySelectorAll('[data-manifest-node-id]')]
      .map(node => node.getAttribute('data-manifest-node-id')).filter(Boolean).sort(),
  });
  const expansionState = () => [...document.querySelectorAll('[data-lens-expand]')]
    .map(control => ({
      owner: control.closest('.react-flow__node[data-id]')?.getAttribute('data-id') || null,
      text: control.textContent?.replace(/\s+/g, ' ').trim() || '',
      title: control.getAttribute('title'),
      ariaExpanded: control.getAttribute('aria-expanded'),
      dataExpanded: control.getAttribute('data-expanded'),
    }))
    .sort((left, right) => JSON.stringify(left).localeCompare(JSON.stringify(right)));
  const snapshot = label => {
    const elements = assertLayout(label);
    const nodes = nodeState();
    return {
      graph: elements.canvas,
      flow: elements.flow,
      canvas: elements.canvas,
      flowRect: elements.flowRect,
      canvasRect: elements.canvasRect,
      nodeIds: nodes.ids,
      nodeElements: nodes.elements,
      nodeRects: nodes.rectangles,
      camera: {
        inline: elements.viewport.style.transform,
        computed: getComputedStyle(elements.viewport).transform,
      },
      selection: selectionState(),
      expansion: expansionState(),
    };
  };
  const compare = (expected, label) => {
    const actual = snapshot(label);
    if (actual.graph !== expected.graph) fail(`${label}: .react-flow was remounted`);
    if (JSON.stringify(actual.nodeIds) !== JSON.stringify(expected.nodeIds)) {
      fail(`${label}: mounted graph nodes changed`, JSON.stringify({
        before: expected.nodeIds, after: actual.nodeIds,
      }));
    }
    for (const id of expected.nodeIds) {
      if (actual.nodeElements.get(id) !== expected.nodeElements.get(id)) {
        fail(`${label}: graph node ${id} was remounted`);
      }
      sameRect(expected.nodeRects.get(id), actual.nodeRects.get(id), `${label}: graph node ${id}`, NODE_EPSILON);
    }
    sameRect(expected.flowRect, actual.flowRect, `${label}: flow`);
    sameRect(expected.canvasRect, actual.canvasRect, `${label}: canvas`);
    if (JSON.stringify(actual.camera) !== JSON.stringify(expected.camera)) {
      fail(`${label}: viewport transform changed`, JSON.stringify({ before: expected.camera, after: actual.camera }));
    }
    if (JSON.stringify(actual.selection) !== JSON.stringify(expected.selection)) {
      fail(`${label}: selection changed`, JSON.stringify({ before: expected.selection, after: actual.selection }));
    }
    if (JSON.stringify(actual.expansion) !== JSON.stringify(expected.expansion)) {
      fail(`${label}: expansion changed`, JSON.stringify({ before: expected.expansion, after: actual.expansion }));
    }
    return actual;
  };

  const chooseSurface = async next => {
    const button = need(`[data-manifest-surface-choice="${next}"]`);
    if (!visible(button)) fail(`The ${next} surface button is hidden`);
    button.click();
    await waitFor(`${next} surface`, () => currentSurface() === next);
    await settle(`switching to ${next}`);
  };
  const flipPanel = async label => {
    const button = toggle();
    if (!button || !visible(button)) fail(`${label}: panel toggle is not clickable`);
    const before = expanded();
    button.click();
    await waitFor(`${label} aria-expanded`, () => expanded() === !before);
    await settle(label);
  };
  const assertCanvasHit = label => {
    const elements = dom();
    const box = rect(elements.flow);
    for (const dx of [4, 8, 16, 28, 44, 64, 88]) {
      for (const dy of [4, 8, 16, 28, 44, 64, 88]) {
        const x = box.left + dx;
        const y = box.top + dy;
        if (x >= box.right - 2 || y >= box.bottom - 2) continue;
        const hit = document.elementFromPoint(x, y);
        if (!hit || !elements.flow.contains(hit)) continue;
        if (hit.closest('.manifest-view-shell, .react-flow__controls, .react-flow__node, .react-flow__minimap')) continue;
        const pane = hit.closest('.react-flow__pane, .react-flow__renderer') || hit === elements.canvas;
        if (!pane || getComputedStyle(hit).pointerEvents === 'none') continue;
        return { x: round(x), y: round(y), target: hit.className || hit.tagName };
      }
    }
    fail(`${label}: no uncovered hit-testable React Flow pane near flow top-left`, JSON.stringify(box));
  };

  await waitFor('initial Manifest surface', () => {
    const value = document.documentElement.dataset.manifestSurface
      || document.documentElement.dataset.manifestView;
    return value === 'planning' || value === 'implementation';
  });
  await settle('initial render');
  assertLayout('initial canvas');
  const human = JSON.parse(need('#manifest-human-view').textContent);
  if (human.objective.phase === 'planning') {
    assertSurface('planning', 'canonical Planning view');
    if (document.querySelector('[data-manifest-surface-choice="implementation"]')) {
      fail('Planning Objective exposes an Implementation choice');
    }
    return { ok: true, surfaces: ['planning'], hitTest: assertCanvasHit('canonical Planning view') };
  }
  const originalSurface = currentSurface();
  const originalPanel = originalSurface === 'implementation' ? expanded() : null;
  let passed = false;
  try {
    if (originalSurface !== 'implementation') await chooseSurface('implementation');
    if (expanded() === false) await flipPanel('open implementation panel for baseline');
    assertSurface('implementation', 'implementation baseline');
    const baseline = snapshot('implementation baseline');
    for (let cycle = 1; cycle <= 2; cycle += 1) {
      await flipPanel(`implementation panel cycle ${cycle}`);
      assertSurface('implementation', `implementation panel cycle ${cycle}`);
      compare(baseline, `implementation panel cycle ${cycle}`);
      await flipPanel(`implementation panel restore ${cycle}`);
      compare(baseline, `implementation panel restore ${cycle}`);
    }

    let hitTest = null;
    for (let cycle = 1; cycle <= 2; cycle += 1) {
      await chooseSurface('planning');
      assertSurface('planning', `planning phase switch ${cycle}`);
      compare(baseline, `planning phase switch ${cycle}`);
      hitTest = assertCanvasHit(`planning phase switch ${cycle}`);
      await chooseSurface('implementation');
      assertSurface('implementation', `implementation phase restore ${cycle}`);
      compare(baseline, `implementation phase restore ${cycle}`);
      await flipPanel(`implementation panel after phase switch ${cycle}`);
      compare(baseline, `implementation panel after phase switch ${cycle}`);
      await flipPanel(`implementation panel final restore ${cycle}`);
      compare(baseline, `implementation panel final restore ${cycle}`);
    }
    passed = true;
    return {
      ok: true,
      surfaces: ['planning', 'implementation'],
      mountedNodes: baseline.nodeIds.length,
      panelToggles: 8,
      phaseSwitches: 4,
      hitTest,
      originalSurface,
      originalPanelExpanded: originalPanel,
    };
  } finally {
    if (passed) {
      if (currentSurface() !== originalSurface) await chooseSurface(originalSurface);
      if (originalSurface === 'implementation' && originalPanel !== null
        && expanded() !== originalPanel) await flipPanel('restore original panel visibility');
      await settle('restoring the original surface');
    }
  }
})();
