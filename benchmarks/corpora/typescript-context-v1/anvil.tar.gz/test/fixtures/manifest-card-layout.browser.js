// Evaluate in Agent Browser on the fully expanded Brain Objective.
// Uses the actual rendered rectangles, including cards outside the viewport.
(() => {
  const expected = ['W2.2', 'W2.4', 'W2.5', 'W2.5.1', 'W2.5.2', 'W2.5.3',
    'W2.6', 'W2.6.1', 'W2.6.2', 'W2.6.3'];
  const cards = [...document.querySelectorAll('.react-flow__node[data-id]')]
    .filter(node => node.querySelector('.node:not(.node--detail)'));
  const boxes = cards.map(node => ({
    reference: node.querySelector('.manifest-card__reference')?.textContent || 'Objective',
    rect: node.getBoundingClientRect(),
  }));
  const intersections = [];
  for (let i = 0; i < boxes.length; i++) {
    for (let j = i + 1; j < boxes.length; j++) {
      const a = boxes[i], b = boxes[j];
      const width = Math.min(a.rect.right, b.rect.right) - Math.max(a.rect.left, b.rect.left);
      const height = Math.min(a.rect.bottom, b.rect.bottom) - Math.max(a.rect.top, b.rect.top);
      if (width > 0.1 && height > 0.1) intersections.push([a.reference, b.reference, width, height]);
    }
  }
  if (intersections.length) throw new Error('Overlapping cards: ' + JSON.stringify(intersections));
  if (cards.length !== 30) throw new Error('Expected the full 30-card Brain graph, got ' + cards.length);
  const marked = cards.filter(node => node.innerText.includes('Added during Implementation'))
    .map(node => node.querySelector('.manifest-card__reference')?.textContent).sort();
  if (JSON.stringify(marked) !== JSON.stringify(expected.sort())) {
    throw new Error('Incorrect visible creation markers: ' + JSON.stringify(marked));
  }
  if (document.querySelector('.manifest-card__creation, #manifest-task-creation-style')) {
    throw new Error('The injected marker frontend still exists');
  }
  return { cards: cards.length, intersections: 0, marked,
    viewport: [innerWidth, innerHeight], camera: document.querySelector('.react-flow__viewport')?.style.transform };
})();
