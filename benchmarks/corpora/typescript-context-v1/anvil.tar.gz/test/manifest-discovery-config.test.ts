import assert from "node:assert/strict";
import { execFileSync, spawn, spawnSync } from "node:child_process";
import { mkdir, mkdtemp, realpath, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join, resolve } from "node:path";
import { afterEach, test } from "node:test";

import { createObjectiveFile, validateObjective } from "../src/manifest/index.ts";

const roots: string[] = [];

afterEach(async () => {
  await Promise.all(roots.splice(0).map((root) => rm(root, { recursive: true, force: true })));
});

async function gitRepository(prefix: string): Promise<string> {
  const root = await mkdtemp(join(tmpdir(), prefix));
  roots.push(root);
  execFileSync("git", ["init", "-q"], { cwd: root });
  return root;
}

async function nestedGitRepository(parent: string, name: string): Promise<string> {
  const root = join(parent, name);
  await mkdir(root, { recursive: true });
  execFileSync("git", ["init", "-q"], { cwd: root });
  return root;
}

async function directory(prefix: string): Promise<string> {
  const root = await mkdtemp(join(tmpdir(), prefix));
  roots.push(root);
  return root;
}

async function addObjective(repository: string, title: string, id: string): Promise<void> {
  const result = validateObjective({
    id,
    title,
    outcome: "The configured discovery root exposes this repository.",
    details: "",
    phase: "planning",
    workstreams: [],
  });
  assert.equal(result.valid, true);
  if (!result.valid) throw new Error("Discovery configuration fixture must be valid.");
  await createObjectiveFile(repository, result.graph);
}

function childEnvironment(configHome: string, discoveryRoot?: string): NodeJS.ProcessEnv {
  const environment = { ...process.env };
  environment.XDG_CONFIG_HOME = configHome;
  delete environment.MANIFEST_DISCOVERY_ROOT;
  if (discoveryRoot !== undefined) environment.MANIFEST_DISCOVERY_ROOT = discoveryRoot;
  return environment;
}

async function writeInstallationConfig(configHome: string, value: unknown): Promise<string> {
  const path = join(configHome, "manifest", "config.json");
  await mkdir(join(configHome, "manifest"), { recursive: true });
  await writeFile(path, typeof value === "string" ? value : JSON.stringify(value), "utf8");
  return path;
}

async function startCli(
  command: readonly string[],
  cwd: string,
  environment: NodeJS.ProcessEnv,
): Promise<{ child: ReturnType<typeof spawn>; url: string }> {
  const child = spawn(process.execPath, [...command, "--port", "0", "--json"], {
    cwd,
    env: environment,
    stdio: ["ignore", "pipe", "pipe"],
  });
  const line = await firstLine(child);
  const started = JSON.parse(line) as { repository: string; url: string };
  assert.match(started.url, /^http:\/\/127\.0\.0\.1:\d+$/);
  return { child, url: started.url };
}

async function getDiscovery(url: string): Promise<any> {
  const response = await fetch(`${url}/api/discovery`);
  return { status: response.status, body: await response.json() };
}

async function stopCli(child: ReturnType<typeof spawn>): Promise<void> {
  const result = await terminateChild(child);
  assert.equal(result.code, 0);
  assert.equal(result.signal, null);
}

test("Manifest CLI resolves discovery root by flag, environment, config, then Git fallback", async () => {
  const startupRepository = await gitRepository("manifest-discovery-config-startup-");
  const startupNested = join(startupRepository, "packages", "app");
  await mkdir(startupNested, { recursive: true });
  await addObjective(startupRepository, "Startup repository", "obj_11111111111111111111111111111111");

  const configScope = await directory("manifest-discovery-config-scope-");
  const configuredRoot = join(configScope, "configured");
  const additionalRootOne = join(configScope, "additional-one");
  const additionalRootTwo = join(configScope, "additional-two");
  const unrelatedSiblingRoot = join(configScope, "unrelated-sibling");
  await mkdir(configuredRoot, { recursive: true });
  await mkdir(additionalRootOne, { recursive: true });
  await mkdir(additionalRootTwo, { recursive: true });
  await mkdir(unrelatedSiblingRoot, { recursive: true });
  const configRepository = await nestedGitRepository(configuredRoot, "nested/repository");
  await addObjective(configRepository, "Config repository", "obj_22222222222222222222222222222222");
  const additionalRepositoryOne = await nestedGitRepository(additionalRootOne, "nested/repository");
  await addObjective(additionalRepositoryOne, "Additional repository one", "obj_77777777777777777777777777777777");
  const additionalRepositoryTwo = await nestedGitRepository(additionalRootTwo, "nested/repository");
  await addObjective(additionalRepositoryTwo, "Additional repository two", "obj_88888888888888888888888888888888");
  const unrelatedSiblingRepository = await nestedGitRepository(unrelatedSiblingRoot, "nested/repository");
  await addObjective(unrelatedSiblingRepository, "Unrelated sibling", "obj_99999999999999999999999999999999");

  const environmentRoot = await directory("manifest-discovery-config-environment-");
  const environmentRepository = await nestedGitRepository(environmentRoot, "nested/repository");
  await addObjective(environmentRepository, "Environment repository", "obj_33333333333333333333333333333333");

  const flagRoot = await directory("manifest-discovery-config-flag-");
  const flagRepository = await nestedGitRepository(flagRoot, "nested/repository");
  await addObjective(flagRepository, "Flag repository", "obj_44444444444444444444444444444444");

  const configHome = await directory("manifest-discovery-config-home-");
  const standalone = resolve("bin/manifest.ts");
  const routed = resolve("bin/anvil.ts");

  const fallback = await startCli([standalone], startupNested, childEnvironment(configHome));
  try {
    const result = await getDiscovery(fallback.url);
    assert.equal(result.status, 200);
    assert.equal(result.body.root, await realpath(startupRepository));
    assert.deepEqual(result.body.repositories.map((item: any) => item.repository), [await realpath(startupRepository)]);
    assert.equal(result.body.repositories[0].objectives[0].objective.title, "Startup repository");
    assert.deepEqual(result.body.problems, []);
  } finally {
    await stopCli(fallback.child);
  }

  await writeInstallationConfig(configHome, {
    discoveryRoot: configuredRoot,
    additionalDiscoveryRoots: [additionalRootOne, additionalRootTwo],
  });
  const configured = await startCli([standalone], startupNested, childEnvironment(configHome));
  try {
    const result = await getDiscovery(configured.url);
    assert.equal(result.body.root, await realpath(configuredRoot));
    assert.deepEqual(result.body.roots, [
      await realpath(configuredRoot),
      await realpath(additionalRootOne),
      await realpath(additionalRootTwo),
    ]);
    assert.deepEqual(
      result.body.repositories.map((item: any) => item.repository).sort(),
      (await Promise.all([configRepository, additionalRepositoryOne, additionalRepositoryTwo].map((repository) => realpath(repository)))).sort(),
    );
    assert.deepEqual(
      result.body.repositories.flatMap((item: any) => item.objectives.map((entry: any) => entry.objective?.title)).sort(),
      ["Additional repository one", "Additional repository two", "Config repository"],
    );
    assert.equal(JSON.stringify(result.body).includes("Unrelated sibling"), false);
  } finally {
    await stopCli(configured.child);
  }

  const fromEnvironment = await startCli([routed, "manifest"], startupNested, childEnvironment(configHome, environmentRoot));
  try {
    const result = await getDiscovery(fromEnvironment.url);
    assert.equal(result.body.root, await realpath(environmentRoot));
    assert.deepEqual(result.body.repositories.map((item: any) => item.repository), [await realpath(environmentRepository)]);
    assert.equal("roots" in result.body, false);
    assert.equal(JSON.stringify(result.body).includes("Additional repository"), false);
  } finally {
    await stopCli(fromEnvironment.child);
  }

  const fromFlag = await startCli([standalone, "--discovery-root", flagRoot], startupNested, childEnvironment(configHome, environmentRoot));
  try {
    const result = await getDiscovery(fromFlag.url);
    assert.equal(result.body.root, await realpath(flagRoot));
    assert.deepEqual(result.body.repositories.map((item: any) => item.repository), [await realpath(flagRepository)]);
    assert.equal("roots" in result.body, false);
    assert.equal(JSON.stringify(result.body).includes("Additional repository"), false);
  } finally {
    await stopCli(fromFlag.child);
  }
});

test("malformed installation config fails explicitly, while higher priority overrides bypass it", async () => {
  const startupRepository = await gitRepository("manifest-discovery-config-invalid-startup-");
  await addObjective(startupRepository, "Invalid config startup", "obj_55555555555555555555555555555555");
  const overrideRoot = await directory("manifest-discovery-config-invalid-override-");
  const overrideRepository = await nestedGitRepository(overrideRoot, "repository");
  await addObjective(overrideRepository, "Override repository", "obj_66666666666666666666666666666666");
  const configHome = await directory("manifest-discovery-config-invalid-home-");
  const configPath = await writeInstallationConfig(configHome, "{ invalid");
  const environment = childEnvironment(configHome);

  const failed = spawnSync(process.execPath, [resolve("bin/manifest.ts"), "--port", "0", "--json"], {
    cwd: startupRepository,
    env: environment,
    encoding: "utf8",
  });
  assert.equal(failed.status, 1);
  assert.match(failed.stderr, new RegExp(`malformed JSON: ${escapeRegExp(configPath)}`));

  const fromEnvironment = await startCli(
    [resolve("bin/manifest.ts")],
    startupRepository,
    childEnvironment(configHome, overrideRoot),
  );
  try {
    const result = await getDiscovery(fromEnvironment.url);
    assert.equal(result.body.root, await realpath(overrideRoot));
  } finally {
    await stopCli(fromEnvironment.child);
  }

  const fromFlag = await startCli(
    [resolve("bin/manifest.ts"), "--discovery-root", overrideRoot],
    startupRepository,
    childEnvironment(configHome, "relative-environment-root"),
  );
  try {
    const result = await getDiscovery(fromFlag.url);
    assert.equal(result.body.root, await realpath(overrideRoot));
  } finally {
    await stopCli(fromFlag.child);
  }
});

test("configured discovery roots require an absolute path", async () => {
  const repository = await gitRepository("manifest-discovery-config-relative-");
  const configHome = await directory("manifest-discovery-config-relative-home-");
  await writeInstallationConfig(configHome, { discoveryRoot: "relative/root" });
  const failed = spawnSync(process.execPath, [resolve("bin/manifest.ts"), "--port", "0", "--json"], {
    cwd: repository,
    env: childEnvironment(configHome),
    encoding: "utf8",
  });
  assert.equal(failed.status, 1);
  assert.match(failed.stderr, /discoveryRoot must be an absolute path/);
});

test("configured additional discovery roots require an array of non-empty absolute existing directories", async () => {
  const repository = await gitRepository("manifest-discovery-config-additional-invalid-");
  const configHome = await directory("manifest-discovery-config-additional-invalid-home-");
  const scenarios: readonly { value: unknown; pattern: RegExp }[] = [
    { value: "not-an-array", pattern: /additionalDiscoveryRoots must be an array of absolute paths/ },
    { value: ["relative/root"], pattern: /additionalDiscoveryRoots\[0\] must be an absolute path/ },
    { value: [""], pattern: /additionalDiscoveryRoots\[0\] must be a non-empty absolute path/ },
    { value: [join(configHome, "missing-root")], pattern: /Cannot use Manifest discovery root/ },
  ];

  for (const scenario of scenarios) {
    await writeInstallationConfig(configHome, {
      discoveryRoot: repository,
      additionalDiscoveryRoots: scenario.value,
    });
    const failed = spawnSync(process.execPath, [resolve("bin/manifest.ts"), "--port", "0", "--json"], {
      cwd: repository,
      env: childEnvironment(configHome),
      encoding: "utf8",
    });
    assert.equal(failed.status, 1);
    assert.match(failed.stderr, scenario.pattern);
  }
});

function escapeRegExp(value: string): string {
  return value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function firstLine(child: ReturnType<typeof spawn>): Promise<string> {
  const stream = child.stdout!;
  return new Promise((resolvePromise, reject) => {
    let buffered = "";
    const timeout = setTimeout(() => {
      cleanup();
      reject(new Error("Timed out waiting for Manifest CLI startup output."));
    }, 5_000);
    const cleanup = () => {
      clearTimeout(timeout);
      stream.off("data", onData);
      stream.off("error", onError);
      child.off("exit", onExit);
    };
    const onData = (chunk: string) => {
      buffered += chunk;
      const newline = buffered.indexOf("\n");
      if (newline !== -1) {
        cleanup();
        resolvePromise(buffered.slice(0, newline));
      }
    };
    const onError = (error: Error) => {
      cleanup();
      reject(error);
    };
    const onExit = (code: number | null, signal: NodeJS.Signals | null) => {
      cleanup();
      reject(new Error(`Manifest CLI exited before startup output (code=${code}, signal=${signal}).`));
    };
    stream.setEncoding("utf8");
    stream.on("data", onData);
    stream.on("error", onError);
    child.on("exit", onExit);
    if (child.exitCode !== null || child.signalCode !== null) onExit(child.exitCode, child.signalCode);
  });
}

function terminateChild(child: ReturnType<typeof spawn>): Promise<{
  code: number | null;
  signal: NodeJS.Signals | null;
}> {
  return new Promise((resolvePromise, reject) => {
    let timeout: ReturnType<typeof setTimeout> | undefined;
    const cleanup = () => {
      if (timeout !== undefined) clearTimeout(timeout);
      child.off("exit", onExit);
      child.off("error", onError);
    };
    const onExit = (code: number | null, signal: NodeJS.Signals | null) => {
      cleanup();
      resolvePromise({ code, signal });
    };
    const onError = (error: Error) => {
      cleanup();
      reject(error);
    };
    child.once("exit", onExit);
    child.once("error", onError);
    timeout = setTimeout(() => {
      child.kill("SIGKILL");
      cleanup();
      reject(new Error("Timed out waiting for Manifest CLI to exit after SIGTERM."));
    }, 5_000);
    if (child.exitCode !== null || child.signalCode !== null) {
      onExit(child.exitCode, child.signalCode);
      return;
    }
    child.kill("SIGTERM");
  });
}
