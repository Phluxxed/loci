import assert from "node:assert/strict";
import { join } from "node:path";
import { test } from "node:test";

import {
  BROWSERLESS_BASE_IMAGE,
  BrowserConfigurationError,
  buildAgentBrowserEnvironment,
  buildBrowserMcpLaunch,
  serveBrowserMcp,
} from "../src/browser/index.ts";
import type { BrowserLaunchPolicy, BrowserState, BrowserStateRead } from "../src/browser/index.ts";

function state(corporate: "configured" | "unconfigured" = "configured"): BrowserState {
  const root = "/tmp/anvil/browser";
  return {
    paths: { root, config: join(root, "config.json"), secrets: join(root, "secrets.json") },
    config: {
      schema_version: 1,
      base_image: BROWSERLESS_BASE_IMAGE,
      local: { host_port: 48131 },
      corporate:
        corporate === "configured"
          ? {
              host_port: 48132,
              status: "configured",
              image_ref: "anvil/browserless-corporate:ca-test-base-test",
              ca_fingerprint: "A1".repeat(32),
              installed_ca_path: "/tmp/anvil/browser/certs/corporate-root.crt",
              source: {
                kind: "keychain",
                label: "Test Corporate Root CA",
                keychain: "/tmp/test-system.keychain",
              },
            }
          : { host_port: 48132, status: "unconfigured" },
    },
    secrets: {
      schema_version: 1,
      local_token: "a".repeat(64),
      corporate_token: "b".repeat(64),
    },
  };
}

test("buildBrowserMcpLaunch carries local restrictions in environment without exposing the token in arguments", () => {
  const runtime = state();
  const launch = buildBrowserMcpLaunch("local", runtime);

  assert.deepEqual(launch.args, ["mcp", "--tools", "all"]);
  assert.equal(launch.args.join(" ").includes(runtime.secrets.local_token), false);
  assert.match(launch.env.AGENT_BROWSER_CDP ?? "", /^ws:\/\/127\.0\.0\.1:48131\//);
  assert.match(launch.env.AGENT_BROWSER_CDP ?? "", new RegExp(`token=${runtime.secrets.local_token}`));
  assert.equal(launch.env.AGENT_BROWSER_ALLOWED_DOMAINS, "localhost,*.localhost,host.docker.internal");
  assert.equal(launch.env.AGENT_BROWSER_CONTENT_BOUNDARIES, "true");
  assert.match(launch.env.AGENT_BROWSER_NAMESPACE ?? "", /^anvil-browser-local-[a-f0-9]{12}$/);

  const cdp = new URL(launch.env.AGENT_BROWSER_CDP!);
  const browserlessLaunch = JSON.parse(cdp.searchParams.get("launch")!);
  assert.equal(browserlessLaunch.acceptInsecureCerts, true);
});

test("agent-browser launch environment discards ambient policy and proxy overrides", () => {
  const env = buildAgentBrowserEnvironment(
    {
      AGENT_BROWSER_CDP: "ws://127.0.0.1:48131/?token=selected",
      AGENT_BROWSER_CONTENT_BOUNDARIES: "true",
    },
    {
      PATH: "/usr/bin",
      AGENT_BROWSER_ARGS: "--ignore-certificate-errors",
      AGENT_BROWSER_ALLOWED_DOMAINS: "*",
      AGENT_BROWSER_PROFILE: "/tmp/persistent-profile",
      HTTP_PROXY: "http://untrusted-proxy.invalid",
      https_proxy: "http://untrusted-proxy.invalid",
    },
  );

  assert.equal(env.PATH, "/usr/bin");
  assert.equal(env.AGENT_BROWSER_CDP, "ws://127.0.0.1:48131/?token=selected");
  assert.equal(env.AGENT_BROWSER_CONTENT_BOUNDARIES, "true");
  assert.equal("AGENT_BROWSER_ARGS" in env, false);
  assert.equal("AGENT_BROWSER_ALLOWED_DOMAINS" in env, false);
  assert.equal("AGENT_BROWSER_PROFILE" in env, false);
  assert.equal("HTTP_PROXY" in env, false);
  assert.equal("https_proxy" in env, false);
});

test("corporate MCP launch is explicit, open-world, and keeps TLS verification enabled", () => {
  const runtime = state();
  const launch = buildBrowserMcpLaunch("corporate", runtime);

  assert.equal("AGENT_BROWSER_ALLOWED_DOMAINS" in launch.env, false);
  const cdp = new URL(launch.env.AGENT_BROWSER_CDP!);
  const browserlessLaunch = JSON.parse(cdp.searchParams.get("launch")!);
  assert.equal("acceptInsecureCerts" in browserlessLaunch, false);
  assert.match(launch.env.AGENT_BROWSER_NAMESPACE ?? "", /^anvil-browser-corporate-[a-f0-9]{12}$/);
});

test("corporate MCP launch fails closed when its CA-backed profile is unconfigured", () => {
  assert.throws(
    () => buildBrowserMcpLaunch("corporate", state("unconfigured")),
    (error: unknown) => error instanceof BrowserConfigurationError && error.code === "CORPORATE_CA_MISSING",
  );
});

test("serveBrowserMcp reconciles only the selected renderer and launches protocol-clean stdio MCP", async () => {
  const runtime = state();
  const reconciled: BrowserLaunchPolicy[] = [];
  let spawned:
    | {
        command: string;
        args: string[];
        env: Record<string, string | undefined>;
      }
    | undefined;

  const exitCode = await serveBrowserMcp(
    { mode: "local", anvilHome: "/tmp/anvil" },
    {
      readState: async (): Promise<BrowserStateRead> => ({ kind: "ok", ...runtime }),
      reconcile: async (input) => {
        reconciled.push(input.policy);
        return {
          mode: input.policy.mode,
          state: "ready",
          image_ref: input.policy.container.image_ref,
          renderer_status: "healthy",
          registration_status: "unknown",
          diagnostics: [],
        };
      },
      spawnMcp: async (command, args, env) => {
        spawned = { command, args, env };
        return 0;
      },
    },
  );

  assert.equal(exitCode, 0);
  assert.equal(reconciled.length, 1);
  assert.equal(reconciled[0]?.mode, "local");
  assert.equal(spawned?.command, "agent-browser");
  assert.deepEqual(spawned?.args, ["mcp", "--tools", "all"]);
  assert.equal(spawned?.args.join(" ").includes(runtime.secrets.local_token), false);
});

test("serveBrowserMcp refuses missing or malformed installation state", async () => {
  await assert.rejects(
    serveBrowserMcp(
      { mode: "local", anvilHome: "/tmp/anvil" },
      {
        readState: async () => ({ kind: "missing" }),
      },
    ),
    (error: unknown) => error instanceof BrowserConfigurationError && error.code === "BROWSER_STATE_INVALID",
  );
});
