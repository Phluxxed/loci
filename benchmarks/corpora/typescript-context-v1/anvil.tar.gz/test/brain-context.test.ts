import assert from "node:assert/strict";
import { chmod, mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import { join } from "node:path";
import { tmpdir } from "node:os";
import { test } from "node:test";
import { fileURLToPath } from "node:url";

import {
  BrainContextError,
  parseBrainBootstrapManifest,
  type BrainBootstrapManifest,
} from "../src/brain-context/manifest.ts";
import {
  normalizeGitRemote,
  selectBrainProject,
  toWorkspaceIdentityInput,
  toWorkspaceIdentityInputWithDiagnostics,
} from "../src/brain-context/project.ts";
import { parseCompilerOutput, retrieveBrainContext } from "../src/brain-context/retrieve.ts";

const fixturesRoot = fileURLToPath(new URL("./fixtures/brain-context/", import.meta.url));

function assertManifestError(value: unknown, expectedCode: string): boolean {
  assert.ok(value instanceof BrainContextError);
  assert.equal(value.code, expectedCode);
  return true;
}

test("the parser accepts the real Brain bootstrap manifest fixture", async () => {
  const raw = JSON.parse(await readFile(`${fixturesRoot}/real-brain-bootstrap.json`, "utf8"));
  const manifest = parseBrainBootstrapManifest(raw);

  assert.equal(manifest.version, 1);
  assert.deepEqual(manifest.core_pages, [
    "self-model/i-am-rowan.md",
    "self-model/working-with-vik.md",
    "self-model/brain-is-maintained-cognitive-wiki.md",
  ]);
  assert.deepEqual(
    manifest.projects.map((project) => project.page),
    ["projects/anvil-redux.md", "projects/ai-graph-ideas.md"],
  );
});

test("manifest declares one bounded section locator for each Collaboration Kernel role", () => {
  const base = {
    version: 1,
    core_pages: ["self-model/identity.md", "self-model/collaboration.md", "self-model/authority.md"],
    prompt_guidance_pages: [],
    projects: [],
    budgets: {
      session_start_target_bytes: 16_384,
      session_start_hard_bytes: 24_576,
      prompt_recall_target_bytes: 8_192,
      prompt_recall_hard_bytes: 16_384,
      prompt_guidance_hard_bytes: 0,
    },
  };
  const collaborationKernel = {
    target_bytes: 3_072,
    hard_bytes: 4_096,
    sources: [
      { role: "identity", page: "self-model/identity.md", section: "Operating Rule" },
      { role: "collaboration", page: "self-model/collaboration.md", section: "Operating Rule" },
      { role: "authority", page: "self-model/authority.md", section: "Operating Rule" },
    ],
  };

  const manifest = parseBrainBootstrapManifest({ ...base, collaboration_kernel: collaborationKernel });
  assert.deepEqual(manifest.collaboration_kernel, collaborationKernel);

  for (const collaboration_kernel of [
    { ...collaborationKernel, target_bytes: 3_073 },
    { ...collaborationKernel, hard_bytes: 4_097 },
    { ...collaborationKernel, sources: collaborationKernel.sources.slice(0, 2) },
    { ...collaborationKernel, sources: [...collaborationKernel.sources, collaborationKernel.sources[0]] },
    {
      ...collaborationKernel,
      sources: collaborationKernel.sources.map((source) =>
        source.role === "identity" ? { ...source, page: "outside/not-core.md" } : source,
      ),
    },
    {
      ...collaborationKernel,
      sources: collaborationKernel.sources.map((source) =>
        source.role === "identity" ? { ...source, section: "" } : source,
      ),
    },
  ]) {
    assert.throws(
      () => parseBrainBootstrapManifest({ ...base, collaboration_kernel }),
      (error) => assertManifestError(error, "BRAIN_MANIFEST_INVALID"),
    );
  }
});

test("manifest validation rejects versions, duplicate identifiers, unsafe paths, and invalid budgets", () => {
  const base: BrainBootstrapManifest = {
    version: 1,
    core_pages: ["self-model/core.md"],
    prompt_guidance_pages: [],
    projects: [
      { page: "projects/one.md", aliases: ["one"], remotes: ["github.com/example/one"] },
      { page: "projects/two.md", aliases: ["two"], remotes: ["github.com/example/two"] },
    ],
    budgets: {
      session_start_target_bytes: 100,
      session_start_hard_bytes: 200,
      prompt_recall_target_bytes: 50,
      prompt_recall_hard_bytes: 100,
      prompt_guidance_hard_bytes: 0,
    },
  };

  for (const invalid of [
    { ...base, version: 2 },
    { ...base, core_pages: ["../outside.md"] },
    { ...base, projects: [base.projects[0], { ...base.projects[1], aliases: ["ONE"] }] },
    {
      ...base,
      projects: [base.projects[0], { ...base.projects[1], remotes: ["git@github.com:EXAMPLE/one.git"] }],
    },
    { ...base, budgets: { ...base.budgets, session_start_target_bytes: 201 } },
  ]) {
    assert.throws(
      () => parseBrainBootstrapManifest(invalid),
      (error) => assertManifestError(error, "BRAIN_MANIFEST_INVALID"),
    );
  }
});

test("project matching normalizes remotes and gives an exact remote precedence over a directory alias", async () => {
  const raw = JSON.parse(await readFile(`${fixturesRoot}/real-brain-bootstrap.json`, "utf8"));
  const manifest = parseBrainBootstrapManifest(raw);

  assert.equal(normalizeGitRemote("git@GitHub.com:Phluxxed/Anvil.git"), "github.com/phluxxed/anvil");
  assert.equal(normalizeGitRemote("https://github.com/Phluxxed/Anvil.git/"), "github.com/phluxxed/anvil");

  const selection = selectBrainProject(manifest, {
    gitRoot: "/tmp/ai_graph_ideas",
    directoryAlias: "ai_graph_ideas",
    remotes: ["git@github.com:Phluxxed/Anvil.git"],
  });
  assert.equal(selection.kind, "matched");
  if (selection.kind === "matched") assert.equal(selection.project.page, "projects/anvil-redux.md");

  const ambiguousManifest = parseBrainBootstrapManifest({
    ...raw,
    projects: [
      raw.projects[0],
      { ...raw.projects[1], remotes: ["github.com/example/second"] },
    ],
  });
  const ambiguous = selectBrainProject(ambiguousManifest, {
    gitRoot: "/tmp/workspace",
    directoryAlias: "workspace",
    remotes: ["github.com/Phluxxed/Anvil", "git@github.com:example/second.git"],
  });
  assert.equal(ambiguous.kind, "ambiguous");
});

test("manifest v2 omits the legacy project catalogue and rejects a projects field", () => {
  const base = {
    version: 2,
    core_pages: ["self-model/core.md"],
    prompt_guidance_pages: [],
    budgets: {
      session_start_target_bytes: 100,
      session_start_hard_bytes: 200,
      prompt_recall_target_bytes: 50,
      prompt_recall_hard_bytes: 100,
      prompt_guidance_hard_bytes: 0,
    },
  };

  const manifest = parseBrainBootstrapManifest(base);
  assert.equal(manifest.version, 2);
  assert.equal("projects" in manifest, false);

  assert.throws(
    () => parseBrainBootstrapManifest({ ...base, projects: [] }),
    (error) => assertManifestError(error, "BRAIN_MANIFEST_INVALID"),
  );
});

test("WorkspaceIdentityInput contains only portable alias and normalized remotes", () => {
  const input = toWorkspaceIdentityInput({
    gitRoot: "/private/checkout/renamed",
    directoryAlias: "Renamed",
    remotes: [
      "git@GitHub.com:Phluxxed/Anvil.git",
      "https://github.com/Phluxxed/Anvil/",
      "github.com/example/other",
    ],
  });

  assert.deepEqual(input, {
    directory_alias: "renamed",
    remotes: ["github.com/phluxxed/anvil", "github.com/example/other"],
  });
  assert.equal("gitRoot" in input, false);
  assert.equal(JSON.stringify(input).includes("/private/checkout/renamed"), false);
});

test("Workspace Identity discards unusable remotes with one bounded path-free diagnostic", () => {
  const conversion = toWorkspaceIdentityInputWithDiagnostics({
    gitRoot: "/private/checkout/renamed",
    directoryAlias: "Renamed",
    remotes: [
      "https://github.com/phluxxed/anvil?token=secret",
      "github.com/../private",
      "github.com/phluxxed/anvil",
      "github.com/PHLUXXED/other",
    ],
  });

  assert.deepEqual(conversion.input, {
    directory_alias: "renamed",
    remotes: ["github.com/phluxxed/anvil", "github.com/phluxxed/other"],
  });
  assert.deepEqual(conversion.diagnostics, [{
    code: "PROJECT_IDENTITY_INVALID",
    message: "One or more workspace remote observations were discarded before compiler transport.",
    recovery: "Repair the repository remote or continue with directory-alias routing.",
  }]);
  assert.equal(JSON.stringify(conversion.diagnostics).includes("/private/checkout/renamed"), false);
  assert.equal(JSON.stringify(conversion.diagnostics).includes("token=secret"), false);
});

test("compiler contract v3 parses project resolution metadata without admitting absolute paths", () => {
  const envelope = {
    kind: "compiled_context",
    contract_version: "3",
    wiki: { alias: "fixture-brain", schema_version: "1", runtime_contract: "3" },
    query: {
      question: "What should I do next?",
      shapes: ["lookup"],
      state_view: "current",
      resolved_seeds: [],
      project_resolution: {
        status: "ambiguous",
        matched_by: "remote",
        candidates: [
          { project_id: "alpha", page: "projects/alpha.md" },
          { project_id: "beta", page: "projects/beta.md" },
        ],
        candidate_count: 2,
      },
    },
    evidence: [],
    omissions: [],
    coverage: { required_roles: [], covered_roles: [], uncovered_roles: [] },
    budget: {
      limits: {
        target_bytes: 100,
        max_bytes: 200,
        target_items: 8,
        max_items: 12,
        max_estimated_tokens: null,
      },
      target_exceeded_for_coverage: false,
      evidence_bytes: 0,
      envelope_bytes: 0,
      items: 0,
      estimated_tokens: 0,
    },
    stop: { reason: "no_evidence", sufficient: false, detail: "No evidence" },
    continuation: null,
    diagnostics: [
      {
        code: "PROJECT_IDENTITY_AMBIGUOUS",
        message: "Multiple projects match the workspace identity.",
        provider: null,
        details: {},
      },
    ],
    reporting: {
      omissions: { total: 0, returned: 0 },
      diagnostics: { total: 1, returned: 1 },
    },
  };

  const parsed = parseCompilerOutput(JSON.stringify(envelope));
  assert.equal(parsed.contractVersion, "3");
  assert.deepEqual(parsed.query.projectResolution, {
    status: "ambiguous",
    matchedBy: "remote",
    candidates: [
      { projectId: "alpha", page: "projects/alpha.md" },
      { projectId: "beta", page: "projects/beta.md" },
    ],
    candidateCount: 2,
  });

  assert.throws(
    () => parseCompilerOutput(JSON.stringify({
      ...envelope,
      query: {
        ...envelope.query,
        project_resolution: {
          status: "matched",
          project_id: "alpha",
          page: "/private/alpha.md",
          matched_by: "remote",
        },
      },
    })),
    (error) => assertManifestError(error, "BRAIN_SELECTED_PATH_UNSAFE"),
  );
});

test("compiler contract v3 rejects absolute paths nested in response metadata while v1 remains compatible", () => {
  const evidence = {
    id: "text:patterns/support.md#rule",
    provider: "text",
    route: "question_match",
    page: "patterns/support.md",
    source: null,
    locator: { section: "Rule", start_line: 1, end_line: 1 },
    content: "",
    roles: ["answer"],
    authored_state: "current",
    derived_flags: [],
    authority_signals: [],
    selection_reasons: ["question_match"],
    byte_cost: 0,
    truncated: false,
    atomic: false,
  };
  const base = {
    kind: "compiled_context",
    contract_version: "3",
    wiki: { alias: "fixture-brain", schema_version: "1", runtime_contract: "3" },
    query: {
      question: "next",
      shapes: ["lookup"],
      state_view: "current",
      resolved_seeds: [],
      project_resolution: { status: "unknown" },
    },
    evidence: [evidence],
    omissions: [],
    coverage: { required_roles: [], covered_roles: [], uncovered_roles: [] },
    budget: {
      limits: {
        target_bytes: 100,
        max_bytes: 200,
        target_items: 8,
        max_items: 12,
        max_estimated_tokens: null,
      },
      target_exceeded_for_coverage: false,
      evidence_bytes: 0,
      envelope_bytes: 0,
      items: 1,
      estimated_tokens: 0,
    },
    stop: { reason: "sufficient", sufficient: true, detail: "Selected" },
    continuation: null,
    diagnostics: [],
    reporting: {
      omissions: { total: 0, returned: 0 },
      diagnostics: { total: 0, returned: 0 },
    },
  };

  const maliciousV3 = [
    ["evidence.locator", {
      evidence: [{ ...evidence, locator: { nested: [{ path: "/private/secret" }] } }],
    }],
    ["continuation", { continuation: { nested: { cursor: "C:\\Users\\secret" } } }],
    ["diagnostic.details", {
      diagnostics: [{
        code: "PROJECT_IDENTITY_INVALID",
        message: "Invalid project metadata.",
        provider: null,
        details: { nested: { source_path: "//server/share/secret" } },
      }],
      reporting: { diagnostics: { total: 1, returned: 1 } },
    }],
  ] as const;

  for (const [label, mutation] of maliciousV3) {
    assert.throws(
      () => parseCompilerOutput(JSON.stringify({ ...base, ...mutation })),
      (error) => {
        assertManifestError(error, "BRAIN_SELECTED_PATH_UNSAFE");
        assert.doesNotMatch((error as Error).message, /secret/);
        return true;
      },
      label,
    );
  }

  const legacy = {
    ...base,
    contract_version: "1",
    wiki: { ...base.wiki, runtime_contract: "2" },
    query: {
      question: "next",
      shapes: ["lookup"],
      state_view: "current",
      resolved_seeds: [],
    },
    evidence: [{ ...evidence, locator: { nested: [{ path: "/private/secret" }] } }],
    continuation: { nested: { cursor: "C:\\Users\\secret" } },
    diagnostics: [{
      code: "PROJECT_IDENTITY_INVALID",
      message: "Invalid project metadata.",
      provider: null,
      details: { nested: { source_path: "//server/share/secret" } },
    }],
    reporting: {
      omissions: { total: 0, returned: 0 },
      diagnostics: { total: 1, returned: 1 },
    },
  };
  assert.equal(parseCompilerOutput(JSON.stringify(legacy)).contractVersion, "1");
});

test("compiler contract v3 transport sends only path-free Workspace Identity flags", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-brain-v3-transport-"));
  try {
    const argsPath = join(temp, "args.json");
    const compiler = join(temp, "capture-compiler.mjs");
    await writeFile(
      compiler,
      `#!/usr/bin/env node
import { writeFile } from "node:fs/promises";
await writeFile(process.env.CAPTURE_ARGS, JSON.stringify(process.argv.slice(2)));
process.stdout.write(JSON.stringify({
  kind: "compiled_context",
  contract_version: "3",
  wiki: { alias: "fixture-brain", schema_version: "1", runtime_contract: "3" },
  query: { question: "next", shapes: [], state_view: "current", resolved_seeds: [], project_resolution: { status: "not_requested" } },
  evidence: [], omissions: [],
  coverage: { required_roles: [], covered_roles: [], uncovered_roles: [] },
  budget: { limits: { target_bytes: 1, max_bytes: 2, target_items: 8, max_items: 12, max_estimated_tokens: null }, target_exceeded_for_coverage: false, evidence_bytes: 0, envelope_bytes: 0, items: 0, estimated_tokens: 0 },
  stop: { reason: "no_evidence", sufficient: false, detail: "No evidence" }, continuation: null,
  diagnostics: [], reporting: { omissions: { total: 0, returned: 0 }, diagnostics: { total: 0, returned: 0 } }
}));
`,
      "utf8",
    );
    await chmod(compiler, 0o755);

    const result = await retrieveBrainContext({
      brainRoot: temp,
      wikiAlias: "fixture-brain",
      seeds: [],
      question: "next",
      targetBytes: 1,
      hardBytes: 2,
      compilerContractVersion: "3",
      workspaceIdentity: {
        directory_alias: "renamed-checkout",
        remotes: ["github.com/phluxxed/llm-wiki"],
      },
      env: { ANVIL_LLM_WIKI_BIN: compiler, CAPTURE_ARGS: argsPath },
    });
    const args = JSON.parse(await readFile(argsPath, "utf8")) as string[];

    assert.equal(result.contractVersion, "3");
    assert.deepEqual(result.query.projectResolution, { status: "not_requested" });
    assert.deepEqual(args.slice(-6), [
      "--workspace-directory-alias",
      "renamed-checkout",
      "--workspace-remote",
      "github.com/phluxxed/llm-wiki",
      "--contract-version",
      "3",
    ]);
    assert.equal(args[args.length - 1], "3");
    assert.equal(args.includes(temp), true, "the Brain root remains the explicit --wiki execution target");
    assert.equal(args.some((value) => value.includes("gitRoot") || value.includes("cwd")), false);
    assert.equal(JSON.stringify(result).includes(temp), false);

    await assert.rejects(
      () => retrieveBrainContext({
        brainRoot: temp,
        wikiAlias: "fixture-brain",
        seeds: [],
        question: "next",
        targetBytes: 1,
        hardBytes: 2,
        compilerContractVersion: "3",
        workspaceIdentity: {
          directory_alias: "renamed-checkout",
          remotes: ["/private/checkout/renamed"],
        },
        env: { ANVIL_LLM_WIKI_BIN: compiler, CAPTURE_ARGS: argsPath },
      }),
      (error) => assertManifestError(error, "BRAIN_RETRIEVAL_INVALID"),
    );
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});
