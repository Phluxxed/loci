import assert from "node:assert/strict";
import { spawn, spawnSync } from "node:child_process";
import { mkdir, mkdtemp, readFile, realpath, rm, writeFile } from "node:fs/promises";
import { createServer } from "node:http";
import { tmpdir } from "node:os";
import { dirname, join, resolve } from "node:path";
import { test } from "node:test";

import {
  brainUsageMetricsOutputSchema,
  readBrainUsageOutputSchema,
  readBrainUsage,
  recordBoundBrainUsageOutputSchema,
  recordBoundBrainUsage,
  recordBrainUsage,
  resolveBrainUsageWorkspace,
  summarizeBrainUsage,
} from "../src/brain-usage/index.ts";
import type { BrainRecallObservation } from "../src/brain-context/index.ts";
import { bindWorkContext, WorkContextError } from "../src/work-context/index.ts";
import { recordPromptRecallTelemetry } from "../src/brain-usage/recall.ts";

const anvilBin = resolve("bin/anvil.ts");
const brainBin = resolve("bin/brain.ts");
const defaultBrainDashboardPort = 27246;

function readyRecallObservation(input: {
  attempted: number;
  guidance?: number;
  retrieved?: number;
  framing?: number;
  totalMs?: number;
  retrievalMs?: number;
}): BrainRecallObservation {
  const guidance = input.guidance ?? 100;
  const retrieved = input.retrieved ?? 0;
  const framing = input.framing ?? input.attempted - guidance - retrieved;
  return {
    phase: "render",
    timing: { total_ms: input.totalMs ?? 20, retrieval_ms: input.retrievalMs ?? 5 },
    pages: {
      guidance_count: 1,
      compiler_evidence_count: retrieved > 0 ? 3 : 0,
      candidate_count: retrieved > 0 ? 2 : 0,
      supporting_count: retrieved > 0 ? 1 : 0,
      selected_count: retrieved > 0 ? 2 : 1,
      filtered_count: retrieved > 0 ? 1 : 0,
    },
    bytes: {
      guidance,
      guidance_limit: 256,
      guidance_headroom: 256 - guidance,
      retrieved_context: retrieved,
      framing,
      attempted: input.attempted,
      rendered: input.attempted,
      payload_limit: 1024,
      payload_headroom: 1024 - input.attempted,
    },
    selection_outcome: retrieved > 0 ? "filtered" : "unchanged",
    render_outcome: "within_limit",
    diagnostics: [],
  };
}

test("Brain usage output schemas parse every runtime result and reject undeclared fields", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-brain-usage-schemas-"));
  try {
    const workspace = join(temp, "workspace");
    const missingWorkspace = join(temp, "missing-workspace");
    const stateRoot = join(temp, "state");
    await mkdir(workspace, { recursive: true });
    await mkdir(missingWorkspace, { recursive: true });
    const { binding } = await bindWorkContext({
      host: "codex",
      sessionId: "session-brain-schemas",
      cwd: workspace,
      lifecycle: "SessionStart:startup",
      stateRoot,
    });

    const recorded = await recordBoundBrainUsage({
      binding,
      stateRoot,
      usage: { event: "used", trigger: "Schema-backed Brain usage output." },
      id: () => "brain_usage_schema",
    });
    assert.deepEqual(recordBoundBrainUsageOutputSchema.parse(recorded), recorded);
    assert.equal(recorded.paths.workspace.root, await realpath(workspace));
    assert.throws(() => recordBoundBrainUsageOutputSchema.parse({ ...recorded, unexpected: true }));

    const read = await readBrainUsage({ cwd: workspace, stateRoot });
    assert.deepEqual(readBrainUsageOutputSchema.parse(read), read);
    const metrics = await summarizeBrainUsage({ cwd: workspace, stateRoot });
    assert.deepEqual(brainUsageMetricsOutputSchema.parse(metrics), metrics);

    const missingRead = await readBrainUsage({ cwd: missingWorkspace, stateRoot });
    assert.equal(missingRead.kind, "missing");
    assert.deepEqual(readBrainUsageOutputSchema.parse(missingRead), missingRead);
    const missingMetrics = await summarizeBrainUsage({ cwd: missingWorkspace, stateRoot });
    assert.equal(missingMetrics.kind, "missing");
    assert.deepEqual(brainUsageMetricsOutputSchema.parse(missingMetrics), missingMetrics);

    await writeFile(recorded.paths.usagePath, "{not-json}\n", "utf8");
    const malformedRead = await readBrainUsage({ cwd: workspace, stateRoot });
    assert.equal(malformedRead.kind, "malformed");
    assert.deepEqual(readBrainUsageOutputSchema.parse(malformedRead), malformedRead);
    const malformedMetrics = await summarizeBrainUsage({ cwd: workspace, stateRoot });
    assert.equal(malformedMetrics.kind, "malformed");
    assert.deepEqual(brainUsageMetricsOutputSchema.parse(malformedMetrics), malformedMetrics);
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("bound Brain usage keeps agent-wide evidence attributed to the active workspace", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-brain-usage-bound-"));
  try {
    const improvements = join(temp, "improvements");
    const stateRoot = join(temp, "state");
    await mkdir(improvements, { recursive: true });
    const { binding } = await bindWorkContext({
      host: "codex",
      sessionId: "session-brain-bound",
      cwd: improvements,
      lifecycle: "SessionStart:startup",
      stateRoot,
    });

    const result = await recordBoundBrainUsage({
      binding,
      stateRoot,
      usage: { event: "used", trigger: "Brain influenced bound work." },
      id: () => "brain_usage_bound",
    });

    assert.equal(result.record.workspace.root, await realpath(improvements));
    assert.equal(result.binding.id, binding.id);
    assert.match(result.paths.usagePath, /brain-usage\/workspaces/);
    assert.doesNotMatch(result.paths.usagePath, /continuity\/workspaces/);
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("stale Work Context rejects bound Brain usage before writing", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-brain-usage-bound-stale-"));
  try {
    const workspace = join(temp, "workspace");
    const stateRoot = join(temp, "state");
    await mkdir(workspace, { recursive: true });
    const { binding } = await bindWorkContext({
      host: "codex",
      sessionId: "session-brain-stale",
      cwd: workspace,
      lifecycle: "SessionStart:startup",
      stateRoot,
      now: () => "2026-07-16T00:00:00.000Z",
      maxAgeMs: 1_000,
    });

    await assert.rejects(
      () =>
        recordBoundBrainUsage({
          binding,
          stateRoot,
          bindingNow: () => "2026-07-16T00:00:02.000Z",
          usage: { event: "used", trigger: "Must not write." },
        }),
      (error: unknown) => error instanceof WorkContextError && error.code === "WORK_CONTEXT_STALE",
    );
    assert.equal((await readBrainUsage({ cwd: workspace, stateRoot })).kind, "missing");
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

async function waitForDashboardReady(child: ReturnType<typeof spawn>): Promise<{ url: string; metrics_path?: string }> {
  let stdout = "";
  let stderr = "";
  return await new Promise((resolveReady, rejectReady) => {
    const timeout = setTimeout(() => {
      rejectReady(new Error(`Timed out waiting for dashboard startup. stdout=${stdout} stderr=${stderr}`));
    }, 5000);
    child.stdout?.on("data", (chunk: Buffer) => {
      stdout += chunk.toString("utf8");
      if (!stdout.includes("\n}")) return;
      clearTimeout(timeout);
      try {
        resolveReady(JSON.parse(stdout.slice(0, stdout.indexOf("\n}") + 2)) as { url: string });
      } catch (error) {
        rejectReady(error);
      }
    });
    child.stderr?.on("data", (chunk: Buffer) => {
      stderr += chunk.toString("utf8");
    });
    child.once("exit", (code) => {
      clearTimeout(timeout);
      rejectReady(new Error(`Dashboard exited before startup with code ${code}. stdout=${stdout} stderr=${stderr}`));
    });
  });
}

function runGit(args: string[], cwd: string): void {
  const result = spawnSync("git", args, { cwd, encoding: "utf8" });
  assert.equal(result.status, 0, result.stderr);
}

async function writeBrainConfig(anvilHome: string, agentId: string, wikiAlias: string): Promise<void> {
  const path = join(anvilHome, "agents", agentId, "config.json");
  await mkdir(dirname(path), { recursive: true });
  await writeFile(
    path,
    `${JSON.stringify({
      schema_version: 1,
      agent_id: agentId,
      brain_root: join(anvilHome, "brains", agentId),
      wiki_alias: wikiAlias,
    })}\n`,
    "utf8",
  );
}

async function canBindPort(port: number): Promise<boolean> {
  const server = createServer();
  return await new Promise((resolveCanBind) => {
    server.once("error", () => resolveCanBind(false));
    server.listen(port, "127.0.0.1", () => {
      server.close(() => resolveCanBind(true));
    });
  });
}

async function writeFakeLensMcpServer(path: string, returnedPath?: string): Promise<void> {
  const packageJsonPath = resolve("package.json");
  await writeFile(
    path,
    `
import { createRequire } from "node:module";
import { mkdir, writeFile } from "node:fs/promises";
import { join } from "node:path";

const require = createRequire(${JSON.stringify(packageJsonPath)});
const { McpServer } = await import(require.resolve("@modelcontextprotocol/server"));
const { StdioServerTransport } = await import(require.resolve("@modelcontextprotocol/server/stdio"));
const { z } = await import(require.resolve("zod"));
const configuredResultPath = ${JSON.stringify(returnedPath ?? null)};

const server = new McpServer({ name: "fake-lens", version: "0.0.0" });
server.registerTool(
  "lens_render",
  {
    description: "Fake Lens render for Anvil tests.",
    inputSchema: {
      id: z.string(),
      data: z.unknown(),
      out_dir: z.string().optional(),
    },
  },
  async ({ data, out_dir }) => {
    const outDir = out_dir ?? process.cwd();
    await mkdir(outDir, { recursive: true });
    const path = join(outDir, "fake-lens-graph.html");
    const title = data && typeof data === "object" && "meta" in data && data.meta && typeof data.meta === "object" && "title" in data.meta
      ? String(data.meta.title)
      : "untitled";
    const nodes = data && typeof data === "object" && "nodes" in data && Array.isArray(data.nodes) ? data.nodes.length : 0;
    const html = \`<!doctype html><html><head><title>\${title}</title></head><body><h1>Lens graph received</h1><p>\${nodes} nodes</p></body></html>\`;
    await writeFile(path, html, "utf8");
    const resultPath = configuredResultPath ?? path;
    return {
      content: [
        {
          type: "text",
          text: JSON.stringify({
            ok: true,
            path: resultPath,
            bytes: Buffer.byteLength(html),
            warnings: [],
            validation: { valid: true, errors: [] },
          }),
        },
      ],
    };
  },
);

await server.connect(new StdioServerTransport());
`,
    "utf8",
  );
}

test("recordBrainUsage appends bounded workspace-local records", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-brain-usage-record-"));
  try {
    const repo = join(temp, "repo");
    const stateRoot = join(temp, "state");
    const anvilHome = join(temp, "anvil-home");
    await mkdir(repo, { recursive: true });
    runGit(["init"], repo);
    await writeBrainConfig(anvilHome, "codex", "anvil-brain-codex");

    const first = await recordBrainUsage({
      cwd: repo,
      stateRoot,
      anvilHome,
      env: { ANVIL_AGENT_ID: "codex" },
      usage: {
        event: "consulted",
        brain: "anvil-brain-codex",
        trigger: "Opened Brain before shaping a usage-log slice.",
        pages: ["self-model/working-name-rowan.md"],
        related: ["evt_20260701_8b879f16c016"],
      },
      now: () => "2026-07-01T13:10:00.000Z",
      id: () => "brain_usage_1",
    });
    await recordBrainUsage({
      cwd: repo,
      stateRoot,
      anvilHome,
      env: { ANVIL_AGENT_ID: "codex" },
      usage: {
        event: "stale",
        trigger: "Brain conflicted with current repo evidence.",
        outcome: "corrected",
        severity: "warn",
      },
      now: () => "2026-07-01T13:11:00.000Z",
      id: () => "brain_usage_2",
    });

    const paths = resolveBrainUsageWorkspace({ cwd: repo, stateRoot });
    const read = await readBrainUsage({ cwd: repo, stateRoot, limit: 1 });

    assert.equal(first.record.workspace.root, await realpath(repo));
    assert.equal(first.record.severity, "info");
    assert.deepEqual(first.record.pages, ["self-model/working-name-rowan.md"]);
    assert.equal(paths.usagePath.endsWith("usage.jsonl"), true);
    assert.equal(read.kind, "ok");
    assert.equal(read.items.length, 1);
    assert.equal(read.items[0].id, "brain_usage_2");
    assert.equal(read.items[0].event, "stale");
    assert.equal(read.items[0].severity, "warn");
    assert.equal(read.total, 2);
    assert.equal(read.truncated, true);
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("recordBrainUsage snapshots configured identity and treats a caller label only as a compatibility hint", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-brain-usage-identity-"));
  try {
    const repo = join(temp, "repo");
    const stateRoot = join(temp, "state");
    const anvilHome = join(temp, "anvil-home");
    await mkdir(repo, { recursive: true });
    runGit(["init"], repo);
    await writeBrainConfig(anvilHome, "codex", "anvil-brain-codex");

    const recorded = await recordBrainUsage({
      cwd: repo,
      stateRoot,
      anvilHome,
      env: { ANVIL_AGENT_ID: "codex" },
      usage: {
        event: "used",
        brain: "codex",
        trigger: "Brain context changed the implementation boundary.",
      },
      now: () => "2026-07-15T08:00:00.000Z",
      id: () => "brain_usage_identity",
    });

    assert.equal(recorded.record.version, 2);
    assert.equal(recorded.record.brain_id, "agent:codex");
    assert.equal(recorded.record.brain_alias, "anvil-brain-codex");
    assert.equal("brain" in recorded.record, false);

    await assert.rejects(
      () =>
        recordBrainUsage({
          cwd: repo,
          stateRoot,
          anvilHome,
          env: { ANVIL_AGENT_ID: "codex" },
          usage: {
            event: "used",
            brain: "another-brain",
            trigger: "An invalid caller label must not define identity.",
          },
        }),
      /BRAIN_IDENTITY_HINT_MISMATCH/,
    );
    await assert.rejects(
      () =>
        recordBrainUsage({
          cwd: repo,
          stateRoot,
          usage: {
            event: "used",
            trigger: "Trusted snapshots still obey the stable identity contract.",
          },
          brainIdentity: {
            id: "codex",
            agentId: "codex",
            wikiAlias: "anvil-brain-codex",
          },
        }),
      /BRAIN_IDENTITY_INVALID/,
    );
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("summarizeBrainUsage projects legacy labels honestly without rewriting append-only history", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-brain-usage-legacy-identity-"));
  try {
    const repo = join(temp, "repo");
    const stateRoot = join(temp, "state");
    const anvilHome = join(temp, "anvil-home");
    await mkdir(repo, { recursive: true });
    runGit(["init"], repo);
    await writeBrainConfig(anvilHome, "codex", "anvil-brain-codex");
    await writeBrainConfig(anvilHome, "claude", "anvil-brain-claude");

    const paths = resolveBrainUsageWorkspace({ cwd: repo, stateRoot });
    await mkdir(dirname(paths.usagePath), { recursive: true });
    const records = [
      { version: 1, id: "legacy-codex-id", created_at: "2026-07-15T08:00:00.000Z", workspace: paths.workspace, event: "used", trigger: "Legacy agent id.", severity: "info", trigger_bucket: "identity", brain: "codex" },
      { version: 1, id: "legacy-codex-alias", created_at: "2026-07-15T08:01:00.000Z", workspace: paths.workspace, event: "used", trigger: "Legacy wiki alias.", severity: "info", trigger_bucket: "identity", brain: "anvil-brain-codex" },
      { version: 1, id: "legacy-codex-stable-id", created_at: "2026-07-15T08:01:30.000Z", workspace: paths.workspace, event: "used", trigger: "Legacy stable id label.", severity: "info", trigger_bucket: "identity", brain: "agent:codex" },
      { version: 1, id: "legacy-claude-id", created_at: "2026-07-15T08:02:00.000Z", workspace: paths.workspace, event: "used", trigger: "A distinct agent Brain.", severity: "info", trigger_bucket: "identity", brain: "claude" },
      { version: 1, id: "legacy-unknown", created_at: "2026-07-15T08:03:00.000Z", workspace: paths.workspace, event: "used", trigger: "Unknown historical label.", severity: "info", trigger_bucket: "identity", brain: "mystery" },
      { version: 1, id: "legacy-unassigned", created_at: "2026-07-15T08:04:00.000Z", workspace: paths.workspace, event: "not_needed", trigger: "No Brain applied.", severity: "info", trigger_bucket: "identity" },
    ];
    const journal = `${records.map((record) => JSON.stringify(record)).join("\n")}\n`;
    await writeFile(paths.usagePath, journal, "utf8");

    const metrics = await summarizeBrainUsage({ cwd: repo, stateRoot, anvilHome, env: { ANVIL_AGENT_ID: "codex" } });

    assert.equal(metrics.kind, "ok");
    assert.deepEqual(metrics.by_brain, { "agent:claude": 1, "agent:codex": 3 });
    assert.deepEqual(metrics.brain_aliases, {
      "agent:claude": "anvil-brain-claude",
      "agent:codex": "anvil-brain-codex",
    });
    assert.deepEqual(metrics.brain_identity, {
      resolved_events: 4,
      legacy_normalized_events: 4,
      unresolved_events: 1,
      unassigned_events: 1,
      diagnostics: [{ code: "LEGACY_BRAIN_IDENTITY_UNKNOWN", label: "mystery", count: 1 }],
    });
    assert.equal(await readFile(paths.usagePath, "utf8"), journal);
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("readBrainUsage rejects impossible schema-v2 identity states", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-brain-usage-invalid-v2-"));
  try {
    const repo = join(temp, "repo");
    const stateRoot = join(temp, "state");
    await mkdir(repo, { recursive: true });
    runGit(["init"], repo);
    const paths = resolveBrainUsageWorkspace({ cwd: repo, stateRoot });
    await mkdir(dirname(paths.usagePath), { recursive: true });

    const base = {
      version: 2,
      id: "invalid-v2",
      created_at: "2026-07-15T08:00:00.000Z",
      workspace: paths.workspace,
      event: "used",
      trigger: "Invalid schema-v2 identity state.",
      severity: "info",
      trigger_bucket: "identity",
    };
    await writeFile(
      paths.usagePath,
      `${JSON.stringify({
        ...base,
        brain_id: "codex",
        brain_alias: "anvil-brain-codex",
        brain_identity_status: "resolved",
      })}\n`,
      "utf8",
    );
    const invalidId = await readBrainUsage({ cwd: repo, stateRoot });
    assert.equal(invalidId.kind, "malformed");
    assert.match(invalidId.message, /BRAIN_IDENTITY_INVALID/);

    await writeFile(paths.usagePath, `${JSON.stringify(base)}\n`, "utf8");
    const missingIdentity = await readBrainUsage({ cwd: repo, stateRoot });
    assert.equal(missingIdentity.kind, "malformed");
    assert.match(missingIdentity.message, /used records require resolved or unresolved Brain identity/);
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("summarizeBrainUsage refuses to guess when a legacy alias matches multiple configured Brains", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-brain-usage-ambiguous-identity-"));
  try {
    const repo = join(temp, "repo");
    const stateRoot = join(temp, "state");
    const anvilHome = join(temp, "anvil-home");
    await mkdir(repo, { recursive: true });
    runGit(["init"], repo);
    await writeBrainConfig(anvilHome, "codex", "shared-brain");
    await writeBrainConfig(anvilHome, "claude", "shared-brain");

    const paths = resolveBrainUsageWorkspace({ cwd: repo, stateRoot });
    await mkdir(dirname(paths.usagePath), { recursive: true });
    await writeFile(
      paths.usagePath,
      `${JSON.stringify({
        version: 1,
        id: "legacy-ambiguous",
        created_at: "2026-07-15T08:00:00.000Z",
        workspace: paths.workspace,
        event: "used",
        trigger: "Ambiguous historical alias.",
        severity: "info",
        trigger_bucket: "identity",
        brain: "shared-brain",
      })}\n`,
      "utf8",
    );

    const metrics = await summarizeBrainUsage({ cwd: repo, stateRoot, anvilHome });

    assert.equal(metrics.kind, "ok");
    assert.deepEqual(metrics.by_brain, {});
    assert.equal(metrics.brain_identity.unresolved_events, 1);
    assert.deepEqual(metrics.brain_identity.diagnostics, [
      { code: "LEGACY_BRAIN_IDENTITY_AMBIGUOUS", label: "shared-brain", count: 1 },
    ]);
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("Brain usage state root precedence is explicit option, environment, then user-level default", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-brain-usage-state-root-"));
  try {
    const repo = join(temp, "repo");
    const explicitStateRoot = join(temp, "explicit-state");
    const environmentStateRoot = join(temp, "environment-state");
    const homeDir = join(temp, "home");
    await mkdir(repo, { recursive: true });
    runGit(["init"], repo);

    assert.equal(
      resolveBrainUsageWorkspace({
        cwd: repo,
        stateRoot: explicitStateRoot,
        env: { ANVIL_STATE_ROOT: environmentStateRoot },
        homeDir,
      }).stateRoot,
      explicitStateRoot,
    );
    assert.equal(
      resolveBrainUsageWorkspace({
        cwd: repo,
        env: { ANVIL_STATE_ROOT: environmentStateRoot },
        homeDir,
      }).stateRoot,
      environmentStateRoot,
    );
    assert.equal(
      resolveBrainUsageWorkspace({ cwd: repo, env: {}, homeDir }).stateRoot,
      join(homeDir, ".anvil", "state"),
    );
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("recordBrainUsage does not append a retry with the same stable id", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-brain-usage-idempotent-"));
  try {
    const repo = join(temp, "repo");
    const stateRoot = join(temp, "state");
    await mkdir(repo, { recursive: true });
    runGit(["init"], repo);

    const first = await recordBrainUsage({
      cwd: repo,
      stateRoot,
      usage: { event: "recalled", trigger: "Prompt recall selected durable context." },
      now: () => "2026-07-15T02:30:00.000Z",
      id: () => "brain_recall_stable",
    });
    const retry = await recordBrainUsage({
      cwd: repo,
      stateRoot,
      usage: { event: "recalled", trigger: "Prompt recall selected durable context." },
      now: () => "2026-07-15T02:31:00.000Z",
      id: () => "brain_recall_stable",
    });

    const journal = await readFile(first.paths.usagePath, "utf8");
    assert.equal(journal.trim().split("\n").length, 1);
    assert.equal(retry.record.created_at, first.record.created_at);
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("automatic prompt recall records the exact Brain identity snapshot used for retrieval", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-brain-recall-identity-"));
  try {
    const repo = join(temp, "repo");
    const stateRoot = join(temp, "state");
    await mkdir(repo, { recursive: true });
    runGit(["init"], repo);

    await recordPromptRecallTelemetry({
      cwd: repo,
      stateRoot,
      lifecycle: { session_id: "session-identity", message_id: "message-identity" },
      event: "recalled",
      brain: {
        status: "ready",
        markdown: "Relevant context.",
        diagnostics: [],
        brainAgentId: "codex",
        brainAlias: "anvil-brain-codex",
        selectedPages: ["entities/anvil-mcp.md"],
        renderedBytes: 17,
        hardBytes: 1024,
        recallObservation: {
          phase: "render",
          timing: { total_ms: 23, retrieval_ms: 7 },
          pages: {
            guidance_count: 1,
            compiler_evidence_count: 2,
            candidate_count: 2,
            supporting_count: 1,
            selected_count: 2,
            filtered_count: 1,
          },
          bytes: {
            guidance: 100,
            guidance_limit: 256,
            guidance_headroom: 156,
            retrieved_context: 200,
            framing: 50,
            attempted: 350,
            rendered: 350,
            payload_limit: 1024,
            payload_headroom: 674,
          },
          selection_outcome: "filtered",
          render_outcome: "within_limit",
          diagnostics: [],
        },
      },
    });

    const read = await readBrainUsage({ cwd: repo, stateRoot, limit: 1 });
    assert.equal(read.kind, "ok");
    assert.equal(read.items[0].brain_id, "agent:codex");
    assert.equal(read.items[0].brain_alias, "anvil-brain-codex");
    assert.equal(read.items[0].brain_identity_status, "resolved");
    assert.deepEqual(read.items[0].recall_observation, {
      phase: "render",
      timing: { total_ms: 23, retrieval_ms: 7 },
      pages: {
        guidance_count: 1,
        compiler_evidence_count: 2,
        candidate_count: 2,
        supporting_count: 1,
        selected_count: 2,
        filtered_count: 1,
      },
      bytes: {
        guidance: 100,
        guidance_limit: 256,
        guidance_headroom: 156,
        retrieved_context: 200,
        framing: 50,
        attempted: 350,
        rendered: 350,
        payload_limit: 1024,
        payload_headroom: 674,
      },
      selection_outcome: "filtered",
      render_outcome: "within_limit",
      diagnostics: [],
    });
    const journal = await readFile(read.path, "utf8");
    assert.doesNotMatch(journal, /Relevant context\./);
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("readBrainUsage rejects malformed recall observations without rewriting old records", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-brain-usage-invalid-recall-observation-"));
  try {
    const repo = join(temp, "repo");
    const stateRoot = join(temp, "state");
    await mkdir(repo, { recursive: true });
    runGit(["init"], repo);
    const paths = resolveBrainUsageWorkspace({ cwd: repo, stateRoot });
    await mkdir(dirname(paths.usagePath), { recursive: true });

    const base = {
      version: 2,
      id: "invalid-recall-observation",
      created_at: "2026-07-18T00:00:00.000Z",
      workspace: paths.workspace,
      event: "recalled",
      trigger: "Automatic prompt recall selected context.",
      severity: "info",
      trigger_bucket: "brain-recall",
      brain_id: "agent:codex",
      brain_alias: "anvil-brain-codex",
      brain_identity_status: "resolved",
    };
    await writeFile(
      paths.usagePath,
      `${JSON.stringify({
        ...base,
        recall_observation: {
          phase: "guidance_preflight",
          timing: { total_ms: 1 },
          pages: { guidance_count: 1 },
          bytes: {
            guidance: 257,
            guidance_limit: 256,
            guidance_headroom: 0,
            rendered: 100,
            payload_limit: 2048,
          },
          selection_outcome: "not_run",
          render_outcome: "guidance_rejected",
          diagnostics: ["BRAIN_PROMPT_GUIDANCE_TOO_LARGE"],
        },
      })}\n`,
      "utf8",
    );

    const malformed = await readBrainUsage({ cwd: repo, stateRoot });
    assert.equal(malformed.kind, "malformed");
    assert.match(malformed.message, /guidance_headroom/);

    await writeFile(
      paths.usagePath,
      `${JSON.stringify({
        ...base,
        recall_observation: {
          ...readyRecallObservation({ attempted: 350, retrieved: 200, framing: 50 }),
          timing: { total_ms: 4, retrieval_ms: 5 },
        },
      })}\n`,
      "utf8",
    );
    const impossibleTiming = await readBrainUsage({ cwd: repo, stateRoot });
    assert.equal(impossibleTiming.kind, "malformed");
    assert.match(impossibleTiming.message, /retrieval_ms must not exceed total_ms/);

    await writeFile(
      paths.usagePath,
      `${JSON.stringify({
        ...base,
        recall_observation: {
          ...readyRecallObservation({ attempted: 350, retrieved: 200, framing: 50 }),
          prompt_body: "secret prompt content",
        },
      })}\n`,
      "utf8",
    );
    const unsafePayload = await readBrainUsage({ cwd: repo, stateRoot });
    assert.equal(unsafePayload.kind, "malformed");
    assert.match(unsafePayload.message, /unsupported fields: prompt_body/);

    const historical = `${JSON.stringify(base)}\n`;
    await writeFile(paths.usagePath, historical, "utf8");
    const compatible = await readBrainUsage({ cwd: repo, stateRoot });
    assert.equal(compatible.kind, "ok");
    assert.equal(compatible.items[0].recall_observation, undefined);
    assert.equal(await readFile(paths.usagePath, "utf8"), historical);
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("recordBrainUsage stores trace metadata and metrics groups it by project, bucket, session, and prompt", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-brain-usage-trace-"));
  try {
    const repo = join(temp, "repo");
    const stateRoot = join(temp, "state");
    await mkdir(repo, { recursive: true });
    runGit(["init"], repo);

    const first = await recordBrainUsage({
      cwd: repo,
      stateRoot,
      usage: {
        event: "used",
        brain: "anvil-brain-codex",
        trigger: "Brain shaped the trace dashboard contract.",
        trigger_bucket: "metrics/dashboard iteration",
        session_id: "session_20260702",
        turn_id: "turn_12",
        message_id: "msg_12",
        mcp_call_id: "call_brain_context_1",
        prompt_excerpt: "Let's do the trace stuff then",
        prompt_raw: "Let's do the trace stuff then",
        pages: ["projects/anvil-redux.md"],
        outcome: "Added a trace contract.",
      },
      now: () => "2026-07-02T04:00:00.000Z",
      id: () => "brain_usage_trace_1",
    });
    await recordBrainUsage({
      cwd: repo,
      stateRoot,
      usage: {
        event: "updated",
        brain: "anvil-brain-codex",
        trigger: "Recorded follow-up Brain work.",
        trigger_bucket: "metrics/dashboard iteration",
        session_id: "session_20260702",
        turn_id: "turn_12",
        message_id: "msg_12",
        mcp_call_id: "call_brain_log_1",
        prompt_excerpt: "Let's do the trace stuff then",
        pages: ["work-history/2026-07-02.md"],
      },
      now: () => "2026-07-02T04:01:00.000Z",
      id: () => "brain_usage_trace_2",
    });

    assert.equal(first.record.trigger_bucket, "metrics/dashboard iteration");
    assert.equal(first.record.session_id, "session_20260702");
    assert.equal(first.record.prompt_raw, "Let's do the trace stuff then");

    const metrics = await summarizeBrainUsage({ cwd: repo, stateRoot });

    assert.equal(metrics.kind, "ok");
    assert.deepEqual(metrics.by_trigger_bucket, { "metrics/dashboard iteration": 2 });
    assert.equal(metrics.trace.projects.length, 1);
    assert.equal(metrics.trace.projects[0].project_root, await realpath(repo));
    assert.equal(metrics.trace.projects[0].total, 2);
    assert.equal(metrics.trace.projects[0].buckets[0].bucket, "metrics/dashboard iteration");
    assert.equal(metrics.trace.projects[0].buckets[0].sessions[0].session_id, "session_20260702");
    assert.equal(metrics.trace.projects[0].buckets[0].sessions[0].prompts[0].message_id, "msg_12");
    assert.equal(metrics.trace.projects[0].buckets[0].sessions[0].prompts[0].prompt_excerpt, "Let's do the trace stuff then");
    assert.deepEqual(
      metrics.trace.projects[0].buckets[0].sessions[0].prompts[0].events.map((event) => event.id),
      ["brain_usage_trace_1", "brain_usage_trace_2"],
    );
    assert.deepEqual(
      metrics.trace.recent.map((event) => event.id),
      ["brain_usage_trace_2", "brain_usage_trace_1"],
    );
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("recordBrainUsage auto-classifies missing trigger buckets while preserving explicit buckets", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-brain-usage-classify-"));
  try {
    const repo = join(temp, "repo");
    const stateRoot = join(temp, "state");
    await mkdir(repo, { recursive: true });
    runGit(["init"], repo);

    const dashboard = await recordBrainUsage({
      cwd: repo,
      stateRoot,
      usage: {
        event: "used",
        brain: "anvil-brain-codex",
        trigger: "Brain dashboard trace tree changed the metrics view.",
        outcome: "Rendered a dashboard graph.",
      },
      now: () => "2026-07-02T05:00:00.000Z",
      id: () => "brain_usage_classify_1",
    });
    const continuity = await recordBrainUsage({
      cwd: repo,
      stateRoot,
      usage: {
        event: "used",
        trigger: "Promoted a compact continuity note after dashboard work.",
      },
      now: () => "2026-07-02T05:01:00.000Z",
      id: () => "brain_usage_classify_2",
    });
    const explicit = await recordBrainUsage({
      cwd: repo,
      stateRoot,
      usage: {
        event: "updated",
        trigger: "Recorded an intentionally manual classification.",
        trigger_bucket: "manual-bucket",
      },
      now: () => "2026-07-02T05:02:00.000Z",
      id: () => "brain_usage_classify_3",
    });

    assert.equal(dashboard.record.trigger_bucket, "metrics-dashboard");
    assert.equal(continuity.record.trigger_bucket, "continuity");
    assert.equal(explicit.record.trigger_bucket, "manual-bucket");

    const metrics = await summarizeBrainUsage({ cwd: repo, stateRoot });

    assert.equal(metrics.kind, "ok");
    assert.deepEqual(metrics.by_trigger_bucket, {
      "metrics-dashboard": 1,
      continuity: 1,
      "manual-bucket": 1,
    });
    assert.deepEqual(
      metrics.trace.projects[0].buckets.map((bucket) => bucket.bucket),
      ["continuity", "manual-bucket", "metrics-dashboard"],
    );
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("recordBrainUsage rejects unknown events and oversized trigger text", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-brain-usage-validate-"));
  try {
    const repo = join(temp, "repo");
    const stateRoot = join(temp, "state");
    await mkdir(repo, { recursive: true });
    runGit(["init"], repo);

    await assert.rejects(
      () =>
        recordBrainUsage({
          cwd: repo,
          stateRoot,
          usage: { event: "watched" as never, trigger: "valid trigger" },
        }),
      /event must be one of/,
    );

    await assert.rejects(
      () =>
        recordBrainUsage({
          cwd: repo,
          stateRoot,
          usage: { event: "consulted", trigger: "x".repeat(501) },
        }),
      /trigger must be 500 characters or fewer/,
    );

    await assert.rejects(
      () =>
        recordBrainUsage({
          cwd: repo,
          stateRoot,
          usage: { event: "consulted", trigger: "valid trigger", prompt_raw: "x".repeat(12001) },
        }),
      /prompt_raw must be 12000 characters or fewer/,
    );

    await assert.rejects(
      () => readBrainUsage({ cwd: repo, stateRoot, limit: -1 }),
      /limit must be a non-negative integer/,
    );
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("summarizeBrainUsage separates automatic recall, agent outcomes, and incident metrics", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-brain-usage-metrics-"));
  try {
    const repo = join(temp, "repo");
    const stateRoot = join(temp, "state");
    const anvilHome = join(temp, "anvil-home");
    await mkdir(repo, { recursive: true });
    runGit(["init"], repo);
    await writeBrainConfig(anvilHome, "codex", "anvil-brain-codex");

    const events = [
      { event: "recalled", brain: "anvil-brain-codex", trigger: "Prompt recall selected durable context." },
      { event: "no_match", brain: "anvil-brain-codex", trigger: "Prompt recall selected no supporting pages." },
      { event: "degraded", brain: "anvil-brain-codex", trigger: "Prompt recall returned a diagnostic.", severity: "warn" },
      { event: "disabled", trigger: "Prompt recall was explicitly disabled." },
      { event: "consulted", brain: "anvil-brain-codex", trigger: "Opened Brain for orientation." },
      { event: "used", brain: "anvil-brain-codex", trigger: "Brain context changed the answer." },
      { event: "not_needed", trigger: "Repo evidence was enough." },
      { event: "blocked", brain: "anvil-brain-codex", trigger: "Brain was unavailable.", severity: "warn" },
      { event: "updated", brain: "anvil-brain-codex", trigger: "Updated Brain after durable learning." },
      { event: "stale", brain: "anvil-brain-codex", trigger: "Brain conflicted with current evidence.", severity: "error" },
    ] as const;

    for (const [index, usage] of events.entries()) {
      await recordBrainUsage({
        cwd: repo,
        stateRoot,
        anvilHome,
        env: { ANVIL_AGENT_ID: "codex" },
        usage,
        now: () => `2026-07-01T13:${String(index).padStart(2, "0")}:00.000Z`,
        id: () => `brain_usage_${index}`,
      });
    }

    const metrics = await summarizeBrainUsage({
      cwd: repo,
      stateRoot,
      anvilHome,
      env: { ANVIL_AGENT_ID: "codex" },
    });

    assert.equal(metrics.kind, "ok");
    assert.equal(metrics.total, 10);
    assert.deepEqual(metrics.by_event, {
      recalled: 1,
      no_match: 1,
      degraded: 1,
      disabled: 1,
      consulted: 1,
      used: 1,
      not_needed: 1,
      updated: 1,
      missed_update: 0,
      stale: 1,
      wrong: 0,
      blocked: 1,
      eval_failed: 0,
    });
    assert.deepEqual(metrics.recall.by_event, {
      recalled: 1,
      no_match: 1,
      degraded: 1,
      disabled: 1,
    });
    assert.equal(metrics.recall.total, 4);
    assert.deepEqual(metrics.coverage.by_event, {
      consulted: 1,
      used: 1,
      not_needed: 1,
      blocked: 1,
    });
    assert.equal(metrics.coverage.total, 4);
    assert.deepEqual(metrics.incidents.by_event, {
      updated: 1,
      missed_update: 0,
      stale: 1,
      wrong: 0,
      eval_failed: 0,
    });
    assert.equal(metrics.incidents.total, 2);
    assert.deepEqual(metrics.by_severity, { info: 7, warn: 2, error: 1 });
    assert.deepEqual(metrics.by_brain, { "agent:codex": 8 });
    assert.deepEqual(metrics.brain_aliases, { "agent:codex": "anvil-brain-codex" });
    assert.deepEqual(metrics.brain_identity, {
      resolved_events: 8,
      legacy_normalized_events: 0,
      unresolved_events: 0,
      unassigned_events: 2,
      diagnostics: [],
    });
    assert.equal(metrics.first_created_at, "2026-07-01T13:00:00.000Z");
    assert.equal(metrics.last_created_at, "2026-07-01T13:09:00.000Z");
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("summarizeBrainUsage reports recall rates, diagnostics, workspaces, trends, and numeric distributions", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-brain-recall-observation-metrics-"));
  try {
    const firstRepo = join(temp, "alpha");
    const secondRepo = join(temp, "codex");
    const stateRoot = join(temp, "state");
    await mkdir(firstRepo, { recursive: true });
    await mkdir(secondRepo, { recursive: true });
    runGit(["init"], firstRepo);
    runGit(["init"], secondRepo);
    const brainIdentity = { id: "agent:codex", agentId: "codex", wikiAlias: "anvil-brain-codex" };

    const rows = [
      {
        cwd: firstRepo,
        event: "recalled" as const,
        at: "2026-07-17T10:00:00.000Z",
        observation: readyRecallObservation({ attempted: 350, retrieved: 200, framing: 50, totalMs: 20, retrievalMs: 5 }),
      },
      {
        cwd: firstRepo,
        event: "no_match" as const,
        at: "2026-07-17T10:30:00.000Z",
        observation: readyRecallObservation({ attempted: 200, framing: 100, totalMs: 10, retrievalMs: 4 }),
      },
      { cwd: firstRepo, event: "recalled" as const, at: "2026-07-18T11:00:00.000Z" },
      {
        cwd: secondRepo,
        event: "degraded" as const,
        at: "2026-07-18T11:01:00.000Z",
        observation: {
          phase: "guidance_preflight" as const,
          timing: { total_ms: 2 },
          pages: { guidance_count: 1 },
          bytes: {
            guidance: 257,
            guidance_limit: 256,
            guidance_headroom: -1,
            rendered: 120,
            payload_limit: 1024,
          },
          selection_outcome: "not_run" as const,
          render_outcome: "guidance_rejected" as const,
          diagnostics: ["BRAIN_PROMPT_GUIDANCE_TOO_LARGE" as const],
        },
      },
      {
        cwd: secondRepo,
        event: "degraded" as const,
        at: "2026-07-18T11:02:00.000Z",
        outcome: "retrieval_ms=42; selected_pages=0; diagnostic=BRAIN_RETRIEVAL_FAILED",
      },
      { cwd: firstRepo, event: "disabled" as const, at: "2026-07-18T11:05:00.000Z" },
    ];

    for (const [index, row] of rows.entries()) {
      await recordBrainUsage({
        cwd: row.cwd,
        stateRoot,
        brainIdentity: row.event === "disabled" ? undefined : brainIdentity,
        ...(row.observation !== undefined ? { automaticRecallObservation: row.observation } : {}),
        usage: {
          event: row.event,
          trigger: "Automatic prompt-specific Brain recall.",
          trigger_bucket: "brain-recall",
          severity: row.event === "degraded" ? "warn" : "info",
          ...(row.outcome !== undefined ? { outcome: row.outcome } : {}),
        },
        now: () => row.at,
        id: () => `recall-metric-${index}`,
      });
    }

    const metrics = await summarizeBrainUsage({ cwd: firstRepo, stateRoot, scope: "all" });
    assert.equal(metrics.kind, "ok");
    assert.deepEqual(brainUsageMetricsOutputSchema.parse(metrics), metrics);
    assert.equal(metrics.recall.eligible_total, 5);
    assert.deepEqual(metrics.recall.success, { numerator: 3, denominator: 5, rate: 0.6 });
    assert.deepEqual(metrics.recall.degradation, { numerator: 2, denominator: 5, rate: 0.4 });
    assert.deepEqual(metrics.recall.diagnostics.by_code, {
      BRAIN_PROMPT_GUIDANCE_TOO_LARGE: 1,
      BRAIN_RETRIEVAL_FAILED: 1,
    });
    assert.equal(metrics.recall.diagnostics.events_with_diagnostics, 2);
    assert.deepEqual(metrics.recall.instrumentation, {
      instrumented_records: 3,
      eligible_records: 5,
      coverage: 0.6,
    });
    assert.deepEqual(metrics.recall.payload_bytes.attempted, {
      count: 2,
      min: 200,
      p50: 200,
      p90: 350,
      p95: 350,
      p99: 350,
      max: 350,
    });
    assert.deepEqual(metrics.recall.limit_bytes.guidance, {
      count: 3,
      min: 256,
      p50: 256,
      p90: 256,
      p95: 256,
      p99: 256,
      max: 256,
    });
    assert.deepEqual(metrics.recall.limit_bytes.payload, {
      count: 3,
      min: 1024,
      p50: 1024,
      p90: 1024,
      p95: 1024,
      p99: 1024,
      max: 1024,
    });
    assert.deepEqual(metrics.recall.headroom_bytes.guidance, {
      count: 3,
      min: -1,
      p05: -1,
      p50: 156,
      p95: 156,
      max: 156,
    });
    assert.deepEqual(metrics.recall.by_phase, {
      disabled: 0,
      guidance_preflight: 1,
      retrieval: 0,
      render: 2,
    });
    assert.deepEqual(metrics.recall.overflow_stage, { none: 2, guidance: 1, payload: 0, unknown: 0 });
    const codex = metrics.recall.by_workspace.find((workspace) => workspace.workspace.label === "codex");
    assert.ok(codex);
    assert.deepEqual(codex.degradation, { numerator: 2, denominator: 2, rate: 1 });
    assert.equal(codex.instrumented_records, 1);
    assert.equal(metrics.recall.trends.hourly.length, 48);
    assert.equal(metrics.recall.trends.daily.length, 30);
    assert.equal(
      metrics.recall.trends.hourly.reduce((total, bucket) => total + bucket.eligible_total, 0),
      5,
    );
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("Brain usage metrics and bounded reads can aggregate all workspace journals under a state root", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-brain-usage-all-workspaces-"));
  try {
    const firstRepo = join(temp, "first-repo");
    const secondRepo = join(temp, "second-repo");
    const stateRoot = join(temp, "state");
    await mkdir(firstRepo, { recursive: true });
    await mkdir(secondRepo, { recursive: true });
    runGit(["init"], firstRepo);
    runGit(["init"], secondRepo);

    await recordBrainUsage({
      cwd: firstRepo,
      stateRoot,
      usage: {
        event: "used",
        brain: "anvil-brain-codex",
        trigger: "Brain shaped the first repo dashboard work.",
        trigger_bucket: "dashboard",
      },
      now: () => "2026-07-08T01:00:00.000Z",
      id: () => "brain_usage_first_repo",
    });
    await recordBrainUsage({
      cwd: secondRepo,
      stateRoot,
      usage: {
        event: "updated",
        brain: "anvil-brain-codex",
        trigger: "Brain captured Lens follow-up work in another repo.",
        trigger_bucket: "lens",
      },
      now: () => "2026-07-08T01:01:00.000Z",
      id: () => "brain_usage_second_repo",
    });

    const workspaceMetrics = await summarizeBrainUsage({ cwd: firstRepo, stateRoot });
    const aggregateMetrics = await summarizeBrainUsage({ cwd: firstRepo, stateRoot, scope: "all" });
    const aggregateRead = await readBrainUsage({ cwd: firstRepo, stateRoot, scope: "all", limit: 1 });

    assert.equal(workspaceMetrics.kind, "ok");
    assert.equal(workspaceMetrics.total, 1);

    assert.equal(aggregateMetrics.kind, "ok");
    assert.equal(aggregateMetrics.path.endsWith(join("brain-usage", "workspaces")), true);
    assert.equal(aggregateMetrics.total, 2);
    assert.deepEqual(aggregateMetrics.by_event, {
      recalled: 0,
      no_match: 0,
      degraded: 0,
      disabled: 0,
      consulted: 0,
      used: 1,
      not_needed: 0,
      updated: 1,
      missed_update: 0,
      stale: 0,
      wrong: 0,
      blocked: 0,
      eval_failed: 0,
    });
    assert.deepEqual(
      aggregateMetrics.trace.projects.map((project) => project.project_root).sort(),
      [await realpath(firstRepo), await realpath(secondRepo)].sort(),
    );
    assert.deepEqual(
      aggregateMetrics.trace.recent.map((event) => event.id),
      ["brain_usage_second_repo", "brain_usage_first_repo"],
    );
    assert.equal(aggregateRead.kind, "ok");
    assert.equal(aggregateRead.path.endsWith(join("brain-usage", "workspaces")), true);
    assert.equal(aggregateRead.total, 2);
    assert.equal(aggregateRead.truncated, true);
    assert.deepEqual(aggregateRead.items.map((event) => event.id), ["brain_usage_second_repo"]);
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("brain CLI logs and reads usage records", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-brain-usage-cli-"));
  try {
    const repo = join(temp, "repo");
    const stateRoot = join(temp, "state");
    await mkdir(repo, { recursive: true });
    runGit(["init"], repo);

    const log = spawnSync(
      process.execPath,
      [
        anvilBin,
        "brain",
        "log",
        "--cwd",
        repo,
        "--state-root",
        stateRoot,
        "--event",
        "updated",
        "--brain",
        "anvil-brain-codex",
        "--trigger",
        "Recorded a durable working-name decision.",
        "--pages",
        "self-model/working-name-rowan.md,entities/codex.md",
        "--related",
        "evt_20260701_8b879f16c016",
        "--outcome",
        "committed",
        "--trigger-bucket",
        "Brain page update",
        "--session-id",
        "session_cli",
        "--turn-id",
        "turn_cli",
        "--message-id",
        "msg_cli",
        "--mcp-call-id",
        "call_cli",
        "--prompt-excerpt",
        "Welcome to the world Rowan",
        "--prompt-raw",
        "Welcome to the world Rowan",
        "--json",
      ],
      { cwd: resolve("."), encoding: "utf8" },
    );
    assert.equal(log.status, 0, log.stderr);
    const logged = JSON.parse(log.stdout) as {
      record: {
        event: string;
        pages: string[];
        trigger_bucket: string;
        session_id: string;
        prompt_excerpt: string;
      };
    };
    assert.equal(logged.record.event, "updated");
    assert.deepEqual(logged.record.pages, ["self-model/working-name-rowan.md", "entities/codex.md"]);
    assert.equal(logged.record.trigger_bucket, "Brain page update");
    assert.equal(logged.record.session_id, "session_cli");
    assert.equal(logged.record.prompt_excerpt, "Welcome to the world Rowan");

    const read = spawnSync(
      process.execPath,
      [anvilBin, "brain", "usage", "--cwd", repo, "--state-root", stateRoot, "--json"],
      { cwd: resolve("."), encoding: "utf8" },
    );
    assert.equal(read.status, 0, read.stderr);
    const output = JSON.parse(read.stdout) as { kind: "ok"; items: Array<{ event: string; outcome?: string }> };
    assert.equal(output.kind, "ok");
    assert.equal(output.items[0].event, "updated");
    assert.equal(output.items[0].outcome, "committed");
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("brain CLI prints usage metrics as JSON", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-brain-usage-metrics-cli-"));
  try {
    const repo = join(temp, "repo");
    const stateRoot = join(temp, "state");
    await mkdir(repo, { recursive: true });
    runGit(["init"], repo);

    for (const event of ["consulted", "used", "updated"] as const) {
      const log = spawnSync(
        process.execPath,
        [
          anvilBin,
          "brain",
          "log",
          "--cwd",
          repo,
          "--state-root",
          stateRoot,
          "--event",
          event,
          "--brain",
          "anvil-brain-codex",
          "--trigger",
          `Recorded ${event}.`,
          "--json",
        ],
        { cwd: resolve("."), encoding: "utf8" },
      );
      assert.equal(log.status, 0, log.stderr);
    }

    const metrics = spawnSync(
      process.execPath,
      [anvilBin, "brain", "metrics", "--cwd", repo, "--state-root", stateRoot, "--json"],
      { cwd: resolve("."), encoding: "utf8" },
    );

    assert.equal(metrics.status, 0, metrics.stderr);
    const output = JSON.parse(metrics.stdout) as {
      kind: "ok";
      total: number;
      by_trigger_bucket: Record<string, number>;
      coverage: { total: number; by_event: { consulted: number; used: number } };
      incidents: { total: number; by_event: { updated: number } };
      recall: {
        eligible_total: number;
        success: { rate: number | null };
        degradation: { rate: number | null };
        instrumentation: { instrumented_records: number; eligible_records: number; coverage: number | null };
        payload_bytes: { attempted: { count: number } };
        limit_bytes: { guidance: { count: number }; payload: { count: number } };
      };
      trace: { projects: Array<{ buckets: Array<{ bucket: string }> }> };
    };
    assert.equal(output.kind, "ok");
    assert.equal(output.total, 3);
    assert.deepEqual(output.by_trigger_bucket, { "brain-maintenance": 1, general: 1, orientation: 1 });
    assert.deepEqual(
      output.trace.projects[0].buckets.map((bucket) => bucket.bucket),
      ["brain-maintenance", "general", "orientation"],
    );
    assert.equal(output.coverage.total, 2);
    assert.equal(output.coverage.by_event.consulted, 1);
    assert.equal(output.coverage.by_event.used, 1);
    assert.equal(output.incidents.total, 1);
    assert.equal(output.incidents.by_event.updated, 1);
    assert.equal(output.recall.eligible_total, 0);
    assert.equal(output.recall.success.rate, null);
    assert.equal(output.recall.degradation.rate, null);
    assert.deepEqual(output.recall.instrumentation, {
      instrumented_records: 0,
      eligible_records: 0,
      coverage: null,
    });
    assert.equal(output.recall.payload_bytes.attempted.count, 0);
    assert.equal(output.recall.limit_bytes.guidance.count, 0);
    assert.equal(output.recall.limit_bytes.payload.count, 0);

    const humanMetrics = spawnSync(
      process.execPath,
      [anvilBin, "brain", "metrics", "--cwd", repo, "--state-root", stateRoot],
      { cwd: resolve("."), encoding: "utf8" },
    );
    assert.equal(humanMetrics.status, 0, humanMetrics.stderr);
    assert.match(humanMetrics.stdout, /Recall events: 0 \(recalled=0, no_match=0, degraded=0, disabled=0\)/);
    assert.match(humanMetrics.stdout, /Recall success: n\/a \(0\/0\)/);
    assert.match(humanMetrics.stdout, /Recall degradation: n\/a \(0\/0\)/);
    assert.match(humanMetrics.stdout, /Recall instrumentation: 0\/0 \(n\/a\)/);
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("brain CLI serves a live dashboard metrics endpoint", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-brain-dashboard-cli-"));
  let dashboard: ReturnType<typeof spawn> | undefined;
  try {
    const repo = join(temp, "repo");
    const stateRoot = join(temp, "state");
    await mkdir(repo, { recursive: true });
    runGit(["init"], repo);

    const log = spawnSync(
      process.execPath,
      [
        anvilBin,
        "brain",
        "log",
        "--cwd",
        repo,
        "--state-root",
        stateRoot,
        "--event",
        "used",
        "--brain",
        "anvil-brain-codex",
        "--trigger",
        "Brain changed the dashboard implementation.",
        "--json",
      ],
      { cwd: resolve("."), encoding: "utf8" },
    );
    assert.equal(log.status, 0, log.stderr);

    dashboard = spawn(
      process.execPath,
      [anvilBin, "brain", "dashboard", "--cwd", repo, "--state-root", stateRoot, "--port", "0", "--json"],
      { cwd: resolve("."), stdio: ["ignore", "pipe", "pipe"] },
    );

    const ready = await waitForDashboardReady(dashboard);
    assert.equal(ready.metrics_path, undefined);

    const shellResponse = await fetch(ready.url);
    assert.equal(shellResponse.status, 200);
    const shell = await shellResponse.text();
    assert.match(shell, /color-scheme: dark/);
    assert.match(shell, /href="\/graph"/);
    assert.doesNotMatch(shell, /loadTraceGraphRuntime/);
    assert.doesNotMatch(shell, /react\/jsx-runtime/);
    assert.doesNotMatch(shell, /\.anvil\/brain-usage/);

    const firstResponse = await fetch(new URL("api/metrics", ready.url));
    assert.equal(firstResponse.status, 200);
    const first = (await firstResponse.json()) as {
      kind: "ok";
      total: number;
      by_event: { used: number };
      trace: { recent: Array<{ id: string; event: string }> };
    };
    assert.equal(first.kind, "ok");
    assert.equal(first.total, 1);
    assert.equal(first.by_event.used, 1);
    assert.equal(first.trace.recent[0].event, "used");

    const secondLog = spawnSync(
      process.execPath,
      [
        anvilBin,
        "brain",
        "log",
        "--cwd",
        repo,
        "--state-root",
        stateRoot,
        "--event",
        "not_needed",
        "--trigger",
        "Repo evidence was enough.",
        "--json",
      ],
      { cwd: resolve("."), encoding: "utf8" },
    );
    assert.equal(secondLog.status, 0, secondLog.stderr);

    const secondResponse = await fetch(new URL("api/metrics", ready.url));
    assert.equal(secondResponse.status, 200);
    const second = (await secondResponse.json()) as {
      kind: "ok";
      total: number;
      by_event: { not_needed: number; used: number };
    };
    assert.equal(second.kind, "ok");
    assert.equal(second.total, 2);
    assert.equal(second.by_event.used, 1);
    assert.equal(second.by_event.not_needed, 1);
  } finally {
    if (dashboard !== undefined) dashboard.kill("SIGTERM");
    await rm(temp, { recursive: true, force: true });
  }
});

test("brain dashboard serves a separate graph page through Lens MCP", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-brain-dashboard-graph-"));
  let dashboard: ReturnType<typeof spawn> | undefined;
  try {
    const repo = join(temp, "repo");
    const stateRoot = join(temp, "state");
    const fakeLens = join(temp, "fake-lens.mjs");
    await mkdir(repo, { recursive: true });
    await writeFakeLensMcpServer(fakeLens);
    runGit(["init"], repo);

    const log = spawnSync(
      process.execPath,
      [
        anvilBin,
        "brain",
        "log",
        "--cwd",
        repo,
        "--state-root",
        stateRoot,
        "--event",
        "used",
        "--brain",
        "anvil-brain-codex",
        "--trigger",
        "Brain changed the graph page implementation.",
        "--message-id",
        "msg_graph",
        "--json",
      ],
      { cwd: resolve("."), encoding: "utf8" },
    );
    assert.equal(log.status, 0, log.stderr);

    dashboard = spawn(
      process.execPath,
      [anvilBin, "brain", "dashboard", "--cwd", repo, "--state-root", stateRoot, "--port", "0", "--json"],
      {
        cwd: resolve("."),
        env: {
          ...process.env,
          ANVIL_LENS_MCP_COMMAND: process.execPath,
          ANVIL_LENS_MCP_SCRIPT: fakeLens,
        },
        stdio: ["ignore", "pipe", "pipe"],
      },
    );

    const ready = await waitForDashboardReady(dashboard);
    const response = await fetch(new URL("graph", ready.url));
    assert.equal(response.status, 200);
    assert.match(response.headers.get("content-type") ?? "", /text\/html/);
    const html = await response.text();
    assert.match(html, /Lens graph received/);
    assert.match(html, /Brain Usage Trace/);
  } finally {
    if (dashboard !== undefined) dashboard.kill("SIGTERM");
    await rm(temp, { recursive: true, force: true });
  }
});

test("brain dashboard refuses Lens output paths outside its generated directory", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-brain-dashboard-path-"));
  let dashboard: ReturnType<typeof spawn> | undefined;
  try {
    const repo = join(temp, "repo");
    const stateRoot = join(temp, "state");
    const fakeLens = join(temp, "fake-lens.mjs");
    const outside = join(temp, "outside.html");
    await mkdir(repo, { recursive: true });
    await writeFakeLensMcpServer(fakeLens, outside);
    await writeFile(outside, "private local file must not be served", "utf8");
    runGit(["init"], repo);

    const log = spawnSync(
      process.execPath,
      [
        anvilBin,
        "brain",
        "log",
        "--cwd",
        repo,
        "--state-root",
        stateRoot,
        "--event",
        "used",
        "--trigger",
        "Exercise Lens output containment.",
        "--json",
      ],
      { cwd: resolve("."), encoding: "utf8" },
    );
    assert.equal(log.status, 0, log.stderr);

    dashboard = spawn(
      process.execPath,
      [anvilBin, "brain", "dashboard", "--cwd", repo, "--state-root", stateRoot, "--port", "0", "--json"],
      {
        cwd: resolve("."),
        env: {
          ...process.env,
          ANVIL_LENS_MCP_COMMAND: process.execPath,
          ANVIL_LENS_MCP_SCRIPT: fakeLens,
        },
        stdio: ["ignore", "pipe", "pipe"],
      },
    );

    const ready = await waitForDashboardReady(dashboard);
    const response = await fetch(new URL("graph", ready.url));
    assert.equal(response.status, 502);
    const html = await response.text();
    assert.match(html, /Brain Usage Graph Unavailable/);
    assert.doesNotMatch(html, /private local file must not be served/);
  } finally {
    if (dashboard !== undefined) dashboard.kill("SIGTERM");
    await rm(temp, { recursive: true, force: true });
  }
});

test("brain dashboard metrics aggregate all workspaces by default", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-brain-dashboard-all-workspaces-"));
  let dashboard: ReturnType<typeof spawn> | undefined;
  try {
    const firstRepo = join(temp, "first-repo");
    const secondRepo = join(temp, "second-repo");
    const stateRoot = join(temp, "state");
    await mkdir(firstRepo, { recursive: true });
    await mkdir(secondRepo, { recursive: true });
    runGit(["init"], firstRepo);
    runGit(["init"], secondRepo);

    for (const [repo, id, trigger] of [
      [firstRepo, "first", "Brain shaped the dashboard root view."],
      [secondRepo, "second", "Brain shaped Lens work in another repo."],
    ] as const) {
      const log = spawnSync(
        process.execPath,
        [
          anvilBin,
          "brain",
          "log",
          "--cwd",
          repo,
          "--state-root",
          stateRoot,
          "--event",
          "used",
          "--brain",
          "anvil-brain-codex",
          "--trigger",
          trigger,
          "--message-id",
          `msg_${id}`,
          "--json",
        ],
        { cwd: resolve("."), encoding: "utf8" },
      );
      assert.equal(log.status, 0, log.stderr);
    }

    dashboard = spawn(
      process.execPath,
      [anvilBin, "brain", "dashboard", "--cwd", firstRepo, "--state-root", stateRoot, "--port", "0", "--json"],
      { cwd: resolve("."), stdio: ["ignore", "pipe", "pipe"] },
    );

    const ready = await waitForDashboardReady(dashboard);
    const response = await fetch(new URL("api/metrics", ready.url));
    assert.equal(response.status, 200);
    const metrics = (await response.json()) as {
      kind: "ok";
      total: number;
      trace: { projects: Array<{ project_root: string }> };
    };

    assert.equal(metrics.kind, "ok");
    assert.equal(metrics.total, 2);
    assert.deepEqual(
      metrics.trace.projects.map((project) => project.project_root).sort(),
      [await realpath(firstRepo), await realpath(secondRepo)].sort(),
    );
  } finally {
    if (dashboard !== undefined) dashboard.kill("SIGTERM");
    await rm(temp, { recursive: true, force: true });
  }
});

test("brain dashboard uses a stable default port", async (context) => {
  if (!(await canBindPort(defaultBrainDashboardPort))) {
    context.skip(`port ${defaultBrainDashboardPort} is already in use`);
    return;
  }

  let dashboard: ReturnType<typeof spawn> | undefined;
  try {
    dashboard = spawn(process.execPath, [anvilBin, "brain", "dashboard", "--json"], {
      cwd: resolve("."),
      stdio: ["ignore", "pipe", "pipe"],
    });
    const ready = await waitForDashboardReady(dashboard);
    const url = new URL(ready.url);
    assert.equal(url.hostname, "127.0.0.1");
    assert.equal(Number(url.port), defaultBrainDashboardPort);
  } finally {
    if (dashboard !== undefined) dashboard.kill("SIGTERM");
  }
});

test("brain dashboard wrapper runs from another directory", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-brain-wrapper-"));
  let dashboard: ReturnType<typeof spawn> | undefined;
  try {
    const env: NodeJS.ProcessEnv = { ...process.env, HOME: temp };
    delete env.ANVIL_STATE_ROOT;
    dashboard = spawn(process.execPath, [brainBin, "dashboard", "--port", "0", "--json"], {
      cwd: temp,
      env,
      stdio: ["ignore", "pipe", "pipe"],
    });
    const ready = await waitForDashboardReady(dashboard);
    assert.equal(ready.metrics_path, undefined);

    const response = await fetch(new URL("api/metrics", ready.url));
    assert.equal(response.status, 200);
    const metrics = (await response.json()) as { kind: string; path?: string };
    assert.equal(["ok", "missing", "malformed"].includes(metrics.kind), true);
    assert.equal(metrics.path?.startsWith(join(temp, ".anvil", "state")), true);
  } finally {
    if (dashboard !== undefined) dashboard.kill("SIGTERM");
    await rm(temp, { recursive: true, force: true });
  }
});
