import assert from "node:assert/strict";
import { test } from "node:test";

import { inquireObjective, validateObjective } from "../src/manifest/index.ts";

const objective = {
  id: "obj_11111111111111111111111111111111",
  title: "Manifest V2",
  outcome: "The canonical graph explains the accepted work.",
  details: "One Objective.",
  phase: "implementation",
  workstreams: [{
    id: "ws_22222222222222222222222222222222",
    title: "Current-graph inquiry",
    outcome: "Rowan can inspect connected graph facts.",
    details: "W3",
    tasks: [
      {
        id: "task_33333333333333333333333333333333",
        title: "Complete the graph module",
        outcome: "The graph module is available to its dependents.",
        details: "W1",
        completionCriteria: ["The focused graph tests pass."],
        dependencies: [],
        externalBlocker: null,
        completion: {
          evidence: [{
            criterion: "The focused graph tests pass.",
            summary: "The focused tests pass.",
            references: ["node --test test/manifest-graph.test.ts"],
          }],
        },
        discontinued: null,
      },
      {
        id: "task_44444444444444444444444444444444",
        title: "Expose connected facts",
        outcome: "Inquiry returns Work Structure and Work Dependencies.",
        details: "W3 query.",
        completionCriteria: ["Exact inquiry returns connected graph facts."],
        dependencies: ["task_33333333333333333333333333333333"],
        externalBlocker: "The query Interface is not implemented.",
        completion: null,
        discontinued: null,
      },
    ],
  }],
} as const;

test("exact Task inquiry returns its connected graph and execution facts", () => {
  const validated = validateObjective(objective);
  assert.equal(validated.valid, true);
  if (!validated.valid) return;
  const task = validated.graph.workstreams[0]!.tasks[1]!;

  const result = inquireObjective(validated.graph, { id: task.id }, { currentTaskId: task.id });
  assert.equal(result.outcome, "found");
  if (result.outcome !== "found") return;
  assert.equal(result.entity.kind, "task");
  assert.equal(result.entity.id, task.id);
  assert.equal(result.entity.parent?.id, validated.graph.workstreams[0]!.id);
  assert.deepEqual(result.entity.children, []);
  assert.deepEqual(result.entity.prerequisites.map((item) => item.id), [
    validated.graph.workstreams[0]!.tasks[0]!.id,
  ]);
  assert.deepEqual(result.entity.dependents, []);
  assert.equal(result.entity.externalBlocker, task.externalBlocker);
  assert.equal(result.entity.completion, null);
  assert.equal(result.entity.discontinued, null);
  assert.equal(result.entity.execution?.current, true);
  assert.equal(result.entity.execution?.available, false);
  assert.deepEqual(result.entity.execution?.reasons, [
    `External Blocker: ${task.externalBlocker}`,
    "Task is Current and excluded from Available choices.",
  ]);
});

test("text inquiry is literal, bounded, graph-ordered, and explicit about ambiguity", () => {
  const validated = validateObjective(objective);
  assert.equal(validated.valid, true);
  if (!validated.valid) return;

  const multiple = inquireObjective(validated.graph, { text: "GRAPH", limit: 2 });
  assert.equal(multiple.outcome, "multiple");
  if (multiple.outcome !== "multiple") return;
  assert.equal(multiple.matchCount, 4);
  assert.equal(multiple.limit, 2);
  assert.deepEqual(multiple.matches.map((match) => match.id), [
    validated.graph.id,
    validated.graph.workstreams[0]!.id,
  ]);

  const criterionMatch = inquireObjective(validated.graph, { text: "exact inquiry" });
  assert.equal(criterionMatch.outcome, "found");
  if (criterionMatch.outcome === "found") {
    assert.equal(criterionMatch.entity.id, validated.graph.workstreams[0]!.tasks[1]!.id);
  }

  assert.deepEqual(inquireObjective(validated.graph, { text: "not present" }), {
    outcome: "not_found",
    matches: [],
  });
  const capped = inquireObjective(validated.graph, { text: "graph", limit: 500 });
  assert.equal(capped.outcome === "multiple" ? capped.limit : null, 50);
});

test("exact inquiry covers Work Structure, dependents, completion evidence, and missing identity", () => {
  const validated = validateObjective(objective);
  assert.equal(validated.valid, true);
  if (!validated.valid) return;
  const workstream = validated.graph.workstreams[0]!;
  const completedTask = workstream.tasks[0]!;

  const objectiveResult = inquireObjective(validated.graph, { id: validated.graph.id });
  assert.equal(objectiveResult.outcome, "found");
  if (objectiveResult.outcome === "found") {
    assert.equal(objectiveResult.entity.parent, null);
    assert.deepEqual(objectiveResult.entity.children.map((item) => item.id), [workstream.id]);
  }

  const workstreamResult = inquireObjective(validated.graph, { id: workstream.id });
  assert.equal(workstreamResult.outcome, "found");
  if (workstreamResult.outcome === "found") {
    assert.equal(workstreamResult.entity.parent?.id, validated.graph.id);
    assert.deepEqual(workstreamResult.entity.children.map((item) => item.id), workstream.tasks.map((task) => task.id));
  }

  const taskResult = inquireObjective(validated.graph, { id: completedTask.id });
  assert.equal(taskResult.outcome, "found");
  if (taskResult.outcome === "found") {
    assert.deepEqual(taskResult.entity.dependents.map((item) => item.id), [workstream.tasks[1]!.id]);
    assert.deepEqual(taskResult.entity.completion, completedTask.completion);
    assert.equal(taskResult.entity.execution?.complete, true);
  }

  assert.deepEqual(inquireObjective(validated.graph, { id: "task_99999999999999999999999999999999" }), {
    outcome: "not_found",
    matches: [],
  });
});

test("exact inquiry keeps a Discontinued Task visible with its reason", () => {
  const discontinued = {
    ...objective.workstreams[0].tasks[1],
    externalBlocker: null,
    discontinued: { reason: "The accepted plan no longer requires this Task." },
  } as const;
  const validated = validateObjective({
    ...objective,
    workstreams: [{ ...objective.workstreams[0], tasks: [objective.workstreams[0].tasks[0], discontinued] }],
  });
  assert.equal(validated.valid, true);
  if (!validated.valid) return;

  const result = inquireObjective(validated.graph, { id: validated.graph.workstreams[0]!.tasks[1]!.id });
  assert.equal(result.outcome, "found");
  if (result.outcome !== "found") return;
  assert.deepEqual(result.entity.discontinued, discontinued.discontinued);
  assert.equal(result.entity.execution?.discontinued, true);
  assert.equal(result.entity.execution?.available, false);
});
