import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { mkdtemp, mkdir, rm, symlink, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { test } from 'node:test';
import {
  MAX_CONTENT_BYTES,
  MAX_DIFF_CONTENT_BYTES,
  MAX_FILES,
  MAX_TOTAL_BYTES,
  diffTrees,
  snapshotManifest,
  snapshotTree,
} from '../scripts/brain-case-files.mjs';

async function fixture(prefix = 'brain-case-files-') {
  const root = await mkdtemp(join(tmpdir(), prefix));
  return {
    root,
    async close() {
      await rm(root, { recursive: true, force: true });
    },
  };
}

function hash(value) {
  return createHash('sha256').update(value).digest('hex');
}

test('snapshots add, modify and delete files with deterministic text diffs', async () => {
  const f = await fixture();
  try {
    await writeFile(join(f.root, 'same.txt'), 'unchanged\n');
    await writeFile(join(f.root, 'modify.txt'), 'before\n');
    await writeFile(join(f.root, 'delete.txt'), 'removed later\n');
    const before = snapshotTree(f.root);

    await writeFile(join(f.root, 'modify.txt'), 'after\n');
    await rm(join(f.root, 'delete.txt'));
    await writeFile(join(f.root, 'new.txt'), 'new file\n');
    const after = snapshotTree(f.root);
    const diff = diffTrees(before, after);

    assert.deepEqual(diff.map(({ path, kind }) => ({ path, kind })), [
      { path: 'delete.txt', kind: 'deleted' },
      { path: 'modify.txt', kind: 'modified' },
      { path: 'new.txt', kind: 'added' },
    ]);
    assert.equal(diff[0].before.content, 'removed later\n');
    assert.equal(diff[0].after, null);
    assert.equal(diff[1].before.content, 'before\n');
    assert.equal(diff[1].after.content, 'after\n');
    assert.equal(diff[2].before, null);
    assert.equal(diff[2].after.content, 'new file\n');
  } finally {
    await f.close();
  }
});

test('snapshot manifest removes text but retains hashes, sizes and omissions', async () => {
  const f = await fixture();
  try {
    const content = 'small text\n';
    const binary = Buffer.from([0, 1, 2, 255]);
    await writeFile(join(f.root, 'small.txt'), content);
    await writeFile(join(f.root, 'binary.bin'), binary);
    const tree = snapshotTree(f.root);
    const manifest = snapshotManifest(tree);

    assert.equal(manifest['small.txt'].sha256, hash(content));
    assert.equal(manifest['small.txt'].bytes, Buffer.byteLength(content));
    assert.equal(Object.hasOwn(manifest['small.txt'], 'content'), false);
    assert.deepEqual(manifest['binary.bin'].contentOmitted, { reason: 'binary' });
    assert.deepEqual(manifest, snapshotManifest(new Map(Object.entries(tree))));
    assert.equal(tree['small.txt'].content, content);
  } finally {
    await f.close();
  }
});

test('excluded internals and a .venv directory symlink are not traversed, while wiki.html is included', async () => {
  const f = await fixture();
  const outside = await fixture('brain-case-files-outside-');
  try {
    await mkdir(join(f.root, '.git'), { recursive: true });
    await mkdir(join(f.root, '.venv'), { recursive: true });
    await mkdir(join(f.root, 'node_modules', 'pkg'), { recursive: true });
    await mkdir(join(f.root, 'nested', '__pycache__'), { recursive: true });
    await writeFile(join(f.root, '.git', 'secret'), 'ignored');
    await writeFile(join(f.root, '.venv', 'private'), 'ignored');
    await writeFile(join(f.root, 'node_modules', 'pkg', 'index.js'), 'ignored');
    await writeFile(join(f.root, 'nested', '__pycache__', 'x.pyc'), 'ignored');
    await writeFile(join(outside.root, 'outside.txt'), 'must not appear');
    await rm(join(f.root, '.venv'), { recursive: true, force: true });
    await symlink(outside.root, join(f.root, '.venv'), 'dir');
    await writeFile(join(f.root, 'visible.txt'), 'included');
    await writeFile(join(f.root, 'wiki.html'), '<html>generated</html>');

    const tree = snapshotTree(f.root);
    assert.deepEqual(Object.keys(tree), ['visible.txt', 'wiki.html']);
    assert.equal(tree['visible.txt'].content, 'included');
    assert.equal(tree['wiki.html'].sha256, hash('<html>generated</html>'));
    assert.equal(tree['wiki.html'].bytes, Buffer.byteLength('<html>generated</html>'));
    assert.equal(tree['outside.txt'], undefined);
  } finally {
    await f.close();
    await outside.close();
  }
});

test('unexpected symlinks fail closed even when the target is outside the root', async () => {
  const f = await fixture();
  const outside = await fixture('brain-case-files-outside-');
  try {
    await writeFile(join(outside.root, 'secret.txt'), 'outside');
    await symlink(join(outside.root, 'secret.txt'), join(f.root, 'link.txt'), 'file');
    assert.throws(() => snapshotTree(f.root), /Unexpected symlink/);
  } finally {
    await f.close();
    await outside.close();
  }
});

test('binary and oversized text retain hashes and explicit omission reasons', async () => {
  const f = await fixture();
  try {
    const binary = Buffer.from([0, 1, 2, 3, 255]);
    const large = 'x'.repeat(MAX_CONTENT_BYTES + 1);
    const generated = '<!doctype html>' + 'y'.repeat(MAX_CONTENT_BYTES + 1);
    await writeFile(join(f.root, 'binary.dat'), binary);
    await writeFile(join(f.root, 'large.txt'), large);
    await writeFile(join(f.root, 'wiki.html'), generated);

    const tree = snapshotTree(f.root);
    assert.equal(tree['binary.dat'].sha256, hash(binary));
    assert.equal(tree['binary.dat'].bytes, binary.byteLength);
    assert.deepEqual(tree['binary.dat'].contentOmitted, { reason: 'binary' });
    assert.equal(tree['binary.dat'].content, undefined);
    assert.equal(tree['large.txt'].sha256, hash(large));
    assert.equal(tree['large.txt'].bytes, Buffer.byteLength(large));
    assert.deepEqual(tree['large.txt'].contentOmitted, { reason: 'too_large' });
    assert.equal(tree['wiki.html'].sha256, hash(generated));
    assert.equal(tree['wiki.html'].bytes, Buffer.byteLength(generated));
    assert.deepEqual(tree['wiki.html'].contentOmitted, { reason: 'too_large' });
  } finally {
    await f.close();
  }
});

test('diff content is bounded and records omitted text without dropping hashes', () => {
  const unit = 'z'.repeat(MAX_DIFF_CONTENT_BYTES / 2);
  const before = {
    'a.txt': { sha256: hash('a-before'), bytes: 8, content: unit },
    'b.txt': { sha256: hash('b-before'), bytes: 8, content: unit },
  };
  const after = {
    'a.txt': { sha256: hash('a-after'), bytes: 8, content: unit },
    'b.txt': { sha256: hash('b-after'), bytes: 8, content: unit },
  };
  const diff = diffTrees(before, after);

  assert.equal(diff.length, 2);
  assert.equal(diff[0].before.content, unit);
  assert.equal(diff[0].after.content, unit);
  assert.equal(diff[1].before.content, undefined);
  assert.equal(diff[1].after.content, undefined);
  assert.deepEqual(diff[1].before.contentOmitted, { reason: 'diff_budget' });
  assert.deepEqual(diff[1].after.contentOmitted, { reason: 'diff_budget' });
  assert.equal(diff[1].before.sha256, hash('b-before'));
  assert.equal(diff[1].after.sha256, hash('b-after'));
});

test('tree file-count and byte budgets fail closed', async () => {
  const bytesFixture = await fixture('brain-case-files-bytes-');
  const countFixture = await fixture('brain-case-files-count-');
  try {
    await writeFile(join(bytesFixture.root, 'too-big.bin'), Buffer.alloc(MAX_TOTAL_BYTES + 1));
    assert.throws(() => snapshotTree(bytesFixture.root), /exceeds 16777216 bytes/);

    for (let index = 0; index <= MAX_FILES; index += 1) {
      await writeFile(join(countFixture.root, `file-${String(index).padStart(4, '0')}.txt`), '');
    }
    assert.throws(() => snapshotTree(countFixture.root), /exceeds 3000 regular files/);
  } finally {
    await bytesFixture.close();
    await countFixture.close();
  }
});
