import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import { createHash } from "node:crypto";
import { mkdir, mkdtemp, readFile, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join, resolve } from "node:path";
import { test } from "node:test";

import {
  auditContinuityRouting,
  deriveContinuityPaths,
  initWorkspace,
  recordContinuityEvent,
  recordEvent,
} from "../src/continuity/index.ts";
import type { CurrentFrameInput, EventInput } from "../src/continuity/index.ts";
import { bindWorkContext } from "../src/work-context/index.ts";

const anvilBin = resolve("bin/anvil.ts");

function frameInput(): CurrentFrameInput {
  return {
    operating_mode: "routing-audit-test",
    intent: "Audit history without moving it.",
    quality_bar: ["Unknown ownership remains unknown."],
    permission_envelope: {
      default: "read only",
      allowed_without_approval: ["audit partitions"],
      requires_approval: ["move events"],
    },
    active_decisions: [],
    open_questions: [],
    next_actions: [],
    continuity_notes: [],
  };
}

function event(summary: string, type: EventInput["type"] = "decision"): EventInput {
  return {
    type,
    status: "active",
    summary,
    supersedes: [],
    resolves: [],
    related_events: [],
  };
}

async function digest(paths: string[]): Promise<Record<string, string>> {
  const result: Record<string, string> = {};
  for (const path of paths) {
    result[path] = createHash("sha256").update(await readFile(path)).digest("hex");
  }
  return result;
}

test("historical routing audit classifies evidence without inferring unknown destinations or mutating state", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-continuity-routing-audit-"));
  try {
    const improvements = join(temp, "improvements");
    const improvementsNested = join(improvements, "src", "feature");
    const anvilRedux = join(temp, "anvil_redux");
    const stateRoot = join(temp, "state");
    await mkdir(improvementsNested, { recursive: true });
    await mkdir(anvilRedux, { recursive: true });
    const git = spawnSync("git", ["init"], { cwd: improvements, encoding: "utf8" });
    assert.equal(git.status, 0, git.stderr);
    const improvementsBinding = await bindWorkContext({
      host: "codex",
      sessionId: "session-audit-improvements",
      cwd: improvements,
      lifecycle: "SessionStart:startup",
      stateRoot,
    });
    const anvilBinding = await bindWorkContext({
      host: "codex",
      sessionId: "session-audit-anvil",
      cwd: anvilRedux,
      lifecycle: "SessionStart:startup",
      stateRoot,
    });
    const improvementsPaths = deriveContinuityPaths({
      stateRoot,
      workspace: improvementsBinding.binding.collaboration_space,
    });
    const anvilPaths = deriveContinuityPaths({
      stateRoot,
      workspace: anvilBinding.binding.collaboration_space,
    });
    await initWorkspace(improvementsPaths, frameInput(), { now: () => "2026-07-15T00:00:00.000Z" });
    await initWorkspace(anvilPaths, frameInput(), { now: () => "2026-07-15T00:00:00.000Z" });

    await recordContinuityEvent({
      binding: improvementsBinding.binding,
      stateRoot,
      event: event("Confirmed improvements event.", "phase_change"),
      source: { kind: "codex_mcp" },
      now: () => "2026-07-15T01:00:00.000Z",
      id: () => "evt_audit_confirmed",
    });
    await recordEvent(improvementsPaths, event("Legacy same-root event."), {
      source: { kind: "legacy_mcp", cwd: improvements },
      now: () => "2026-07-15T02:00:00.000Z",
      id: () => "evt_audit_unknown",
    });
    await recordEvent(improvementsPaths, event("Legacy nested same-repository event."), {
      source: { kind: "legacy_mcp", cwd: improvementsNested },
      now: () => "2026-07-15T02:30:00.000Z",
      id: () => "evt_audit_nested_unknown",
    });
    await recordEvent(improvementsPaths, event("Legacy cross-root event.", "correction"), {
      source: { kind: "legacy_mcp", cwd: anvilRedux },
      now: () => "2026-07-15T03:00:00.000Z",
      id: () => "evt_audit_candidate",
    });
    await recordEvent(anvilPaths, event("Anvil legacy event."), {
      source: { kind: "legacy_mcp" },
      now: () => "2026-07-15T04:00:00.000Z",
      id: () => "evt_audit_anvil_unknown",
    });

    const stateFiles = [
      improvementsPaths.indexPath,
      improvementsPaths.currentPath,
      improvementsPaths.eventsPath,
      anvilPaths.currentPath,
      anvilPaths.eventsPath,
    ];
    const before = await digest(stateFiles);
    const audit = await auditContinuityRouting({
      stateRoot,
      now: () => "2026-07-16T00:00:00.000Z",
    });
    const cli = spawnSync(
      process.execPath,
      [anvilBin, "continuity", "routing-audit", "--state-root", stateRoot, "--json"],
      { cwd: resolve("."), encoding: "utf8" },
    );
    const after = await digest(stateFiles);

    assert.equal(audit.partition_count, 2);
    assert.equal(audit.event_count, 5);
    assert.deepEqual(audit.classifications, { confirmed: 1, candidate: 1, unknown: 3 });
    const improvementsAudit = audit.partitions.find(
      (partition) => partition.workspace.key === improvementsBinding.binding.collaboration_space.key,
    );
    assert.ok(improvementsAudit);
    assert.deepEqual(improvementsAudit.date_range, {
      first: "2026-07-15T01:00:00.000Z",
      last: "2026-07-15T03:00:00.000Z",
    });
    assert.equal(improvementsAudit.cross_repository_references.length, 1);
    assert.equal(improvementsAudit.compact_frame_churn.phase_change_events, 1);
    assert.equal(improvementsAudit.compact_frame_churn.correction_events, 1);
    assert.equal(improvementsAudit.source_provenance.some((source) => source.kind === "codex_mcp"), true);
    const unknown = audit.partitions.flatMap((partition) => partition.events).filter((item) => item.classification === "unknown");
    assert.equal(unknown.length, 3);
    assert.equal(unknown.some((item) => "destination" in item), false);
    assert.deepEqual(after, before);
    assert.equal(cli.status, 0, cli.stderr);
    assert.equal(JSON.parse(cli.stdout).classifications.unknown, 3);
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});
