import assert from "node:assert/strict";
import { execFileSync } from "node:child_process";
import { mkdtemp, readFile, realpath, rm, symlink, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { afterEach, test } from "node:test";
import { runInNewContext } from "node:vm";

import {
  createObjectiveFile,
  discoverObjectives,
  objectiveIdSchema,
  startManifestViewServer,
  validateObjective,
  writeObjective,
} from "../src/manifest/index.ts";

const roots: string[] = [];

afterEach(async () => {
  await Promise.all(roots.splice(0).map((root) => rm(root, { recursive: true, force: true })));
});

const OBJECTIVE_ID = "obj_11111111111111111111111111111111";
const SECOND_OBJECTIVE_ID = "obj_22222222222222222222222222222222";
const THIRD_OBJECTIVE_ID = "obj_33333333333333333333333333333333";
const WORKSTREAM_ID = "ws_11111111111111111111111111111111";
const TASK_ID = "task_11111111111111111111111111111111";
const OTHER_TASK_ID = "task_22222222222222222222222222222222";

type ObjectivePhase = "planning" | "implementation";

function objective(title: string, id = OBJECTIVE_ID, phase: ObjectivePhase = "planning") {
  const result = validateObjective({
    id,
    title,
    outcome: `${title} outcome.`,
    details: "Manifest navigation contract fixture.",
    phase,
    ...(phase === "implementation" ? {
      implementation: {
        sequence: [["W1"]],
        stages: [{
          id: "W1",
          label: "Navigation",
          detail: "Navigation contract fixture.",
          coverage: "Manifest routing",
          exit: "The graph route is stable.",
          primary: { concepts: [], nodes: [TASK_ID] },
          supporting: { concepts: [], nodes: [] },
          slices: [{
            id: "W1.1",
            label: "Route the graph",
            coverage: "Qualified links",
            acceptance: "Qualified links resolve.",
            mapsTo: { concepts: [], nodes: [TASK_ID] },
          }],
        }],
        scenario: ["Open the qualified graph route."],
      },
    } : {}),
    workstreams: [{
      id: WORKSTREAM_ID,
      title: "Navigation",
      outcome: "The graph can be opened from the landing page.",
      details: "",
      tasks: [{
        id: TASK_ID,
        title: "Open the graph",
        outcome: "The canonical graph route renders.",
        details: "",
        completionCriteria: ["The canonical graph route renders."],
        dependencies: [],
        externalBlocker: null,
        completion: null,
        discontinued: null,
      }, {
        id: OTHER_TASK_ID,
        title: "Keep the target stable",
        outcome: "Requests remain scoped to their repository.",
        details: "",
        completionCriteria: ["Requests remain scoped to their repository."],
        dependencies: [TASK_ID],
        externalBlocker: null,
        completion: null,
        discontinued: null,
      }],
    }],
  });
  assert.equal(result.valid, true);
  if (!result.valid) throw new Error("Navigation fixture must be valid.");
  return result.graph;
}

async function gitRepository(prefix: string): Promise<string> {
  const repository = await mkdtemp(join(tmpdir(), prefix));
  roots.push(repository);
  execFileSync("git", ["init", "-q"], { cwd: repository });
  return repository;
}

async function directory(prefix: string): Promise<string> {
  const path = await mkdtemp(join(tmpdir(), prefix));
  roots.push(path);
  return path;
}

async function putObjective(repository: string, title: string, id = OBJECTIVE_ID, phase: ObjectivePhase = "planning") {
  return createObjectiveFile(repository, objective(title, id, phase));
}

function graphUrl(serverUrl: string, repository: string, id = OBJECTIVE_ID, parameters: Record<string, string> = {}): URL {
  const url = new URL(`/objectives/${encodeURIComponent(id)}`, serverUrl);
  url.searchParams.set("repository", repository);
  for (const [key, value] of Object.entries(parameters)) url.searchParams.set(key, value);
  return url;
}

function apiUrl(serverUrl: string, repository: string, id = OBJECTIVE_ID): URL {
  const url = new URL(`/api/objectives/${encodeURIComponent(id)}`, serverUrl);
  url.searchParams.set("repository", repository);
  return url;
}

function locationUrl(response: Response, base: string): URL {
  const location = response.headers.get("location");
  assert.ok(location, "redirect must include a Location header");
  return new URL(location, base);
}

function jsonScript(html: string, id: string): unknown {
  const escaped = id.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const match = html.match(new RegExp(`<script id="${escaped}"[^>]*>([\\s\\S]*?)<\\/script>`));
  assert.ok(match, `expected ${id} JSON script`);
  return JSON.parse(match[1]!);
}

test("the stable entry always redirects to automatic landing and landing refreshes discovery", async () => {
  const repository = await gitRepository("manifest-navigation-count-");
  const server = await startManifestViewServer({ repository, host: "127.0.0.1", port: 0 });
  try {
    for (const [count, title, id] of [
      [0, "", ""],
      [1, "One Objective", OBJECTIVE_ID],
      [2, "Two Objectives", SECOND_OBJECTIVE_ID],
    ] as const) {
      if (id) await putObjective(repository, title, id);
      const entry = await fetch(server.url, { redirect: "manual" });
      assert.equal(entry.status, 302, `entry redirect for ${count} files`);
      assert.equal(locationUrl(entry, server.url).pathname, "/objectives");

      const landing = await fetch(new URL("/objectives", server.url));
      assert.equal(landing.status, 200);
      const html = await landing.text();
      assert.match(html, /<main data-testid="manifest-objectives-landing">/);
      assert.match(html, /fetch\("\/api\/discovery"/);
      assert.match(html, /POLL_MS\s*=\s*5000/);
      assert.match(html, /href = "\/objectives\/" \+ encodeURIComponent\(text\(objective\.id\)\) \+ "\?repository=" \+ encodeURIComponent\(repository\)/);
      assert.doesNotMatch(html, /current-task-id/);

      const discovery = await fetch(new URL("/api/discovery", server.url));
      assert.equal(discovery.status, 200);
      const body = await discovery.json() as { repositories: Array<{ objectives: Array<{ objective?: { id: string } }> }> };
      const ids = body.repositories.flatMap((item) => item.objectives
        .filter((entry) => entry.objective)
        .map((entry) => entry.objective!.id));
      assert.equal(ids.length, count);
    }
  } finally {
    await server.close();
  }
});

test("an explicit server Objective target makes the stable entry redirect to its qualified graph", async () => {
  const repository = await gitRepository("manifest-navigation-server-target-");
  await putObjective(repository, "Server-selected Objective");
  const server = await startManifestViewServer({
    repository,
    objectiveId: objectiveIdSchema.parse(OBJECTIVE_ID),
    host: "127.0.0.1",
    port: 0,
  });
  try {
    const response = await fetch(server.url, { redirect: "manual" });
    assert.equal(response.status, 302);
    const target = locationUrl(response, server.url);
    assert.equal(target.pathname, `/objectives/${OBJECTIVE_ID}`);
    assert.equal(target.searchParams.get("repository"), await realpath(repository));
  } finally {
    await server.close();
  }
});

test("qualified graph targets canonicalize aliases, keep startup roots immutable, and isolate concurrent repositories", async () => {
  const first = await gitRepository("manifest-navigation-first root-");
  const second = await gitRepository("manifest-navigation-second root-");
  await putObjective(first, "First repository");
  await putObjective(second, "Second repository");
  const aliases = await directory("manifest-navigation-aliases-");
  const firstAlias = join(aliases, "first alias");
  const secondAlias = join(aliases, "second alias");
  await symlink(first, firstAlias, "dir");
  await symlink(second, secondAlias, "dir");
  const firstCanonical = await realpath(first);
  const secondCanonical = await realpath(second);

  const server = await startManifestViewServer({ repository: firstAlias, host: "127.0.0.1", port: 0 });
  try {
    const omitted = await fetch(`${server.url}/objectives/${OBJECTIVE_ID}`, { redirect: "manual" });
    assert.equal(omitted.status, 302);
    const omittedTarget = locationUrl(omitted, server.url);
    assert.equal(omittedTarget.pathname, `/objectives/${OBJECTIVE_ID}`);
    assert.equal(omittedTarget.searchParams.get("repository"), firstCanonical);

    const firstPage = await fetch(omittedTarget);
    assert.equal(firstPage.status, 200);
    assert.equal((jsonScript(await firstPage.text(), "manifest-target") as { repository: string }).repository, firstCanonical);

    const aliasPage = await fetch(graphUrl(server.url, secondAlias), { redirect: "manual" });
    assert.equal(aliasPage.status, 302);
    const aliasTarget = locationUrl(aliasPage, server.url);
    assert.equal(aliasTarget.pathname, `/objectives/${OBJECTIVE_ID}`);
    assert.equal(aliasTarget.searchParams.get("repository"), secondCanonical);
    assert.equal(aliasTarget.searchParams.get("current-task-id"), null);

    const secondPage = await fetch(graphUrl(server.url, secondCanonical));
    assert.equal(secondPage.status, 200);
    const secondHtml = await secondPage.text();
    assert.equal((jsonScript(secondHtml, "manifest-human-view") as { objective: { title: string } }).objective.title, "Second repository");
    assert.deepEqual(jsonScript(secondHtml, "manifest-target"), { repository: secondCanonical, objectiveId: OBJECTIVE_ID });

    const [firstApi, secondApi] = await Promise.all([
      fetch(apiUrl(server.url, firstCanonical)),
      fetch(apiUrl(server.url, secondCanonical)),
    ]);
    assert.equal(firstApi.status, 200);
    assert.equal(secondApi.status, 200);
    const [firstBody, secondBody] = await Promise.all([
      firstApi.json() as Promise<{ objective: { title: string }; target: { repository: string; objectiveId: string } }>,
      secondApi.json() as Promise<{ objective: { title: string }; target: { repository: string; objectiveId: string } }>,
    ]);
    assert.equal(firstBody.objective.title, "First repository");
    assert.equal(secondBody.objective.title, "Second repository");
    assert.deepEqual(firstBody.target, { repository: firstCanonical, objectiveId: OBJECTIVE_ID });
    assert.deepEqual(secondBody.target, { repository: secondCanonical, objectiveId: OBJECTIVE_ID });

    const legacy = await fetch(`${server.url}/api/objectives/${OBJECTIVE_ID}`);
    assert.equal(legacy.status, 200);
    const legacyBody = await legacy.json() as { objective: { title: string }; target?: unknown };
    assert.equal(legacyBody.objective.title, "First repository");
    assert.equal("target" in legacyBody, false);
  } finally {
    await server.close();
  }
});

test("qualified graph responses read subsequent file updates without mutating browsing bytes", async () => {
  const repository = await gitRepository("manifest-navigation-refresh-");
  const created = await putObjective(repository, "Fresh first response");
  const before = await readFile(created.path, "utf8");
  const server = await startManifestViewServer({ repository, host: "127.0.0.1", port: 0 });
  try {
    const first = await fetch(apiUrl(server.url, await realpath(repository)));
    assert.equal(first.status, 200);
    assert.equal((await first.json()).objective.title, "Fresh first response");

    await writeObjective(repository, objective("Fresh second response"));
    const afterWrite = await readFile(created.path, "utf8");
    assert.notEqual(afterWrite, before);

    const second = await fetch(apiUrl(server.url, await realpath(repository)));
    assert.equal(second.status, 200);
    assert.equal((await second.json()).objective.title, "Fresh second response");
    assert.equal(await readFile(created.path, "utf8"), afterWrite);
  } finally {
    await server.close();
  }
});

test("legacy and alias graph queries redirect before rendering, preserve presentation parameters, and qualify generated links", async () => {
  const repository = await gitRepository("manifest-navigation-redirect-");
  const canonical = await realpath(repository);
  const parent = await directory("manifest-navigation-redirect-alias-");
  const alias = join(parent, "repository alias");
  await symlink(repository, alias, "dir");
  await putObjective(repository, "Qualified implementation", OBJECTIVE_ID, "implementation");
  const server = await startManifestViewServer({ repository, host: "127.0.0.1", port: 0 });
  try {
    const response = await fetch(graphUrl(server.url, alias, OBJECTIVE_ID, {
      "manifest-surface": "implementation",
      surface: "plan",
      "current-task-id": TASK_ID,
    }), { redirect: "manual" });
    assert.equal(response.status, 302);
    const target = locationUrl(response, server.url);
    assert.equal(target.pathname, `/objectives/${OBJECTIVE_ID}`);
    assert.equal(target.searchParams.get("repository"), canonical);
    assert.equal(target.searchParams.get("manifest-surface"), "implementation");
    assert.equal(target.searchParams.get("surface"), "plan");
    assert.equal(target.searchParams.get("current-task-id"), TASK_ID);
    assert.equal(response.headers.get("content-type"), null);

    const html = await fetch(target).then((result) => result.text());
    const source = html.match(/<script id="manifest-implementation-view">([\s\S]*?)<\/script>/)?.[1] ?? "";
    assert.match(source, /const targetKey = JSON\.stringify\(\[target\.repository, target\.objectiveId\]\)/);
    assert.match(source, /manifest-human-surface-v2::/);
    assert.match(source, /manifest-map-implementation-view-v6::/);
    assert.match(source, /const targetHref = \(\) =>/);
    assert.match(source, /href\.searchParams\.set\('repository', target\.repository\)/);
    assert.match(source, /const currentTask = requested\.get\('current-task-id'\)/);
    assert.match(source, /const planHref = \(\) =>/);
    assert.match(source, /const graphHref = \(stageId = initialStage, sliceId = initialSlice\) =>/);
    assert.match(source, /href\.searchParams\.set\('surface', 'plan'\)/);
    assert.doesNotMatch(source, /new URL\(location\.href\).*?href\.search = ''/s);

    const graphHref = source.match(/  const graphHref = \(stageId = initialStage, sliceId = initialSlice\) => \{[\s\S]*?\n  \};/)?.[0];
    const planHref = source.match(/  const planHref = \(\) => \{[\s\S]*?\n  \};/)?.[0];
    const targetHref = source.match(/  const targetHref = \(\) => \{[\s\S]*?\n  \};/)?.[0];
    assert.ok(graphHref);
    assert.ok(planHref);
    assert.ok(targetHref);
    const canonicalGraphRequest = graphUrl(server.url, canonical, OBJECTIVE_ID, {
      "manifest-surface": "implementation",
      surface: "plan",
      "current-task-id": TASK_ID,
    });
    const links = JSON.parse(runInNewContext(`
      const target = ${JSON.stringify({ repository: canonical, objectiveId: OBJECTIVE_ID })};
      const requested = new URLSearchParams(${JSON.stringify(canonicalGraphRequest.search)});
      const location = { href: ${JSON.stringify(canonicalGraphRequest.href)} };
      const initialStage = 'W1';
      const initialSlice = 'W1.1';
      ${targetHref}
      ${graphHref}
      ${planHref}
      JSON.stringify([graphHref('W1', 'W1.1'), planHref()]);
    `, { URL, URLSearchParams, encodeURIComponent }));
    for (const link of links as string[]) {
      const url = new URL(link);
      assert.equal(url.searchParams.get("repository"), canonical);
      assert.equal(url.searchParams.get("current-task-id"), TASK_ID);
    }
    assert.equal(new URL(links[0]!).searchParams.get("variant"), "adaptive");
    assert.equal(new URL(links[1]!).searchParams.get("surface"), "plan");
  } finally {
    await server.close();
  }
});

test("explicit target errors never fall back to the startup repository and malformed targets do not poison valid requests", async () => {
  const startup = await gitRepository("manifest-navigation-errors-startup-");
  const other = await gitRepository("manifest-navigation-errors-other-");
  await putObjective(startup, "Startup Objective");
  await putObjective(other, "Other Objective", SECOND_OBJECTIVE_ID);
  const otherDirectory = join(await realpath(other), ".manifest", "objectives");
  await writeFile(join(otherDirectory, `${OBJECTIVE_ID}.json`), JSON.stringify(objective("Mismatched graph", SECOND_OBJECTIVE_ID), null, 2), "utf8");
  const invalidRoot = await directory("manifest-navigation-invalid-root-");
  const server = await startManifestViewServer({ repository: startup, host: "127.0.0.1", port: 0 });
  try {
    const unknown = await fetch(apiUrl(server.url, await realpath(other)), { redirect: "manual" });
    assert.equal(unknown.status, 400);
    assert.match((await unknown.json()).error.message, /does not match(?: its)? filename|does not exist/);

    const invalid = await fetch(apiUrl(server.url, invalidRoot));
    assert.equal(invalid.status, 400);
    assert.match((await invalid.json()).error.message, /not a Git worktree root/);

    const malformed = await fetch(`${server.url}/api/objectives/${OBJECTIVE_ID}?repository=${encodeURIComponent(await realpath(other))}`);
    assert.equal(malformed.status, 400);
    assert.match((await malformed.json()).error.message, /does not match(?: its)? filename/);

    const [valid, missing] = await Promise.all([
      fetch(apiUrl(server.url, await realpath(startup))),
      fetch(apiUrl(server.url, await realpath(other), THIRD_OBJECTIVE_ID)),
    ]);
    assert.equal(valid.status, 200);
    assert.equal(missing.status, 400);
    const validBody = await valid.json() as { objective: { title: string }; target: { repository: string } };
    assert.equal(validBody.objective.title, "Startup Objective");
    assert.equal(validBody.target.repository, await realpath(startup));
  } finally {
    await server.close();
  }
});

test("automatic discovery and legacy lists remain target-free while explicit API context is qualified", async () => {
  const repository = await gitRepository("manifest-navigation-discovery-");
  await putObjective(repository, "Discovery Objective");
  const server = await startManifestViewServer({ repository, host: "127.0.0.1", port: 0 });
  try {
    const legacyList = await fetch(`${server.url}/api/objectives`).then((result) => result.json()) as unknown;
    assert.deepEqual(legacyList, await discoverObjectives(repository));
    assert.equal(JSON.stringify(legacyList).includes("target"), false);

    const explicit = await fetch(apiUrl(server.url, await realpath(repository))).then((result) => result.json()) as { target: unknown };
    assert.deepEqual(explicit.target, { repository: await realpath(repository), objectiveId: OBJECTIVE_ID });

    const discovery = await fetch(`${server.url}/api/discovery`).then((result) => result.json()) as { repositories: unknown[] };
    assert.equal(discovery.repositories.length, 1);
    assert.equal(JSON.stringify(discovery).includes("target"), false);
  } finally {
    await server.close();
  }
});
