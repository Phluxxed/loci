import test from 'node:test';
import assert from 'node:assert/strict';
import { applyExecutionOverrides, lunaOverrides } from '../scripts/brain-frozen-cases.mjs';
import { estimateLunaCredits } from '../scripts/brain-case-runner.mjs';

const profiles = [
  ['knowledge', '/synthetic/knowledge'],
  ['operational', '/synthetic/operational'],
];

function syntheticSettings(kind, root) {
  return {
    kind,
    root,
    workspace: `${root}/workspace`,
    brain: `${root}/brain`,
    paths: { captures: `${root}/captures`, source: `${root}/source` },
    env: { ANVIL_HOME: `${root}/anvil-home`, ANVIL_STATE_ROOT: `${root}/state` },
    permissions: { filesystem: { [root]: 'write', [`${root}/**`]: 'write' }, network: { enabled: false } },
    hooks: { SessionStart: [{ command: 'synthetic-hook' }], Stop: [{ command: 'synthetic-hook' }] },
    mcp: { anvil: { enabled: true, command: 'synthetic-mcp' } },
    overrides: {
      model: 'gpt-6-astra',
      model_reasoning_effort: 'high',
      unrelated_setting: { retained: true },
    },
  };
}

test('Luna/max execution overrides are exact and preserve every profile setting', () => {
  assert.deepEqual(lunaOverrides, {
    model: 'gpt-5.6-luna',
    model_reasoning_effort: 'max',
    service_tier: 'default',
    'features.fast_mode': false,
    'features.multi_agent': false,
    'features.goals': false,
  });

  for (const [kind, root] of profiles) {
    const original = syntheticSettings(kind, root);
    const originalBytes = JSON.stringify(original);
    const result = applyExecutionOverrides(original, lunaOverrides);

    assert.notStrictEqual(result, original);
    assert.deepEqual(result.overrides, { ...original.overrides, ...lunaOverrides });
    for (const key of ['permissions', 'hooks', 'mcp', 'env', 'paths', 'root', 'workspace', 'brain', 'kind']) {
      assert.deepEqual(result[key], original[key], `${kind} profile changed ${key}`);
    }
    assert.deepEqual(result.overrides.unrelated_setting, original.overrides.unrelated_setting);
    assert.equal(JSON.stringify(original), originalBytes, `${kind} profile was mutated`);
    assert.equal(original.overrides.model, 'gpt-6-astra');
    assert.equal(original.overrides.model_reasoning_effort, 'high');
  }
});

test('applyExecutionOverrides rejects every non-exact Luna/max override', () => {
  const settings = syntheticSettings('knowledge', '/synthetic/rejection');
  const rejected = [
    ['model', { ...lunaOverrides, model: 'gpt-6-astra' }],
    ['reasoning effort', { ...lunaOverrides, model_reasoning_effort: 'high' }],
    ['fast mode', { ...lunaOverrides, 'features.fast_mode': true }],
    ['multi-agent', { ...lunaOverrides, 'features.multi_agent': true }],
    ['goals', { ...lunaOverrides, 'features.goals': true }],
    ['permission override', { ...lunaOverrides, 'permissions.synthetic': { filesystem: 'write' } }],
    ['missing required key', (() => {
      const copy = { ...lunaOverrides };
      delete copy['features.goals'];
      return copy;
    })()],
  ];

  for (const [label, candidate] of rejected) {
    assert.throws(() => applyExecutionOverrides(settings, candidate), undefined, label);
  }
});

test('estimateLunaCredits estimates reported token usage and counts cached input once', () => {
  const usage = { input_tokens: 100_000, cached_input_tokens: 20_000, output_tokens: 10_000 };
  const estimate = estimateLunaCredits(usage);

  assert.equal(estimate.status, 'estimated');
  assert.equal(estimate.credits, 0.71);
  assert.equal(estimate.model, 'gpt-5.6-luna');
  assert.equal(estimate.serviceTier, 'default');
  assert.deepEqual(estimate.ratesPerMillion, { input: 5, cachedInput: 0.5, output: 30 });
  assert.match(estimate.note, /estimate/i);
  assert(!Object.keys(estimate).some(key => /dollar|usd|actual.?account|billing/i.test(key)));
  assert.doesNotMatch(JSON.stringify(estimate), /\$\s*0\.71|\bUSD\b/i);
  assert.deepEqual(usage, { input_tokens: 100_000, cached_input_tokens: 20_000, output_tokens: 10_000 });

  assert.equal(estimateLunaCredits({ input_tokens: 100_000, cached_input_tokens: 20_000, output_tokens: 0 }).credits, 0.41);
  assert.equal(estimateLunaCredits({ input_tokens: 0, cached_input_tokens: 0, output_tokens: 0 }).credits, 0);
});

test('estimateLunaCredits is unproven for incomplete, invalid, or cache-write usage', () => {
  const invalid = [
    undefined,
    {},
    { input_tokens: -1, cached_input_tokens: 0, output_tokens: 0 },
    { input_tokens: 1.5, cached_input_tokens: 0, output_tokens: 0 },
    { input_tokens: 1, cached_input_tokens: 2, output_tokens: 0 },
    { input_tokens: 1, cached_input_tokens: 0, output_tokens: -1 },
    { input_tokens: 1, cached_input_tokens: 0, output_tokens: 0, cache_write_input_tokens: 1 },
  ];

  for (const usage of invalid) {
    const estimate = estimateLunaCredits(usage);
    assert.equal(estimate.status, 'unproven');
    assert.equal(estimate.credits, null);
  }

  assert.equal(estimateLunaCredits({ input_tokens: 1, cached_input_tokens: 0, output_tokens: 0, cache_write_input_tokens: 0 }).status, 'estimated');
});
