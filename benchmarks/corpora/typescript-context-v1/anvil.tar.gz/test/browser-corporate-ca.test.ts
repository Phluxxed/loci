import assert from "node:assert/strict";
import { mkdtemp, readFile, rm, stat, symlink } from "node:fs/promises";
import { tmpdir } from "node:os";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { test } from "node:test";

import {
  BROWSERLESS_BASE_IMAGE,
  CORPORATE_IMAGE_RECIPE_VERSION,
  BrowserConfigurationError,
  buildCorporateImage,
  discoverCorporateCa,
  installCorporateCa,
  loadCorporateCaFile,
  parseCorporateCa,
} from "../src/browser/index.ts";
import type { BrowserCommandRunner } from "../src/browser/index.ts";

const fixturePath = join(dirname(fileURLToPath(import.meta.url)), "fixtures", "browser", "test-root-ca.crt");
const corporateDockerfilePath = join(
  dirname(fileURLToPath(import.meta.url)),
  "..",
  "src",
  "browser",
  "assets",
  "Dockerfile.corporate",
);

test("parseCorporateCa accepts one valid CA and returns stable metadata", async () => {
  const pem = await readFile(fixturePath, "utf8");
  const ca = parseCorporateCa(pem, { kind: "file", path: fixturePath }, new Date("2027-01-01T00:00:00Z"));

  assert.equal(ca.fingerprint, "6EEF4479ED5C212782E4C62E6AB21C8357B76223ECD25A16C79CBBEA4EEF444C");
  assert.match(ca.subject, /CN=Anvil Browser Test Root/);
  assert.equal(ca.source.kind, "file");
  assert.equal(ca.pem, pem);
});

test("parseCorporateCa rejects malformed, multiple, or out-of-validity input", async () => {
  const pem = await readFile(fixturePath, "utf8");

  assert.throws(
    () => parseCorporateCa("not a certificate", { kind: "file", path: fixturePath }),
    (error: unknown) => error instanceof BrowserConfigurationError && error.code === "CORPORATE_CA_INVALID",
  );
  assert.throws(
    () => parseCorporateCa(`${pem}\n${pem}`, { kind: "file", path: fixturePath }),
    (error: unknown) => error instanceof BrowserConfigurationError && error.code === "CORPORATE_CA_AMBIGUOUS",
  );
  assert.throws(
    () => parseCorporateCa(pem, { kind: "file", path: fixturePath }, new Date("2040-01-01T00:00:00Z")),
    (error: unknown) => error instanceof BrowserConfigurationError && error.code === "CORPORATE_CA_INVALID",
  );
});

test("loadCorporateCaFile requires an absolute path and validates the file contents", async () => {
  const ca = await loadCorporateCaFile(fixturePath, new Date("2027-01-01T00:00:00Z"));
  assert.equal(ca.source.kind, "file");
  assert.equal(ca.fingerprint, "6EEF4479ED5C212782E4C62E6AB21C8357B76223ECD25A16C79CBBEA4EEF444C");

  await assert.rejects(
    loadCorporateCaFile("relative/root.crt"),
    (error: unknown) => error instanceof BrowserConfigurationError && error.code === "CORPORATE_CA_INVALID",
  );
});

test("discoverCorporateCa fails closed when keychain lookup has zero or multiple candidates", async () => {
  const pem = await readFile(fixturePath, "utf8");
  const emptyRunner: BrowserCommandRunner = async () => ({ status: 0, stdout: "", stderr: "" });
  const duplicateRunner: BrowserCommandRunner = async () => ({ status: 0, stdout: `${pem}\n${pem}`, stderr: "" });

  await assert.rejects(
    discoverCorporateCa({ label: "Anvil Browser Test Root", keychains: ["/tmp/login.keychain"] }, emptyRunner),
    (error: unknown) => error instanceof BrowserConfigurationError && error.code === "CORPORATE_CA_MISSING",
  );
  await assert.rejects(
    discoverCorporateCa({ label: "Anvil Browser Test Root", keychains: ["/tmp/login.keychain"] }, duplicateRunner),
    (error: unknown) => error instanceof BrowserConfigurationError && error.code === "CORPORATE_CA_AMBIGUOUS",
  );
});

test("discoverCorporateCa reports candidates across keychains instead of guessing", async () => {
  const pem = await readFile(fixturePath, "utf8");
  const runner: BrowserCommandRunner = async (_command, args) => ({
    status: 0,
    stdout: args.at(-1)?.includes("system") ? pem.replace("MIIDUT", "MIIDUT") : pem,
    stderr: "",
  });

  await assert.rejects(
    discoverCorporateCa(
      {
        label: "Anvil Browser Test Root",
        keychains: ["/tmp/login.keychain", "/tmp/system.keychain"],
      },
      runner,
    ),
    (error: unknown) =>
      error instanceof BrowserConfigurationError &&
      error.code === "CORPORATE_CA_AMBIGUOUS" &&
      error.message.includes("/tmp/login.keychain") &&
      error.message.includes("/tmp/system.keychain"),
  );
});

test("installCorporateCa writes an atomic user-only copy and refuses symlinked state", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-browser-ca-"));
  try {
    const pem = await readFile(fixturePath, "utf8");
    const ca = parseCorporateCa(pem, { kind: "file", path: fixturePath }, new Date("2027-01-01T00:00:00Z"));
    const installed = await installCorporateCa(ca, join(temp, ".anvil"));

    assert.equal(await readFile(installed.path, "utf8"), pem);
    assert.equal((await stat(installed.path)).mode & 0o777, 0o600);
    assert.equal(installed.fingerprint, ca.fingerprint);

    const unsafeHome = join(temp, "unsafe-home");
    await symlink(join(temp, "outside"), unsafeHome);
    await assert.rejects(
      installCorporateCa(ca, unsafeHome),
      (error: unknown) => error instanceof BrowserConfigurationError && error.code === "CORPORATE_CA_INVALID",
    );
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("corporate image recipe installs the selected CA at build time and restores the Browserless user", async () => {
  const dockerfile = await readFile(corporateDockerfilePath, "utf8");

  assert.match(dockerfile, new RegExp(`^ARG BROWSERLESS_IMAGE=${BROWSERLESS_BASE_IMAGE.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}$`, "m"));
  assert.match(dockerfile, /^FROM \$\{BROWSERLESS_IMAGE\}$/m);
  assert.match(dockerfile, /update-ca-certificates/);
  assert.match(dockerfile, /libnss3-tools/);
  assert.match(dockerfile, /sql:\/home\/blessuser\/\.local\/share\/pki\/nssdb/);
  assert.match(dockerfile, /certutil -A -t "C,,"/);
  assert.match(dockerfile, /^USER blessuser$/m);
  assert.match(dockerfile, /io\.anvil\.browser\.ca-fingerprint="\$\{ANVIL_CA_FINGERPRINT\}"/);
  assert.match(dockerfile, /io\.anvil\.browser\.base-image="\$\{BROWSERLESS_IMAGE\}"/);
  assert.match(dockerfile, /io\.anvil\.browser\.recipe-version="\$\{ANVIL_BROWSER_RECIPE_VERSION\}"/);
  assert.doesNotMatch(dockerfile, /latest|acceptInsecureCerts|ignoreHTTPSErrors/);
});

test("buildCorporateImage uses a generated user-only context and never puts certificate contents in arguments", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-browser-image-"));
  try {
    const pem = await readFile(fixturePath, "utf8");
    const ca = parseCorporateCa(pem, { kind: "file", path: fixturePath }, new Date("2027-01-01T00:00:00Z"));
    const installed = await installCorporateCa(ca, join(temp, ".anvil"));
    const commands: string[][] = [];
    const runner: BrowserCommandRunner = async (command, args, options) => {
      assert.equal(command, "docker");
      assert.ok(options?.cwd);
      assert.equal((await stat(join(options.cwd, "corporate-root.crt"))).mode & 0o777, 0o600);
      assert.equal(await readFile(join(options.cwd, "corporate-root.crt"), "utf8"), pem);
      assert.equal(args.join(" ").includes("BEGIN CERTIFICATE"), false);
      commands.push(args);
      return { status: 0, stdout: "built", stderr: "" };
    };

    const output = await buildCorporateImage({
      installedCa: installed,
      anvilHome: join(temp, ".anvil"),
      run: runner,
    });

    assert.equal(output.image_ref, "anvil/browserless-corporate:ca-6eef4479ed5c-base-05f10074ec39-r1");
    assert.equal(commands[0]?.includes(`BROWSERLESS_IMAGE=${BROWSERLESS_BASE_IMAGE}`), true);
    assert.equal(commands[0]?.includes(`ANVIL_BROWSER_RECIPE_VERSION=${CORPORATE_IMAGE_RECIPE_VERSION}`), true);
    await assert.rejects(stat(output.build_context));
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});
