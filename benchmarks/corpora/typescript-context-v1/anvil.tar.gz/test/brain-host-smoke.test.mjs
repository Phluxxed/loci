import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { chmodSync, mkdtempSync, realpathSync, rmSync, symlinkSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { test } from 'node:test';
import { fileURLToPath } from 'node:url';
import { checkHooks, deliveredContext, sandboxDiagnosticCommands, smokeFilesystem, toml } from '../scripts/brain-host-smoke.mjs';

const command = '/reviewed/test-hook';
const hooks = () => ['preToolUse', 'sessionStart', 'stop', 'userPromptSubmit'].map(eventName => ({
  key: eventName, eventName, enabled: true, command, source: 'sessionFlags', trustStatus: 'trusted', additionalContextLimit: null,
}));
const entries = values => [{ errors: [], hooks: values }];
test('delivery capture keeps actual hook text and provenance, not upstream or unrelated context', () => {
  const kernel = '## Anvil Work Context\n\n## Brain Context\nKernel';
  const preview = 'Warning: truncated output (original token count: 4096)\n\n## Brain Context\n[truncated]\nFull hook output saved to: /tmp/full.txt';
  const transcript = [
    { type: 'session_meta', payload: { id: 'smoke-id', cwd: '/smoke', base_instructions: 'omit' } },
    { type: 'response_item', payload: { type: 'message', role: 'developer', content: [{ type: 'input_text', text: 'unrelated instructions' }, { type: 'input_text', text: kernel }] } },
    { type: 'response_item', payload: { type: 'message', role: 'developer', content: [{ type: 'input_text', text: preview }] } },
    { type: 'response_item', payload: { type: 'message', role: 'user', content: [{ type: 'input_text', text: kernel }] } },
    { type: 'response_item', payload: { type: 'reasoning', content: 'omit' } },
  ].map(JSON.stringify).join('\n');
  assert.deepEqual(deliveredContext(transcript, 'smoke-id', '/smoke'), [
    { line: 2, part: 1, text: kernel }, { line: 3, part: 0, text: preview },
  ]);
  assert.throws(() => deliveredContext(transcript, 'wrong-id', '/smoke'), /session/);
  assert.throws(() => deliveredContext(transcript, 'smoke-id', '/wrong'), /workspace/);
  assert.deepEqual(deliveredContext(JSON.stringify({ type: 'session_meta', payload: { id: 'smoke-id', cwd: '/smoke' } }), 'smoke-id', '/smoke'), []);
});
test('sandbox diagnostic separates executable paths without a model session', () => {
  assert.deepEqual(sandboxDiagnosticCommands('/launcher', '/runtime', '/instructions'), [
    { name: 'system-executable', command: ['/usr/bin/true'] },
    { name: 'resolved-codex-executable', command: ['/runtime', '--version'] },
    { name: 'codex-launcher-symlink', command: ['/launcher', '--version'] },
    { name: 'global-instructions-readable', command: [process.execPath, '-e', "require('node:fs').readFileSync(process.argv[1]);", '/instructions'] },
  ]);
});
test('host preflight accepts only the exact four reviewed hooks', () => {
  assert.equal(checkHooks(entries(hooks()), command).length, 4);
});
test('host preflight rejects a still-enabled live hook, wrong command, or changed limit', () => {
  assert.throws(() => checkHooks(entries([...hooks(), { enabled: true, command: '/live' }]), command));
  for (const change of [{ command: '/live' }, { additionalContextLimit: 0 }, { source: 'user' }]) {
    const items = hooks(); Object.assign(items[0], change);
    assert.throws(() => checkHooks(entries(items), command));
  }
});
test('inspection may expose untrusted hooks but execution preflight rejects them', () => {
  const items = hooks(); items[0].trustStatus = 'untrusted';
  assert.equal(checkHooks(entries(items), command, false).length, 4);
  assert.throws(() => checkHooks(entries(items), command), /Review this exact test hook/);
});
test('table overrides retain literal hook keys rather than splitting dotted paths', () => {
  assert.equal(toml({ '/a.b/hooks.json:session_start:0:0': { enabled: false } }), '{"/a.b/hooks.json:session_start:0:0"={"enabled"=false}}');
});

test('smoke filesystem profile preserves exact runtime and instruction exceptions', () => {
  const workspace = '/private/tmp/brain-w41-smoke.fixture/workspace';
  const brain = '/private/tmp/brain-w41-smoke.fixture/brain';
  const runtime = '/Users/brummerv/.codex/packages/standalone/releases/test/bin/codex';
  const instructions = ['/Users/brummerv/.codex/AGENTS.md'];
  const filesystem = smokeFilesystem(workspace, brain, runtime, instructions);

  assert.deepEqual(filesystem, {
    ':minimal': 'read',
    '/': 'read',
    [workspace]: 'write',
    [brain]: 'write',
    '/Users/brummerv/.claude': 'deny',
    '/Users/brummerv/.claude/**': 'deny',
    '/Users/brummerv/Downloads': 'deny',
    '/Users/brummerv/Downloads/**': 'deny',
    '/Users/brummerv/claude-otel': 'deny',
    '/Users/brummerv/claude-otel/**': 'deny',
    '/Users/brummerv/improvements': 'deny',
    '/Users/brummerv/improvements/**': 'deny',
    '/Users/brummerv/work': 'deny',
    '/Users/brummerv/work/**': 'deny',
    '/Users/brummerv/.anvil': 'deny',
    '/Users/brummerv/.anvil/**': 'deny',
    '/Users/brummerv/.anvil-brain': 'deny',
    '/Users/brummerv/.anvil-brain/**': 'deny',
    '/Users/brummerv/.codex': 'deny',
    [runtime]: 'read',
    [instructions[0]]: 'read',
  });
  assert.equal(filesystem['/Users/brummerv/.codex'], 'deny');
  assert.equal(filesystem['/Users/brummerv/.codex/**'], undefined);
  assert.equal(filesystem[runtime], 'read');
  assert.equal(filesystem[instructions[0]], 'read');
  assert.equal(filesystem['/Users/brummerv/.codex/packages'], undefined);
  assert.equal(filesystem['/Users/brummerv/.codex/auth.json'], undefined);
  assert.deepEqual(Object.entries(filesystem).filter(([, mode]) => mode === 'write').map(([path]) => path), [workspace, brain]);
});

test('Codex launcher resolves PATH symlinks before spawning', () => {
  const fixture = realpathSync(mkdtempSync(join(tmpdir(), 'brain-host-codex-')));
  const target = join(fixture, 'codex-real.mjs');
  const launcher = join(fixture, 'codex');
  writeFileSync(target, `#!${process.execPath}
process.stdout.write(JSON.stringify({ script: process.argv[1], args: process.argv.slice(2), cwd: process.cwd() }));
`, { mode: 0o755 });
  chmodSync(target, 0o755);
  symlinkSync(target, launcher);
  try {
    const child = spawnSync(process.execPath, ['--input-type=module', '-e', `
const { spawnCodex } = await import(process.env.SPAWN_CODEX_MODULE);
const processChild = spawnCodex(['--version'], { cwd: process.cwd(), stdio: ['ignore', 'pipe', 'pipe'] });
let output = '';
processChild.stdout.on('data', chunk => { output += chunk; });
processChild.stderr.on('data', chunk => { process.stderr.write(chunk); });
processChild.on('close', code => { if (code !== 0) process.exitCode = code ?? 1; else process.stdout.write(output); });
`], { cwd: fixture, env: { ...process.env, PATH: fixture, SPAWN_CODEX_MODULE: fileURLToPath(new URL('../scripts/brain-host-smoke.mjs', import.meta.url)) }, encoding: 'utf8' });
    assert.equal(child.status, 0, child.stderr);
    const result = JSON.parse(child.stdout);
    assert.equal(result.script, target);
    assert.notEqual(result.script, launcher);
    assert.deepEqual(result.args, ['--version']);
    assert.equal(result.cwd, fixture);
  } finally {
    rmSync(fixture, { recursive: true, force: true });
  }
});
