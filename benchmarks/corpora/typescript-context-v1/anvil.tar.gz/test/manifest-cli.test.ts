import assert from "node:assert/strict";
import { spawn, execFileSync } from "node:child_process";
import { mkdir, mkdtemp, readFile, realpath, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join, resolve } from "node:path";
import { afterEach, test } from "node:test";

import {
  createObjectiveFile,
  DEFAULT_MANIFEST_VIEW_PORT,
  validateObjective,
} from "../src/manifest/index.ts";

const roots: string[] = [];

const manifestLaunchers = [
  { name: "standalone manifest", command: [resolve("bin/manifest.ts")] },
  { name: "anvil manifest", command: [resolve("bin/anvil.ts"), "manifest"] },
] as const;

test("Manifest owns one explicit default loopback port", () => {
  assert.equal(DEFAULT_MANIFEST_VIEW_PORT, 27247);
  const help = execFileSync(process.execPath, [resolve("bin/manifest.ts"), "--help"], {
    encoding: "utf8",
  });
  assert.match(help, /dedicated loopback port \(27247\)/);
  const routedHelp = execFileSync(process.execPath, [resolve("bin/anvil.ts"), "manifest", "--help"], {
    encoding: "utf8",
  });
  assert.match(routedHelp, /dedicated loopback port \(27247\)/);
});

afterEach(async () => {
  await Promise.all(roots.splice(0).map((root) => rm(root, { recursive: true, force: true })));
});

test("manifest command resolves the surrounding Git repository and prints its live URL", async () => {
  const repository = await mkdtemp(join(tmpdir(), "manifest-cli-"));
  roots.push(repository);
  execFileSync("git", ["init", "-q"], { cwd: repository });
  const nested = join(repository, "src", "nested");
  await mkdir(nested, { recursive: true });
  const validated = validateObjective({
    id: "obj_11111111111111111111111111111111",
    title: "CLI Objective",
    outcome: "Vanilla manifest starts from the current repository.",
    details: "",
    phase: "planning",
    workstreams: [],
  });
  assert.equal(validated.valid, true);
  if (!validated.valid) return;
  await createObjectiveFile(repository, validated.graph);

  const packageJson = JSON.parse(await readFile(resolve("package.json"), "utf8"));
  assert.equal(packageJson.bin.manifest, "./bin/manifest.ts");
  const child = spawn(process.execPath, [resolve("bin/manifest.ts"), "--port", "0", "--json"], {
    cwd: nested,
    env: { ...process.env, MANIFEST_DISCOVERY_ROOT: repository },
    stdio: ["ignore", "pipe", "pipe"],
  });
  try {
    const line = await firstLine(child);
    const started = JSON.parse(line);
    assert.equal(started.repository, await realpath(repository));
    assert.match(started.url, /^http:\/\/127\.0\.0\.1:\d+$/);
    const response = await fetch(started.url);
    assert.equal(response.status, 200);
    assert.match(await response.text(), /data-testid="manifest-objectives-landing"/);
    const discovery = await fetch(new URL("/api/discovery", started.url));
    assert.equal(discovery.status, 200);
    assert.match(await discovery.text(), /CLI Objective/);
  } finally {
    const exited = await terminateChild(child);
    assert.equal(exited.code, 0);
    assert.equal(exited.signal, null);
  }
});

test("anvil manifest routes the nested Git repository to the Human view", async () => {
  const repository = await mkdtemp(join(tmpdir(), "manifest-anvil-cli-"));
  roots.push(repository);
  execFileSync("git", ["init", "-q"], { cwd: repository });
  const nested = join(repository, "packages", "app");
  await mkdir(nested, { recursive: true });
  const validated = validateObjective({
    id: "obj_22222222222222222222222222222222",
    title: "Routed Objective",
    outcome: "The anvil manifest command serves the repository graph.",
    details: "",
    phase: "planning",
    workstreams: [],
  });
  assert.equal(validated.valid, true);
  if (!validated.valid) return;
  await createObjectiveFile(repository, validated.graph);

  const child = spawn(process.execPath, [resolve("bin/anvil.ts"), "manifest", "--port", "0", "--json"], {
    cwd: nested,
    env: { ...process.env, MANIFEST_DISCOVERY_ROOT: repository },
    stdio: ["ignore", "pipe", "pipe"],
  });
  try {
    const line = await firstLine(child);
    const started = JSON.parse(line);
    assert.equal(started.repository, await realpath(repository));
    assert.match(started.url, /^http:\/\/127\.0\.0\.1:\d+$/);
    const response = await fetch(started.url);
    assert.equal(response.status, 200);
    assert.match(await response.text(), /data-testid="manifest-objectives-landing"/);
    const discovery = await fetch(new URL("/api/discovery", started.url));
    assert.equal(discovery.status, 200);
    assert.match(await discovery.text(), /Routed Objective/);
  } finally {
    const exited = await terminateChild(child);
    assert.equal(exited.code, 0);
    assert.equal(exited.signal, null);
  }
});

test("manifest objective-id emits the qualified canonical graph URL", async () => {
  const repository = await mkdtemp(join(tmpdir(), "manifest-cli-objective-"));
  roots.push(repository);
  execFileSync("git", ["init", "-q"], { cwd: repository });
  const objectiveId = "obj_33333333333333333333333333333333";
  const validated = validateObjective({
    id: objectiveId,
    title: "CLI Qualified Objective",
    outcome: "The CLI points at the selected graph.",
    details: "",
    phase: "planning",
    workstreams: [],
  });
  assert.equal(validated.valid, true);
  if (!validated.valid) return;
  await createObjectiveFile(repository, validated.graph);

  const child = spawn(process.execPath, [
    resolve("bin/manifest.ts"), "--objective-id", objectiveId, "--port", "0", "--json",
  ], {
    cwd: repository,
    stdio: ["ignore", "pipe", "pipe"],
  });
  try {
    const line = await firstLine(child);
    const started = JSON.parse(line);
    const url = new URL(started.url);
    assert.equal(url.pathname, `/objectives/${objectiveId}`);
    assert.equal(url.searchParams.get("repository"), await realpath(repository));
    const response = await fetch(url);
    assert.equal(response.status, 200);
    assert.match(await response.text(), /CLI Qualified Objective/);
  } finally {
    const exited = await terminateChild(child);
    assert.equal(exited.code, 0);
    assert.equal(exited.signal, null);
  }
});

test("standalone and anvil manifest honor explicit repository and Objective flags", async () => {
  const repository = await mkdtemp(join(tmpdir(), "manifest-cli-explicit-repository-"));
  const callerRepository = await mkdtemp(join(tmpdir(), "manifest-cli-explicit-caller-"));
  roots.push(repository, callerRepository);
  execFileSync("git", ["init", "-q"], { cwd: repository });
  execFileSync("git", ["init", "-q"], { cwd: callerRepository });
  const nested = join(callerRepository, "packages", "app");
  await mkdir(nested, { recursive: true });
  const objectiveId = "obj_44444444444444444444444444444444";
  const validated = validateObjective({
    id: objectiveId,
    title: "Explicit CLI Objective",
    outcome: "Both launchers honor explicit repository and Objective targeting.",
    details: "",
    phase: "planning",
    workstreams: [],
  });
  assert.equal(validated.valid, true);
  if (!validated.valid) return;
  const repositoryPath = await realpath(repository);
  await createObjectiveFile(repositoryPath, validated.graph);

  for (const launcher of manifestLaunchers) {
    for (const json of [false, true]) {
      const child = spawn(process.execPath, [
        ...launcher.command,
        "--repository", repositoryPath,
        "--objective-id", objectiveId,
        "--port", "0",
        ...(json ? ["--json"] : []),
      ], {
        cwd: nested,
        env: { ...process.env, MANIFEST_DISCOVERY_ROOT: callerRepository },
        stdio: ["ignore", "pipe", "pipe"],
      });
      try {
        const line = await firstLine(child);
        let outputUrl: string;
        if (json) {
          const started = JSON.parse(line);
          assert.equal(started.repository, repositoryPath, launcher.name);
          outputUrl = started.url;
        } else {
          assert.match(line, /^Manifest: http:\/\/127\.0\.0\.1:\d+\/objectives\//, launcher.name);
          outputUrl = line.replace(/^Manifest: /, "");
        }
        const url = new URL(outputUrl);
        assert.equal(url.pathname, `/objectives/${objectiveId}`, launcher.name);
        assert.equal(url.searchParams.get("repository"), repositoryPath, launcher.name);
        const response = await fetch(url);
        assert.equal(response.status, 200, launcher.name);
        assert.match(await response.text(), /Explicit CLI Objective/, launcher.name);
      } finally {
        const exited = await terminateChild(child);
        assert.equal(exited.code, 0, launcher.name);
        assert.equal(exited.signal, null, launcher.name);
      }
    }
  }
});

test("manifest launchers fail on an occupied requested port without replacing its listener", async () => {
  const repository = await mkdtemp(join(tmpdir(), "manifest-cli-port-collision-"));
  roots.push(repository);
  execFileSync("git", ["init", "-q"], { cwd: repository });
  const nested = join(repository, "src", "nested");
  await mkdir(nested, { recursive: true });
  const objectiveId = "obj_55555555555555555555555555555555";
  const validated = validateObjective({
    id: objectiveId,
    title: "Occupied Port Objective",
    outcome: "The requested listener remains the only listener.",
    details: "",
    phase: "planning",
    workstreams: [],
  });
  assert.equal(validated.valid, true);
  if (!validated.valid) return;
  const repositoryPath = await realpath(repository);
  await createObjectiveFile(repositoryPath, validated.graph);

  for (let index = 0; index < manifestLaunchers.length; index += 1) {
    const launcher = manifestLaunchers[index]!;
    const collisionLauncher = manifestLaunchers[(index + 1) % manifestLaunchers.length]!;
    const child = spawn(process.execPath, [
      ...launcher.command,
      "--repository", repositoryPath,
      "--objective-id", objectiveId,
      "--port", "0",
      "--json",
    ], {
      cwd: nested,
      stdio: ["ignore", "pipe", "pipe"],
    });
    try {
      const started = JSON.parse(await firstLine(child));
      const startedUrl = new URL(started.url);
      const occupiedPort = Number(startedUrl.port);
      assert.ok(occupiedPort > 0, launcher.name);

      const collision = spawn(process.execPath, [
        ...collisionLauncher.command,
        "--repository", repositoryPath,
        "--objective-id", objectiveId,
        "--port", String(occupiedPort),
        "--json",
      ], {
        cwd: nested,
        stdio: ["ignore", "pipe", "pipe"],
      });
      const result = await waitForExit(collision);
      assert.equal(result.code, 1, `${collisionLauncher.name} collision`);
      assert.equal(result.signal, null, `${collisionLauncher.name} collision`);
      assert.equal(result.stdout.trim(), "", `${collisionLauncher.name} collision`);
      assert.match(result.stderr, /EADDRINUSE|address already in use/i, `${collisionLauncher.name} collision`);

      const response = await fetch(startedUrl);
      assert.equal(response.status, 200, launcher.name);
      assert.match(await response.text(), /Occupied Port Objective/, launcher.name);
    } finally {
      const exited = await terminateChild(child);
      assert.equal(exited.code, 0, launcher.name);
      assert.equal(exited.signal, null, launcher.name);
    }
  }
});

function firstLine(child: ReturnType<typeof spawn>): Promise<string> {
  const stream = child.stdout!;
  return new Promise((resolvePromise, reject) => {
    let buffered = "";
    const timeout = setTimeout(() => {
      cleanup();
      reject(new Error("Timed out waiting for Manifest CLI startup output."));
    }, 5_000);
    const cleanup = () => {
      clearTimeout(timeout);
      stream.off("data", onData);
      stream.off("error", onError);
      child.off("exit", onExit);
    };
    const onData = (chunk: string) => {
      buffered += chunk;
      const newline = buffered.indexOf("\n");
      if (newline !== -1) {
        cleanup();
        resolvePromise(buffered.slice(0, newline));
      }
    };
    const onError = (error: Error) => {
      cleanup();
      reject(error);
    };
    const onExit = (code: number | null, signal: NodeJS.Signals | null) => {
      cleanup();
      reject(new Error(`Manifest CLI exited before startup output (code=${code}, signal=${signal}).`));
    };
    stream.setEncoding("utf8");
    stream.on("data", onData);
    stream.on("error", onError);
    child.on("exit", onExit);
    if (child.exitCode !== null || child.signalCode !== null) {
      onExit(child.exitCode, child.signalCode);
    }
  });
}

function waitForExit(child: ReturnType<typeof spawn>): Promise<{
  code: number | null;
  signal: NodeJS.Signals | null;
  stdout: string;
  stderr: string;
}> {
  return new Promise((resolvePromise, reject) => {
    let timeout: ReturnType<typeof setTimeout> | undefined;
    let stdout = "";
    let stderr = "";
    const cleanup = () => {
      if (timeout !== undefined) clearTimeout(timeout);
      child.stdout?.off("data", onStdout);
      child.stderr?.off("data", onStderr);
      child.off("exit", onExit);
      child.off("error", onError);
    };
    const onStdout = (chunk: string) => {
      stdout += chunk;
    };
    const onStderr = (chunk: string) => {
      stderr += chunk;
    };
    const onExit = (code: number | null, signal: NodeJS.Signals | null) => {
      cleanup();
      resolvePromise({ code, signal, stdout, stderr });
    };
    const onError = (error: Error) => {
      cleanup();
      reject(error);
    };
    child.stdout?.setEncoding("utf8");
    child.stderr?.setEncoding("utf8");
    child.stdout?.on("data", onStdout);
    child.stderr?.on("data", onStderr);
    child.once("exit", onExit);
    child.once("error", onError);
    timeout = setTimeout(() => {
      child.kill("SIGKILL");
      cleanup();
      reject(new Error("Timed out waiting for Manifest CLI collision process to exit."));
    }, 5_000);
    if (child.exitCode !== null || child.signalCode !== null) {
      onExit(child.exitCode, child.signalCode);
    }
  });
}

function terminateChild(child: ReturnType<typeof spawn>): Promise<{
  code: number | null;
  signal: NodeJS.Signals | null;
}> {
  return new Promise((resolvePromise, reject) => {
    let timeout: ReturnType<typeof setTimeout> | undefined;
    const cleanup = () => {
      if (timeout !== undefined) clearTimeout(timeout);
      child.off("exit", onExit);
      child.off("error", onError);
    };
    const onExit = (code: number | null, signal: NodeJS.Signals | null) => {
      cleanup();
      resolvePromise({ code, signal });
    };
    const onError = (error: Error) => {
      cleanup();
      reject(error);
    };
    child.once("exit", onExit);
    child.once("error", onError);
    timeout = setTimeout(() => {
      child.kill("SIGKILL");
      cleanup();
      reject(new Error("Timed out waiting for Manifest CLI to exit after SIGTERM."));
    }, 5_000);
    if (child.exitCode !== null || child.signalCode !== null) {
      onExit(child.exitCode, child.signalCode);
      return;
    }
    child.kill("SIGTERM");
  });
}
