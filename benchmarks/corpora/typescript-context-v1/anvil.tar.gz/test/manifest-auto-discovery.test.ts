import assert from "node:assert/strict";
import { cp, mkdir, mkdtemp, readFile, realpath, rm, symlink, writeFile } from "node:fs/promises";
import { execFileSync } from "node:child_process";
import { tmpdir } from "node:os";
import { basename, dirname, join } from "node:path";
import { afterEach, test } from "node:test";

import {
  createObjectiveFile,
  discoverObjectives,
  ManifestFileError,
  startManifestViewServer,
  validateObjective,
} from "../src/manifest/index.ts";

const roots: string[] = [];

afterEach(async () => {
  await Promise.all(roots.splice(0).map((root) => rm(root, { recursive: true, force: true })));
});

const BASE_OBJECTIVE_ID = "obj_11111111111111111111111111111111";
const BASE_WORKSTREAM_ID = "ws_22222222222222222222222222222222";
const BASE_TASK_ID = "task_33333333333333333333333333333333";
const NESTED_OBJECTIVE_ID = "obj_44444444444444444444444444444444";
const NEW_OBJECTIVE_ID = "obj_55555555555555555555555555555555";
const MALFORMED_OBJECTIVE_ID = "obj_66666666666666666666666666666666";
const DISAPPEARING_OBJECTIVE_ID = "obj_77777777777777777777777777777777";

const excludedDirectories = [
  "node_modules",
  ".cache",
  "dist",
  "target",
] as const;

type DiscoveryObjective = {
  valid: boolean;
  path: string;
  objective?: { id: string; title: string; outcome: string; phase: string };
  problems?: readonly { path: string; message: string }[];
};

type DiscoveryBody = {
  root: string;
  roots?: readonly string[];
  repositories: readonly { repository: string; objectives: readonly DiscoveryObjective[] }[];
  problems: readonly { path: string; message: string }[];
};

async function gitRepositoryAt(path: string): Promise<string> {
  await mkdir(path, { recursive: true });
  execFileSync("git", ["init", "-q"], { cwd: path });
  return path;
}

async function projectDirectory(prefix: string): Promise<string> {
  const root = await mkdtemp(join(tmpdir(), prefix));
  roots.push(root);
  return root;
}

function objective(title: string, id = BASE_OBJECTIVE_ID) {
  const result = validateObjective({
    id,
    title,
    outcome: "The repository owns the Objective graph.",
    details: "Automatic discovery test fixture.",
    phase: "planning",
    workstreams: [{
      id: BASE_WORKSTREAM_ID,
      title: "Repository discovery",
      outcome: "The current repository is visible.",
      details: "",
      tasks: [{
        id: BASE_TASK_ID,
        title: "Discover Objective files",
        outcome: "The Objective is returned by the discovery endpoint.",
        details: "",
        completionCriteria: ["The discovery endpoint returns this Objective."],
        dependencies: [],
        externalBlocker: null,
        completion: null,
        discontinued: null,
      }],
    }],
  });
  assert.equal(result.valid, true);
  if (!result.valid) throw new Error("Automatic discovery fixture must be valid.");
  return result.graph;
}

function objectivePath(repository: string, id = BASE_OBJECTIVE_ID): string {
  return join(repository, ".manifest", "objectives", `${id}.json`);
}

async function getDiscovery(serverUrl: string): Promise<{ status: number; body: DiscoveryBody }> {
  const response = await fetch(`${serverUrl}/api/discovery`);
  return { status: response.status, body: await response.json() as DiscoveryBody };
}

function repositoryMap(body: DiscoveryBody): Map<string, readonly DiscoveryObjective[]> {
  return new Map(body.repositories.map((entry) => [entry.repository, entry.objectives]));
}

test("automatic discovery scans nested repositories, coalesces aliases, and rescans after startup", async () => {
  const project = await projectDirectory("manifest-auto-project-");
  const startupRepository = await gitRepositoryAt(join(project, "projects", "original"));
  await createObjectiveFile(startupRepository, objective("Original title"));

  const copiedRepository = join(project, "projects", "copied");
  await cp(startupRepository, copiedRepository, { recursive: true });
  const copiedBytesPath = objectivePath(copiedRepository);
  const copiedGraph = JSON.parse(await readFile(copiedBytesPath, "utf8")) as Record<string, unknown>;
  copiedGraph.title = "Copied title";
  await writeFile(copiedBytesPath, `${JSON.stringify(copiedGraph, null, 2)}\n`, "utf8");

  const nestedRepository = await gitRepositoryAt(join(startupRepository, "nested", "project"));
  await createObjectiveFile(nestedRepository, objective("Nested title", NESTED_OBJECTIVE_ID));
  await symlink(startupRepository, join(project, "projects", "original-alias"), "dir");

  const discoveryRootAlias = join(dirname(project), `${basename(project)}-alias`);
  await symlink(project, discoveryRootAlias, "dir");
  roots.push(discoveryRootAlias);
  const canonicalProject = await realpath(project);
  const canonicalStartup = await realpath(startupRepository);
  const canonicalCopied = await realpath(copiedRepository);
  const canonicalNested = await realpath(nestedRepository);
  const graphPaths = [objectivePath(startupRepository), copiedBytesPath, objectivePath(nestedRepository, NESTED_OBJECTIVE_ID)];
  const graphBytesBefore = new Map<string, string>();
  for (const path of graphPaths) graphBytesBefore.set(path, await readFile(path, "utf8"));

  const server = await startManifestViewServer({
    repository: startupRepository,
    discoveryRoot: discoveryRootAlias,
    port: 0,
  });
  try {
    const initial = await getDiscovery(server.url);
    assert.equal(initial.status, 200);
    assert.equal(initial.body.root, canonicalProject);
    assert.deepEqual(initial.body.problems, []);
    assert.deepEqual([...repositoryMap(initial.body).keys()].sort(), [canonicalCopied, canonicalNested, canonicalStartup].sort());

    const initialRepositories = repositoryMap(initial.body);
    const original = initialRepositories.get(canonicalStartup);
    const copied = initialRepositories.get(canonicalCopied);
    assert.ok(original);
    assert.ok(copied);
    assert.deepEqual(original.map((entry) => entry.objective?.id), [BASE_OBJECTIVE_ID]);
    assert.deepEqual(copied.map((entry) => entry.objective?.id), [BASE_OBJECTIVE_ID]);
    assert.deepEqual(original.map((entry) => entry.objective?.title), ["Original title"]);
    assert.deepEqual(copied.map((entry) => entry.objective?.title), ["Copied title"]);
    assert.equal(initial.body.repositories.filter((entry) => entry.repository === canonicalStartup).length, 1);
    assert.deepEqual(repositoryMap(initial.body).get(canonicalNested)?.map((entry) => entry.objective?.title), ["Nested title"]);

    const newRepository = await gitRepositoryAt(join(project, "projects", "new-b"));
    const afterRepository = await getDiscovery(server.url);
    assert.equal(afterRepository.status, 200);
    assert.equal(repositoryMap(afterRepository.body).has(await realpath(newRepository)), false);

    await createObjectiveFile(newRepository, objective("Post-startup title", NEW_OBJECTIVE_ID));
    const afterObjective = await getDiscovery(server.url);
    assert.equal(afterObjective.status, 200);
    assert.deepEqual(repositoryMap(afterObjective.body).get(await realpath(newRepository))?.map((entry) => entry.objective?.title), ["Post-startup title"]);
    assert.equal(afterObjective.body.repositories.filter((entry) => entry.repository === canonicalStartup).length, 1);
  } finally {
    await server.close();
  }

  for (const [path, bytes] of graphBytesBefore) assert.equal(await readFile(path, "utf8"), bytes, path);
});

test("automatic discovery preserves malformed Objective problems and reports unsafe storage beside healthy repositories", async () => {
  const project = await projectDirectory("manifest-auto-errors-");
  const healthyRepository = await gitRepositoryAt(join(project, "healthy"));
  await createObjectiveFile(healthyRepository, objective("Healthy repository"));

  const malformedRepository = await gitRepositoryAt(join(project, "malformed"));
  await createObjectiveFile(malformedRepository, objective("Malformed repository"));
  const malformedPath = objectivePath(malformedRepository, "obj_99999999999999999999999999999999");
  const canonicalMalformedPath = objectivePath(await realpath(malformedRepository), "obj_99999999999999999999999999999999");
  const malformedBytes = "{ invalid";
  await writeFile(malformedPath, malformedBytes, "utf8");
  const expectedMalformedObjectives = await discoverObjectives(malformedRepository);

  const outside = await projectDirectory("manifest-auto-outside-");
  const outsideObjectives = join(outside, ".manifest", "objectives");
  await mkdir(outsideObjectives, { recursive: true });
  const outsidePath = join(outsideObjectives, `${BASE_OBJECTIVE_ID}.json`);
  const outsideBytes = `${JSON.stringify(objective("OUTSIDE-STORAGE-SENTINEL"), null, 2)}\n`;
  await writeFile(outsidePath, outsideBytes, "utf8");

  const unsafeRepository = await gitRepositoryAt(join(project, "unsafe"));
  await mkdir(join(unsafeRepository, ".manifest"));
  const unsafeObjectives = join(unsafeRepository, ".manifest", "objectives");
  await symlink(outsideObjectives, unsafeObjectives, "dir");
  let expectedUnsafeProblem: { path: string; message: string } | undefined;
  await assert.rejects(discoverObjectives(unsafeRepository), (error: unknown) => {
    assert.ok(error instanceof ManifestFileError);
    expectedUnsafeProblem = { path: error.path, message: error.message };
    return true;
  });
  assert.ok(expectedUnsafeProblem);
  assert.equal(expectedUnsafeProblem.path, join(await realpath(unsafeRepository), ".manifest", "objectives"));

  const graphPaths = [objectivePath(healthyRepository), objectivePath(malformedRepository), malformedPath, outsidePath];
  const graphBytesBefore = new Map<string, string>();
  for (const path of graphPaths) graphBytesBefore.set(path, await readFile(path, "utf8"));
  const server = await startManifestViewServer({ repository: healthyRepository, discoveryRoot: project, port: 0 });
  try {
    const result = await getDiscovery(server.url);
    assert.equal(result.status, 200);
    assert.equal(result.body.root, await realpath(project));
    const repositories = repositoryMap(result.body);
    assert.deepEqual(repositories.get(await realpath(healthyRepository))?.map((entry) => entry.objective?.title), ["Healthy repository"]);
    assert.deepEqual(repositories.get(await realpath(malformedRepository)), expectedMalformedObjectives);
    const malformed = repositories.get(await realpath(malformedRepository))?.find((entry) => !entry.valid);
    assert.ok(malformed);
    assert.equal(malformed.path, canonicalMalformedPath);
    assert.match(malformed.problems?.[0]?.message ?? "", /Malformed JSON/);
    assert.equal(repositories.has(await realpath(unsafeRepository)), false);
    assert.deepEqual(result.body.problems, [expectedUnsafeProblem]);
    assert.equal(JSON.stringify(result.body).includes("OUTSIDE-STORAGE-SENTINEL"), false);
  } finally {
    await server.close();
  }

  for (const [path, bytes] of graphBytesBefore) assert.equal(await readFile(path, "utf8"), bytes, path);
});

test("automatic discovery excludes generated trees and does not follow outside repository links", async () => {
  const project = await projectDirectory("manifest-auto-boundary-");
  const visibleRepository = await gitRepositoryAt(join(project, "visible"));
  await createObjectiveFile(visibleRepository, objective("VISIBLE-REPOSITORY"));

  for (const directory of excludedDirectories) {
    const excludedRepository = await gitRepositoryAt(join(project, directory, "sentinel"));
    await createObjectiveFile(excludedRepository, objective(`EXCLUDED-${directory}`));
  }
  await symlink(join(project, "node_modules", "sentinel"), join(project, "alias-to-excluded"), "dir");

  const outside = await projectDirectory("manifest-auto-outside-repository-");
  const outsideRepository = await gitRepositoryAt(join(outside, "outside"));
  await createObjectiveFile(outsideRepository, objective("OUTSIDE-REPOSITORY-SENTINEL"));
  await symlink(outsideRepository, join(project, "outside-link"), "dir");

  const server = await startManifestViewServer({ repository: visibleRepository, discoveryRoot: project, port: 0 });
  try {
    const result = await getDiscovery(server.url);
    assert.equal(result.status, 200);
    const titles = result.body.repositories.flatMap((entry) => entry.objectives
      .filter((objectiveEntry) => objectiveEntry.valid)
      .map((objectiveEntry) => objectiveEntry.objective?.title));
    assert.deepEqual(titles, ["VISIBLE-REPOSITORY"]);
    assert.equal(JSON.stringify(result.body).includes("OUTSIDE-REPOSITORY-SENTINEL"), false);
    assert.equal(JSON.stringify(result.body).includes("EXCLUDED-"), false);
    assert.equal(result.body.problems.some((problem) => problem.path.includes("outside")), false);
  } finally {
    await server.close();
  }
});

test("automatic discovery reports a configured root after it disappears", async () => {
  const container = await projectDirectory("manifest-auto-disappearing-");
  const project = join(container, "workspace");
  const startupRepository = await gitRepositoryAt(join(project, "startup"));
  await createObjectiveFile(startupRepository, objective("Before disappearance"));
  const discoveryRootAlias = join(container, "workspace-alias");
  await symlink(project, discoveryRootAlias, "dir");
  const canonicalProject = await realpath(project);

  const server = await startManifestViewServer({ repository: startupRepository, discoveryRoot: discoveryRootAlias, port: 0 });
  try {
    const before = await getDiscovery(server.url);
    assert.equal(before.status, 200);
    assert.equal(before.body.root, canonicalProject);
    assert.equal(before.body.problems.length, 0);

    await rm(project, { recursive: true, force: true });
    const after = await getDiscovery(server.url);
    assert.equal(after.status, 200);
    assert.deepEqual(after.body.repositories, []);
    assert.equal(after.body.problems.length, 1);
    assert.equal(after.body.problems[0]?.path, canonicalProject);
    assert.equal(typeof after.body.problems[0]?.message, "string");
    assert.notEqual(after.body.problems[0]?.message, "");
  } finally {
    await server.close();
  }
});

test("automatic discovery unions canonical roots, retains healthy results across failures, and rescans added roots", async () => {
  const primaryRoot = await projectDirectory("manifest-auto-union-primary-");
  const primaryRepository = await gitRepositoryAt(join(primaryRoot, "primary"));
  await createObjectiveFile(primaryRepository, objective("Primary repository"));
  const nestedRepository = await gitRepositoryAt(join(primaryRepository, "nested", "project"));
  await createObjectiveFile(nestedRepository, objective("Nested repository", NESTED_OBJECTIVE_ID));

  const primaryAlias = join(dirname(primaryRoot), `${basename(primaryRoot)}-alias`);
  await symlink(primaryRoot, primaryAlias, "dir");
  roots.push(primaryAlias);

  const outside = await projectDirectory("manifest-auto-union-outside-");
  const outsideRepository = await gitRepositoryAt(join(outside, "outside"));
  await createObjectiveFile(outsideRepository, objective("OUTSIDE-UNION-SENTINEL"));
  await symlink(outsideRepository, join(primaryRoot, "outside-link"), "dir");

  const additionalRoot = await projectDirectory("manifest-auto-union-additional-");
  const additionalRepository = await gitRepositoryAt(join(additionalRoot, "additional"));
  await createObjectiveFile(additionalRepository, objective("Additional repository"));
  const additionalAlias = join(dirname(additionalRoot), `${basename(additionalRoot)}-alias`);
  await symlink(additionalRoot, additionalAlias, "dir");
  roots.push(additionalAlias);

  const malformedRepository = await gitRepositoryAt(join(additionalRoot, "malformed"));
  await createObjectiveFile(malformedRepository, objective("Malformed repository", MALFORMED_OBJECTIVE_ID));
  await writeFile(objectivePath(malformedRepository, MALFORMED_OBJECTIVE_ID), "{ invalid", "utf8");

  const disappearingRoot = await projectDirectory("manifest-auto-union-disappearing-");
  const disappearingRepository = await gitRepositoryAt(join(disappearingRoot, "disappearing"));
  await createObjectiveFile(disappearingRepository, objective("Disappearing repository", DISAPPEARING_OBJECTIVE_ID));

  const canonicalPrimaryRoot = await realpath(primaryRoot);
  const canonicalPrimaryRepository = await realpath(primaryRepository);
  const canonicalNestedRepository = await realpath(nestedRepository);
  const canonicalAdditionalRoot = await realpath(additionalRoot);
  const canonicalDisappearingRoot = await realpath(disappearingRoot);
  const canonicalAdditionalRepository = await realpath(additionalRepository);
  const canonicalMalformedRepository = await realpath(malformedRepository);
  const canonicalDisappearingRepository = await realpath(disappearingRepository);

  const server = await startManifestViewServer({
    repository: primaryRepository,
    discoveryRoot: primaryAlias,
    additionalDiscoveryRoots: [
      primaryRoot,
      primaryRepository,
      additionalRoot,
      additionalAlias,
      disappearingRoot,
    ],
    port: 0,
  });
  try {
    const initial = await getDiscovery(server.url);
    assert.equal(initial.status, 200);
    assert.equal(initial.body.root, canonicalPrimaryRoot);
    assert.deepEqual(initial.body.roots, [
      canonicalPrimaryRoot,
      canonicalPrimaryRepository,
      canonicalAdditionalRoot,
      canonicalDisappearingRoot,
    ]);
    const initialRepositories = repositoryMap(initial.body);
    assert.deepEqual([...initialRepositories.keys()].sort(), [
      canonicalAdditionalRepository,
      canonicalDisappearingRepository,
      canonicalMalformedRepository,
      canonicalNestedRepository,
      canonicalPrimaryRepository,
    ].sort());
    assert.equal(initial.body.repositories.filter((entry) => entry.repository === canonicalPrimaryRepository).length, 1);
    assert.equal(initial.body.repositories.filter((entry) => entry.repository === canonicalAdditionalRepository).length, 1);
    assert.deepEqual(initialRepositories.get(canonicalAdditionalRepository)?.map((entry) => entry.objective?.title), ["Additional repository"]);
    assert.deepEqual(initialRepositories.get(canonicalDisappearingRepository)?.map((entry) => entry.objective?.title), ["Disappearing repository"]);
    const malformed = initialRepositories.get(canonicalMalformedRepository)?.find((entry) => !entry.valid);
    assert.ok(malformed);
    assert.match(malformed.problems?.[0]?.message ?? "", /Malformed JSON/);
    assert.equal(JSON.stringify(initial.body).includes("OUTSIDE-UNION-SENTINEL"), false);

    await rm(disappearingRoot, { recursive: true, force: true });
    await createObjectiveFile(additionalRepository, objective("Post-startup additional repository", NEW_OBJECTIVE_ID));
    const after = await getDiscovery(server.url);
    assert.equal(after.status, 200);
    const afterRepositories = repositoryMap(after.body);
    assert.deepEqual(afterRepositories.get(canonicalAdditionalRepository)?.map((entry) => entry.objective?.title), [
      "Additional repository",
      "Post-startup additional repository",
    ]);
    assert.equal(afterRepositories.has(canonicalDisappearingRepository), false);
    assert.ok(after.body.problems.some((problem) => problem.path === canonicalDisappearingRoot));
    assert.deepEqual(afterRepositories.get(canonicalPrimaryRepository)?.map((entry) => entry.objective?.title), ["Primary repository"]);
    assert.equal(JSON.stringify(after.body).includes("OUTSIDE-UNION-SENTINEL"), false);
  } finally {
    await server.close();
  }
});
