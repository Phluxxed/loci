import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, readdirSync, rmSync } from 'node:fs';
import { join } from 'node:path';
import { turnsFor, run, readinessFiles, recallPreflight } from '../scripts/brain-w4-followup-run.mjs';
import { base } from '../scripts/brain-w4-followup-prepare.mjs';

test('seal requires isolated indexes and unchanged dependency fingerprints', () => {
  const indexes = { modelRuns: 0, indexSetupPassed: true, cases: ['c01'].map(name => ({
    name, workspace: base + '/execution/' + name + '/workspace', lociBaseDir: base + '/execution/' + name + '/loci',
    namespace: 'codex-w4-followup-' + name, graphStatus: 'healthy', verification: { failed: [] },
  })) };
  const dependency = { modelRuns: 0, passed: true, files: { '/test/dependency': 'a'.repeat(64) } };
  assert.deepEqual(readinessFiles(indexes, dependency, () => 'a'.repeat(64)), dependency.files);
  assert.throws(() => readinessFiles(indexes, dependency, () => 'b'.repeat(64)), /Dependency changed/);
  assert.throws(() => readinessFiles(indexes, { ...dependency, passed: false }));
  assert.throws(() => readinessFiles(indexes, { ...dependency, files: {} }), /Missing dependency/);
  assert.throws(() => readinessFiles({ ...indexes, indexSetupPassed: false }, dependency));
  assert.throws(() => readinessFiles({ ...indexes, cases: indexes.cases.slice(1) }, dependency));
});

test('fresh-only turns expose prompts and bounded budgets, never answer keys', () => {
  const cases = ['c01'].map(name => ({ name, prompt: 'Question ' + name, expectations: ['private key'] }));
  const turns = turnsFor(cases);
  assert.deepEqual(turns, cases.map(c => ({ name: c.name, prompt: c.prompt, timeoutMs: 3_600_000, idleTimeoutMs: 600_000 })));
  assert(!JSON.stringify(turns).includes('private key'));
  const runnerSource = readFileSync(new URL('../scripts/brain-w4-followup-run.mjs', import.meta.url), 'utf8');
  assert.match(runnerSource, /captureProcess\(runtime, args, \{ input: turn\.prompt, directory,\s+timeoutMs: turn\.timeoutMs, idleTimeoutMs: turn\.idleTimeoutMs \}\)/);
  assert.throws(() => turnsFor([{ name: 'p01', prompt: 'Question p01', expectations: ['private key'] }]));
  assert.throws(() => turnsFor(cases.map(c => ({ ...c, prompt: '' }))));
});

test('run refuses absent approval before reading files or launching anything', async () => {
  await assert.rejects(run(), /Separate explicit Vik approval/);
  await assert.rejects(run(false), /Separate explicit Vik approval/);
});

const preflightSettings = { name: 'c01', workspace: '/isolated/workspace', sourceRoot: '/pinned/anvil', env: {
  ANVIL_HOME: '/isolated/anvil-home', LLM_WIKI_HOME: '/isolated/registry', ANVIL_LLM_WIKI_BIN: '/pinned/compiler.py',
  ANVIL_STATE_ROOT: '/isolated/state', LOCI_BASE_DIR: '/isolated/loci', LOCI_STORE_NAMESPACE: 'case-c01',
  LLM_WIKI_GRAPH_CACHE_DIR: '/isolated/graph-cache',
} };
const envelopeFixture = () => ({
  startup: { status: 'ready', receipt: { snapshotDigest: 'a'.repeat(64) } },
  recall: { status: 'ready', markdown: '## Brain Context\n\nTask evidence', diagnostics: [], receipt: {
    snapshotDigest: 'a'.repeat(64), compilerBudget: { items: 1 },
    selectedEvidence: [{ id: 'loci:rule.md::Rule#section', provider: 'loci', route: 'indexed_section', byteCost: 13 }], compilerDiagnostics: [],
  } },
});

test('recall preflight checks the pinned context service with the real prompt in disposable state', t => {
  const report = recallPreflight(preflightSettings, 'The exact policy question', (command, args, options) => {
    assert.equal(command, process.execPath);
    assert.deepEqual(args.slice(0, 2), ['--input-type=module', '-e']);
    assert.match(args[2], /src\/brain-context\/harness.ts/);
    assert.match(args[2], /lifecycle: 'session_start'/);
    assert.match(args[2], /lifecycle: 'prompt'/);
    assert(!args[2].includes('context-hook'));
    assert.deepEqual(JSON.parse(options.input), { sourceRoot: '/pinned/anvil', cwd: '/isolated/workspace', prompt: 'The exact policy question' });
    for (const key of ['ANVIL_STATE_ROOT', 'LOCI_BASE_DIR', 'LLM_WIKI_GRAPH_CACHE_DIR']) {
      assert.notEqual(options.env[key], preflightSettings.env[key]);
      assert.match(options.env[key], /brain-recall-preflight-/);
      assert.deepEqual(readdirSync(options.env[key]), [], key + ' must start empty');
    }
    assert.equal(options.env.ANVIL_HOME, preflightSettings.env.ANVIL_HOME);
    assert.equal(options.env.ANVIL_LLM_WIKI_BIN, preflightSettings.env.ANVIL_LLM_WIKI_BIN);
    assert.equal(options.env.PYTHONDONTWRITEBYTECODE, '1');
    assert.equal(options.timeout, 30000);
    return { status: 0, signal: null, stdout: JSON.stringify(envelopeFixture()), stderr: '' };
  });
  t.after(() => rmSync(report.directory, { recursive: true, force: true }));
  assert.equal(report.passed, true);
  assert.equal(report.modelRuns, 0);
  assert.equal(Object.keys(report.files).length, 3);
  assert.equal(JSON.parse(readFileSync(join(report.directory, 'result.json'), 'utf8')).passed, true);
});

test('recall preflight rejects diagnostic-only, kernel-only, malformed and timed-out results', t => {
  const cases = [
    { status: null, signal: 'SIGTERM', error: new Error('timeout'), stdout: '', stderr: '' },
    { status: 0, signal: null, stdout: 'not json', stderr: '' },
    ...[
      e => { e.startup.status = 'degraded'; },
      e => { e.recall.status = 'empty'; },
      e => { e.recall.receipt.compilerBudget = null; },
      e => { e.recall.receipt.selectedEvidence = [{ id: 'kernel:0:identity', byteCost: 30 }]; },
      e => { e.recall.receipt.snapshotDigest = 'b'.repeat(64); },
      e => { e.recall.markdown += '\n## Brain Recall Diagnostic\nBRAIN_SELECTED_PATH_UNSAFE'; },
    ].map(change => { const e = envelopeFixture(); change(e); return { status: 0, signal: null, stdout: JSON.stringify(e), stderr: '' }; }),
  ];
  for (const output of cases) {
    const report = recallPreflight(preflightSettings, 'Question', () => output);
    t.after(() => rmSync(report.directory, { recursive: true, force: true }));
    assert.equal(report.passed, false);
    assert.equal(report.errors.length, 1);
    assert.deepEqual(JSON.parse(readFileSync(join(report.directory, 'capture.json'), 'utf8')).stdout, output.stdout);
  }
});

test('recall preflight rejects other-provider evidence even with a safely serialized missing-index warning', t => {
  const e = envelopeFixture();
  e.recall.status = 'partial';
  e.recall.receipt.selectedEvidence = [
    { id: 'text:rule', provider: 'text', route: 'lexical_section', byteCost: 13 },
    { id: 'frontmatter:rule', provider: 'frontmatter', route: 'tag_match', byteCost: 13 },
    { id: 'temporal:rule', provider: 'temporal', route: 'temporal_current', byteCost: 13 },
    { id: 'graph:loci:rule', provider: 'graph', route: 'path_node_section', byteCost: 13 },
    { id: 'graph:loci:path', provider: 'graph', route: 'evidence_backed_path', byteCost: 13 },
  ];
  for (const diagnostics of [[], [{ code: 'LOCI_REPO_NOT_INDEXED', provider: 'loci', details: { type: 'LociGatewayError' } }]]) {
    e.recall.receipt.compilerDiagnostics = diagnostics;
    const report = recallPreflight(preflightSettings, 'Question', () => ({ status: 0, signal: null, stdout: JSON.stringify(e), stderr: '' }));
    t.after(() => rmSync(report.directory, { recursive: true, force: true }));
    assert.equal(report.passed, false);
    assert.match(report.errors[0], /no delivered Loci indexed-section evidence/);
    assert.deepEqual(report.compilerDiagnostics, diagnostics);
  }
});

test('Loci delivery requires both section provenance and positive delivered bytes, not an evidence ID', t => {
  for (const change of [
    item => { delete item.provider; },
    item => { item.provider = 'graph'; },
    item => { delete item.route; },
    item => { item.route = 'path_node_section'; },
    item => { item.byteCost = 0; },
  ]) {
    const e = envelopeFixture();
    change(e.recall.receipt.selectedEvidence[0]);
    e.recall.receipt.selectedEvidence.push({ id: 'text:rule', provider: 'text', route: 'lexical_section', byteCost: 13 });
    const report = recallPreflight(preflightSettings, 'Question', () => ({ status: 0, signal: null, stdout: JSON.stringify(e), stderr: '' }));
    t.after(() => rmSync(report.directory, { recursive: true, force: true }));
    assert.equal(report.passed, false);
    assert.match(report.errors[0], /no delivered Loci indexed-section evidence/);
  }
});

test('delivered Loci sections permit unrelated warnings without becoming an answer-sufficiency gate', t => {
  const e = envelopeFixture();
  e.recall.status = 'partial';
  e.recall.receipt.compilerDiagnostics = [{ code: 'TEMPORAL_STATE_UNCERTAIN', provider: 'temporal', details: {} }];
  e.recall.receipt.stop = { sufficient: false };
  const report = recallPreflight(preflightSettings, 'Question', () => ({ status: 0, signal: null, stdout: JSON.stringify(e), stderr: 'retrieval warning' }));
  t.after(() => rmSync(report.directory, { recursive: true, force: true }));
  assert.equal(report.passed, true);
  assert.equal(report.compilerDiagnostics[0].code, 'TEMPORAL_STATE_UNCERTAIN');
});
