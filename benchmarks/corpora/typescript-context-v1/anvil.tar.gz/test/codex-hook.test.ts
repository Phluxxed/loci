import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import { existsSync } from "node:fs";
import { cp, mkdir, mkdtemp, realpath, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { dirname, join, resolve } from "node:path";
import { test } from "node:test";
import { fileURLToPath } from "node:url";

import { Client } from "@modelcontextprotocol/client";
import { StdioClientTransport } from "@modelcontextprotocol/client/stdio";
import { checkpointActiveTask, deriveContinuityPaths, gitWorkspaceRef, initWorkspace } from "../src/continuity/index.ts";
import type { CurrentFrameInput } from "../src/continuity/index.ts";
import { readBrainUsage, recordBrainUsage } from "../src/brain-usage/index.ts";
import {
  bindWorkContext,
  bindingIdForSession,
  requireWorkContextBinding,
  supersedeWorkContextBinding,
} from "../src/work-context/index.ts";

const anvilBin = resolve("bin/anvil.ts");
const brainFixtures = fileURLToPath(new URL("./fixtures/brain-context/", import.meta.url));
const fakeLlmWiki = join(brainFixtures, "fake-llm-wiki.mjs");
const realLlmWiki = process.env.ANVIL_REAL_LLM_WIKI_BIN ??
  fileURLToPath(new URL("../../../llm-wiki/.venv/bin/llm-wiki", import.meta.url));
const agentSkillsInvariant =
  "For engineering-adjacent work, use `agent-skills:using-agent-skills` to select and follow applicable Addy Osmani agent-skills before substantive work.";


const blueprintMutationToolNames = [
  "mcp__anvil__anvil_blueprint_propose_revision",
  "mcp__anvil__anvil_blueprint_accept_revision",
  "mcp__anvil__anvil_blueprint_reject_revision",
  "mcp__anvil__anvil_blueprint_decompose_work",
  "mcp__anvil__anvil_blueprint_capture_discovery",
  "mcp__anvil__anvil_blueprint_advance",
] as const;


type HookOutput = {
  continue?: true;
  hookSpecificOutput: {
    hookEventName: "SessionStart" | "UserPromptSubmit" | "PreToolUse";
    additionalContext: string;
    permissionDecision?: "allow" | "deny";
    permissionDecisionReason?: string;
    updatedInput?: Record<string, unknown>;
  };
};

type HookRun = {
  output: HookOutput;
  stdout: string;
  stderr: string;
};

function frameInput(overrides: Partial<CurrentFrameInput> = {}): CurrentFrameInput {
  return {
    operating_mode: "review",
    intent: "Keep Anvil continuity visible at Codex session start.",
    quality_bar: ["Continuity is not truth.", "Current evidence wins."],
    permission_envelope: {
      default: "follow active instructions",
      allowed_without_approval: ["read continuity state"],
      requires_approval: ["delete continuity history"],
    },
    active_decisions: [{ summary: "Use SessionStart hooks for continuity injection." }],
    open_questions: [],
    next_actions: [{ summary: "Review whether MCP tools are needed next." }],
    continuity_notes: ["Hook output is extra developer context."],
    ...overrides,
  };
}

async function configureBrain(temp: string, fixture = "valid-known-project"): Promise<string> {
  const brainRoot = join(temp, "brain");
  const anvilHome = join(temp, "anvil-home");
  await cp(join(brainFixtures, fixture), brainRoot, { recursive: true });
  await mkdir(join(anvilHome, "agents", "codex"), { recursive: true });
  await writeFile(
    join(anvilHome, "agents", "codex", "config.json"),
    `${JSON.stringify({
      schema_version: 1,
      agent_id: "codex",
      brain_root: brainRoot,
      wiki_alias: "fixture-brain",
    })}\n`,
    "utf8",
  );
  return anvilHome;
}

async function configureProjectAwareBrain(temp: string): Promise<string> {
  const brainRoot = join(temp, "brain");
  const anvilHome = join(temp, "anvil-home");
  await mkdir(join(brainRoot, "self-model"), { recursive: true });
  await mkdir(join(brainRoot, "projects"), { recursive: true });
  await mkdir(join(brainRoot, "patterns"), { recursive: true });
  await mkdir(join(anvilHome, "agents", "codex"), { recursive: true });
  await writeFile(
    join(brainRoot, ".llm-wiki.toml"),
    [
      'schema_version = "1"',
      'runtime_contract = "2"',
      "[compiler]",
      'providers = ["seed", "frontmatter", "text", "graph", "source"]',
      'graph_backend = "legacy"',
      "",
    ].join("\n"),
    "utf8",
  );
  await writeFile(join(brainRoot, "wiki-agent.md"), "# Fixture Brain\n", "utf8");
  await writeFile(join(brainRoot, "index.md"), "---\nokf_version: \"0.1\"\n---\n\n# Fixture Brain\n", "utf8");
  await writeFile(join(brainRoot, "log.md"), "# Log\n", "utf8");
  await writeFile(
    join(brainRoot, "brain-bootstrap.json"),
    `${JSON.stringify({
      version: 2,
      core_pages: [
        "self-model/i-am-rowan.md",
        "self-model/working-with-vik.md",
        "self-model/brain-is-maintained-cognitive-wiki.md",
      ],
      collaboration_kernel: {
        target_bytes: 3_072,
        hard_bytes: 4_096,
        sources: [
          { role: "identity", page: "self-model/i-am-rowan.md", section: "Operating Rule" },
          { role: "collaboration", page: "self-model/working-with-vik.md", section: "Operating Rule" },
          { role: "authority", page: "self-model/brain-is-maintained-cognitive-wiki.md", section: "Operating Rule" },
        ],
      },
      budgets: {
        session_start_target_bytes: 16_384,
        session_start_hard_bytes: 24_576,
        prompt_recall_target_bytes: 8_192,
        prompt_recall_hard_bytes: 16_384,
      },
    }, null, 2)}\n`,
    "utf8",
  );
  const page = (title: string, type: string, extra: string, body: string) => [
    "---",
    `title: ${title}`,
    "category: Test",
    "status: Active",
    "owner: Codex",
    `type: ${type}`,
    `description: ${title} fixture.`,
    "timestamp: 2026-08-28T00:00:00Z",
    "tags: []",
    "created: 2026-08-28",
    "last_reviewed: 2026-08-28",
    extra,
    "---",
    "",
    body,
    "",
  ].filter(Boolean).join("\n");
  await writeFile(
    join(brainRoot, "self-model", "i-am-rowan.md"),
    page("Identity", "self-model", "", "## Operating Rule\n\nI am Rowan."),
    "utf8",
  );
  await writeFile(
    join(brainRoot, "self-model", "working-with-vik.md"),
    page("Collaboration", "self-model", "", "## Operating Rule\n\nWork directly with Vik."),
    "utf8",
  );
  await writeFile(
    join(brainRoot, "self-model", "brain-is-maintained-cognitive-wiki.md"),
    page("Authority", "self-model", "", "## Operating Rule\n\nLive evidence outranks Brain."),
    "utf8",
  );
  await writeFile(
    join(brainRoot, "projects", "alpha.md"),
    page(
      "Alpha",
      "project",
      "identity:\n  project_id: alpha\n  aliases: [alpha]\n  remotes: [github.com/acme/alpha]",
      "## Current Orientation\n\nAlpha orientation is automatically available from repository identity.",
    ),
    "utf8",
  );
  await writeFile(
    join(brainRoot, "projects", "beta.md"),
    page(
      "Beta",
      "project",
      "identity:\n  project_id: beta\n  aliases: [beta]\n  remotes: [github.com/acme/beta]",
      "## Current Orientation\n\nBeta should remain outside Alpha recall.",
    ),
    "utf8",
  );
  await writeFile(
    join(brainRoot, "patterns", "beta-next.md"),
    page(
      "Beta Next Work",
      "pattern",
      "projects: [beta]",
      `## Durable Pattern\n\n${"work on the next urgent task in beta ".repeat(24)}`,
    ),
    "utf8",
  );
  await writeFile(
    join(brainRoot, "patterns", "global-planning.md"),
    page(
      "Global Planning",
      "pattern",
      "",
      "## Durable Pattern\n\nGeneral next-step planning guidance remains globally useful.",
    ),
    "utf8",
  );
  await writeFile(
    join(anvilHome, "agents", "codex", "config.json"),
    `${JSON.stringify({
      schema_version: 1,
      agent_id: "codex",
      brain_root: brainRoot,
      wiki_alias: "fixture-brain",
    })}\n`,
    "utf8",
  );
  return anvilHome;
}

function runContextHook({
  cwd,
  stateRoot,
  anvilHome,
  brainContext,
  llmWikiBin = fakeLlmWiki,
  command = "context-hook",
  hookEventName = "SessionStart",
  prompt,
  sessionId = "session_test",
  turnId = "turn_test",
  messageId = "message_test",
  source = "startup",
  prebind = hookEventName === "UserPromptSubmit" || hookEventName === "PreToolUse",
  toolName,
  toolInput,
}: {
  cwd: string;
  stateRoot: string;
  anvilHome?: string;
  brainContext?: string;
  llmWikiBin?: string;
  command?: "context-hook" | "session-start-hook";
  hookEventName?: "SessionStart" | "UserPromptSubmit" | "PreToolUse";
  prompt?: unknown;
  sessionId?: string;
  turnId?: string;
  messageId?: string;
  source?: "startup" | "resume" | "clear" | "compact";
  prebind?: boolean;
  toolName?: string;
  toolInput?: unknown;
}): HookRun {
  const env = {
    ...process.env,
    ANVIL_STATE_ROOT: stateRoot,
    ANVIL_HOME: anvilHome ?? join(dirname(stateRoot), "anvil-home"),
    ANVIL_AGENT_ID: "codex",
    ANVIL_LLM_WIKI_BIN: llmWikiBin,
    ...(brainContext ? { ANVIL_BRAIN_CONTEXT: brainContext } : {}),
  };
  const hookInput = {
    cwd,
    session_id: sessionId,
    turn_id: turnId,
    message_id: messageId,
    hook_event_name: hookEventName,
    source,
    ...(prompt !== undefined ? { prompt } : {}),
    ...(toolName !== undefined ? { tool_name: toolName } : {}),
    ...(toolInput !== undefined ? { tool_input: toolInput } : {}),
  };
  if (prebind) {
    const bindingResult = spawnSync(process.execPath, [anvilBin, "codex", "context-hook"], {
      cwd: resolve("."),
      env: { ...env, ANVIL_BRAIN_CONTEXT: "off" },
      input: `${JSON.stringify({ ...hookInput, hook_event_name: "SessionStart" })}\n`,
      encoding: "utf8",
    });
    assert.equal(bindingResult.status, 0, bindingResult.stderr);
  }
  const result = spawnSync(process.execPath, [anvilBin, "codex", command], {
    cwd: resolve("."),
    env,
    input: `${JSON.stringify(hookInput)}\n`,
    encoding: "utf8",
  });

  assert.equal(result.status, 0, result.stderr);
  const output = JSON.parse(result.stdout) as HookOutput;
  if (hookEventName === "PreToolUse") {
    assert.deepEqual(
      Object.keys(output),
      ["hookSpecificOutput"],
      "PreToolUse must emit only the supported decision envelope so Codex applies the rewrite or denial",
    );
  }
  return {
    output,
    stdout: result.stdout,
    stderr: result.stderr,
  };
}

function childEnv(extra: Record<string, string>): Record<string, string> {
  const env: Record<string, string> = {};
  for (const [key, value] of Object.entries(process.env)) {
    if (value !== undefined) env[key] = value;
  }
  return { ...env, ...extra };
}

function runRawPreToolUse({
  cwd,
  stateRoot,
  sessionId,
  toolName,
  toolInput,
}: {
  cwd: string;
  stateRoot: string;
  sessionId: string;
  toolName: string;
  toolInput: unknown;
}): { stdout: string; stderr: string } {
  const result = spawnSync(process.execPath, [anvilBin, "codex", "context-hook"], {
    cwd: resolve("."),
    env: childEnv({
      ANVIL_STATE_ROOT: stateRoot,
      ANVIL_HOME: join(dirname(stateRoot), "anvil-home"),
      ANVIL_AGENT_ID: "codex",
      ANVIL_BRAIN_CONTEXT: "off",
    }),
    input: `${JSON.stringify({
      cwd,
      session_id: sessionId,
      hook_event_name: "PreToolUse",
      tool_name: toolName,
      tool_input: toolInput,
    })}\n`,
    encoding: "utf8",
  });
  assert.equal(result.status, 0, result.stderr);
  return { stdout: result.stdout, stderr: result.stderr };
}

function runGit(args: string[], cwd: string): void {
  const result = spawnSync("git", args, { cwd, encoding: "utf8" });
  assert.equal(result.status, 0, result.stderr);
}

function runStopHook(input: {
  cwd: string;
  stateRoot: string;
  anvilHome?: string;
  prebind?: boolean;
  lastAssistantMessage?: string | null;
  stopHookActive?: boolean;
  sessionId?: string;
}) {
  const env = {
    ...process.env,
    ANVIL_STATE_ROOT: input.stateRoot,
    ANVIL_HOME: input.anvilHome ?? join(dirname(input.stateRoot), "anvil-home"),
    ANVIL_AGENT_ID: "codex",
  };
  const hookInput = {
    cwd: input.cwd,
    session_id: input.sessionId ?? "session_stop_test",
    turn_id: "turn_stop_test",
  };
  if (input.prebind !== false) {
    const bindingResult = spawnSync(process.execPath, [anvilBin, "codex", "context-hook"], {
      cwd: resolve("."),
      env: { ...env, ANVIL_BRAIN_CONTEXT: "off" },
      input: `${JSON.stringify({ ...hookInput, hook_event_name: "SessionStart", source: "startup" })}\n`,
      encoding: "utf8",
    });
    assert.equal(bindingResult.status, 0, bindingResult.stderr);
  }
  return spawnSync(process.execPath, [anvilBin, "codex", "context-hook"], {
    cwd: resolve("."),
    env,
    input: `${JSON.stringify({
      ...hookInput,
      hook_event_name: "Stop",
      ...(input.lastAssistantMessage !== undefined
        ? { last_assistant_message: input.lastAssistantMessage }
        : {}),
      ...(input.stopHookActive !== undefined ? { stop_hook_active: input.stopHookActive } : {}),
    })}\n`,
    encoding: "utf8",
  });
}

test("Codex Stop hook allows a completion-sounding message", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-codex-stop-completion-"));
  try {
    const repo = join(temp, "repo");
    const stateRoot = join(temp, "state");
    await mkdir(repo, { recursive: true });
    runGit(["init"], repo);

    const result = runStopHook({
      cwd: repo,
      stateRoot,
      lastAssistantMessage: "Implemented the completion Stop hook and verified it with focused tests.",
    });
    assert.equal(result.status, 0, result.stderr);
    assert.equal(result.stdout, "");
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("Codex Stop hook passes non-completion, negative, hypothetical, and missing messages", async () => {
  const cases: Array<string | null | undefined> = [
    "I fixed one assertion and will continue investigating.",
    "The task is not complete yet.",
    "If this were complete, we could ship it, but it is not.",
    null,
    undefined,
  ];
  for (const lastAssistantMessage of cases) {
    const temp = await mkdtemp(join(tmpdir(), "anvil-codex-stop-pass-"));
    try {
      const repo = join(temp, "repo");
      const stateRoot = join(temp, "state");
      await mkdir(repo, { recursive: true });
      runGit(["init"], repo);

      const result = runStopHook({ cwd: repo, stateRoot, lastAssistantMessage });

      assert.equal(result.status, 0, result.stderr);
      assert.equal(result.stdout, "");
    } finally {
      await rm(temp, { recursive: true, force: true });
    }
  }
});

test("Codex Stop hook never blocks a second stop pass", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-codex-stop-active-"));
  try {
    const repo = join(temp, "repo");
    const stateRoot = join(temp, "state");
    await mkdir(repo, { recursive: true });
    runGit(["init"], repo);
    await recordBrainUsage({
      cwd: repo,
      stateRoot,
      usage: {
        event: "stale",
        trigger: "Brain is stale.",
        severity: "warn",
        session_id: "session_stop_test",
      },
    });

    const result = runStopHook({
      cwd: repo,
      stateRoot,
      stopHookActive: true,
      lastAssistantMessage: "Implemented the completion Stop hook. The task is complete.",
    });

    assert.equal(result.status, 0, result.stderr);
    assert.equal(result.stdout, "");
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("Codex SessionStart creates an inspectable Work Context binding", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-codex-work-context-start-"));
  try {
    const workspace = join(temp, "improvements");
    const stateRoot = join(temp, "state");
    await mkdir(workspace, { recursive: true });

    const { output, stderr } = runContextHook({
      cwd: workspace,
      stateRoot,
      brainContext: "off",
      sessionId: "session_work_context",
    });
    const binding = await requireWorkContextBinding({
      bindingId: bindingIdForSession("codex", "session_work_context"),
      stateRoot,
    });

    assert.equal(binding.collaboration_space.root, await realpath(workspace));
    assert.equal(binding.provenance.lifecycle, "SessionStart:startup");
    assert.match(output.hookSpecificOutput.additionalContext, /## Anvil Work Context/);
    assert.match(output.hookSpecificOutput.additionalContext, /improvements/);
    assert.match(output.hookSpecificOutput.additionalContext, new RegExp(binding.id));
    assert.equal(stderr, "");
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("Codex SessionStart resumes one binding across startup, resume, clear, and compact", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-codex-work-context-resume-"));
  try {
    const workspace = join(temp, "workspace");
    const stateRoot = join(temp, "state");
    await mkdir(workspace, { recursive: true });

    const outputs = (["startup", "resume", "clear", "compact"] as const).map((source) =>
      runContextHook({
        cwd: workspace,
        stateRoot,
        brainContext: "off",
        sessionId: "session_lifecycle",
        source,
      }),
    );
    const binding = await requireWorkContextBinding({
      bindingId: bindingIdForSession("codex", "session_lifecycle"),
      stateRoot,
    });

    assert.equal(binding.provenance.lifecycle, "SessionStart:compact");
    assert.ok(
      outputs.every(({ output }) => output.hookSpecificOutput.additionalContext.includes(binding.id)),
    );
    assert.ok(outputs.every(({ stderr }) => stderr === ""));
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("a task checkpoint produced in one session is injected into the next session", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-codex-active-task-resume-"));
  try {
    const workspace = join(temp, "workspace");
    const stateRoot = join(temp, "state");
    await mkdir(workspace, { recursive: true });

    runContextHook({
      cwd: workspace,
      stateRoot,
      brainContext: "off",
      sessionId: "session_active_task_producer",
    });
    const producerBinding = await requireWorkContextBinding({
      bindingId: bindingIdForSession("codex", "session_active_task_producer"),
      stateRoot,
    });
    await checkpointActiveTask({
      binding: producerBinding,
      stateRoot,
      checkpointId: "cross-session-active-task",
      task: {
        state: "active",
        summary: "Restore active-task Continuity.",
        nextStep: "Verify the fresh SessionStart consumer.",
      },
      source: { kind: "test", description: "Session A producer" },
      now: () => "2026-08-22T00:00:00.000Z",
    });

    const consumer = runContextHook({
      cwd: workspace,
      stateRoot,
      brainContext: "off",
      sessionId: "session_active_task_consumer",
    });
    const context = consumer.output.hookSpecificOutput.additionalContext;
    assert.match(context, /Active task:/);
    assert.match(context, /Restore active-task Continuity/);
    assert.match(context, /Verify the fresh SessionStart consumer/);
    assert.equal(consumer.stderr, "");
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("Codex lifecycle validation never silently rebinds one session to another space", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-codex-work-context-mismatch-"));
  try {
    const firstWorkspace = join(temp, "improvements");
    const secondWorkspace = join(temp, "anvil_redux");
    const stateRoot = join(temp, "state");
    await mkdir(firstWorkspace, { recursive: true });
    await mkdir(secondWorkspace, { recursive: true });

    runContextHook({
      cwd: firstWorkspace,
      stateRoot,
      brainContext: "off",
      sessionId: "session_drift",
    });
    const mismatch = runContextHook({
      cwd: secondWorkspace,
      stateRoot,
      brainContext: "off",
      sessionId: "session_drift",
      source: "resume",
    });
    const binding = await requireWorkContextBinding({
      bindingId: bindingIdForSession("codex", "session_drift"),
      stateRoot,
    });

    assert.match(mismatch.output.hookSpecificOutput.additionalContext, /WORK_CONTEXT_MISMATCH/);
    assert.match(mismatch.stderr, /WORK_CONTEXT_MISMATCH/);
    assert.equal(binding.collaboration_space.root, await realpath(firstWorkspace));
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("Codex UserPromptSubmit reports a missing binding without creating one", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-codex-work-context-prompt-missing-"));
  try {
    const workspace = join(temp, "workspace");
    const stateRoot = join(temp, "state");
    await mkdir(workspace, { recursive: true });

    const { output, stderr } = runContextHook({
      cwd: workspace,
      stateRoot,
      brainContext: "off",
      hookEventName: "UserPromptSubmit",
      prompt: "Do the work",
      sessionId: "session_missing",
      prebind: false,
    });

    assert.match(output.hookSpecificOutput.additionalContext, /WORK_CONTEXT_NOT_BOUND/);
    assert.match(stderr, /WORK_CONTEXT_NOT_BOUND/);
    await assert.rejects(
      () =>
        requireWorkContextBinding({
          bindingId: bindingIdForSession("codex", "session_missing"),
          stateRoot,
        }),
      /does not exist/,
    );
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("Codex SessionStart exposes malformed lifecycle identity without granting authority", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-codex-work-context-identity-"));
  try {
    const workspace = join(temp, "workspace");
    const stateRoot = join(temp, "state");
    await mkdir(workspace, { recursive: true });

    const { output, stderr } = runContextHook({
      cwd: workspace,
      stateRoot,
      brainContext: "off",
      sessionId: "",
    });

    assert.match(output.hookSpecificOutput.additionalContext, /WORK_CONTEXT_NOT_BOUND/);
    assert.match(stderr, /missing session_id/);
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("Codex Stop is a no-op when no session binding exists", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-codex-work-context-stop-missing-"));
  try {
    const workspace = join(temp, "workspace");
    const stateRoot = join(temp, "state");
    await mkdir(workspace, { recursive: true });

    const result = runStopHook({ cwd: workspace, stateRoot, prebind: false });

    assert.equal(result.status, 0);
    assert.equal(result.stdout, "");
    assert.equal(result.stderr, "");
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("Codex PreToolUse blocks agent-issued lifecycle hook probes", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-codex-probe-block-"));
  try {
    const repo = join(temp, "repo");
    const stateRoot = join(temp, "state");
    await mkdir(repo, { recursive: true });
    runGit(["init"], repo);

    const commands = [
      "printf '%s\\n' '{} ' | anvil codex context-hook",
      "node /Users/example/bin/anvil.ts codex session-start-hook < hook.json",
    ];
    for (const command of commands) {
      const result = runRawPreToolUse({
        cwd: repo,
        stateRoot,
        sessionId: "session_probe_block",
        toolName: "Bash",
        toolInput: { command },
      });
      const output = JSON.parse(result.stdout) as HookOutput;
      assert.equal(output.hookSpecificOutput.permissionDecision, "deny");
      assert.match(
        output.hookSpecificOutput.permissionDecisionReason ?? "",
        /HOST_LIFECYCLE_PROBE_BLOCKED/,
      );
      assert.match(result.stderr, /Agent-issued Codex lifecycle-hook probes are forbidden/);
    }
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("Codex PreToolUse leaves ordinary Bash commands unchanged", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-codex-probe-pass-"));
  try {
    const repo = join(temp, "repo");
    const stateRoot = join(temp, "state");
    await mkdir(repo, { recursive: true });
    runGit(["init"], repo);

    const result = runRawPreToolUse({
      cwd: repo,
      stateRoot,
      sessionId: "session_probe_pass",
      toolName: "Bash",
      toolInput: { command: "npm run typecheck" },
    });
    assert.equal(result.stdout, "");
    assert.equal(result.stderr, "");
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("Codex PreToolUse injects the trusted binding for every bound operation and strips routing paths", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-codex-work-context-pretool-"));
  try {
    const workspace = join(temp, "improvements");
    const stateRoot = join(temp, "state");
    await mkdir(workspace, { recursive: true });
    const toolNames = [
      "mcp__anvil__anvil_continuity_record_event",
      "mcp__anvil__anvil_continuity_promote_event",
      "mcp__anvil__anvil_continuity_retire_projection_item",
      "mcp__anvil__anvil_continuity_checkpoint_task",
      "mcp__anvil__anvil_brain_usage_log",
      "mcp__anvil__anvil_skill_invocation_log",
      "mcp__anvil__anvil_tool_result_manifest",
      "mcp__anvil__anvil_tool_result_search",
      "mcp__anvil__anvil_tool_result_read_slice",
      "mcp__anvil__anvil_tool_result_health",
    ];

    for (const toolName of toolNames) {
      const { output, stderr } = runContextHook({
        cwd: workspace,
        stateRoot,
        brainContext: "off",
        hookEventName: "PreToolUse",
        sessionId: "session_pretool",
        toolName,
        toolInput: {
          cwd: join(temp, "anvil_redux"),
          stateRoot: join(temp, "override-state"),
          bindingId: "wctx_00000000000000000000000000000000",
          eventId: "evt_1",
        },
      });
      const bindingId = bindingIdForSession("codex", "session_pretool");

      assert.equal(output.hookSpecificOutput.hookEventName, "PreToolUse");
      assert.equal(output.hookSpecificOutput.permissionDecision, "allow");
      assert.equal(output.hookSpecificOutput.updatedInput?.bindingId, bindingId);
      assert.equal("cwd" in (output.hookSpecificOutput.updatedInput ?? {}), false);
      assert.equal("stateRoot" in (output.hookSpecificOutput.updatedInput ?? {}), false);
      assert.equal(stderr, "");
    }
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("Codex PreToolUse leaves retired Blueprint tools outside Work Context routing", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-codex-blueprint-routing-retired-"));
  try {
    const workspace = join(temp, "workspace");
    const stateRoot = join(temp, "state");
    await mkdir(workspace, { recursive: true });

    for (const toolName of blueprintMutationToolNames) {
      const result = runRawPreToolUse({
        cwd: workspace,
        stateRoot,
        sessionId: "session_blueprint_routing_retired",
        toolName,
        toolInput: { bindingId: "wctx_00000000000000000000000000000000" },
      });
      assert.equal(result.stdout, "");
      assert.equal(result.stderr, "");
    }
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("Codex PreToolUse injects trusted turn and message trace into skill evidence", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-codex-skill-trace-pretool-"));
  try {
    const workspace = join(temp, "workspace");
    const stateRoot = join(temp, "state");
    await mkdir(workspace, { recursive: true });

    const { output, stderr } = runContextHook({
      cwd: workspace,
      stateRoot,
      brainContext: "off",
      hookEventName: "PreToolUse",
      sessionId: "session-skill-trace",
      turnId: "turn-skill-trace",
      messageId: "message-skill-trace",
      toolName: "mcp__anvil__anvil_skill_invocation_log",
      toolInput: {
        skill: "loci",
        trigger: "Codebase navigation was required.",
        outcome: "used",
        reason: "Loci retrieved the implementation symbols.",
        host: "caller-selected-host",
        sessionId: "caller-selected-session",
        turnId: "caller-selected-turn",
        messageId: "caller-selected-message",
      },
    });

    assert.equal(output.hookSpecificOutput.permissionDecision, "allow");
    assert.equal(output.hookSpecificOutput.updatedInput?.turnId, "turn-skill-trace");
    assert.equal(output.hookSpecificOutput.updatedInput?.messageId, "message-skill-trace");
    assert.equal("host" in (output.hookSpecificOutput.updatedInput ?? {}), false);
    assert.equal("sessionId" in (output.hookSpecificOutput.updatedInput ?? {}), false);
    assert.equal(stderr, "");
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("Codex PreToolUse denies Continuity mutation when the session is not bound", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-codex-work-context-pretool-deny-"));
  try {
    const workspace = join(temp, "workspace");
    const stateRoot = join(temp, "state");
    await mkdir(workspace, { recursive: true });

    const { output, stderr } = runContextHook({
      cwd: workspace,
      stateRoot,
      brainContext: "off",
      hookEventName: "PreToolUse",
      sessionId: "session_pretool_missing",
      toolName: "mcp__anvil__anvil_continuity_record_event",
      toolInput: { event: { type: "decision", summary: "Must not write." } },
      prebind: false,
    });

    assert.equal(output.hookSpecificOutput.permissionDecision, "deny");
    assert.match(output.hookSpecificOutput.permissionDecisionReason ?? "", /WORK_CONTEXT_NOT_BOUND/);
    assert.equal(output.hookSpecificOutput.updatedInput, undefined);
    assert.match(stderr, /WORK_CONTEXT_NOT_BOUND/);
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("Codex context hook returns exact prompt evidence and restores the kernel when retention is unproven", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-codex-hook-prompt-"));
  const prompt = "What durable rule did we choose for project-aware Brain retrieval?";
  try {
    const repo = join(temp, "anvil_redux");
    const stateRoot = join(temp, "state");
    await mkdir(repo, { recursive: true });
    const anvilHome = await configureBrain(temp);
    await writeFile(
      join(temp, "brain", "fake-llm-wiki.json"),
      `${JSON.stringify({ mode: "success", expected_question: prompt })}\n`,
      "utf8",
    );

    const first = runContextHook({
      cwd: repo,
      stateRoot,
      anvilHome,
      hookEventName: "UserPromptSubmit",
      prompt,
    });
    const retry = runContextHook({
      cwd: repo,
      stateRoot,
      anvilHome,
      hookEventName: "UserPromptSubmit",
      prompt,
    });
    const { output, stderr } = first;
    const context = output.hookSpecificOutput.additionalContext;
    const usage = await readBrainUsage({ cwd: repo, stateRoot });

    assert.equal(output.continue, true);
    assert.equal(output.hookSpecificOutput.hookEventName, "UserPromptSubmit");
    assert.match(context, /## Brain Context/);
    assert.match(context, /### Prompt Evidence/);
    assert.match(context, /- roles: `identity`/);
    assert.match(context, /- roles: `collaboration`/);
    assert.match(context, /- roles: `authority`/);
    assert.doesNotMatch(context, new RegExp(agentSkillsInvariant.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")));
    assert.doesNotMatch(context, /## Anvil Continuity Frame/);
    assert.doesNotMatch(context, /Anvil coordinates Continuity, Brain, and Loci/);
    assert.equal(stderr, "");
    assert.equal(retry.stderr, "");
    assert.equal(usage.kind, "ok");
    assert.equal(usage.total, 1);
    assert.equal(usage.items[0].event, "recalled");
    assert.deepEqual(usage.items[0].pages, [
      "self-model/i-am-rowan.md",
      "self-model/working-with-vik.md",
      "self-model/brain-is-maintained-cognitive-wiki.md",
      "patterns/support.md",
    ]);
    assert.equal(usage.items[0].session_id, "session_test");
    assert.equal(usage.items[0].turn_id, "turn_test");
    assert.equal(usage.items[0].message_id, "message_test");
    assert.equal(usage.items[0].prompt_excerpt, undefined);
    assert.equal(usage.items[0].prompt_raw, undefined);
    assert.equal(usage.items[0].recall_observation?.phase, "render");
    assert.equal(usage.items[0].recall_observation?.pages.guidance_count, 0);
    assert.equal(usage.items[0].recall_observation?.pages.compiler_evidence_count, 3);
    assert.equal(usage.items[0].recall_observation?.render_outcome, "within_limit");
    assert.equal(
      usage.items[0].recall_observation?.bytes.attempted,
      (usage.items[0].recall_observation?.bytes.guidance ?? 0) +
        (usage.items[0].recall_observation?.bytes.retrieved_context ?? 0) +
        (usage.items[0].recall_observation?.bytes.framing ?? 0),
    );
    assert.doesNotMatch(JSON.stringify(usage.items[0].recall_observation), /What durable rule/);
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("Codex prompt hook does not inject the retired Agent Skills invariant when Brain is disabled", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-codex-hook-skills-off-"));
  try {
    const repo = join(temp, "anvil_redux");
    const stateRoot = join(temp, "state");
    await mkdir(repo, { recursive: true });

    const { output, stderr } = runContextHook({
      cwd: repo,
      stateRoot,
      brainContext: "off",
      hookEventName: "UserPromptSubmit",
      prompt: "Fix the TypeScript parser bug.",
    });
    const usage = await readBrainUsage({ cwd: repo, stateRoot });

    assert.doesNotMatch(output.hookSpecificOutput.additionalContext, new RegExp(agentSkillsInvariant.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")));
    assert.doesNotMatch(output.hookSpecificOutput.additionalContext, /Blueprint Runtime Authority/);
    assert.equal(stderr, "");
    assert.equal(usage.kind, "ok");
    assert.equal(usage.total, 1);
    assert.equal(usage.items[0].event, "disabled");
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("Codex prompt hook preserves its diagnostic without the retired Agent Skills invariant when Brain retrieval degrades", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-codex-hook-skills-degraded-"));
  try {
    const repo = join(temp, "anvil_redux");
    const stateRoot = join(temp, "state");
    await mkdir(repo, { recursive: true });

    const { output, stderr } = runContextHook({
      cwd: repo,
      stateRoot,
      hookEventName: "UserPromptSubmit",
      prompt: "Fix the TypeScript parser bug.",
    });
    const context = output.hookSpecificOutput.additionalContext;
    const usage = await readBrainUsage({ cwd: repo, stateRoot });

    assert.doesNotMatch(context, new RegExp(agentSkillsInvariant.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")));
    assert.ok(context.startsWith("## Brain Recall Diagnostic"));
    assert.match(context, /## Brain Recall Diagnostic/);
    assert.match(context, /BRAIN_NOT_CONFIGURED/);
    assert.match(stderr, /BRAIN_NOT_CONFIGURED/);
    assert.equal(usage.kind, "ok");
    assert.equal(usage.total, 1);
    assert.equal(usage.items[0].event, "degraded");
    assert.match(usage.items[0].outcome ?? "", /BRAIN_NOT_CONFIGURED/);
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("Codex prompt hook records retained-Kernel retrieval failure as degraded, not recalled", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-codex-hook-retained-kernel-failure-"));
  const prompt = "What durable rule did we choose for project-aware Brain retrieval?";
  try {
    const repo = join(temp, "anvil_redux");
    const stateRoot = join(temp, "state");
    await mkdir(repo, { recursive: true });
    const anvilHome = await configureBrain(temp);
    await writeFile(
      join(temp, "brain", "fake-llm-wiki.json"),
      `${JSON.stringify({ mode: "success", expected_question: prompt, failure_questions: [prompt] })}\n`,
      "utf8",
    );

    const { output, stderr } = runContextHook({
      cwd: repo,
      stateRoot,
      anvilHome,
      hookEventName: "UserPromptSubmit",
      prompt,
    });
    const usage = await readBrainUsage({ cwd: repo, stateRoot });

    assert.match(output.hookSpecificOutput.additionalContext, /evidence_id: `kernel:0`/);
    assert.match(stderr, /BRAIN_RETRIEVAL_FAILED/);
    assert.equal(usage.kind, "ok");
    assert.equal(usage.total, 1);
    assert.equal(usage.items[0].event, "degraded");
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("Codex prompt hook records useful evidence with a retrieval limit as recalled", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-codex-hook-useful-partial-"));
  const prompt = "What durable rule did we choose for project-aware Brain retrieval?";
  try {
    const repo = join(temp, "anvil_redux");
    const stateRoot = join(temp, "state");
    await mkdir(repo, { recursive: true });
    const anvilHome = await configureBrain(temp);
    await writeFile(
      join(temp, "brain", "fake-llm-wiki.json"),
      `${JSON.stringify({ mode: "success", expected_question: prompt })}\n`,
      "utf8",
    );
    await writeFile(
      join(temp, "brain", "compiled-context.json"),
      `${JSON.stringify({
        kind: "compiled_context",
        contract_version: "1",
        evidence: [{ page: "patterns/support.md", content: "Useful retrieved evidence remains available." }],
        diagnostics: [{
          code: "SOURCE_NOT_FOUND",
          message: "A referenced source could not be loaded.",
          provider: "source",
          details: {},
        }],
        stop: {
          reason: "provider_degraded",
          sufficient: true,
          detail: "Useful evidence was retained despite a source failure.",
        },
      })}\n`,
      "utf8",
    );

    const { output, stderr } = runContextHook({
      cwd: repo,
      stateRoot,
      anvilHome,
      hookEventName: "UserPromptSubmit",
      prompt,
    });
    const context = output.hookSpecificOutput.additionalContext;
    const usage = await readBrainUsage({ cwd: repo, stateRoot });

    assert.match(context, /Useful retrieved evidence remains available\./);
    assert.match(context, /### Retrieval limits/);
    assert.equal(
      context.split("Some sources or retrieval providers could not supply evidence; retrieval may be incomplete.").length - 1,
      1,
    );
    assert.equal(stderr, "");
    assert.equal(usage.kind, "ok");
    assert.equal(usage.total, 1);
    assert.equal(usage.items[0].event, "recalled");
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("Codex prompt hook records clean prompt no-evidence as no_match despite retained Kernel", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-codex-hook-clean-no-match-"));
  const prompt = "What durable rule did we choose for project-aware Brain retrieval?";
  try {
    const repo = join(temp, "anvil_redux");
    const stateRoot = join(temp, "state");
    await mkdir(repo, { recursive: true });
    const anvilHome = await configureBrain(temp);
    await writeFile(
      join(temp, "brain", "fake-llm-wiki.json"),
      `${JSON.stringify({ mode: "success", expected_question: prompt })}\n`,
      "utf8",
    );
    await writeFile(
      join(temp, "brain", "compiled-context.json"),
      `${JSON.stringify({
        kind: "compiled_context",
        contract_version: "1",
        evidence: [],
        diagnostics: [],
        stop: { reason: "no_evidence", sufficient: false, detail: "No supporting evidence was selected." },
      })}\n`,
      "utf8",
    );

    const { output, stderr } = runContextHook({
      cwd: repo,
      stateRoot,
      anvilHome,
      hookEventName: "UserPromptSubmit",
      prompt,
    });
    const usage = await readBrainUsage({ cwd: repo, stateRoot });

    assert.match(output.hookSpecificOutput.additionalContext, /evidence_id: `kernel:0`/);
    assert.equal(stderr, "");
    assert.equal(usage.kind, "ok");
    assert.equal(usage.total, 1);
    assert.equal(usage.items[0].event, "no_match");
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("Codex prompt hook records empty prompt evidence with a provider failure as degraded", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-codex-hook-empty-provider-failure-"));
  const prompt = "What durable rule did we choose for project-aware Brain retrieval?";
  try {
    const repo = join(temp, "anvil_redux");
    const stateRoot = join(temp, "state");
    await mkdir(repo, { recursive: true });
    const anvilHome = await configureBrain(temp);
    await writeFile(
      join(temp, "brain", "fake-llm-wiki.json"),
      `${JSON.stringify({ mode: "success", expected_question: prompt })}\n`,
      "utf8",
    );
    await writeFile(
      join(temp, "brain", "compiled-context.json"),
      `${JSON.stringify({
        kind: "compiled_context",
        contract_version: "1",
        evidence: [],
        diagnostics: [{
          code: "SOURCE_NOT_FOUND",
          message: "A referenced source could not be loaded.",
          provider: "source",
          details: {},
        }],
        stop: { reason: "provider_degraded", sufficient: false, detail: "A source failed before selection." },
      })}\n`,
      "utf8",
    );

    const { output, stderr } = runContextHook({
      cwd: repo,
      stateRoot,
      anvilHome,
      hookEventName: "UserPromptSubmit",
      prompt,
    });
    const usage = await readBrainUsage({ cwd: repo, stateRoot });

    assert.match(output.hookSpecificOutput.additionalContext, /evidence_id: `kernel:0`/);
    assert.match(output.hookSpecificOutput.additionalContext, /### Retrieval limits/);
    assert.equal(stderr, "");
    assert.equal(usage.kind, "ok");
    assert.equal(usage.total, 1);
    assert.equal(usage.items[0].event, "degraded");
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("Codex prompt hook records a retained-Kernel delivery-budget failure as degraded", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-codex-hook-retained-kernel-budget-failure-"));
  const prompt = "What durable rule did we choose for project-aware Brain retrieval?";
  try {
    const repo = join(temp, "anvil_redux");
    const stateRoot = join(temp, "state");
    await mkdir(repo, { recursive: true });
    const anvilHome = await configureBrain(temp);
    await writeFile(
      join(temp, "brain", "fake-llm-wiki.json"),
      `${JSON.stringify({
        mode: "success",
        expected_question: prompt,
        delivery_budget_override: { delivery_bytes: 0 },
      })}\n`,
      "utf8",
    );

    const { output, stderr } = runContextHook({
      cwd: repo,
      stateRoot,
      anvilHome,
      hookEventName: "UserPromptSubmit",
      prompt,
    });
    const usage = await readBrainUsage({ cwd: repo, stateRoot });

    assert.match(output.hookSpecificOutput.additionalContext, /evidence_id: `kernel:0`/);
    assert.match(stderr, /BRAIN_CONTEXT_BUDGET_VIOLATION/);
    assert.equal(usage.kind, "ok");
    assert.equal(usage.total, 1);
    assert.equal(usage.items[0].event, "degraded");
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("Codex prompt hook does not flood non-engineering prompts with a skill catalogue", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-codex-hook-skills-non-engineering-"));
  try {
    const repo = join(temp, "anvil_redux");
    const stateRoot = join(temp, "state");
    await mkdir(repo, { recursive: true });
    const anvilHome = await configureBrain(temp);
    await writeFile(
      join(temp, "brain", "compiled-context.json"),
      `${JSON.stringify({
        kind: "compiled_context",
        contract_version: "1",
        evidence: [
          { page: "self-model/i-am-rowan.md" },
          { page: "projects/anvil-redux.md" },
        ],
      })}\n`,
      "utf8",
    );

    const { output, stderr } = runContextHook({
      cwd: repo,
      stateRoot,
      anvilHome,
      hookEventName: "UserPromptSubmit",
      prompt: "Rewrite this sentence more warmly.",
    });
    const context = output.hookSpecificOutput.additionalContext;
    const usage = await readBrainUsage({ cwd: repo, stateRoot });

    assert.doesNotMatch(context, new RegExp(agentSkillsInvariant.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")));
    assert.ok(context.startsWith("## Brain Context"));
    assert.match(context, /### Prompt Evidence/);
    assert.doesNotMatch(context, /Anvil coordinates Continuity, Brain, and Loci/);
    assert.doesNotMatch(context, /Available skills|test-driven-development|security-and-hardening/);
    assert.equal(stderr, "");
    assert.equal(usage.kind, "ok");
    assert.equal(usage.total, 1);
    assert.equal(usage.items[0].event, "recalled");
    assert.deepEqual(usage.items[0].pages, [
      "self-model/i-am-rowan.md",
      "self-model/working-with-vik.md",
      "self-model/brain-is-maintained-cognitive-wiki.md",
    ]);
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("Codex context hook keeps invalid prompt inputs non-blocking and private", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-codex-hook-invalid-prompt-"));
  try {
    const repo = join(temp, "anvil_redux");
    const stateRoot = join(temp, "state");
    await mkdir(repo, { recursive: true });
    const anvilHome = await configureBrain(temp);

    const { output, stderr } = runContextHook({
      cwd: repo,
      stateRoot,
      anvilHome,
      hookEventName: "UserPromptSubmit",
      prompt: 42,
    });

    assert.equal(output.hookSpecificOutput.hookEventName, "UserPromptSubmit");
    assert.match(output.hookSpecificOutput.additionalContext, /BRAIN_PROMPT_INVALID/);
    assert.match(stderr, /BRAIN_PROMPT_INVALID/);
    assert.doesNotMatch(stderr, /42/);
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("Codex prompt hook keeps context injection successful when automatic telemetry cannot be written", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-codex-hook-telemetry-failure-"));
  const prompt = "What durable rule did we choose for project-aware Brain retrieval?";
  try {
    const repo = join(temp, "anvil_redux");
    const stateRoot = join(temp, "state");
    await mkdir(repo, { recursive: true });
    runContextHook({ cwd: repo, stateRoot, brainContext: "off" });
    await writeFile(join(stateRoot, "brain-usage"), "not a directory", "utf8");
    const anvilHome = await configureBrain(temp);
    await writeFile(
      join(temp, "brain", "fake-llm-wiki.json"),
      `${JSON.stringify({ mode: "success", expected_question: prompt })}\n`,
      "utf8",
    );

    const { output, stderr } = runContextHook({
      cwd: repo,
      stateRoot,
      anvilHome,
      hookEventName: "UserPromptSubmit",
      prompt,
      prebind: false,
    });

    assert.equal(output.continue, true);
    assert.match(output.hookSpecificOutput.additionalContext, /## Brain Context/);
    assert.match(stderr, /BRAIN_USAGE_RECORD_FAILED/);
    assert.doesNotMatch(stderr, new RegExp(prompt));
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("Codex context hook injects Continuity before stable Brain context for a known project", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-codex-hook-ok-"));
  try {
    const repo = join(temp, "anvil_redux");
    const stateRoot = join(temp, "state");
    await mkdir(repo, { recursive: true });
    const paths = deriveContinuityPaths({ stateRoot, workspace: gitWorkspaceRef(repo, "anvil_redux") });
    await initWorkspace(paths, frameInput(), { now: () => "2026-06-03T00:00:00.000Z" });
    const anvilHome = await configureBrain(temp);

    const first = runContextHook({ cwd: repo, stateRoot, anvilHome });
    const second = runContextHook({ cwd: repo, stateRoot, anvilHome });
    const context = first.output.hookSpecificOutput.additionalContext;

    assert.equal(first.output.continue, true);
    assert.equal(first.output.hookSpecificOutput.hookEventName, "SessionStart");
    assert.match(context, /## Anvil Continuity Frame/);
    assert.match(context, /Use SessionStart hooks for continuity injection/);
    assert.match(context, /## Brain Context/);
    assert.match(context, /- roles: `identity`/);
    assert.match(context, /- roles: `collaboration`/);
    assert.match(context, /- roles: `authority`/);
    assert.doesNotMatch(context, /Anvil coordinates Continuity, Brain, and Loci/);
    assert.ok(context.indexOf("## Anvil Continuity Frame") < context.indexOf("## Brain Context"));
    assert.equal(first.stderr, "");
    assert.equal(first.stdout, second.stdout);
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test(
  "Codex UserPromptSubmit carries Git identity through the real llm-wiki compiler",
  { skip: !existsSync(realLlmWiki) && "real llm-wiki checkout is unavailable" },
  async () => {
    const temp = await mkdtemp(join(tmpdir(), "anvil-codex-real-project-aware-"));
    try {
      const repo = join(temp, "renamed-checkout");
      const stateRoot = join(temp, "state");
      await mkdir(repo, { recursive: true });
      runGit(["init"], repo);
      runGit(["remote", "add", "origin", "https://github.com/acme/alpha.git"], repo);
      const anvilHome = await configureProjectAwareBrain(temp);

      const { output, stderr } = runContextHook({
        cwd: repo,
        stateRoot,
        anvilHome,
        llmWikiBin: realLlmWiki,
        hookEventName: "UserPromptSubmit",
        prompt: "What should I work on next?",
      });
      const context = output.hookSpecificOutput.additionalContext;
      const usage = await readBrainUsage({ cwd: repo, stateRoot });

      assert.equal(output.continue, true);
      assert.equal(output.hookSpecificOutput.hookEventName, "UserPromptSubmit");
      assert.match(context, /current_project: `projects\/alpha\.md`/);
      assert.match(context, /Alpha orientation is automatically available from repository identity/);
      assert.match(context, /General next-step planning guidance remains globally useful/);
      assert.doesNotMatch(context, /Beta should remain outside Alpha recall/);
      assert.doesNotMatch(context, /next urgent task in beta/);
      assert.equal(usage.kind, "ok");
      assert.equal(usage.total, 1);
      if (usage.kind === "ok") {
        const [{ workspace: _trustedWorkspaceProvenance, ...usagePayload }] = usage.items;
        assert.doesNotMatch(JSON.stringify(usagePayload), new RegExp(repo.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")));
        assert.doesNotMatch(JSON.stringify(usagePayload), /github\.com\/acme\/alpha/);
      }
      assert.equal(stderr, "");
    } finally {
      const writable = spawnSync("chmod", ["-R", "u+w", temp], { encoding: "utf8" });
      assert.equal(writable.status, 0, writable.stderr);
      await rm(temp, { recursive: true, force: true });
    }
  },
);

test("Codex context hook enforces the SessionStart hard cap across Continuity and Brain", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-codex-hook-total-cap-"));
  try {
    const repo = join(temp, "anvil_redux");
    const stateRoot = join(temp, "state");
    await mkdir(repo, { recursive: true });
    const paths = deriveContinuityPaths({ stateRoot, workspace: gitWorkspaceRef(repo, "anvil_redux") });
    const longItem = "A deliberately verbose Continuity projection item used to exercise the combined host envelope boundary. ".repeat(4);
    await initWorkspace(paths, frameInput({
      active_task: {
        event_id: "evt_active_task_hard_cap",
        recorded_at: "2026-08-22T00:00:00.000Z",
        summary: "Restore active-task Continuity under truncation.",
        state: "active",
        next_step: "Verify the compact SessionStart carrier.",
      },
      active_decisions: Array.from({ length: 8 }, (_, index) => ({
        summary: `${longItem} Decision ${index + 1}.`,
      })),
      open_questions: Array.from({ length: 8 }, (_, index) => ({
        summary: `${longItem} Question ${index + 1}.`,
      })),
      next_actions: Array.from({ length: 8 }, (_, index) => ({
        summary: `${longItem} Action ${index + 1}.`,
      })),
      continuity_notes: Array.from({ length: 6 }, (_, index) => `${longItem} Note ${index + 1}.`),
    }), { now: () => "2026-06-03T00:00:00.000Z" });
    const anvilHome = await configureBrain(temp, "oversized-retrieval");

    const { output, stderr } = runContextHook({ cwd: repo, stateRoot, anvilHome });
    const context = output.hookSpecificOutput.additionalContext;

    assert.ok(
      Buffer.byteLength(context, "utf8") <= 5_120,
      "combined SessionStart context must honor the hard byte limit",
    );
    assert.match(context, /## Anvil Continuity Frame/);
    assert.match(context, /## Anvil Continuity Active Task/);
    assert.match(context, /Restore active-task Continuity under truncation/);
    assert.match(context, /Verify the compact SessionStart carrier/);
    assert.match(context, /BRAIN_CONTEXT_TRUNCATED/);
    assert.match(stderr, /BRAIN_CONTEXT_BUDGET_VIOLATION/);
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("Codex context hook keeps unknown projects honest while retaining core identity", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-codex-hook-unknown-"));
  try {
    const repo = join(temp, "unknown_workspace");
    const stateRoot = join(temp, "state");
    await mkdir(repo, { recursive: true });
    const anvilHome = await configureBrain(temp);

    const { output, stderr } = runContextHook({ cwd: repo, stateRoot, anvilHome });
    const context = output.hookSpecificOutput.additionalContext;

    assert.match(context, /No Anvil continuity frame is initialized/);
    assert.match(context, /- roles: `identity`/);
    assert.match(context, /current_project: unknown_project/);
    assert.doesNotMatch(context, /Anvil coordinates Continuity, Brain, and Loci/);
    assert.equal(stderr, "");
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("Codex context hook exposes Brain degradation without blocking Continuity", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-codex-hook-degraded-"));
  try {
    const repo = join(temp, "repo");
    const stateRoot = join(temp, "state");
    await mkdir(repo, { recursive: true });
    const paths = deriveContinuityPaths({ stateRoot, workspace: gitWorkspaceRef(repo, "repo") });
    await initWorkspace(paths, frameInput(), { now: () => "2026-06-03T00:00:00.000Z" });

    const { output, stderr } = runContextHook({ cwd: repo, stateRoot });
    const context = output.hookSpecificOutput.additionalContext;

    assert.match(context, /## Anvil Continuity Frame/);
    assert.match(context, /## Brain Bootstrap Diagnostic/);
    assert.match(context, /BRAIN_NOT_CONFIGURED/);
    assert.match(stderr, /BRAIN_NOT_CONFIGURED/);
    assert.match(stderr, /Run anvil_brain_setup/);
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("Codex context hook preserves malformed Continuity diagnostics alongside Brain", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-codex-hook-malformed-"));
  try {
    const repo = join(temp, "anvil_redux");
    const stateRoot = join(temp, "state");
    await mkdir(repo, { recursive: true });
    const paths = deriveContinuityPaths({ stateRoot, workspace: gitWorkspaceRef(repo, "anvil_redux") });
    await mkdir(dirname(paths.currentPath), { recursive: true });
    await writeFile(paths.currentPath, "{ nope", "utf8");
    const anvilHome = await configureBrain(temp);

    const { output } = runContextHook({ cwd: repo, stateRoot, anvilHome });
    const context = output.hookSpecificOutput.additionalContext;

    assert.match(context, /## Anvil Continuity Diagnostic/);
    assert.match(context, /Do not trust/);
    assert.match(context, /Malformed JSON/);
    assert.match(context, /## Brain Context/);
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("ANVIL_BRAIN_CONTEXT=off bypasses Brain without disabling Continuity", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-codex-hook-bypass-"));
  try {
    const repo = join(temp, "anvil_redux");
    const stateRoot = join(temp, "state");
    await mkdir(repo, { recursive: true });
    const paths = deriveContinuityPaths({ stateRoot, workspace: gitWorkspaceRef(repo, "anvil_redux") });
    await initWorkspace(paths, frameInput(), { now: () => "2026-06-03T00:00:00.000Z" });
    const anvilHome = await configureBrain(temp);

    const { output, stderr } = runContextHook({ cwd: repo, stateRoot, anvilHome, brainContext: "off" });
    const context = output.hookSpecificOutput.additionalContext;

    assert.match(context, /## Anvil Continuity Frame/);
    assert.match(context, /anvil_session_bootstrap/);
    assert.doesNotMatch(context, /## Brain Bootstrap/);
    assert.doesNotMatch(context, /I am Rowan/);
    assert.equal(stderr, "");
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("the installed SessionStart command remains a compatibility alias during rollout", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-codex-hook-compat-"));
  try {
    const repo = join(temp, "anvil_redux");
    const stateRoot = join(temp, "state");
    await mkdir(repo, { recursive: true });
    const anvilHome = await configureBrain(temp);

    const current = runContextHook({ cwd: repo, stateRoot, anvilHome });
    const legacy = runContextHook({ cwd: repo, stateRoot, anvilHome, command: "session-start-hook" });

    assert.equal(legacy.stdout, current.stdout);
    assert.equal(legacy.stderr, current.stderr);
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("Codex hook uses the Context Harness as its only Brain delivery route", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-codex-hook-context-harness-"));
  try {
    const repo = join(temp, "anvil_redux");
    const stateRoot = join(temp, "state");
    await mkdir(repo, { recursive: true });
    const anvilHome = await configureBrain(temp);
    await writeFile(
      join(temp, "brain", "compiled-context.json"),
      `${JSON.stringify({
        kind: "compiled_context",
        contract_version: "1",
        evidence: [{ content: "EXACT-KERNEL-RULE" }],
      })}\n`,
      "utf8",
    );

    const result = runContextHook({
      cwd: repo,
      stateRoot,
      anvilHome,
      sessionId: "context-harness-route",
    });

    assert.match(result.output.hookSpecificOutput.additionalContext, /EXACT-KERNEL-RULE/);
    assert.match(result.output.hookSpecificOutput.additionalContext, /## Anvil Continuity Frame/);
    assert.doesNotMatch(result.output.hookSpecificOutput.additionalContext, /I am Rowan, working through the Codex runtime/);
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("Context Harness hook suppresses an already-delivered kernel on the next prompt", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-codex-hook-candidate-retention-"));
  const prompt = "Return the exact prompt evidence.";
  try {
    const repo = join(temp, "anvil_redux");
    const stateRoot = join(temp, "state");
    await mkdir(repo, { recursive: true });
    const anvilHome = await configureBrain(temp);
    await writeFile(
      join(temp, "brain", "compiled-context.json"),
      `${JSON.stringify({
        kind: "compiled_context",
        contract_version: "1",
        evidence: [{ page: "patterns/support.md", content: "placeholder" }],
      })}\n`,
      "utf8",
    );
    await writeFile(
      join(temp, "brain", "fake-llm-wiki.json"),
      `${JSON.stringify({
        mode: "success",
        expected_question: prompt,
        content_by_question: {
          "Provide the durable identity, collaboration, and current-project orientation required at session start.": "EXACT-KERNEL-RULE",
          [prompt]: "EXACT-PROMPT-EVIDENCE",
        },
      })}\n`,
      "utf8",
    );

    runContextHook({
      cwd: repo,
      stateRoot,
      anvilHome,
      sessionId: "candidate-retention",
    });
    const nextPrompt = runContextHook({
      cwd: repo,
      stateRoot,
      anvilHome,
      sessionId: "candidate-retention",
      hookEventName: "UserPromptSubmit",
      prompt,
      prebind: false,
    });

    assert.match(nextPrompt.output.hookSpecificOutput.additionalContext, /EXACT-PROMPT-EVIDENCE/);
    assert.doesNotMatch(nextPrompt.output.hookSpecificOutput.additionalContext, /EXACT-KERNEL-RULE/);
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("Codex Stop hook passes when the Brain maintenance journal has no open incident", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-codex-stop-eligible-"));
  try {
    const repo = join(temp, "repo");
    const stateRoot = join(temp, "state");
    await mkdir(repo, { recursive: true });
    runGit(["init"], repo);

    const result = runStopHook({ cwd: repo, stateRoot });

    assert.equal(result.status, 0, result.stderr);
    assert.equal(result.stdout, "");
    assert.equal(result.stderr, "");
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("Codex Stop hook blocks an unresolved Brain maintenance incident", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-codex-stop-brain-open-"));
  try {
    const repo = join(temp, "repo");
    const stateRoot = join(temp, "state");
    await mkdir(repo, { recursive: true });
    runGit(["init"], repo);
    const incident = await recordBrainUsage({
      cwd: repo,
      stateRoot,
      usage: {
        event: "wrong",
        trigger: "Brain has an obsolete runtime claim.",
        pages: ["projects/anvil-redux.md"],
        severity: "warn",
        session_id: "session_stop_test",
      },
    });
    const noChangeIncident = await recordBrainUsage({
      cwd: repo,
      stateRoot,
      usage: {
        event: "stale",
        trigger: "Possible drift needs Steward review.",
        severity: "warn",
        session_id: "session_stop_test",
      },
    });
    await recordBrainUsage({
      cwd: repo,
      stateRoot,
      usage: {
        event: "not_needed",
        trigger: "Steward review found no durable Brain change.",
        related: [noChangeIncident.record.id],
        outcome: "Live evidence already matches Brain.",
        severity: "info",
        session_id: "session_stop_test",
      },
    });

    const result = runStopHook({ cwd: repo, stateRoot });
    const output = JSON.parse(result.stdout);

    assert.equal(result.status, 0, result.stderr);
    assert.equal(output.decision, "block");
    assert.match(output.reason, new RegExp(incident.record.id));
    assert.match(output.reason, /current main session/i);
    assert.match(output.reason, /updated event related/i);
    assert.match(output.reason, /not_needed event related/i);
    assert.match(output.reason, /Do not launch a child/i);
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("Codex Stop hook passes after an explicitly related Brain resolution", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-codex-stop-brain-closed-"));
  try {
    const repo = join(temp, "repo");
    const stateRoot = join(temp, "state");
    await mkdir(repo, { recursive: true });
    runGit(["init"], repo);
    const incident = await recordBrainUsage({
      cwd: repo,
      stateRoot,
      usage: {
        event: "missed_update",
        trigger: "Durable change was not integrated.",
        severity: "error",
        session_id: "session_stop_test",
      },
    });
    await recordBrainUsage({
      cwd: repo,
      stateRoot,
      usage: {
        event: "updated",
        trigger: "Integrated the durable change.",
        related: [incident.record.id],
        outcome: "Brain change committed and verified.",
        severity: "info",
        session_id: "session_stop_test",
      },
    });
    const noChangeIncident = await recordBrainUsage({
      cwd: repo,
      stateRoot,
      usage: {
        event: "wrong",
        trigger: "Possible contradiction needs Steward review.",
        severity: "warn",
        session_id: "session_stop_test",
      },
    });
    await recordBrainUsage({
      cwd: repo,
      stateRoot,
      usage: {
        event: "not_needed",
        trigger: "Steward review found no durable Brain change.",
        related: [noChangeIncident.record.id],
        outcome: "The apparent contradiction was not durable.",
        severity: "info",
        session_id: "session_stop_test",
      },
    });

    const result = runStopHook({ cwd: repo, stateRoot });

    assert.equal(result.status, 0, result.stderr);
    assert.equal(result.stdout, "");
    assert.equal(result.stderr, "");
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});
