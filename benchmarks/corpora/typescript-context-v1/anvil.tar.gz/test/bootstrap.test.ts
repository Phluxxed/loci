import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import { constants as fsConstants } from "node:fs";
import { access, mkdir, mkdtemp, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { test } from "node:test";

import { bootstrapSession, sessionBootstrapOutputSchema } from "../src/bootstrap/index.ts";
import { ensureBrowserState } from "../src/browser/index.ts";
import { bindWorkContext } from "../src/work-context/index.ts";

async function exists(path: string): Promise<boolean> {
  try {
    await access(path, fsConstants.F_OK);
    return true;
  } catch {
    return false;
  }
}

test("bootstrap reports missing agent identity and does not create user-level state", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-bootstrap-missing-agent-"));
  try {
    const repo = join(temp, "repo");
    const anvilHome = join(temp, ".anvil");
    await mkdir(repo, { recursive: true });

    const output = await bootstrapSession({
      cwd: repo,
      anvilHome,
      env: {},
      homeDir: temp,
    });

    assert.equal(output.workspace.inside_git, false);
    assert.equal(output.brain.configured, false);
    assert.equal(output.brain.setup_required, true);
    assert.equal(output.brain.agent_id_status, "missing");
    assert.equal(output.brain.brain_root_status, "missing_config");
    assert.equal(output.brain.llm_wiki_registration_status, "not_checked");
    assert.match(JSON.stringify(output.warnings), /ANVIL_AGENT_ID/);
    assert.deepEqual(sessionBootstrapOutputSchema.parse(output), output);
    assert.throws(() => sessionBootstrapOutputSchema.parse({ ...output, unexpected: true }));
    assert.equal(await exists(anvilHome), false);
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("bootstrap reports missing Brain config for a configured runtime identity", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-bootstrap-missing-config-"));
  try {
    const repo = join(temp, "repo");
    await mkdir(repo, { recursive: true });

    const output = await bootstrapSession({
      cwd: repo,
      env: { ANVIL_AGENT_ID: "codex" },
      homeDir: temp,
    });

    assert.equal(output.brain.agent_id, "codex");
    assert.equal(output.brain.agent_id_status, "configured");
    assert.equal(output.brain.wiki_alias, "anvil-brain-codex");
    assert.equal(output.brain.configured, false);
    assert.equal(output.brain.setup_required, true);
    assert.equal(output.brain.brain_root_status, "missing_config");
    assert.equal(output.brain.llm_wiki_setup_status, "available");
    assert.equal(output.brain.llm_wiki_registration_status, "not_checked");
    assert.deepEqual(output.brain.suggested_calls[0], {
      tool: "anvil_brain_setup",
      arguments: {
        agentId: "codex",
        mode: "dry_run",
      },
      reason: "Plan creation of the agent-owned Brain wiki before any durable writes.",
      precondition: "Run after ANVIL_AGENT_ID is set for this agent runtime.",
    });
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("bootstrap distinguishes git and non-git folders", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-bootstrap-git-"));
  try {
    const repo = join(temp, "repo");
    await mkdir(repo, { recursive: true });
    const gitInit = spawnSync("git", ["init"], { cwd: repo, encoding: "utf8" });
    assert.equal(gitInit.status, 0, gitInit.stderr);

    const gitOutput = await bootstrapSession({
      cwd: repo,
      env: { ANVIL_AGENT_ID: "codex" },
      homeDir: temp,
    });
    assert.equal(gitOutput.workspace.inside_git, true);
    assert.equal(gitOutput.workspace.git_root, "~/repo");
    assert.equal(gitOutput.workspace.git_remote_status, "missing");
    assert.equal(gitOutput.workspace.identity_confidence, "medium");

    const plainDir = join(temp, "plain");
    await mkdir(plainDir);
    const plainOutput = await bootstrapSession({
      cwd: plainDir,
      env: { ANVIL_AGENT_ID: "codex" },
      homeDir: temp,
    });
    assert.equal(plainOutput.workspace.inside_git, false);
    assert.equal(plainOutput.workspace.git_root, null);
    assert.equal(plainOutput.workspace.identity_confidence, "low");
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("bootstrap leaves Loci indexing decisions to the Loci runtime", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-bootstrap-loci-"));
  try {
    const repo = join(temp, "repo");
    await mkdir(repo, { recursive: true });

    const output = await bootstrapSession({
      cwd: repo,
      env: { ANVIL_AGENT_ID: "codex" },
      homeDir: temp,
    });

    assert.deepEqual(output.loci.suggested_calls, []);
    assert.equal(
      output.suggested_next_calls.some((call) => call.tool === "loci_index"),
      false,
    );
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("bootstrap inspects an existing Work Context binding without creating one", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-bootstrap-work-context-"));
  try {
    const workspace = join(temp, "improvements");
    const stateRoot = join(temp, "state");
    await mkdir(workspace, { recursive: true });
    const { binding } = await bindWorkContext({
      host: "codex",
      sessionId: "session-bootstrap",
      cwd: workspace,
      lifecycle: "SessionStart:startup",
      stateRoot,
    });

    const output = await bootstrapSession({
      cwd: workspace,
      stateRoot,
      bindingId: binding.id,
      env: { ANVIL_AGENT_ID: "codex" },
      homeDir: temp,
    });

    assert.equal(output.work_context.status, "active");
    assert.equal(output.work_context.binding?.id, binding.id);
    assert.equal(output.work_context.binding?.host, "codex");
    assert.equal(output.work_context.binding?.collaboration_space.root, "~/improvements");
    assert.equal("session_id" in (output.work_context.binding ?? {}), false);
    assert.deepEqual(sessionBootstrapOutputSchema.parse(output), output);
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("bootstrap reads existing Brain config without checking llm-wiki registry itself", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-bootstrap-existing-config-"));
  try {
    const repo = join(temp, "repo");
    const anvilHome = join(temp, ".anvil");
    const brainRoot = join(temp, ".anvil-brain", "codex");
    await mkdir(repo, { recursive: true });
    await mkdir(join(anvilHome, "agents", "codex"), { recursive: true });
    await mkdir(brainRoot, { recursive: true });
    await writeFile(
      join(anvilHome, "agents", "codex", "config.json"),
      `${JSON.stringify(
        {
          schema_version: 1,
          agent_id: "codex",
          brain_root: brainRoot,
          wiki_alias: "anvil-brain-codex",
        },
        null,
        2,
      )}\n`,
      "utf8",
    );

    const output = await bootstrapSession({
      cwd: repo,
      anvilHome,
      env: { ANVIL_AGENT_ID: "codex" },
      homeDir: temp,
    });

    assert.equal(output.brain.configured, true);
    assert.equal(output.brain.setup_required, false);
    assert.equal(output.brain.brain_root, "~/.anvil-brain/codex");
    assert.equal(output.brain.brain_root_status, "exists");
    assert.equal(output.brain.llm_wiki_registration_status, "unknown");
    assert.equal(
      output.brain.llm_wiki_registration_note,
      'Call wiki_list through llm-wiki MCP and inspect structuredContent.wikis for the exact configured alias "anvil-brain-codex" and path before inferring registration state; blank text content is not absence evidence.',
    );
    assert.deepEqual(output.brain.suggested_calls.slice(0, 2), [
      {
        tool: "wiki_list",
        arguments: {},
        reason:
          'Inspect structuredContent.wikis for the exact configured Brain alias "anvil-brain-codex" and path before inferring registration state; blank text content is not absence evidence.',
      },
      {
        tool: "wiki_register",
        arguments: {
          alias: "anvil-brain-codex",
          path: "~/.anvil-brain/codex",
          created_by: "anvil",
        },
        reason: "Register the Brain wiki only after its exact alias/path pair is confirmed absent.",
        precondition:
          'Only after the Brain wiki scaffold exists and wiki_list structuredContent.wikis confirms the exact alias/path pair "anvil-brain-codex" -> "~/.anvil-brain/codex" is absent; blank text content is not absence evidence.',
      },
    ]);
    assert.equal(output.brain.suggested_calls.some((call) => call.tool === "wiki_doctor"), true);
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("bootstrap redacts home-relative paths by default and can return local full paths", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-bootstrap-redaction-"));
  try {
    const repo = join(temp, "repo");
    const stateRoot = join(temp, "state");
    await mkdir(repo, { recursive: true });

    const redacted = await bootstrapSession({
      cwd: repo,
      stateRoot,
      env: { ANVIL_AGENT_ID: "codex" },
      homeDir: temp,
    });
    const redactedJson = JSON.stringify(redacted);
    assert.match(redacted.workspace.cwd, /^~\/repo$/);
    assert.doesNotMatch(redactedJson, new RegExp(stateRoot.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")));

    const localFull = await bootstrapSession({
      cwd: repo,
      mode: "local_full",
      env: { ANVIL_AGENT_ID: "codex" },
      homeDir: temp,
    });
    assert.equal(localFull.workspace.cwd, repo);
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("bootstrap keeps output bounded", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-bootstrap-bounds-"));
  try {
    const repo = join(temp, "repo");
    await mkdir(repo, { recursive: true });

    const output = await bootstrapSession({
      cwd: repo,
      env: { ANVIL_AGENT_ID: "codex" },
      homeDir: temp,
    });

    assert.ok(output.warnings.length <= 10);
    assert.ok(output.suggested_next_calls.length <= 10);
    assert.ok(Buffer.byteLength(JSON.stringify(output), "utf8") <= 12_000);
    for (const warning of output.warnings) {
      assert.ok(warning.message.length <= 240);
    }
    for (const call of output.suggested_next_calls) {
      assert.ok(call.reason.length <= 240);
    }
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("bootstrap reports Browser Eyes discovery without starting Docker or exposing secrets", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-bootstrap-browser-"));
  try {
    const repo = join(temp, "repo");
    const anvilHome = join(temp, ".anvil");
    await mkdir(repo, { recursive: true });

    const missing = await bootstrapSession({ cwd: repo, anvilHome, env: { ANVIL_AGENT_ID: "codex" }, homeDir: temp });
    assert.equal(missing.browser.capability_status, "unconfigured");
    assert.equal(missing.browser.default_tool_namespace, "agent-browser");
    assert.equal(missing.browser.corporate_tool_namespace, "agent-browser-corporate");
    assert.equal(missing.browser.suggested_calls[0]?.tool, "anvil browser install");

    await ensureBrowserState({
      anvilHome,
      randomToken: (() => {
        const values = ["4".repeat(64), "5".repeat(64)];
        return () => values.shift()!;
      })(),
    });
    const configured = await bootstrapSession({ cwd: repo, anvilHome, env: { ANVIL_AGENT_ID: "codex" }, homeDir: temp });
    assert.equal(configured.browser.capability_status, "unknown");
    assert.equal(configured.browser.local_profile_status, "configured_not_checked");
    assert.equal(configured.browser.corporate_profile_status, "unconfigured");
    assert.equal(configured.browser.suggested_calls[0]?.tool, "anvil browser status");
    assert.doesNotMatch(JSON.stringify(configured.browser), /4{64}|5{64}|token/i);
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});
