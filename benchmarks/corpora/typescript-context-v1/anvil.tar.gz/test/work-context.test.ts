import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import { mkdir, mkdtemp, realpath, rm, stat, symlink } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join, resolve } from "node:path";
import { test } from "node:test";

import { gitWorkspaceRef } from "../src/continuity/workspace.ts";
import {
  bindWorkContext,
  requireWorkContextBinding,
  resolveCollaborationSpace,
  supersedeWorkContextBinding,
  WorkContextError,
} from "../src/work-context/index.ts";

const anvilBin = resolve("bin/anvil.ts");

function runGit(args: string[], cwd: string): void {
  const result = spawnSync("git", args, { cwd, encoding: "utf8" });
  assert.equal(result.status, 0, result.stderr);
}

test("resolveCollaborationSpace uses the canonical root for a nested Git session", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-work-context-git-"));
  try {
    const repo = join(temp, "repo");
    const nested = join(repo, "src", "nested");
    await mkdir(nested, { recursive: true });
    runGit(["init"], repo);

    const space = await resolveCollaborationSpace(nested);
    const canonicalRepo = await realpath(repo);

    assert.deepEqual(space, gitWorkspaceRef(canonicalRepo));
    assert.equal(space.kind, "git");
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("resolveCollaborationSpace keeps a plain directory as the collaboration space", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-work-context-directory-"));
  try {
    const space = await resolveCollaborationSpace(temp);

    assert.equal(space.root, await realpath(temp));
    assert.equal(space.kind, "directory");
    assert.equal(space.label, temp.split("/").at(-1));
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("resolveCollaborationSpace canonicalizes a symlink before deriving identity", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-work-context-symlink-"));
  try {
    const target = join(temp, "target");
    const link = join(temp, "link");
    await mkdir(target, { recursive: true });
    await symlink(target, link, "dir");

    const direct = await resolveCollaborationSpace(target);
    const throughLink = await resolveCollaborationSpace(link);

    assert.deepEqual(throughLink, direct);
    assert.equal(throughLink.kind, "directory");
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("bindWorkContext creates and idempotently refreshes one session binding", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-work-context-bind-"));
  try {
    const workspace = join(temp, "workspace");
    const stateRoot = join(temp, "state");
    await mkdir(workspace, { recursive: true });

    const first = await bindWorkContext({
      host: "codex",
      sessionId: "session-bind",
      cwd: workspace,
      lifecycle: "startup",
      stateRoot,
      now: () => "2026-07-16T00:00:00.000Z",
    });
    const resumed = await bindWorkContext({
      host: "codex",
      sessionId: "session-bind",
      cwd: workspace,
      lifecycle: "resume",
      stateRoot,
      now: () => "2026-07-16T01:00:00.000Z",
    });

    assert.equal(first.created, true);
    assert.equal(resumed.created, false);
    assert.equal(resumed.binding.id, first.binding.id);
    assert.equal(resumed.binding.bound_at, first.binding.bound_at);
    assert.equal(resumed.binding.last_seen_at, "2026-07-16T01:00:00.000Z");
    assert.equal(resumed.binding.collaboration_space.kind, "directory");
    assert.equal(resumed.binding.collaboration_space.root, await realpath(workspace));
    assert.doesNotMatch(resumed.binding.id, /session-bind/);
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("Work Context binding state is private to the local user", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-work-context-permissions-"));
  try {
    const workspace = join(temp, "workspace");
    const stateRoot = join(temp, "state");
    await mkdir(workspace, { recursive: true });
    const { binding } = await bindWorkContext({
      host: "codex",
      sessionId: "session-private-state",
      cwd: workspace,
      lifecycle: "SessionStart:startup",
      stateRoot,
    });
    const bindingsDir = join(stateRoot, "work-context", "bindings");
    const bindingPath = join(bindingsDir, `${binding.id}.json`);

    assert.equal((await stat(bindingsDir)).mode & 0o777, 0o700);
    assert.equal((await stat(bindingPath)).mode & 0o777, 0o600);
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("bindWorkContext rejects collaboration-space drift for an existing session", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-work-context-mismatch-"));
  try {
    const firstWorkspace = join(temp, "first");
    const secondWorkspace = join(temp, "second");
    const stateRoot = join(temp, "state");
    await mkdir(firstWorkspace, { recursive: true });
    await mkdir(secondWorkspace, { recursive: true });

    await bindWorkContext({
      host: "codex",
      sessionId: "session-mismatch",
      cwd: firstWorkspace,
      lifecycle: "startup",
      stateRoot,
    });

    await assert.rejects(
      () =>
        bindWorkContext({
          host: "codex",
          sessionId: "session-mismatch",
          cwd: secondWorkspace,
          lifecycle: "resume",
          stateRoot,
        }),
      (error: unknown) => error instanceof WorkContextError && error.code === "WORK_CONTEXT_MISMATCH",
    );
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("bindWorkContext serializes concurrent resumes", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-work-context-concurrent-"));
  try {
    const workspace = join(temp, "workspace");
    const stateRoot = join(temp, "state");
    await mkdir(workspace, { recursive: true });

    const bindings = await Promise.all(
      Array.from({ length: 8 }, () =>
        bindWorkContext({
          host: "codex",
          sessionId: "session-concurrent",
          cwd: workspace,
          lifecycle: "startup",
          stateRoot,
          now: () => "2026-07-16T02:00:00.000Z",
        }),
      ),
    );

    assert.equal(new Set(bindings.map((item) => item.binding.id)).size, 1);
    assert.equal(bindings.filter((item) => item.created).length, 1);
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("requireWorkContextBinding fails closed for missing and stale bindings", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-work-context-stale-"));
  try {
    const workspace = join(temp, "workspace");
    const stateRoot = join(temp, "state");
    await mkdir(workspace, { recursive: true });

    await assert.rejects(
      () => requireWorkContextBinding({ bindingId: "wctx_missing", stateRoot }),
      (error: unknown) => error instanceof WorkContextError && error.code === "WORK_CONTEXT_NOT_BOUND",
    );

    const { binding } = await bindWorkContext({
      host: "codex",
      sessionId: "session-stale",
      cwd: workspace,
      lifecycle: "startup",
      stateRoot,
      now: () => "2026-07-16T00:00:00.000Z",
      maxAgeMs: 1_000,
    });

    await assert.rejects(
      () =>
        requireWorkContextBinding({
          bindingId: binding.id,
          stateRoot,
          now: () => "2026-07-16T00:00:02.000Z",
        }),
      (error: unknown) => error instanceof WorkContextError && error.code === "WORK_CONTEXT_STALE",
    );
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("supersedeWorkContextBinding preserves the old binding but prevents its use", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-work-context-supersede-"));
  try {
    const workspace = join(temp, "workspace");
    const stateRoot = join(temp, "state");
    await mkdir(workspace, { recursive: true });

    const oldBinding = await bindWorkContext({
      host: "codex",
      sessionId: "session-old",
      cwd: workspace,
      lifecycle: "startup",
      stateRoot,
    });
    const replacement = await bindWorkContext({
      host: "codex",
      sessionId: "session-new",
      cwd: workspace,
      lifecycle: "startup",
      stateRoot,
    });

    const superseded = await supersedeWorkContextBinding({
      bindingId: oldBinding.binding.id,
      replacementBindingId: replacement.binding.id,
      stateRoot,
      now: () => "2026-07-16T03:00:00.000Z",
    });

    assert.equal(superseded.status, "superseded");
    assert.equal(superseded.superseded_by, replacement.binding.id);
    await assert.rejects(
      () => requireWorkContextBinding({ bindingId: oldBinding.binding.id, stateRoot }),
      (error: unknown) => error instanceof WorkContextError && error.code === "WORK_CONTEXT_STALE",
    );
    assert.equal((await requireWorkContextBinding({ bindingId: replacement.binding.id, stateRoot })).status, "active");
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("work-context read CLI inspects a binding without exposing the session id", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-work-context-cli-"));
  try {
    const workspace = join(temp, "workspace");
    const stateRoot = join(temp, "state");
    await mkdir(workspace, { recursive: true });
    const { binding } = await bindWorkContext({
      host: "codex",
      sessionId: "session-cli",
      cwd: workspace,
      lifecycle: "SessionStart:startup",
      stateRoot,
    });

    const result = spawnSync(
      process.execPath,
      [anvilBin, "work-context", "read", "--binding-id", binding.id, "--json"],
      {
        cwd: resolve("."),
        env: { ...process.env, ANVIL_STATE_ROOT: stateRoot },
        encoding: "utf8",
      },
    );

    assert.equal(result.status, 0, result.stderr);
    const output = JSON.parse(result.stdout) as { host: string; session_id?: string; id: string };
    assert.equal(output.id, binding.id);
    assert.equal(output.host, "codex");
    assert.equal(output.session_id, undefined);
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});
