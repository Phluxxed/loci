import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { test } from 'node:test';
import {
  base, caseNames, contextLimits, control, followupHooks, hash, inspect, pathRules, prepare, probe, read, save, settings,
} from '../scripts/brain-w4-followup-prepare.mjs';
import { checkHooks } from '../scripts/brain-host-smoke.mjs';

test('follow-up context handlers preserve Anvil envelopes and preflight pins the host limits', () => {
  const command = '/reviewed/follow-up-hook';
  const overrides = followupHooks(command);
  const events = { SessionStart: 'sessionStart', UserPromptSubmit: 'userPromptSubmit', PreToolUse: 'preToolUse', Stop: 'stop' };
  const hooks = Object.entries(overrides).map(([key, groups]) => ({
    ...groups[0].hooks[0], eventName: events[key.slice('hooks.'.length)],
    enabled: true, source: 'sessionFlags', trustStatus: 'trusted',
    additionalContextLimit: groups[0].hooks[0].additionalContextLimit ?? null,
  }));
  assert.deepEqual(hooks.map(h => h.additionalContextLimit), [8192, 8192, null, null]);
  assert.equal(checkHooks([{ errors: [], hooks }], command, true, contextLimits).length, 4);
  for (const additionalContextLimit of [null, 0, 2500, 8193]) {
    const changed = hooks.map(h => h.eventName === 'userPromptSubmit' ? { ...h, additionalContextLimit } : h);
    assert.throws(() => checkHooks([{ errors: [], hooks: changed }], command, true, contextLimits), /Unexpected host context limit/);
  }
  const untrusted = hooks.map(h => ({ ...h, trustStatus: 'untrusted' }));
  assert.throws(() => checkHooks([{ errors: [], hooks: untrusted }], command, true, contextLimits), /Review this exact test hook/);
  // Historical smoke callers retain the original default-limit contract.
  assert.throws(() => checkHooks([{ errors: [], hooks }], command), /Unexpected host context limit/);
});

test('follow-up preparation is pinned to exactly one unresolved case in a fresh root', () => {
  assert.deepEqual(caseNames, ['c01']);
  assert.equal(base, '/Users/brummerv/phluxxed/brain-w4-closure-2026-09-09');
  assert.equal(control, '/Users/brummerv/phluxxed/workbench/.scratch/brain-w4-closure-2026-09-09');
  assert.throws(() => settings('k01'), /Unknown follow-up case/);
  assert.throws(() => settings('p01'), /Unknown follow-up case/);
  assert.throws(() => settings('r01'), /Unknown follow-up case/);
  assert.equal(typeof prepare, 'function');
  assert.equal(typeof inspect, 'function');
  assert.equal(typeof probe, 'function');
});

test('fresh permissions deny previous runs, answer keys and consumed roots', () => {
  const siblings = caseNames.map(name => base + '/execution/' + name);
  for (const name of caseNames) {
    const root = base + '/execution/' + name;
    const s = { name, root, workspace: root + '/workspace', brain: root + '/brain' };
    const rules = pathRules(s, siblings, '/reviewed/codex', []);
    assert.equal(rules[s.brain], 'write');
    assert.equal(rules[s.brain + '/.git'], 'write');
    assert.notEqual(rules[s.workspace + '/.git'], 'write');
    for (const path of [
      control, root + '/captures', root + '/settings.json',
      ...siblings.filter(path => path !== root),
      '/Users/brummerv/phluxxed/brain-w41-isolated-2026-09-08',
      '/Users/brummerv/phluxxed/brain-w4-followup-2026-09-08',
      '/Users/brummerv/phluxxed/brain-w4-followup-2026-09-09',
      '/Users/brummerv/phluxxed/brain-w4-recheck-2026-09-09',
    ]) {
      assert.equal(rules[path], 'deny', path);
      assert.equal(rules[path + '/**'], 'deny', path);
    }
  }
});

test('read/save are JSON helpers with exclusive writes and hash is SHA-256', () => {
  const root = mkdtempSync(join(tmpdir(), 'brain-w4-followup-prepare-'));
  try {
    const path = join(root, 'record.json');
    save(path, { name: 'c01', modelRuns: 0 });
    assert.deepEqual(read(path), { name: 'c01', modelRuns: 0 });
    assert.equal(hash(path), createHash('sha256').update(readFileSync(path)).digest('hex'));
    assert.throws(() => save(path, { overwritten: true }), /EEXIST/);
  } finally {
    rmSync(root, { recursive: true, force: true });
  }
});

test('preparation module does not expose a model-run mode or mutate on import', () => {
  const source = readFileSync(new URL('../scripts/brain-w4-followup-prepare.mjs', import.meta.url), 'utf8');
  assert(!/mode\s*===\s*['"]run['"]/.test(source));
  assert(!source.includes('codex exec'));
});
