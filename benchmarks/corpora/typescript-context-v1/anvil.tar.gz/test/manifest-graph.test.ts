import assert from "node:assert/strict";
import { test } from "node:test";

import {
  applyObjectiveChange,
  deriveObjective,
  taskIdSchema,
  validateObjective,
  workstreamIdSchema,
} from "../src/manifest/index.ts";

const objective = {
  id: "obj_11111111111111111111111111111111",
  title: "Manifest V2",
  outcome: "Accepted work remains explicit while it is implemented.",
  details: "One repository-owned Objective graph.",
  phase: "planning",
  workstreams: [
    {
      id: "ws_22222222222222222222222222222222",
      title: "Recovered graph module",
      outcome: "One module owns graph validity, derivation, and change.",
      details: "W1",
      tasks: [
        {
          id: "task_33333333333333333333333333333333",
          title: "Validate the canonical graph",
          outcome: "Invalid work graphs cannot become canonical.",
          details: "Use the approved reduced shape.",
          completionCriteria: ["The canonical Objective graph validates."],
          dependencies: [],
          externalBlocker: null,
          completion: null,
          discontinued: null,
          tasks: [],
        },
      ],
    },
  ],
} as const;

test("a canonical Objective graph validates through the public Manifest interface", () => {
  assert.deepEqual(validateObjective(objective), {
    valid: true,
    graph: objective,
  });
});

test("Task decomposition is recursive and execution remains on leaf Tasks", () => {
  const leaf = {
    ...objective.workstreams[0].tasks[0],
    id: "task_44444444444444444444444444444444",
    title: "Deep executable leaf",
  } as const;
  const child = {
    ...objective.workstreams[0].tasks[0],
    title: "Nested decomposition",
    completionCriteria: [],
    tasks: [leaf],
  } as const;
  const graph = {
    ...objective,
    phase: "implementation",
    workstreams: [{ ...objective.workstreams[0], tasks: [child] }],
  } as const;

  const validated = validateObjective(graph);
  assert.equal(validated.valid, true);
  if (!validated.valid) return;
  const view = deriveObjective(validated.graph);

  assert.deepEqual(view.tasks.map((task) => task.title), ["Nested decomposition", "Deep executable leaf"]);
  assert.equal(view.tasks[0]!.available, false);
  assert.match(view.tasks[0]!.reasons[0]!, /decomposed/);
  assert.equal(view.tasks[1]!.available, true);
  assert.deepEqual(view.progress.workstreams[0], {
    id: validated.graph.workstreams[0]!.id,
    total: 1,
    required: 1,
    completed: 0,
    discontinued: 0,
    complete: false,
  });
});

test("duplicate Stable Graph Identities are reported without accepting the graph", () => {
  const duplicate = {
    ...objective,
    workstreams: [
      ...objective.workstreams,
      {
        ...objective.workstreams[0],
        id: "ws_44444444444444444444444444444444",
      },
    ],
  } as const;

  const result = validateObjective(duplicate);
  assert.equal(result.valid, false);
  if (result.valid) return;
  assert.deepEqual(result.problems, [{
    path: "$.workstreams[1].tasks[0].id",
    message: "Duplicate Stable Graph Identity: task_33333333333333333333333333333333.",
  }]);
});

test("invalid dependency endpoints and duplicate edges are reported together", () => {
  const invalidDependencies = {
    ...objective,
    workstreams: [{
      ...objective.workstreams[0],
      tasks: [{
        ...objective.workstreams[0].tasks[0],
        dependencies: [
          "task_33333333333333333333333333333333",
          "task_99999999999999999999999999999999",
          "task_99999999999999999999999999999999",
        ],
      }],
    }],
  } as const;

  const result = validateObjective(invalidDependencies);
  assert.equal(result.valid, false);
  if (result.valid) return;
  assert.deepEqual(result.problems, [
    {
      path: "$.workstreams[0].tasks[0].dependencies[0]",
      message: "A Task cannot depend on itself.",
    },
    {
      path: "$.workstreams[0].tasks[0].dependencies[1]",
      message: "Dependency endpoint does not exist in this Objective: task_99999999999999999999999999999999.",
    },
    {
      path: "$.workstreams[0].tasks[0].dependencies[2]",
      message: "Dependency endpoint does not exist in this Objective: task_99999999999999999999999999999999.",
    },
    {
      path: "$.workstreams[0].tasks[0].dependencies[2]",
      message: "Duplicate Work Dependency: task_99999999999999999999999999999999.",
    },
  ]);
});

test("Work Dependencies cannot cross Workstreams", () => {
  const crossWorkstream = {
    ...objective,
    workstreams: [
      objective.workstreams[0],
      {
        id: "ws_44444444444444444444444444444444",
        title: "Human interface",
        outcome: "The Human view remains independently executable.",
        details: "W5",
        tasks: [{
          ...objective.workstreams[0].tasks[0],
          id: "task_55555555555555555555555555555555",
          title: "Connect the Human view",
          dependencies: [objective.workstreams[0].tasks[0].id],
        }],
      },
    ],
  } as const;

  const result = validateObjective(crossWorkstream);
  assert.equal(result.valid, false);
  if (result.valid) return;
  assert.deepEqual(result.problems, [{
    path: "$.workstreams[1].tasks[0].dependencies[0]",
    message: "Work Dependency cannot cross Workstreams: task_33333333333333333333333333333333.",
  }]);
});

test("cyclic Work Dependencies are rejected", () => {
  const firstTask = {
    ...objective.workstreams[0].tasks[0],
    dependencies: ["task_44444444444444444444444444444444"],
  } as const;
  const secondTask = {
    ...objective.workstreams[0].tasks[0],
    id: "task_44444444444444444444444444444444",
    title: "Derive the graph",
    dependencies: [firstTask.id],
  } as const;
  const cyclic = {
    ...objective,
    workstreams: [{
      ...objective.workstreams[0],
      tasks: [firstTask, secondTask],
    }],
  } as const;

  const result = validateObjective(cyclic);
  assert.equal(result.valid, false);
  if (result.valid) return;
  assert.deepEqual(result.problems, [{
    path: "$.workstreams[0].tasks[0].dependencies",
    message: "Work Dependencies contain a cycle: task_33333333333333333333333333333333 -> task_44444444444444444444444444444444 -> task_33333333333333333333333333333333.",
  }]);
});

test("Task completion requires evidence for every current criterion", () => {
  const invalidCompletion = {
    ...objective,
    workstreams: [{
      ...objective.workstreams[0],
      tasks: [{
        ...objective.workstreams[0].tasks[0],
        completion: {
          evidence: [{
            criterion: "A retired criterion.",
            summary: "This does not prove the current criterion.",
            references: ["test/manifest-graph.test.ts"],
          }],
        },
        discontinued: { reason: "No longer required." },
      }],
    }],
  } as const;

  const result = validateObjective(invalidCompletion);
  assert.equal(result.valid, false);
  if (result.valid) return;
  assert.deepEqual(result.problems, [
    {
      path: "$.workstreams[0].tasks[0].completion.evidence[0].criterion",
      message: "Completion evidence names a criterion that is not current: A retired criterion.",
    },
    {
      path: "$.workstreams[0].tasks[0].completion.evidence",
      message: "Completion evidence is missing for criterion: The canonical Objective graph validates.",
    },
    {
      path: "$.workstreams[0].tasks[0].discontinued",
      message: "A completed Task cannot also be discontinued.",
    },
  ]);
});

test("execution state and Workstream progress derive from current graph facts", () => {
  const first = {
    ...objective.workstreams[0].tasks[0],
    completion: {
      evidence: [{
        criterion: objective.workstreams[0].tasks[0].completionCriteria[0],
        summary: "The canonical graph passed its focused test.",
        references: ["test/manifest-graph.test.ts"],
      }],
    },
  } as const;
  const second = {
    ...objective.workstreams[0].tasks[0],
    id: "task_44444444444444444444444444444444",
    title: "Derive availability",
    dependencies: [first.id],
  } as const;
  const blocked = {
    ...objective.workstreams[0].tasks[0],
    id: "task_55555555555555555555555555555555",
    title: "Connect the file adapter",
    externalBlocker: "The graph Module is not stable yet.",
  } as const;
  const discontinued = {
    ...objective.workstreams[0].tasks[0],
    id: "task_66666666666666666666666666666666",
    title: "Build a second state database",
    discontinued: { reason: "Git owns durable state." },
  } as const;
  const graph = validateObjective({
    ...objective,
    phase: "implementation",
    workstreams: [{
      ...objective.workstreams[0],
      tasks: [first, second, blocked, discontinued],
    }],
  });
  assert.equal(graph.valid, true);
  if (!graph.valid) return;

  const view = deriveObjective(graph.graph);
  assert.deepEqual(view.available.map((task) => task.id), [second.id]);
  assert.equal(view.next?.task.id, second.id);
  assert.deepEqual(view.choices, []);
  assert.deepEqual(view.blockers, [{ taskId: blocked.id, reason: blocked.externalBlocker }]);
  assert.deepEqual(view.progress.workstreams, [{
    id: objective.workstreams[0].id,
    total: 4,
    required: 3,
    completed: 1,
    discontinued: 1,
    complete: false,
  }]);
  assert.deepEqual(view.tasks.find((task) => task.id === second.id)?.position, {
    workstreamIndex: 0,
    siblingIndex: 1,
  });
  assert.equal(view.next?.candidateCount, 1);
  assert.equal(view.tasks.find((task) => task.id === discontinued.id)?.available, false);
});

test("all-discontinued Workstreams complete visibly while empty Workstreams do not", () => {
  const discontinuedTask = {
    ...objective.workstreams[0].tasks[0],
    discontinued: { reason: "No longer needed." },
  } as const;
  const graph = validateObjective({
    ...objective,
    phase: "implementation",
    workstreams: [
      { ...objective.workstreams[0], tasks: [discontinuedTask] },
      {
        ...objective.workstreams[0],
        id: "ws_77777777777777777777777777777777",
        title: "Empty after replanning",
        tasks: [],
      },
    ],
  });
  assert.equal(graph.valid, true);
  if (!graph.valid) return;

  assert.deepEqual(deriveObjective(graph.graph).progress, {
    complete: false,
    workstreams: [
      {
        id: objective.workstreams[0].id,
        total: 1,
        required: 0,
        completed: 0,
        discontinued: 1,
        complete: true,
      },
      {
        id: "ws_77777777777777777777777777777777",
        total: 0,
        required: 0,
        completed: 0,
        discontinued: 0,
        complete: false,
      },
    ],
  });
});

test("Current is a session projection and its unique Available dependent is Next", () => {
  const current = {
    ...objective.workstreams[0].tasks[0],
    completion: {
      evidence: [{
        criterion: objective.workstreams[0].tasks[0].completionCriteria[0],
        summary: "Validation passed.",
        references: ["node --test test/manifest-graph.test.ts"],
      }],
    },
  } as const;
  const dependent = {
    ...objective.workstreams[0].tasks[0],
    id: "task_44444444444444444444444444444444",
    title: "Dependent",
    dependencies: [current.id],
  } as const;
  const unrelated = {
    ...objective.workstreams[0].tasks[0],
    id: "task_55555555555555555555555555555555",
    title: "Unrelated",
  } as const;
  const graph = validateObjective({
    ...objective,
    phase: "implementation",
    workstreams: [{ ...objective.workstreams[0], tasks: [current, dependent, unrelated] }],
  });
  assert.equal(graph.valid, true);
  if (!graph.valid) return;

  const withoutCurrent = deriveObjective(graph.graph);
  assert.equal(withoutCurrent.next, null);
  assert.deepEqual(withoutCurrent.choices.map((task) => task.id), [dependent.id, unrelated.id]);

  const withCurrent = deriveObjective(graph.graph, {
    currentTaskId: graph.graph.workstreams[0]!.tasks[0]!.id,
  });
  assert.equal(withCurrent.current?.id, current.id);
  assert.equal(withCurrent.current?.complete, true);
  assert.equal(withCurrent.current?.available, false);
  assert.equal(withCurrent.next?.task.id, dependent.id);
  assert.deepEqual(withCurrent.choices, []);
});

test("an incomplete Current Task keeps its graph status but is excluded from Available", () => {
  const second = {
    ...objective.workstreams[0].tasks[0],
    id: "task_44444444444444444444444444444444",
    title: "Second Task",
  } as const;
  const graph = validateObjective({
    ...objective,
    phase: "implementation",
    workstreams: [{
      ...objective.workstreams[0],
      tasks: [objective.workstreams[0].tasks[0], second],
    }],
  });
  assert.equal(graph.valid, true);
  if (!graph.valid) return;
  const currentTaskId = graph.graph.workstreams[0]!.tasks[0]!.id;

  const view = deriveObjective(graph.graph, { currentTaskId });
  assert.equal(view.current?.complete, false);
  assert.equal(view.current?.available, false);
  assert.deepEqual(view.available.map((task) => task.id), [graph.graph.workstreams[0]!.tasks[1]!.id]);
  assert.deepEqual(view.current?.reasons, ["Task is Current and excluded from Available choices."]);
});

test("one semantic change atomically adds related Work and enters Implementation", () => {
  const validated = validateObjective(objective);
  assert.equal(validated.valid, true);
  if (!validated.valid) return;

  const newWorkstreamId = workstreamIdSchema.parse("ws_77777777777777777777777777777777");
  const newPrerequisiteId = taskIdSchema.parse("task_88888888888888888888888888888888");
  const newTaskId = taskIdSchema.parse("task_99999999999999999999999999999999");
  const result = applyObjectiveChange(validated.graph, {
    addWorkstreams: [{
      id: newWorkstreamId,
      title: "Objective file adapter",
      outcome: "The graph lives with the thing being built.",
      details: "W2",
      after: validated.graph.workstreams[0]!.id,
    }],
    addTasks: [{
      id: newPrerequisiteId,
      workstream: newWorkstreamId,
      title: "Prepare canonical JSON",
      outcome: "The graph is ready for deterministic serialization.",
      details: "",
      decompositionComplete: true,
      completionCriteria: ["A valid graph is ready to serialize."],
      after: null,
      dependencies: [],
    }, {
      id: newTaskId,
      workstream: newWorkstreamId,
      title: "Write canonical JSON",
      outcome: "Semantic edits become reviewable Git diffs.",
      details: "",
      completionCriteria: ["A valid edit is written atomically."],
      after: newPrerequisiteId,
      dependencies: [newPrerequisiteId],
    }],
    update: [{ id: validated.graph.id, set: { phase: "implementation" } }],
  });

  assert.equal(result.applied, true);
  if (!result.applied) return;
  assert.equal(validated.graph.phase, "planning");
  assert.equal(result.graph.phase, "implementation");
  assert.deepEqual(result.graph.workstreams.map((workstream) => workstream.id), [
    objective.workstreams[0].id,
    newWorkstreamId,
  ]);
  assert.deepEqual(result.graph.workstreams[1]?.tasks[1]?.dependencies, [
    newPrerequisiteId,
  ]);
  assert.equal(result.graph.workstreams[1]?.tasks[0]?.decompositionComplete, true);
  assert.equal(result.view.tasks.find((task) => task.id === newTaskId)?.available, false);
});

test("only leaf Tasks store decomposition completion", () => {
  const candidate = structuredClone(objective) as any;
  candidate.workstreams[0].tasks[0].decompositionComplete = true;
  candidate.workstreams[0].tasks[0].tasks = [{
    ...candidate.workstreams[0].tasks[0],
    id: "task_99999999999999999999999999999999",
    decompositionComplete: false,
    tasks: [],
  }];
  const validated = validateObjective(candidate);
  assert.equal(validated.valid, false);
  if (validated.valid) return;
  assert.equal(validated.problems.some((problem) =>
    problem.path.endsWith(".decompositionComplete") && problem.message.includes("leaf Task")
  ), true);
});

test("semantic graph edits can decompose a Task beneath another Task", () => {
  const validated = validateObjective(objective);
  assert.equal(validated.valid, true);
  if (!validated.valid) return;
  const parent = validated.graph.workstreams[0]!.tasks[0]!;
  const childId = taskIdSchema.parse("task_88888888888888888888888888888888");

  const result = applyObjectiveChange(validated.graph, {
    addTasks: [{
      id: childId,
      parent: parent.id,
      title: "Decomposed child",
      outcome: "The parent can be decomposed as far as the work requires.",
      completionCriteria: ["The recursive child is represented."],
      after: null,
    }],
  });

  assert.equal(result.applied, true);
  if (!result.applied) return;
  assert.equal(result.graph.workstreams[0]!.tasks[0]!.tasks[0]!.id, childId);
});

test("an invalid semantic change returns the exact unchanged graph", () => {
  const validated = validateObjective(objective);
  assert.equal(validated.valid, true);
  if (!validated.valid) return;
  const missingTaskId = taskIdSchema.parse("task_99999999999999999999999999999999");
  const taskId = validated.graph.workstreams[0]!.tasks[0]!.id;

  const result = applyObjectiveChange(validated.graph, {
    update: [{ id: validated.graph.id, set: { title: "This must not leak" } }],
    setDependencies: [{ task: taskId, prerequisites: [missingTaskId] }],
  });

  assert.equal(result.applied, false);
  if (result.applied) return;
  assert.equal(result.graph, validated.graph);
  assert.equal(result.graph.title, objective.title);
  assert.deepEqual(result.problems, [{
    path: "$.workstreams[0].tasks[0].dependencies[0]",
    message: `Dependency endpoint does not exist in this Objective: ${missingTaskId}.`,
  }]);
});

test("one semantic change can split and reorder Work before removing the empty source", () => {
  const secondTask = {
    ...objective.workstreams[0].tasks[0],
    id: "task_44444444444444444444444444444444",
    title: "Second Task",
  } as const;
  const validated = validateObjective({
    ...objective,
    workstreams: [{
      ...objective.workstreams[0],
      tasks: [objective.workstreams[0].tasks[0], secondTask],
    }],
  });
  assert.equal(validated.valid, true);
  if (!validated.valid) return;
  const source = validated.graph.workstreams[0]!;
  const first = source.tasks[0]!;
  const second = source.tasks[1]!;
  const destinationId = workstreamIdSchema.parse("ws_77777777777777777777777777777777");

  const result = applyObjectiveChange(validated.graph, {
    addWorkstreams: [{
      id: destinationId,
      title: "Split Workstream",
      outcome: "Related Work has its own structural branch.",
      after: source.id,
    }],
    place: [
      { id: second.id, parent: destinationId, after: null },
      { id: first.id, parent: destinationId, after: second.id },
    ],
    removeEmptyWorkstreams: [source.id],
  });

  assert.equal(result.applied, true);
  if (!result.applied) return;
  assert.deepEqual(result.graph.workstreams.map((workstream) => workstream.id), [destinationId]);
  assert.deepEqual(result.graph.workstreams[0]?.tasks.map((task) => task.id), [second.id, first.id]);
});
