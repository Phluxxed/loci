import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { rmSync } from 'node:fs';
import test from 'node:test';
import { checkGitProbe, gitCommitPreflight, gitProbeOverrides } from '../scripts/brain-git-permission-probe.mjs';

const settings = { brain: '/case/brain', workspace: '/case/workspace', overrides: {
  approval_policy: 'never', default_permissions: 'w4_followup',
  'permissions.w4_followup': { filesystem: {
    '/': 'read', '/case/brain': 'write', '/case/brain/.git': 'write', '/case/workspace': 'write',
    '/live-brain': 'deny', '/case/captures': 'deny',
  }, network: { enabled: true } },
} };

test('Git probe changes only the disposable path roots and the exact Brain Git grant', () => {
  const paths = { brain: '/probe/brain', workspace: '/probe/workspace' };
  const before = structuredClone(settings);
  const baseline = gitProbeOverrides(settings, paths, false);
  const candidate = gitProbeOverrides(settings, paths, true);
  const rules = candidate['permissions.w4_followup'].filesystem;
  assert.equal(rules['/probe/brain/.git'], 'write');
  assert.equal(rules['/probe/workspace/.git'], undefined);
  assert.equal(rules['/probe/brain/.codex'], undefined);
  assert.equal(rules['/probe/brain/.agents'], undefined);
  delete rules['/probe/brain/.git'];
  assert.deepEqual(candidate, baseline);
  assert.equal(rules['/live-brain'], 'deny');
  assert.equal(rules['/case/captures'], 'deny');
  assert.equal(rules['/case/brain'], undefined);
  assert.equal(candidate.approval_policy, 'never');
  assert.deepEqual(settings, before);
});

const output = observed => ({ status: 0, signal: null, stdout: JSON.stringify(observed), stderr: '' });
const success = () => ({ gitWritable: true, commit: 'a'.repeat(40), clean: true,
  protectedDenied: ['workspace/.git/index', 'brain/.codex/protected', 'brain/.agents/protected'].map(path => ({ path, denied: true, code: 'EPERM' })) });

test('Git probe rejects unproven commit, dirty result, writable protected paths, or sandbox failures', () => {
  assert.equal(checkGitProbe(output({ gitWritable: false }), false).passed, true);
  assert.equal(checkGitProbe(output(success()), true).passed, true);
  assert.equal(checkGitProbe(output({ gitWritable: true }), false).passed, false);
  for (const mutate of [
    r => { r.gitWritable = false; }, r => { delete r.commit; }, r => { r.clean = false; },
    r => { r.protectedDenied.pop(); }, r => { r.protectedDenied[0].denied = false; },
    r => { r.protectedDenied[0].code = 'ENOENT'; },
  ]) { const r = success(); mutate(r); assert.equal(checkGitProbe(output(r), true).passed, false); }
  assert.equal(checkGitProbe({ status: 71, stdout: '', stderr: 'sandbox_apply: Operation not permitted' }, false).passed, false);
  assert.equal(checkGitProbe({ status: 0, stdout: 'malformed', stderr: '' }, true).passed, false);
});

test('preflight exercises baseline then candidate without model or actual case mutations', t => {
  const seen = [];
  const report = gitCommitPreflight(settings, '/pinned/codex', (command, args, options) => {
    assert.equal(command, '/pinned/codex');
    assert.equal(args[0], 'sandbox');
    assert.equal(args[args.indexOf('-P') + 1], 'w4_followup');
    const input = JSON.parse(args.at(-1));
    assert.equal(options.cwd, input.workspace);
    assert.notEqual(input.brain, settings.brain);
    assert.match(input.brain, /brain-git-permission-/);
    seen.push(input.allowGit);
    return input.allowGit ? output(success()) : output({ gitWritable: false });
  });
  t.after(() => rmSync(report.directory, { recursive: true, force: true }));
  assert.deepEqual(seen, [false, true]);
  assert.equal(report.passed, true);
  assert.equal(report.modelRuns, 0);
  const status = spawnSync('git', ['-C', report.directory + '/brain', 'status', '--porcelain'], { encoding: 'utf8' });
  assert.equal(status.status, 0);
  assert.equal(status.stdout, '');
});

test('a blocked baseline stops before candidate execution', t => {
  let calls = 0;
  const report = gitCommitPreflight(settings, '/pinned/codex', () => {
    calls++;
    return { status: 71, stdout: '', stderr: 'sandbox_apply: Operation not permitted' };
  });
  t.after(() => rmSync(report.directory, { recursive: true, force: true }));
  assert.equal(calls, 1);
  assert.equal(report.passed, false);
  assert.equal(report.candidate, null);
});
