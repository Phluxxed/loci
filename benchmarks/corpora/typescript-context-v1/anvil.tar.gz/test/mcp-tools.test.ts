import assert from "node:assert/strict";
import { mkdir, mkdtemp, realpath, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { dirname, join } from "node:path";
import { test } from "node:test";

import * as z from "zod/v4";

import {
  deriveContinuityPaths,
  gitWorkspaceRef,
  initWorkspace,
  MAX_EVENT_DETAILS_CHARS,
  MAX_EVENT_SUMMARY_CHARS,
  readRecentEvents,
} from "../src/continuity/index.ts";
import type { CurrentFrameInput } from "../src/continuity/index.ts";
import {
  brainUsageLogInputSchema,
  brainUsageLogOutputSchema,
  brainUsageMetricsOutputSchema,
  brainUsageReadInputSchema,
  brainUsageReadOutputSchema,
  brainSetupOutputSchema,
  continuityCheckpointTaskInputSchema,
  continuityCheckpointTaskOutputSchema,
  continuityPromoteEventOutputSchema,
  continuityPromoteEventInputSchema,
  continuityRecordEventInputSchema,
  continuityRecordEventOutputSchema,
  continuityReadOutputSchema,
  continuityRetireProjectionItemInputSchema,
  continuityRetireProjectionItemOutputSchema,
  handleBrainSetup,
  handleBrainUsageLog as handleBoundBrainUsageLog,
  handleBrainUsageMetrics,
  handleBrainUsageRead,
  handleSkillInvocationLog as handleBoundSkillInvocationLog,
  handleSkillInvocationAuditSample,
  handleSkillInvocationRead,
  handleSessionBootstrap,
  handleWorkContextRead,
  handleContinuityCheckpointTask as handleBoundContinuityCheckpointTask,
  handleContinuityPromoteEvent as handleBoundContinuityPromoteEvent,
  handleContinuityRead,
  handleContinuityRecordEvent as handleBoundContinuityRecordEvent,
  handleContinuityRetireProjectionItem as handleBoundContinuityRetireProjectionItem,
  skillInvocationLogInputSchema,
  skillInvocationLogOutputSchema,
  skillInvocationAuditSampleInputSchema,
  skillInvocationAuditSampleOutputSchema,
  skillInvocationReadInputSchema,
  skillInvocationReadOutputSchema,
  sessionBootstrapOutputSchema,
  workContextReadOutputSchema,
} from "../src/mcp/tools.ts";
import { bindWorkContext } from "../src/work-context/index.ts";
import type { WorkContextBinding } from "../src/work-context/index.ts";
import { readBrainUsage } from "../src/brain-usage/index.ts";
import { readSkillInvocations } from "../src/skill-invocations/index.ts";

const handlerBindings = new Map<string, WorkContextBinding>();

async function handlerBinding(cwd: string, stateRoot: string, sessionId?: string): Promise<WorkContextBinding> {
  const key = `${stateRoot}\0${cwd}`;
  const existing = handlerBindings.get(key);
  if (existing) return existing;
  const { binding } = await bindWorkContext({
    host: "codex",
    sessionId: sessionId ?? `session_mcp_${handlerBindings.size}`,
    cwd,
    lifecycle: "SessionStart:startup",
    stateRoot,
  });
  handlerBindings.set(key, binding);
  return binding;
}

type BoundRecordArgs = Parameters<typeof handleBoundContinuityRecordEvent>[0];
type BoundCheckpointArgs = Parameters<typeof handleBoundContinuityCheckpointTask>[0];
type BoundPromoteArgs = Parameters<typeof handleBoundContinuityPromoteEvent>[0];
type BoundRetireArgs = Parameters<typeof handleBoundContinuityRetireProjectionItem>[0];
type BoundBrainUsageArgs = Parameters<typeof handleBoundBrainUsageLog>[0];
type BoundSkillInvocationArgs = Parameters<typeof handleBoundSkillInvocationLog>[0];
type BrainUsageRuntimeOptions = {
  anvilHome?: string;
  env?: Record<string, string | undefined>;
  homeDir?: string;
};
type LegacyRecordArgs = {
  cwd: string;
  stateRoot: string;
  event: BoundRecordArgs["event"];
  source?: BoundRecordArgs["source"] & { sessionId?: string };
};
type LegacyCheckpointArgs = {
  cwd: string;
  stateRoot: string;
  checkpointId: BoundCheckpointArgs["checkpointId"];
  task: BoundCheckpointArgs["task"];
  source?: BoundCheckpointArgs["source"];
};
type LegacyPromoteArgs = {
  cwd: string;
  stateRoot: string;
  eventId: BoundPromoteArgs["eventId"];
  target: BoundPromoteArgs["target"];
  mode?: BoundPromoteArgs["mode"];
};
type LegacyRetireArgs = {
  cwd: string;
  stateRoot: string;
  target: BoundRetireArgs["target"];
  eventId?: BoundRetireArgs["eventId"];
  summary?: BoundRetireArgs["summary"];
  correctionEventId?: BoundRetireArgs["correctionEventId"];
};

async function handleContinuityRecordEvent(args: LegacyRecordArgs) {
  const { cwd, stateRoot, source, ...eventArgs } = args;
  const binding = await handlerBinding(cwd, stateRoot, source?.sessionId);
  return handleBoundContinuityRecordEvent(
    {
      ...eventArgs,
      bindingId: binding.id,
      ...(source
        ? {
            source: {
              ...(source.turnId !== undefined ? { turnId: source.turnId } : {}),
              ...(source.description !== undefined ? { description: source.description } : {}),
            },
          }
        : {}),
    },
    { stateRoot },
  );
}

async function handleContinuityCheckpointTask(args: LegacyCheckpointArgs) {
  const { cwd, stateRoot, ...checkpointArgs } = args;
  const binding = await handlerBinding(cwd, stateRoot);
  return handleBoundContinuityCheckpointTask({ ...checkpointArgs, bindingId: binding.id }, { stateRoot });
}

async function handleContinuityPromoteEvent(args: LegacyPromoteArgs) {
  const { cwd, stateRoot, ...promoteArgs } = args;
  const binding = await handlerBinding(cwd, stateRoot);
  return handleBoundContinuityPromoteEvent({ ...promoteArgs, bindingId: binding.id }, { stateRoot });
}

async function handleContinuityRetireProjectionItem(args: LegacyRetireArgs) {
  const { cwd, stateRoot, ...retireArgs } = args;
  const binding = await handlerBinding(cwd, stateRoot);
  return handleBoundContinuityRetireProjectionItem({ ...retireArgs, bindingId: binding.id }, { stateRoot });
}

async function handleBrainUsageLog(
  args: Pick<
    BoundBrainUsageArgs,
    | "event"
    | "trigger"
    | "brain"
    | "pages"
    | "related"
    | "outcome"
    | "severity"
    | "triggerBucket"
    | "turnId"
    | "messageId"
    | "mcpCallId"
  > & { cwd: string; stateRoot: string; sessionId?: string },
  runtime: BrainUsageRuntimeOptions = {},
) {
  const { cwd, stateRoot, sessionId, ...usageArgs } = args;
  const binding = await handlerBinding(cwd, stateRoot, sessionId);
  return handleBoundBrainUsageLog({ ...usageArgs, bindingId: binding.id }, { stateRoot, ...runtime });
}

async function handleSkillInvocationLog(
  args: Pick<BoundSkillInvocationArgs, "skill" | "trigger" | "outcome" | "reason" | "turnId" | "messageId"> & {
    cwd: string;
    stateRoot: string;
    sessionId?: string;
  },
) {
  const { cwd, stateRoot, sessionId, ...invocationArgs } = args;
  const binding = await handlerBinding(cwd, stateRoot, sessionId);
  return handleBoundSkillInvocationLog({ ...invocationArgs, bindingId: binding.id }, { stateRoot });
}

test("MCP Continuity mutation schemas require bindings and expose no routing paths", () => {
  const bindingId = "wctx_00000000000000000000000000000000";
  assert.doesNotThrow(() =>
    continuityRecordEventInputSchema.parse({
      bindingId,
      event: { type: "decision", summary: "Bound mutation." },
    }),
  );
  assert.doesNotThrow(() =>
    continuityRecordEventInputSchema.parse({
      bindingId,
      cwd: "/tmp/override",
      event: { type: "decision", summary: "Legacy override." },
    }),
  );
  assert.throws(() =>
    continuityPromoteEventInputSchema.parse({ eventId: "evt_1", target: "active_decisions" }),
  );
  assert.doesNotThrow(() =>
    continuityCheckpointTaskInputSchema.parse({
      bindingId,
      checkpointId: "checkpoint-1",
      task: { state: "active", summary: "Restore task carryover.", nextStep: "Verify SessionStart." },
    }),
  );
  assert.doesNotThrow(() =>
    continuityRetireProjectionItemInputSchema.parse({
      bindingId,
      stateRoot: "/tmp/override",
      target: "active_decisions",
      summary: "Legacy override.",
    }),
  );
  for (const schema of [
    continuityRecordEventInputSchema,
    continuityCheckpointTaskInputSchema,
    continuityPromoteEventInputSchema,
    continuityRetireProjectionItemInputSchema,
  ]) {
    assert.equal("cwd" in schema.shape, false);
    assert.equal("stateRoot" in schema.shape, false);
  }
});

test("MCP task checkpoint handler returns the active task and rendered readback", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-mcp-active-task-"));
  try {
    const cwd = join(temp, "repo");
    const stateRoot = join(temp, "state");
    await mkdir(cwd, { recursive: true });
    const result = await handleContinuityCheckpointTask({
      cwd,
      stateRoot,
      checkpointId: "mcp-active-task-1",
      task: {
        state: "active",
        summary: "Restore active-task Continuity.",
        nextStep: "Exercise the SessionStart consumer.",
      },
      source: { description: "focused MCP acceptance" },
    });
    assert.equal(result.isError, undefined);
    const output = continuityCheckpointTaskOutputSchema.parse(result.structuredContent);
    assert.equal(output.frame.active_task?.summary, "Restore active-task Continuity.");
    assert.match(output.rendered, /Exercise the SessionStart consumer/);
    assert.throws(() => continuityCheckpointTaskOutputSchema.parse({ ...output, paths: {} }));
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("MCP Continuity mutations fail closed when no binding exists", async () => {
  const result = await handleBoundContinuityRecordEvent(
    {
      bindingId: "wctx_00000000000000000000000000000000",
      event: { type: "decision", summary: "Must not write." },
    },
    { stateRoot: join(tmpdir(), "anvil-missing-work-context") },
  );
  assert.equal(result.isError, true);
  assert.equal(
    (result.structuredContent as { error: { code: string } }).error.code,
    "WORK_CONTEXT_NOT_BOUND",
  );
});

test("MCP Continuity mutations reject legacy routing with WORK_CONTEXT_MISMATCH", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-mcp-routing-mismatch-"));
  try {
    const workspace = join(temp, "improvements");
    const stateRoot = join(temp, "state");
    await mkdir(workspace, { recursive: true });
    const { binding } = await bindWorkContext({
      host: "codex",
      sessionId: "session-routing-mismatch",
      cwd: workspace,
      lifecycle: "SessionStart:startup",
      stateRoot,
    });

    const result = await handleBoundContinuityRecordEvent(
      {
        bindingId: binding.id,
        event: { type: "decision", summary: "Must not route from cwd." },
        cwd: join(temp, "anvil_redux"),
      },
      { stateRoot },
    );

    assert.equal(result.isError, true);
    assert.equal(
      (result.structuredContent as { error: { code: string } }).error.code,
      "WORK_CONTEXT_MISMATCH",
    );
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("MCP Work Context inspection returns bounded public binding provenance", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-mcp-work-context-"));
  try {
    const workspace = join(temp, "improvements");
    const stateRoot = join(temp, "state");
    await mkdir(workspace, { recursive: true });
    const { binding } = await bindWorkContext({
      host: "codex",
      sessionId: "session-inspect",
      cwd: workspace,
      lifecycle: "SessionStart:startup",
      stateRoot,
    });

    const result = await handleWorkContextRead({ bindingId: binding.id }, { stateRoot });

    assert.equal(result.isError, undefined);
    const output = workContextReadOutputSchema.parse(result.structuredContent);
    assert.equal(output.binding.id, binding.id);
    assert.equal(output.binding.status, "active");
    assert.equal(output.binding.host, "codex");
    assert.equal("session_id" in output.binding, false);
    assert.equal(output.binding.collaboration_space.root, await realpath(workspace));
    assert.equal(output.binding.provenance.lifecycle, "SessionStart:startup");
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("MCP Work Context inspection distinguishes unknown and stale bindings", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-mcp-work-context-errors-"));
  try {
    const workspace = join(temp, "workspace");
    const stateRoot = join(temp, "state");
    await mkdir(workspace, { recursive: true });

    const missing = await handleWorkContextRead(
      { bindingId: "wctx_00000000000000000000000000000000" },
      { stateRoot },
    );
    const { binding } = await bindWorkContext({
      host: "codex",
      sessionId: "session-stale-inspect",
      cwd: workspace,
      lifecycle: "SessionStart:startup",
      stateRoot,
      now: () => "2026-07-15T00:00:00.000Z",
      maxAgeMs: 1_000,
    });
    const stale = await handleWorkContextRead(
      { bindingId: binding.id },
      { stateRoot, now: () => "2026-07-15T00:00:02.000Z" },
    );

    assert.equal((missing.structuredContent as { error: { code: string } }).error.code, "WORK_CONTEXT_NOT_BOUND");
    assert.equal((stale.structuredContent as { error: { code: string } }).error.code, "WORK_CONTEXT_STALE");
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

async function writeBrainConfig(anvilHome: string, agentId: string, wikiAlias: string): Promise<void> {
  const path = join(anvilHome, "agents", agentId, "config.json");
  await mkdir(dirname(path), { recursive: true });
  await writeFile(
    path,
    `${JSON.stringify({
      schema_version: 1,
      agent_id: agentId,
      brain_root: join(anvilHome, "brains", agentId),
      wiki_alias: wikiAlias,
    })}\n`,
    "utf8",
  );
}

test("MCP skill invocation schemas preserve the canonical journal bounds", () => {
  const logSchema = skillInvocationLogInputSchema;
  const readSchema = z.object(skillInvocationReadInputSchema);
  const auditSchema = z.object(skillInvocationAuditSampleInputSchema);

  const bindingId = "wctx_00000000000000000000000000000000";
  assert.throws(() => logSchema.parse({ bindingId, skill: "spark-shape", trigger: "Valid trigger." }));
  assert.throws(() =>
    logSchema.parse({ bindingId, skill: "spark-shape", trigger: "Valid trigger.", outcome: "used" }),
  );
  assert.throws(() => logSchema.parse({ bindingId, skill: "spark-shape", trigger: "Valid trigger.", outcome: "ignored" }));
  assert.throws(() => logSchema.parse({ bindingId, skill: "x".repeat(129), trigger: "Valid trigger." }));
  assert.throws(() => logSchema.parse({ bindingId, skill: "spark-shape", trigger: "x".repeat(501) }));
  assert.throws(() => readSchema.parse({ limit: 201 }));
  assert.throws(() => readSchema.parse({ offset: -1 }));
  assert.throws(() => auditSchema.parse({ seed: "2026-W29", size: 26 }));
  assert.doesNotThrow(() =>
    logSchema.parse({
      bindingId,
      skill: "spark-shape",
      trigger: "Valid trigger.",
      outcome: "used",
      reason: "The skill shaped the implementation boundary.",
      turnId: "turn-1",
      messageId: "message-1",
    }),
  );
  assert.equal("cwd" in logSchema.shape, false);
  assert.equal("stateRoot" in logSchema.shape, false);
});

test("MCP manual journal logging rejects caller-selected workspace paths", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-mcp-journal-routing-"));
  try {
    const workspace = join(temp, "improvements");
    const stateRoot = join(temp, "state");
    await mkdir(workspace, { recursive: true });
    const binding = await handlerBinding(workspace, stateRoot, "session-journal-routing");

    const brain = await handleBoundBrainUsageLog(
      {
        bindingId: binding.id,
        cwd: join(temp, "anvil_redux"),
        event: "used",
        trigger: "Must not redirect Brain evidence.",
      },
      { stateRoot },
    );
    const skill = await handleBoundSkillInvocationLog(
      {
        bindingId: binding.id,
        stateRoot: join(temp, "override-state"),
        skill: "agent-skills:using-agent-skills",
        trigger: "Must not redirect skill evidence.",
        outcome: "used",
        reason: "The routing guard must reject the caller-selected state root.",
      },
      { stateRoot },
    );

    assert.equal((brain.structuredContent as { error: { code: string } }).error.code, "WORK_CONTEXT_MISMATCH");
    assert.equal((skill.structuredContent as { error: { code: string } }).error.code, "WORK_CONTEXT_MISMATCH");
    assert.equal((await readBrainUsage({ cwd: workspace, stateRoot })).kind, "missing");
    assert.equal((await readSkillInvocations({ cwd: workspace, stateRoot })).kind, "missing");
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("MCP skill invocation handlers share the canonical workspace journal", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-mcp-skill-invocations-"));
  try {
    const repo = join(temp, "repo");
    const stateRoot = join(temp, "state");
    await mkdir(repo, { recursive: true });

    const first = await handleSkillInvocationLog({
      cwd: repo,
      stateRoot,
      skill: "spark-shape",
      trigger: "Vik brought a half-formed Anvil idea.",
      outcome: "used",
      reason: "The frontmatter matched the shaping request.",
      sessionId: "session-skill-mcp",
      turnId: "turn-skill-1",
      messageId: "message-skill-1",
    });
    const second = await handleSkillInvocationLog({
      cwd: repo,
      stateRoot,
      skill: "agent-skills:browser-testing-with-devtools",
      trigger: "A browser change was reviewed without a runtime browser check.",
      outcome: "missed",
      reason: "The required runtime browser verification was skipped.",
      sessionId: "session-skill-mcp",
      turnId: "turn-skill-2",
      messageId: "message-skill-2",
    });

    assert.equal(first.isError, undefined);
    assert.equal(second.isError, undefined);
    const firstOutput = skillInvocationLogOutputSchema.parse(first.structuredContent);
    assert.equal("paths" in firstOutput, false);
    assert.throws(() => skillInvocationLogOutputSchema.parse({ ...firstOutput, paths: {} }));
    assert.equal(firstOutput.record.skill, "spark-shape");
    assert.equal(firstOutput.record.outcome, "used");
    assert.equal(firstOutput.record.reason, "The frontmatter matched the shaping request.");
    assert.equal(firstOutput.record.host, "codex");
    assert.equal(firstOutput.record.session_id, "session-skill-mcp");
    assert.equal(firstOutput.record.turn_id, "turn-skill-1");

    const read = await handleSkillInvocationRead({ cwd: repo, stateRoot, limit: 1, outcome: "missed" });
    assert.equal(read.isError, undefined);
    const readOutput = skillInvocationReadOutputSchema.parse(read.structuredContent);
    assert.equal(readOutput.kind, "ok");
    assert.equal(readOutput.total, 2);
    assert.equal(readOutput.truncated, false);
    assert.equal(readOutput.summary.matching, 1);
    assert.deepEqual(readOutput.summary.outcomes, { used: 0, missed: 1, false_positive: 0 });
    assert.deepEqual(readOutput.pagination, { offset: 0, limit: 1, returned: 1, next_offset: null });
    assert.deepEqual(readOutput.items.map((item) => [item.skill, item.outcome]), [
      ["agent-skills:browser-testing-with-devtools", "missed"],
    ]);

    const audit = await handleSkillInvocationAuditSample({
      cwd: repo,
      stateRoot,
      seed: "2026-W29",
      size: 1,
    });
    assert.equal(audit.isError, undefined);
    const auditOutput = skillInvocationAuditSampleOutputSchema.parse(audit.structuredContent);
    assert.equal(auditOutput.kind, "ok");
    assert.equal(auditOutput.eligible, 2);
    assert.equal(auditOutput.items.length, 1);
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("MCP Brain usage schemas reject automatic events and enforce journal bounds", () => {
  const logSchema = brainUsageLogInputSchema;
  const readSchema = z.object(brainUsageReadInputSchema);

  const bindingId = "wctx_00000000000000000000000000000000";
  assert.throws(() => logSchema.parse({ bindingId, event: "recalled", trigger: "Hook-owned event." }));
  assert.throws(() => logSchema.parse({ bindingId, event: "used", trigger: "x".repeat(501) }));
  assert.throws(() =>
    logSchema.parse({ bindingId, event: "used", trigger: "Bounded pages.", pages: Array.from({ length: 21 }, () => "page.md") }),
  );
  assert.throws(() => readSchema.parse({ limit: 201 }));
  assert.equal("cwd" in logSchema.shape, false);
  assert.equal("stateRoot" in logSchema.shape, false);
  assert.equal("recall_observation" in logSchema.shape, false);
});

test("MCP Brain usage handlers share canonical logging, bounded reads, and aggregate metrics", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-mcp-brain-usage-"));
  try {
    const firstRepo = join(temp, "first-repo");
    const secondRepo = join(temp, "second-repo");
    const stateRoot = join(temp, "state");
    const anvilHome = join(temp, "anvil-home");
    const runtime = { anvilHome, env: { ANVIL_AGENT_ID: "codex" } };
    await mkdir(firstRepo, { recursive: true });
    await mkdir(secondRepo, { recursive: true });
    await writeBrainConfig(anvilHome, "codex", "anvil-brain-codex");

    const first = await handleBrainUsageLog({
      cwd: firstRepo,
      stateRoot,
      event: "used",
      trigger: "Brain context changed the implementation boundary.",
      brain: "anvil-brain-codex",
      pages: ["entities/anvil-mcp.md"],
      outcome: "Kept one canonical Brain usage core.",
      sessionId: "session-1",
      turnId: "turn-1",
      mcpCallId: "mcp-call-1",
    }, runtime);
    const second = await handleBrainUsageLog({
      cwd: secondRepo,
      stateRoot,
      event: "stale",
      trigger: "A second workspace found stale Brain context.",
      severity: "warn",
    }, runtime);

    assert.equal(first.isError, undefined);
    assert.equal(second.isError, undefined);
    const firstOutput = brainUsageLogOutputSchema.parse(first.structuredContent);
    assert.equal("paths" in firstOutput, false);
    assert.throws(() => brainUsageLogOutputSchema.parse({ ...firstOutput, paths: {} }));
    assert.equal(firstOutput.record.event, "used");
    assert.equal(firstOutput.record.session_id, "session-1");
    assert.equal(firstOutput.record.brain_id, "agent:codex");
    assert.equal(firstOutput.record.brain_alias, "anvil-brain-codex");
    assert.equal(firstOutput.record.mcp_call_id, "mcp-call-1");
    assert.equal(firstOutput.record.prompt_raw, undefined);
    assert.equal(firstOutput.record.prompt_excerpt, undefined);
    assert.equal(firstOutput.record.recall_observation, undefined);

    const mismatch = await handleBrainUsageLog({
      cwd: firstRepo,
      stateRoot,
      event: "used",
      trigger: "Caller labels cannot redefine Brain identity.",
      brain: "another-brain",
    }, runtime);
    assert.equal(mismatch.isError, true);
    assert.equal(
      (mismatch.structuredContent as { error: { code: string } }).error.code,
      "BRAIN_IDENTITY_HINT_MISMATCH",
    );

    const metrics = await handleBrainUsageMetrics({ cwd: firstRepo, stateRoot }, runtime);
    assert.equal(metrics.isError, undefined);
    const metricsOutput = brainUsageMetricsOutputSchema.parse(metrics.structuredContent);
    if (metricsOutput.kind !== "ok") throw new Error(`Expected ok Brain usage metrics, got ${metricsOutput.kind}`);
    assert.equal(metricsOutput.total, 2);
    assert.equal(metricsOutput.coverage.total, 1);
    assert.equal(metricsOutput.incidents.total, 1);
    assert.deepEqual(metricsOutput.by_brain, { "agent:codex": 2 });
    assert.equal(metricsOutput.recall.eligible_total, 0);
    assert.equal(metricsOutput.recall.success.rate, null);
    assert.equal(metricsOutput.recall.payload_bytes.attempted.count, 0);
    assert.equal(metricsOutput.recall.limit_bytes.guidance.count, 0);
    assert.equal(metricsOutput.recall.limit_bytes.payload.count, 0);

    const read = await handleBrainUsageRead({ cwd: firstRepo, stateRoot, limit: 1 });
    assert.equal(read.isError, undefined);
    const readOutput = brainUsageReadOutputSchema.parse(read.structuredContent);
    if (readOutput.kind !== "ok") throw new Error(`Expected ok Brain usage read, got ${readOutput.kind}`);
    assert.equal(readOutput.total, 2);
    assert.equal(readOutput.truncated, true);
    assert.deepEqual(readOutput.items.map((item) => item.event), ["stale"]);
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

function frameInput(): CurrentFrameInput {
  return {
    operating_mode: "mcp-test",
    intent: "Verify Anvil MCP continuity tools.",
    quality_bar: ["Continuity is not truth."],
    permission_envelope: {
      default: "follow current instruction",
      allowed_without_approval: ["read continuity state"],
      requires_approval: ["delete continuity history"],
    },
    active_decisions: [],
    open_questions: [],
    next_actions: [],
    continuity_notes: [],
  };
}

test("MCP read handler returns missing continuity without creating state", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-mcp-read-missing-"));
  try {
    const repo = join(temp, "repo");
    const stateRoot = join(temp, "state");
    await mkdir(repo, { recursive: true });

    const result = await handleContinuityRead({ cwd: repo, stateRoot, includeEvents: true });

    assert.equal(result.isError, undefined);
    const output = continuityReadOutputSchema.parse(result.structuredContent);
    assert.equal("paths" in output, false);
    assert.throws(() => continuityReadOutputSchema.parse({ ...output, paths: {} }));
    assert.equal(output.current.kind, "missing");
    assert.equal(output.events?.kind, "missing");
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("MCP bootstrap handler returns read-only routing status", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-mcp-bootstrap-"));
  try {
    const repo = join(temp, "repo");
    const stateRoot = join(temp, "state");
    const anvilHome = join(temp, ".anvil");
    await mkdir(repo, { recursive: true });

    const result = await handleSessionBootstrap({
      cwd: repo,
      stateRoot,
      anvilHome,
      agentId: "codex",
      mode: "local_full",
    });

    assert.equal(result.isError, undefined);
    const output = sessionBootstrapOutputSchema.parse(result.structuredContent);
    assert.equal(output.brain.agent_id_status, "configured");
    assert.equal(output.brain.setup_required, true);
    assert.equal(output.brain.brain_root_status, "missing_config");
    assert.equal(output.continuity.current_frame_status, "missing");
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("MCP bootstrap handler reports validation errors with the standard error shape", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-mcp-bootstrap-validation-"));
  try {
    const repo = join(temp, "repo");
    await mkdir(repo, { recursive: true });

    const result = await handleSessionBootstrap({
      cwd: repo,
      agentId: "Codex",
    });

    assert.equal(result.isError, true);
    const output = result.structuredContent as { error: { code: string; message: string } };
    assert.equal(output.error.code, "VALIDATION_ERROR");
    assert.match(output.error.message, /agentId/);
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("MCP Brain setup handler returns a dry-run plan by default", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-mcp-brain-setup-"));
  try {
    const anvilHome = join(temp, ".anvil");
    const brainRoot = join(temp, ".anvil-brain", "codex");

    const result = await handleBrainSetup({
      anvilHome,
      brainRoot,
      agentId: "codex",
    });

    assert.equal(result.isError, undefined);
    const output = brainSetupOutputSchema.parse(result.structuredContent);
    assert.equal(output.status, "planned");
    assert.equal(output.resolved_agent_id, "codex");
    assert.match(output.plan_hash, /^[a-f0-9]{64}$/);
    assert.match(output.acknowledgement_token, /^ack-anvil-brain-/);
    assert.equal(output.llm_wiki_setup_action.kind, "wikime_setup");
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("MCP Brain setup handler reports validation errors with the standard error shape", async () => {
  const result = await handleBrainSetup({
    agentId: "codex",
    wikiAlias: "Bad Alias",
  });

  assert.equal(result.isError, true);
  const output = result.structuredContent as { error: { code: string; message: string } };
  assert.equal(output.error.code, "VALIDATION_ERROR");
  assert.match(output.error.message, /wikiAlias/);
});

test("MCP record and promote handlers preserve event lineage", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-mcp-record-promote-"));
  try {
    const repo = join(temp, "repo");
    const stateRoot = join(temp, "state");
    await mkdir(repo, { recursive: true });
    const paths = deriveContinuityPaths({ stateRoot, workspace: gitWorkspaceRef(repo, "repo") });
    await initWorkspace(paths, frameInput(), { now: () => "2026-06-03T00:00:00.000Z" });

    const recorded = await handleContinuityRecordEvent({
      cwd: repo,
      stateRoot,
      event: {
        type: "decision",
        summary: "MCP v0 writes durable events before projection.",
      },
      source: {
        sessionId: "session_test",
        turnId: "turn_test",
        description: "unit test",
      },
    });

    assert.equal(recorded.isError, undefined);
    const recordedOutput = continuityRecordEventOutputSchema.parse(recorded.structuredContent);
    assert.equal("paths" in recordedOutput, false);
    assert.throws(() => continuityRecordEventOutputSchema.parse({ ...recordedOutput, paths: {} }));
    assert.equal(recordedOutput.event.source.kind, "codex_mcp");
    assert.equal(recordedOutput.event.source.session_id, "session_test");

    const promoted = await handleContinuityPromoteEvent({
      cwd: repo,
      stateRoot,
      eventId: recordedOutput.event.id,
      target: "active_decisions",
    });

    assert.equal(promoted.isError, undefined);
    const promotedOutput = continuityPromoteEventOutputSchema.parse(promoted.structuredContent);
    assert.equal("paths" in promotedOutput, false);
    assert.throws(() => continuityPromoteEventOutputSchema.parse({ ...promotedOutput, paths: {} }));
    assert.equal(promotedOutput.changed, true);
    assert.equal(promotedOutput.frame.active_decisions[0].event_id, recordedOutput.event.id);

    const events = await readRecentEvents(paths, 10);
    if (events.kind !== "ok") throw new Error(`Expected events, got ${events.kind}`);
    assert.equal(events.events.length, 1);
    assert.equal(events.events[0].source.kind, "codex_mcp");
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("MCP record handler rejects oversized event text", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-mcp-record-bounds-"));
  try {
    const repo = join(temp, "repo");
    const stateRoot = join(temp, "state");
    await mkdir(repo, { recursive: true });
    const paths = deriveContinuityPaths({ stateRoot, workspace: gitWorkspaceRef(repo, "repo") });
    await initWorkspace(paths, frameInput(), { now: () => "2026-06-03T00:00:00.000Z" });

    const oversizedSummary = await handleContinuityRecordEvent({
      cwd: repo,
      stateRoot,
      event: {
        type: "decision",
        summary: "x".repeat(MAX_EVENT_SUMMARY_CHARS + 1),
      },
    });
    assert.equal(oversizedSummary.isError, true);
    const summaryOutput = oversizedSummary.structuredContent as { error: { code: string; message: string } };
    assert.equal(summaryOutput.error.code, "VALIDATION_ERROR");
    assert.match(summaryOutput.error.message, /summary.*500/);

    const oversizedDetails = await handleContinuityRecordEvent({
      cwd: repo,
      stateRoot,
      event: {
        type: "decision",
        summary: "Details are too long.",
        details: "x".repeat(MAX_EVENT_DETAILS_CHARS + 1),
      },
    });
    assert.equal(oversizedDetails.isError, true);
    const detailsOutput = oversizedDetails.structuredContent as { error: { code: string; message: string } };
    assert.equal(detailsOutput.error.code, "VALIDATION_ERROR");
    assert.match(detailsOutput.error.message, /details.*4000/);
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("MCP promote handler returns a tool error for missing event", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-mcp-promote-error-"));
  try {
    const repo = join(temp, "repo");
    const stateRoot = join(temp, "state");
    await mkdir(repo, { recursive: true });
    const paths = deriveContinuityPaths({ stateRoot, workspace: gitWorkspaceRef(repo, "repo") });
    await initWorkspace(paths, frameInput(), { now: () => "2026-06-03T00:00:00.000Z" });

    const result = await handleContinuityPromoteEvent({
      cwd: repo,
      stateRoot,
      eventId: "evt_missing",
      target: "active_decisions",
    });

    assert.equal(result.isError, true);
    const output = result.structuredContent as { error: { code: string } };
    assert.equal(output.error.code, "EVENT_NOT_FOUND");
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("MCP promote handler rejects non-active events for active compact-frame targets", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-mcp-promote-status-error-"));
  try {
    const repo = join(temp, "repo");
    const stateRoot = join(temp, "state");
    await mkdir(repo, { recursive: true });
    const paths = deriveContinuityPaths({ stateRoot, workspace: gitWorkspaceRef(repo, "repo") });
    await initWorkspace(paths, frameInput(), { now: () => "2026-06-03T00:00:00.000Z" });

    const recorded = await handleContinuityRecordEvent({
      cwd: repo,
      stateRoot,
      event: {
        type: "decision",
        status: "resolved",
        summary: "Resolved decision should stay out of active decisions.",
      },
    });
    const recordedOutput = recorded.structuredContent as { event: { id: string } };

    const result = await handleContinuityPromoteEvent({
      cwd: repo,
      stateRoot,
      eventId: recordedOutput.event.id,
      target: "active_decisions",
    });

    assert.equal(result.isError, true);
    const output = result.structuredContent as { error: { code: string; message: string } };
    assert.equal(output.error.code, "VALIDATION_ERROR");
    assert.match(output.error.message, /resolved/);
    assert.match(output.error.message, /active_decisions/);
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("MCP retire projection handler removes event-linked items with correction lineage", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-mcp-retire-projection-"));
  try {
    const repo = join(temp, "repo");
    const stateRoot = join(temp, "state");
    await mkdir(repo, { recursive: true });
    const paths = deriveContinuityPaths({ stateRoot, workspace: gitWorkspaceRef(repo, "repo") });
    await initWorkspace(paths, frameInput(), { now: () => "2026-06-03T00:00:00.000Z" });

    const recorded = await handleContinuityRecordEvent({
      cwd: repo,
      stateRoot,
      event: {
        type: "decision",
        summary: "Projected decision to retire.",
      },
    });
    const recordedOutput = recorded.structuredContent as { event: { id: string } };

    await handleContinuityPromoteEvent({
      cwd: repo,
      stateRoot,
      eventId: recordedOutput.event.id,
      target: "active_decisions",
    });

    const correction = await handleContinuityRecordEvent({
      cwd: repo,
      stateRoot,
      event: {
        type: "correction",
        summary: "Projected decision no longer belongs in the compact frame.",
      },
    });
    const correctionOutput = correction.structuredContent as { event: { id: string } };

    const retired = await handleContinuityRetireProjectionItem({
      cwd: repo,
      stateRoot,
      target: "active_decisions",
      eventId: recordedOutput.event.id,
      correctionEventId: correctionOutput.event.id,
    });

    assert.equal(retired.isError, undefined);
    const output = continuityRetireProjectionItemOutputSchema.parse(retired.structuredContent);
    assert.equal("paths" in output, false);
    assert.throws(() => continuityRetireProjectionItemOutputSchema.parse({ ...output, paths: {} }));
    assert.equal(output.changed, true);
    assert.equal(output.removedItem?.event_id, recordedOutput.event.id);
    assert.equal(output.correctionEvent?.id, correctionOutput.event.id);
    assert.deepEqual(output.frame.active_decisions, []);
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("MCP retire projection handler returns validation errors for unsafe event-linked removals", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-mcp-retire-projection-error-"));
  try {
    const repo = join(temp, "repo");
    const stateRoot = join(temp, "state");
    await mkdir(repo, { recursive: true });
    const paths = deriveContinuityPaths({ stateRoot, workspace: gitWorkspaceRef(repo, "repo") });
    await initWorkspace(paths, frameInput(), { now: () => "2026-06-03T00:00:00.000Z" });

    const result = await handleContinuityRetireProjectionItem({
      cwd: repo,
      stateRoot,
      target: "active_decisions",
      eventId: "evt_missing_correction",
    });

    assert.equal(result.isError, true);
    const output = result.structuredContent as { error: { code: string } };
    assert.equal(output.error.code, "VALIDATION_ERROR");
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});
