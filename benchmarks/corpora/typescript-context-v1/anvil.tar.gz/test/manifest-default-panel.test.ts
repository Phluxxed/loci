import assert from "node:assert/strict";
import { test } from "node:test";

import { buildManifestHumanView, validateObjective } from "../src/manifest/index.ts";

const leaf = (id: string, title: string, criterion: string, complete = false, dependencies: string[] = []) => ({
  id, title, outcome: title, details: "", completionCriteria: [criterion], dependencies,
  externalBlocker: null, completion: complete ? { evidence: [{ criterion, summary: "Verified.", references: ["test"] }] } : null,
  discontinued: null, tasks: [],
});

const graph = {
  id: "obj_aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", title: "Default panel", outcome: "Render the graph.", details: "",
  phase: "implementation",
  workstreams: [
    { id: "ws_bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb", title: "Nested stream", outcome: "Walk leaves.", details: "", tasks: [{
      id: "task_99999999999999999999999999999999", title: "Parent task", outcome: "Group leaves.", details: "",
      completionCriteria: [], dependencies: [], externalBlocker: null, completion: null, discontinued: null,
      tasks: [
        leaf("task_11111111111111111111111111111111", "Completed leaf", "Completed leaf criterion.", true),
        leaf("task_22222222222222222222222222222222", "Upcoming leaf", "Upcoming leaf criterion.", false, ["task_11111111111111111111111111111111"]),
      ],
    }] },
    { id: "ws_cccccccccccccccccccccccccccccccc", title: "Flat stream", outcome: "Render leaf.", details: "", tasks: [
      leaf("task_33333333333333333333333333333333", "Other leaf", "Other leaf criterion."),
    ] },
  ],
} as const;

test("implementation panel derives recursive Task rows when metadata is absent", () => {
  const before = JSON.stringify(graph);
  const validated = validateObjective(graph);
  assert.equal(validated.valid, true);
  if (!validated.valid) return;

  const currentId = validated.graph.workstreams[0]!.tasks[0]!.tasks[1]!.id;
  const parentId = validated.graph.workstreams[0]!.tasks[0]!.id;
  const completedId = validated.graph.workstreams[0]!.tasks[0]!.tasks[0]!.id;
  const upcomingId = validated.graph.workstreams[0]!.tasks[0]!.tasks[1]!.id;
  const current = buildManifestHumanView(validated.graph, currentId);
  const plan = current.implementation;
  assert.ok(plan);
  assert.deepEqual(plan.stages.map((stage) => stage.id), [
    "ws_bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb", "ws_cccccccccccccccccccccccccccccccc",
  ]);
  const nested = plan.stages[0]!;
  assert.deepEqual(nested.slices.map((slice) => slice.id), [parentId, completedId, upcomingId]);
  const parentSlice = nested.slices.find((slice) => slice.id === parentId)!;
  const completedSlice = nested.slices.find((slice) => slice.id === completedId)!;
  const upcomingSlice = nested.slices.find((slice) => slice.id === upcomingId)!;
  assert.deepEqual(parentSlice.mappedNodeIds, [parentId, completedId, upcomingId]);
  assert.deepEqual(completedSlice.mappedNodeIds, [completedId]);
  assert.deepEqual(upcomingSlice.mappedNodeIds, [upcomingId]);
  assert.equal(parentSlice.status, "partial");
  assert.equal(completedSlice.status, "complete");
  assert.equal(upcomingSlice.status, "active");
  assert.ok(nested.mappedNodeIds.includes(validated.graph.workstreams[0]!.id));
  assert.ok(nested.mappedNodeIds.includes(validated.graph.workstreams[0]!.tasks[0]!.id));
  assert.ok(nested.visibleDependencyEdgeIds.includes("dependency:task_11111111111111111111111111111111:task_22222222222222222222222222222222"));
  assert.deepEqual(plan.stages[1]!.slices.map((slice) => slice.id), ["task_33333333333333333333333333333333"]);
  for (const [id, criterion] of [
    ["task_11111111111111111111111111111111", "Completed leaf criterion."],
    ["task_22222222222222222222222222222222", "Upcoming leaf criterion."],
    ["task_33333333333333333333333333333333", "Other leaf criterion."],
  ] as const) {
    const slice = plan.stages.flatMap((stage) => stage.slices).find((item) => item.id === id)!;
    assert.ok(slice.mappedNodeIds.includes(id));
    assert.ok(slice.acceptance.includes(criterion));
  }
  assert.ok(current.graph.edges.some((edge) => edge.id === "dependency:task_11111111111111111111111111111111:task_22222222222222222222222222222222"));
  assert.equal(plan.currentStage, "ws_bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb");
  assert.equal(plan.currentSlice, upcomingId);

  const noCurrent = buildManifestHumanView(validated.graph).implementation!;
  assert.equal(noCurrent.currentStage, null);
  assert.equal(noCurrent.currentSlice, null);
  const noCurrentNested = noCurrent.stages[0]!;
  assert.equal(noCurrentNested.slices.find((slice) => slice.id === parentId)!.status, "partial");
  assert.equal(noCurrentNested.slices.find((slice) => slice.id === completedId)!.status, "complete");
  assert.equal(noCurrentNested.slices.find((slice) => slice.id === upcomingId)!.status, "upcoming");
  assert.equal(JSON.stringify(graph), before);
});
