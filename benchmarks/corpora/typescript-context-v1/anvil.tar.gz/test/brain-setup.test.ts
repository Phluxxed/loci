import assert from "node:assert/strict";
import { constants as fsConstants } from "node:fs";
import { access, mkdir, mkdtemp, readFile, realpath, rm, symlink, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { test } from "node:test";

import { brainSetupOutputSchema, setupBrain } from "../src/brain/index.ts";

async function exists(path: string): Promise<boolean> {
  try {
    await access(path, fsConstants.F_OK);
    return true;
  } catch {
    return false;
  }
}

async function tempRoot(prefix: string): Promise<string> {
  return mkdtemp(join(await realpath(tmpdir()), prefix));
}

test("Brain setup dry-run plans config without writing files", async () => {
  const temp = await tempRoot("anvil-brain-dry-run-");
  try {
    const anvilHome = join(temp, ".anvil");
    const brainRoot = join(temp, ".anvil-brain", "codex");

    const output = await setupBrain({
      anvilHome,
      brainRoot,
      env: { ANVIL_AGENT_ID: "codex" },
      homeDir: temp,
    });

    assert.equal(output.status, "planned");
    assert.equal(output.resolved_agent_id, "codex");
    assert.equal(output.target_brain_root, brainRoot);
    assert.equal(output.wiki_alias, "anvil-brain-codex");
    assert.match(output.plan_hash, /^[a-f0-9]{64}$/);
    assert.match(output.acknowledgement_token, /^ack-anvil-brain-/);
    assert.match(output.brain_setup_brief.purpose, /Agent-owned Brain wiki/);
    assert.equal(output.llm_wiki_setup_action.kind, "wikime_setup");
    assert.deepEqual(output.llm_wiki_registration_call.arguments, {
      alias: "anvil-brain-codex",
      path: brainRoot,
      created_by: "anvil",
    });
    assert.deepEqual(brainSetupOutputSchema.parse(output), output);
    assert.throws(() => brainSetupOutputSchema.parse({ ...output, unexpected: true }));
    assert.equal(await exists(anvilHome), false);
    assert.equal(await exists(brainRoot), false);
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("Brain setup dry-run refuses missing identity without writing files", async () => {
  const temp = await tempRoot("anvil-brain-missing-id-");
  try {
    const output = await setupBrain({
      anvilHome: join(temp, ".anvil"),
      env: {},
      homeDir: temp,
    });

    assert.equal(output.status, "refused");
    assert.equal(output.error?.code, "RUNTIME_AGENT_ID_MISSING");
    assert.deepEqual(brainSetupOutputSchema.parse(output), output);
    assert.equal(await exists(join(temp, ".anvil")), false);
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("Brain setup apply requires runtime identity, plan hash, and acknowledgement", async () => {
  const temp = await tempRoot("anvil-brain-apply-guards-");
  try {
    const anvilHome = join(temp, ".anvil");
    const brainRoot = join(temp, ".anvil-brain", "codex");
    const plan = await setupBrain({
      anvilHome,
      brainRoot,
      env: { ANVIL_AGENT_ID: "codex" },
      homeDir: temp,
    });

    await assert.rejects(
      () =>
        setupBrain({
          anvilHome,
          brainRoot,
          mode: "apply",
          env: {},
          homeDir: temp,
          planHash: plan.plan_hash,
          acknowledgement: plan.acknowledgement_token,
        }),
      /RUNTIME_AGENT_ID_MISSING/,
    );

    await assert.rejects(
      () =>
        setupBrain({
          anvilHome,
          brainRoot,
          mode: "apply",
          env: { ANVIL_AGENT_ID: "codex" },
          homeDir: temp,
          acknowledgement: plan.acknowledgement_token,
        }),
      /SETUP_PLAN_CONFLICT/,
    );

    await assert.rejects(
      () =>
        setupBrain({
          anvilHome,
          brainRoot,
          mode: "apply",
          env: { ANVIL_AGENT_ID: "codex" },
          homeDir: temp,
          planHash: plan.plan_hash,
          acknowledgement: "wrong",
        }),
      /SETUP_PLAN_CONFLICT/,
    );
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("Brain setup apply creates Anvil-owned config, setup state, log, and target directory", async () => {
  const temp = await tempRoot("anvil-brain-apply-");
  try {
    const anvilHome = join(temp, ".anvil");
    const brainRoot = join(temp, ".anvil-brain", "codex");
    const plan = await setupBrain({
      anvilHome,
      brainRoot,
      env: { ANVIL_AGENT_ID: "codex" },
      homeDir: temp,
    });

    const applied = await setupBrain({
      anvilHome,
      brainRoot,
      mode: "apply",
      env: { ANVIL_AGENT_ID: "codex" },
      homeDir: temp,
      planHash: plan.plan_hash,
      acknowledgement: plan.acknowledgement_token,
    });

    assert.equal(applied.status, "created");
    assert.deepEqual(brainSetupOutputSchema.parse(applied), applied);
    assert.equal(await exists(brainRoot), true);
    const config = JSON.parse(await readFile(join(anvilHome, "agents", "codex", "config.json"), "utf8")) as {
      agent_id: string;
      brain_root: string;
      wiki_alias: string;
    };
    assert.equal(config.agent_id, "codex");
    assert.equal(config.brain_root, brainRoot);
    assert.equal(config.wiki_alias, "anvil-brain-codex");

    const setupState = JSON.parse(await readFile(join(anvilHome, "agents", "codex", "setup-state.json"), "utf8")) as {
      state: string;
      plan_hash: string;
      history: string[];
    };
    assert.equal(setupState.state, "complete");
    assert.equal(setupState.plan_hash, plan.plan_hash);
    assert.deepEqual(setupState.history, ["planning", "writing_config", "prepared_wiki_setup", "verifying", "complete"]);

    const setupLog = await readFile(join(anvilHome, "agents", "codex", "setup-log.jsonl"), "utf8");
    assert.match(setupLog, /"status":"created"/);
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("Brain setup apply is idempotent for matching existing config", async () => {
  const temp = await tempRoot("anvil-brain-idempotent-");
  try {
    const anvilHome = join(temp, ".anvil");
    const brainRoot = join(temp, ".anvil-brain", "codex");
    const plan = await setupBrain({
      anvilHome,
      brainRoot,
      env: { ANVIL_AGENT_ID: "codex" },
      homeDir: temp,
    });

    await setupBrain({
      anvilHome,
      brainRoot,
      mode: "apply",
      env: { ANVIL_AGENT_ID: "codex" },
      homeDir: temp,
      planHash: plan.plan_hash,
      acknowledgement: plan.acknowledgement_token,
    });
    const repeated = await setupBrain({
      anvilHome,
      brainRoot,
      mode: "apply",
      env: { ANVIL_AGENT_ID: "codex" },
      homeDir: temp,
      planHash: plan.plan_hash,
      acknowledgement: plan.acknowledgement_token,
    });

    assert.equal(repeated.status, "already_configured");
    assert.deepEqual(brainSetupOutputSchema.parse(repeated), repeated);
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("Brain setup apply refuses unsafe pre-existing target contents", async () => {
  const temp = await tempRoot("anvil-brain-unsafe-target-");
  try {
    const anvilHome = join(temp, ".anvil");
    const brainRoot = join(temp, ".anvil-brain", "codex");
    await mkdir(brainRoot, { recursive: true });
    await writeFile(join(brainRoot, "notes.md"), "# not a scaffold\n", "utf8");

    const plan = await setupBrain({
      anvilHome,
      brainRoot,
      env: { ANVIL_AGENT_ID: "codex" },
      homeDir: temp,
    });

    await assert.rejects(
      () =>
        setupBrain({
          anvilHome,
          brainRoot,
          mode: "apply",
          env: { ANVIL_AGENT_ID: "codex" },
          homeDir: temp,
          planHash: plan.plan_hash,
          acknowledgement: plan.acknowledgement_token,
        }),
      /UNSAFE_TARGET_PATH/,
    );
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("Brain setup apply refuses symlink ancestors", async () => {
  const temp = await tempRoot("anvil-brain-symlink-ancestor-");
  try {
    const anvilHome = join(temp, ".anvil");
    const realParent = join(temp, "real-parent");
    const linkParent = join(temp, "link-parent");
    await mkdir(realParent, { recursive: true });
    await symlink(realParent, linkParent, "dir");

    const brainRoot = join(linkParent, "codex");
    const plan = await setupBrain({
      anvilHome,
      brainRoot,
      env: { ANVIL_AGENT_ID: "codex" },
      homeDir: temp,
    });

    await assert.rejects(
      () =>
        setupBrain({
          anvilHome,
          brainRoot,
          mode: "apply",
          env: { ANVIL_AGENT_ID: "codex" },
          homeDir: temp,
          planHash: plan.plan_hash,
          acknowledgement: plan.acknowledgement_token,
        }),
      /UNSAFE_TARGET_PATH/,
    );
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("Brain setup apply refuses mismatched existing Anvil config", async () => {
  const temp = await tempRoot("anvil-brain-config-mismatch-");
  try {
    const anvilHome = join(temp, ".anvil");
    const brainRoot = join(temp, ".anvil-brain", "codex");
    await mkdir(join(anvilHome, "agents", "codex"), { recursive: true });
    await writeFile(
      join(anvilHome, "agents", "codex", "config.json"),
      `${JSON.stringify(
        {
          schema_version: 1,
          agent_id: "codex",
          brain_root: join(temp, "other-brain"),
          wiki_alias: "anvil-brain-codex",
        },
        null,
        2,
      )}\n`,
      "utf8",
    );

    const plan = await setupBrain({
      anvilHome,
      brainRoot,
      env: { ANVIL_AGENT_ID: "codex" },
      homeDir: temp,
    });

    await assert.rejects(
      () =>
        setupBrain({
          anvilHome,
          brainRoot,
          mode: "apply",
          env: { ANVIL_AGENT_ID: "codex" },
          homeDir: temp,
          planHash: plan.plan_hash,
          acknowledgement: plan.acknowledgement_token,
        }),
      /SETUP_PLAN_CONFLICT/,
    );
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});
