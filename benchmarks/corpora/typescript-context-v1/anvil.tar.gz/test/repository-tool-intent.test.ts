import assert from "node:assert/strict";
import { test } from "node:test";

import { classifyRepositoryToolUse } from "../src/work-context/repository-tool-intent.ts";

test("repository tool intent recognizes bounded exploration commands", () => {
  for (const command of [
    "pwd",
    "git status --short --branch",
    "git diff --stat",
    "git log --oneline -20",
    "git show HEAD:package.json",
    "git branch --show-current",
    "git rev-parse --show-toplevel",
    "git ls-files src test",
    "git grep -n PreToolUse",
    "rg -n PreToolUse bin src test",
    "rg -n 'repository|mutation' test/codex-hook.test.ts",
    "rg -n '$OUTPUT_FILE' test/codex-hook.test.ts",
    "rg --files src test",
    "sed -n '1,$p' AGENTS.md",
    "sed -n '1,20p' /tmp/first.md && sed -n '21,40p' /tmp/second.md",
    "cat package.json",
    "head -n 40 AGENTS.md",
    "tail -n 20 AGENTS.md",
    "wc -l AGENTS.md",
    "npm test",
    "npm run typecheck",
  ]) {
    assert.equal(
      classifyRepositoryToolUse("Bash", { command }),
      "observe",
      command,
    );
  }
});

test("repository tool intent keeps bounded test verification authority-gated", () => {
  assert.equal(
    classifyRepositoryToolUse("Bash", {
      command:
        "node --test --test-concurrency=1 test/work-context.test.ts test/work-context-doctor.test.ts test/codex-hook.test.ts",
    }),
    "verify",
  );

  for (const command of [
    "node --test",
    "node --test test/*.test.ts",
    "node --test ../outside.test.ts",
    "node --test /tmp/outside.test.ts",
    "node --test --test-reporter=spec test/codex-hook.test.ts",
    "node --test --test-concurrency=0 test/codex-hook.test.ts",
    "node --test test/not-a-test.ts",
  ]) {
    assert.equal(
      classifyRepositoryToolUse("Bash", { command }),
      "unknown",
      command,
    );
  }
});

test("repository tool intent recognizes durable mutation commands", () => {
  assert.equal(classifyRepositoryToolUse("apply_patch", { patch: "*** Begin Patch" }), "mutate");

  for (const command of [
    "touch changed.txt",
    "rm changed.txt",
    "mkdir generated",
    "cp source target",
    "mv source target",
    "git add src/file.ts",
    "git commit -m change",
    "git checkout other-branch",
    "git reset --hard HEAD",
    "git branch --show-current --delete old-branch",
    "git remote -v remove origin",
    "git tag --list --delete old-tag",
    "git worktree list remove ../other",
    "npm install package-name",
    "git status && touch changed.txt",
  ]) {
    assert.equal(
      classifyRepositoryToolUse("Bash", { command }),
      "mutate",
      command,
    );
  }
});

test("repository tool intent fails closed for ambiguous or escaped shell input", () => {
  for (const command of [
    "rg --files src | rg continuity",
    "git status || touch changed.txt",
    "git status; touch changed.txt",
    "for file in src/*; do cat \"$file\"; done",
    "cat package.json > changed.txt",
    "cat $(touch changed.txt)",
    "cat ${OUTPUT_FILE}",
    "cat $OUTPUT_FILE",
    "cat \"$OUTPUT_FILE\"",
    "cat `touch changed.txt`",
    "cat package.json\ncat tsconfig.json",
    "cat 'package.json",
    "cat (package.json)",
    "rg --pre 'touch changed.txt' pattern src",
    "rg '--pre=touch changed.txt' pattern src",
    "git diff --output=changed.patch",
    "git diff '--output=changed.patch'",
    "git diff \\--output=changed.patch",
    "sed -i '' 's/old/new/' file.txt",
    "sed -n 1p -e 'w changed.txt' file.txt",
    "file -C -m custom.magic",
    "python inspect.py",
  ]) {
    assert.equal(
      classifyRepositoryToolUse("Bash", { command }),
      "unknown",
      command,
    );
  }

  assert.equal(classifyRepositoryToolUse("Bash", {}), "unknown");
  assert.equal(classifyRepositoryToolUse("Bash", { command: 42 }), "unknown");
  assert.equal(classifyRepositoryToolUse("unrelated", { command: "git status" }), "unknown");
});
