import assert from "node:assert/strict";
import { existsSync, statSync } from "node:fs";
import { mkdir, mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join, resolve } from "node:path";
import { test } from "node:test";
import { setTimeout as sleep } from "node:timers/promises";

import {
  deriveContinuityPaths,
  CURRENT_SCHEMA_VERSION,
  gitWorkspaceRef,
  initWorkspace,
  MAX_ACTIVE_DECISIONS,
  MAX_CONTINUITY_NOTES,
  MAX_EVENT_DETAILS_CHARS,
  MAX_EVENT_SUMMARY_CHARS,
  MAX_NEXT_ACTIONS,
  MAX_OPEN_QUESTIONS,
  MAX_QUALITY_BAR_ITEMS,
  readCurrent,
  readRecentEvents,
  recordEvent,
  renderContinuityFrame,
  updateCurrent,
  validateCurrentFrameInput,
  validateEventInput,
  withWorkspaceMutationLock,
  workspaceKeyForRoot,
} from "../src/continuity/index.ts";
import type { CurrentFrameInput, EventInput } from "../src/continuity/index.ts";
import type { CurrentFrame } from "../src/continuity/index.ts";

function sampleFrameInput(overrides: Partial<CurrentFrameInput> = {}): CurrentFrameInput {
  return {
    operating_mode: "review",
    intent: "Keep Anvil continuity compact and explicit.",
    quality_bar: ["Continuity is not truth.", "Current evidence wins."],
    permission_envelope: {
      default: "ask before durable semantic writes",
      allowed_without_approval: ["read continuity state"],
      requires_approval: ["delete continuity history"],
    },
    active_decisions: [{ summary: "Keep events separate from current frame updates." }],
    open_questions: [],
    next_actions: [{ summary: "Review whether a host adapter is warranted." }],
    continuity_notes: ["Adapter-neutral core; host adapters supply injection surfaces."],
    ...overrides,
  };
}

function sampleEventInput(overrides: Partial<EventInput> = {}): EventInput {
  return {
    type: "decision",
    status: "active",
    summary: "Continuity core keeps temporal events explicit.",
    details: "This preserves lineage without silently mutating the current frame.",
    supersedes: [],
    resolves: [],
    related_events: [],
    ...overrides,
  };
}

test("derives deterministic workspace paths from a supplied state root", async () => {
  const root = "/Users/brummerv/phluxxed/anvil_redux/./";
  const workspace = gitWorkspaceRef(root, "Anvil Redux");
  const paths = deriveContinuityPaths({
    stateRoot: "/tmp/anvil-state",
    workspace,
  });

  assert.equal(workspace.root, resolve(root));
  assert.equal(workspace.key, workspaceKeyForRoot(root));
  assert.equal(paths.continuityRoot, "/tmp/anvil-state/continuity");
  assert.equal(paths.currentPath, `${paths.workspaceDir}/current.json`);
  assert.equal(paths.eventsPath, `${paths.workspaceDir}/events.jsonl`);
});

test("readCurrent does not create missing continuity files", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-continuity-missing-"));
  try {
    const paths = deriveContinuityPaths({
      stateRoot: temp,
      workspace: gitWorkspaceRef(join(temp, "repo")),
    });

    const result = await readCurrent(paths);
    assert.equal(result.kind, "missing");
    assert.equal(existsSync(paths.workspaceDir), false);
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("initializes workspace state explicitly", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-continuity-init-"));
  try {
    const paths = deriveContinuityPaths({
      stateRoot: temp,
      workspace: gitWorkspaceRef(join(temp, "repo"), "repo"),
    });

    const frame = await initWorkspace(paths, sampleFrameInput(), {
      now: () => "2026-06-03T00:00:00.000Z",
    });

    assert.equal(frame.workspace.label, "repo");
    assert.equal(existsSync(paths.indexPath), true);
    assert.equal(existsSync(paths.currentPath), true);
    assert.equal(existsSync(paths.eventsPath), true);
    assert.equal(statSync(paths.eventsPath).size, 0);

    await assert.rejects(
      () => initWorkspace(paths, sampleFrameInput(), { now: () => "2026-06-03T00:00:00.000Z" }),
      /already initialized/,
    );
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("workspace mutation lock serializes concurrent mutations and cleans up after errors", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-continuity-lock-"));
  try {
    const paths = deriveContinuityPaths({
      stateRoot: temp,
      workspace: gitWorkspaceRef(join(temp, "repo"), "repo"),
    });

    const order: string[] = [];
    let releaseFirst!: () => void;
    let firstStarted!: () => void;
    const firstCanFinish = new Promise<void>((resolveRelease) => {
      releaseFirst = resolveRelease;
    });
    const firstEntered = new Promise<void>((resolveStarted) => {
      firstStarted = resolveStarted;
    });

    const first = withWorkspaceMutationLock(
      paths,
      async () => {
        order.push("first:start");
        firstStarted();
        await firstCanFinish;
        order.push("first:end");
      },
      { retryDelayMs: 1, timeoutMs: 1_000 },
    );
    await firstEntered;

    const second = withWorkspaceMutationLock(
      paths,
      async () => {
        order.push("second");
      },
      { retryDelayMs: 1, timeoutMs: 1_000 },
    );

    await sleep(25);
    assert.deepEqual(order, ["first:start"]);
    releaseFirst();
    await Promise.all([first, second]);
    assert.deepEqual(order, ["first:start", "first:end", "second"]);
    assert.equal(existsSync(paths.workspaceMutationKey), false);

    await assert.rejects(
      () =>
        withWorkspaceMutationLock(paths, async () => {
          throw new Error("mutation failed");
        }),
      /mutation failed/,
    );
    assert.equal(existsSync(paths.workspaceMutationKey), false);
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("workspace mutation lock timeout names the workspace and lock path", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-continuity-lock-timeout-"));
  try {
    const paths = deriveContinuityPaths({
      stateRoot: temp,
      workspace: gitWorkspaceRef(join(temp, "repo"), "repo"),
    });
    await mkdir(paths.workspaceMutationKey, { recursive: true });
    await writeFile(join(paths.workspaceMutationKey, "owner.json"), "{\"pid\":123}", "utf8");

    await assert.rejects(
      () => withWorkspaceMutationLock(paths, async () => undefined, { retryDelayMs: 1, timeoutMs: 5 }),
      (error: unknown) =>
        error instanceof Error &&
        error.message.includes(paths.workspace.key) &&
        error.message.includes(paths.workspaceMutationKey) &&
        error.message.includes("Timed out acquiring continuity mutation lock"),
    );
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("records events and updates current frame separately", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-continuity-record-"));
  try {
    const paths = deriveContinuityPaths({
      stateRoot: temp,
      workspace: gitWorkspaceRef(join(temp, "repo"), "repo"),
    });

    await initWorkspace(paths, sampleFrameInput(), {
      now: () => "2026-06-03T00:00:00.000Z",
    });

    const event = await recordEvent(paths, sampleEventInput(), {
      source: { kind: "manual", description: "unit test" },
      now: () => "2026-06-03T00:01:00.000Z",
      id: () => "evt_test_1",
    });

    assert.equal(event.id, "evt_test_1");
    const before = await readCurrent(paths);
    if (before.kind !== "ok") throw new Error(`Expected current frame, got ${before.kind}`);
    assert.equal(before.value.next_actions[0].summary, "Review whether a host adapter is warranted.");

    await updateCurrent(
      paths,
      sampleFrameInput({
        next_actions: [{ event_id: "evt_test_1", summary: "Decide the first host adapter seam." }],
      }),
      { now: () => "2026-06-03T00:02:00.000Z" },
    );

    const after = await readCurrent(paths);
    if (after.kind !== "ok") throw new Error(`Expected current frame, got ${after.kind}`);
    assert.equal(after.value.next_actions[0].event_id, "evt_test_1");

    const recent = await readRecentEvents(paths, 10);
    if (recent.kind !== "ok") throw new Error(`Expected recent events, got ${recent.kind}`);
    assert.equal(recent.events.length, 1);
    assert.equal(recent.events[0].source.kind, "manual");
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("recordEvent can bootstrap missing workspace state from the first event", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-continuity-bootstrap-"));
  try {
    const paths = deriveContinuityPaths({
      stateRoot: temp,
      workspace: gitWorkspaceRef(join(temp, "repo"), "repo"),
    });

    await recordEvent(paths, sampleEventInput({ summary: "First event bootstraps continuity." }), {
      source: { kind: "manual", description: "bootstrap" },
      now: () => "2026-06-03T00:00:00.000Z",
      id: () => "evt_bootstrap_1",
    });

    const current = await readCurrent(paths);
    if (current.kind !== "ok") throw new Error(`Expected current frame, got ${current.kind}`);
    assert.equal(current.value.active_decisions[0].event_id, "evt_bootstrap_1");
    assert.equal(current.value.active_decisions[0].recorded_at, "2026-06-03T00:00:00.000Z");
    assert.equal(current.value.active_decisions[0].summary, "First event bootstraps continuity.");

    const eventsText = await readFile(paths.eventsPath, "utf8");
    assert.equal(eventsText.trim().split("\n").length, 1);
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("validates input shapes and reports malformed current frames", async () => {
  assert.equal(validateCurrentFrameInput(sampleFrameInput()).ok, true);
  assert.equal(validateEventInput(sampleEventInput()).ok, true);
  assert.equal(validateEventInput({ ...sampleEventInput(), type: "memory" }).ok, false);
  assert.equal(validateEventInput(sampleEventInput({ summary: "x".repeat(MAX_EVENT_SUMMARY_CHARS) })).ok, true);
  assert.equal(validateEventInput(sampleEventInput({ details: "x".repeat(MAX_EVENT_DETAILS_CHARS) })).ok, true);

  const oversizedSummary = validateEventInput(sampleEventInput({ summary: "x".repeat(MAX_EVENT_SUMMARY_CHARS + 1) }));
  assert.equal(oversizedSummary.ok, false);
  if (!oversizedSummary.ok) assert.match(oversizedSummary.message, /summary.*500/);

  const oversizedDetails = validateEventInput(sampleEventInput({ details: "x".repeat(MAX_EVENT_DETAILS_CHARS + 1) }));
  assert.equal(oversizedDetails.ok, false);
  if (!oversizedDetails.ok) assert.match(oversizedDetails.message, /details.*4000/);

  const temp = await mkdtemp(join(tmpdir(), "anvil-continuity-malformed-"));
  try {
    const paths = deriveContinuityPaths({
      stateRoot: temp,
      workspace: gitWorkspaceRef(join(temp, "repo"), "repo"),
    });
    await initWorkspace(paths, sampleFrameInput(), {
      now: () => "2026-06-03T00:00:00.000Z",
    });
    await writeFile(paths.currentPath, "{ nope", "utf8");

    const current = await readCurrent(paths);
    if (current.kind !== "malformed") throw new Error(`Expected malformed current frame, got ${current.kind}`);
    assert.match(current.message, /Malformed JSON/);
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("readCurrent upgrades legacy v1 frames in memory and the next mutation persists v2", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-continuity-v1-migration-"));
  try {
    const paths = deriveContinuityPaths({
      stateRoot: temp,
      workspace: gitWorkspaceRef(join(temp, "repo"), "repo"),
    });
    await initWorkspace(paths, sampleFrameInput(), { now: () => "2026-08-22T00:00:00.000Z" });
    const legacy = JSON.parse(await readFile(paths.currentPath, "utf8")) as Record<string, unknown>;
    legacy.version = 1;
    delete legacy.active_task;
    await writeFile(paths.currentPath, `${JSON.stringify(legacy, null, 2)}\n`, "utf8");

    const migrated = await readCurrent(paths);
    if (migrated.kind !== "ok") throw new Error(`Expected migrated frame, got ${migrated.kind}`);
    assert.equal(migrated.value.version, CURRENT_SCHEMA_VERSION);
    assert.equal(migrated.value.active_task, null);
    const stillLegacy = JSON.parse(await readFile(paths.currentPath, "utf8")) as Record<string, unknown>;
    assert.equal(stillLegacy.version, 1, "read-only migration must not rewrite state");

    await updateCurrent(paths, sampleFrameInput(), { now: () => "2026-08-22T00:01:00.000Z" });
    const persisted = JSON.parse(await readFile(paths.currentPath, "utf8")) as Record<string, unknown>;
    assert.equal(persisted.version, CURRENT_SCHEMA_VERSION);
    assert.equal(persisted.active_task, null);
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("validateCurrentFrameInput enforces compact projection caps", () => {
  const cappedStringFields = [
    { field: "quality_bar", maxItems: MAX_QUALITY_BAR_ITEMS },
    { field: "continuity_notes", maxItems: MAX_CONTINUITY_NOTES },
  ] as const;
  for (const { field, maxItems } of cappedStringFields) {
    assert.equal(validateCurrentFrameInput(sampleFrameInput({ [field]: Array.from({ length: maxItems }, () => "item") })).ok, true);
    const overLimit = validateCurrentFrameInput(sampleFrameInput({ [field]: Array.from({ length: maxItems + 1 }, () => "item") }));
    assert.equal(overLimit.ok, false);
    if (!overLimit.ok) assert.match(overLimit.message, new RegExp(`${field}.*${maxItems}`));
  }

  const cappedItemFields = [
    { field: "active_decisions", maxItems: MAX_ACTIVE_DECISIONS },
    { field: "open_questions", maxItems: MAX_OPEN_QUESTIONS },
    { field: "next_actions", maxItems: MAX_NEXT_ACTIONS },
  ] as const;
  for (const { field, maxItems } of cappedItemFields) {
    const items = Array.from({ length: maxItems }, (_, index) => ({ summary: `Item ${index}` }));
    assert.equal(validateCurrentFrameInput(sampleFrameInput({ [field]: items })).ok, true);

    const overLimitItems = Array.from({ length: maxItems + 1 }, (_, index) => ({ summary: `Item ${index}` }));
    const overLimit = validateCurrentFrameInput(sampleFrameInput({ [field]: overLimitItems }));
    assert.equal(overLimit.ok, false);
    if (!overLimit.ok) assert.match(overLimit.message, new RegExp(`${field}.*${maxItems}`));
  }
});

test("updateCurrent rejects oversized compact projections before writing", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-continuity-update-cap-"));
  try {
    const paths = deriveContinuityPaths({
      stateRoot: temp,
      workspace: gitWorkspaceRef(join(temp, "repo"), "repo"),
    });
    await initWorkspace(paths, sampleFrameInput(), {
      now: () => "2026-06-03T00:00:00.000Z",
    });

    await assert.rejects(
      () =>
        updateCurrent(
          paths,
          sampleFrameInput({
            next_actions: Array.from({ length: MAX_NEXT_ACTIONS + 1 }, (_, index) => ({ summary: `Next action ${index}` })),
          }),
        ),
      /next_actions.*8/,
    );

    const current = await readCurrent(paths);
    if (current.kind !== "ok") throw new Error(`Expected current frame, got ${current.kind}`);
    assert.equal(current.value.next_actions.length, 1);
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("renders compact continuity frame as continuity, not truth", () => {
  const frame: CurrentFrame = {
    version: CURRENT_SCHEMA_VERSION,
    updated_at: "2026-06-03T00:00:00.000Z",
    workspace: gitWorkspaceRef("/repo", "repo"),
    ...sampleFrameInput({
      active_decisions: Array.from({ length: 10 }, (_, index) => ({
        summary: `Decision ${index} ${"x".repeat(280)}`,
      })),
    }),
    active_task: null,
  };

  const rendered = renderContinuityFrame(frame);
  assert.match(rendered, /## Anvil Continuity Frame/);
  assert.match(rendered, /not truth/i);
  assert.match(rendered, /Additional active decisions omitted: 2/);
  assert.equal(rendered.includes("Decision 9"), false);
});

test("renders projection recorded_at as an absolute stable date", () => {
  const frame: CurrentFrame = {
    version: CURRENT_SCHEMA_VERSION,
    updated_at: "2026-06-03T00:00:00.000Z",
    workspace: gitWorkspaceRef("/repo", "repo"),
    ...sampleFrameInput({
      active_decisions: [
        {
          event_id: "evt_recorded",
          recorded_at: "2026-06-03T12:34:56.000Z",
          summary: "Recorded projection carries absolute date.",
        },
      ],
    }),
    active_task: null,
  };

  const first = renderContinuityFrame(frame);
  const second = renderContinuityFrame(frame);
  assert.equal(first, second);
  assert.match(first, /recorded 2026-06-03/);
  assert.doesNotMatch(first, /ago|today|yesterday/);
});
