import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import { mkdtemp, readFile, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { test } from "node:test";

import {
  BROWSERLESS_BASE_IMAGE,
  BrowserConfigurationError,
  browserCliUsage,
  ensureBrowserState,
  installCorporateCa,
  parseCorporateCa,
  readBrowserState,
  runBrowserCli,
} from "../src/browser/index.ts";
import type { BrowserLaunchPolicy } from "../src/browser/index.ts";

const fixturePath = join(dirname(fileURLToPath(import.meta.url)), "fixtures", "browser", "test-root-ca.crt");

function outputCapture(): { lines: string[]; write: (value: string) => void } {
  const lines: string[] = [];
  return { lines, write: (value) => lines.push(value) };
}

test("browser CLI usage exposes the lifecycle and explicit network-mode commands", () => {
  const usage = browserCliUsage();
  assert.match(usage, /browser install --host codex/);
  assert.match(usage, /browser status/);
  assert.match(usage, /browser doctor/);
  assert.match(usage, /browser mcp serve --network-mode local\|corporate/);
  assert.match(usage, /browser upgrade --image/);
  assert.match(usage, /browser uninstall --host codex/);
});

test("anvil executable dispatches browser commands from another directory", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-browser-cli-bin-"));
  try {
    const binary = join(dirname(fileURLToPath(import.meta.url)), "..", "bin", "anvil.ts");
    const result = spawnSync(process.execPath, [binary, "browser", "status", "--json"], {
      cwd: temp,
      env: { ...process.env, ANVIL_HOME: join(temp, ".anvil") },
      encoding: "utf8",
    });
    assert.equal(result.status, 0, result.stderr);
    const payload = JSON.parse(result.stdout);
    assert.equal(payload.capability_status, "unconfigured");
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("browser status reports unconfigured state without creating it", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-browser-cli-status-"));
  try {
    const stdout = outputCapture();
    const code = await runBrowserCli(["status", "--json"], {
      anvilCommand: "/opt/anvil/bin/anvil.ts",
      anvilHome: join(temp, ".anvil"),
      stdout: stdout.write,
    });

    assert.equal(code, 0);
    const payload = JSON.parse(stdout.lines.join(""));
    assert.equal(payload.schema_version, 1);
    assert.equal(payload.capability_status, "unconfigured");
    assert.deepEqual(await readBrowserState(join(temp, ".anvil")), { kind: "missing" });
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("browser status is degraded when a configured corporate renderer is missing", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-browser-cli-corporate-missing-"));
  try {
    const anvilHome = join(temp, ".anvil");
    await ensureBrowserState({
      anvilHome,
      corporate: {
        imageRef: "anvil/browserless-corporate:ca-test-base-test",
        installedCaPath: join(anvilHome, "browser", "certs", "corporate-root.crt"),
        fingerprint: "A1".repeat(32),
        source: { kind: "file", path: "/tmp/test-root-ca.crt" },
      },
    });
    const stdout = outputCapture();
    const code = await runBrowserCli(["status", "--json"], {
      anvilCommand: "/opt/anvil/bin/anvil.ts",
      anvilHome,
      stdout: stdout.write,
      readStatus: async (input) => ({
        mode: input.policy.mode,
        state: input.policy.mode === "local" ? "ready" : "unconfigured",
        image_ref: input.policy.container.image_ref,
        renderer_status: input.policy.mode === "local" ? "healthy" : "missing",
        registration_status: "unknown",
        diagnostics: [],
      }),
      registrationStatus: async () => ({ local: "matches", corporate: "matches" }),
    });

    assert.equal(code, 0);
    const payload = JSON.parse(stdout.lines.join(""));
    assert.equal(payload.capability_status, "degraded");
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("browser status is degraded when Codex registrations are not both exact matches", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-browser-cli-registration-drift-"));
  try {
    const anvilHome = join(temp, ".anvil");
    await ensureBrowserState({ anvilHome });
    const stdout = outputCapture();
    const code = await runBrowserCli(["status", "--json"], {
      anvilCommand: "/opt/anvil/bin/anvil.ts",
      anvilHome,
      stdout: stdout.write,
      readStatus: async (input) => ({
        mode: input.policy.mode,
        state: "ready",
        image_ref: input.policy.container.image_ref,
        renderer_status: "healthy",
        registration_status: "unknown",
        diagnostics: [],
      }),
      registrationStatus: async () => ({ local: "drifted", corporate: "missing" }),
    });

    assert.equal(code, 0);
    const payload = JSON.parse(stdout.lines.join(""));
    assert.equal(payload.capability_status, "degraded");
    assert.equal(payload.diagnostics.some((item: { code: string }) => item.code === "CODEX_REGISTRATION_DRIFT"), true);
    assert.doesNotMatch(JSON.stringify(payload), /token=/i);
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("browser install configures both profiles and reconciles before Codex registration", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-browser-cli-install-"));
  try {
    const stdout = outputCapture();
    const reconciled: BrowserLaunchPolicy[] = [];
    let registered = false;
    let registrationsValidated = false;
    const code = await runBrowserCli(
      ["install", "--host", "codex", "--corporate-ca", fixturePath, "--json"],
      {
        anvilCommand: "/opt/anvil/bin/anvil.ts",
        anvilHome: join(temp, ".anvil"),
        stdout: stdout.write,
        assertCanonical: async () => undefined,
        run: async (command) =>
          command === "agent-browser"
            ? { status: 0, stdout: "agent-browser 0.31.1\n", stderr: "" }
            : { status: 0, stdout: "27.1.1\n", stderr: "" },
        validateRegistrations: async () => {
          registrationsValidated = true;
        },
        buildImage: async ({ installedCa, baseImage }) => {
          assert.equal(registrationsValidated, true);
          return {
            image_ref: "anvil/browserless-corporate:ca-6eef4479ed5c-base-05f10074ec39",
            build_context: join(temp, "removed-build-context"),
            ca_fingerprint: installedCa.fingerprint,
            base_image: baseImage ?? BROWSERLESS_BASE_IMAGE,
          };
        },
        reconcile: async (input) => {
          assert.equal(registered, false);
          reconciled.push(input.policy);
          return {
            mode: input.policy.mode,
            state: "ready",
            image_ref: input.policy.container.image_ref,
            renderer_status: "healthy",
            registration_status: "unknown",
            diagnostics: [],
          };
        },
        installRegistrations: async () => {
          registered = true;
          return { changed: true, status: { local: "matches", corporate: "matches" } };
        },
      },
    );

    assert.equal(code, 0);
    assert.deepEqual(reconciled.map((policy) => policy.mode), ["local", "corporate"]);
    assert.equal(registered, true);
    const state = await readBrowserState(join(temp, ".anvil"));
    assert.equal(state.kind, "ok");
    if (state.kind === "ok") assert.equal(state.config.corporate.status, "configured");
    const payload = JSON.parse(stdout.lines.join(""));
    assert.equal(payload.operation, "install");
    assert.doesNotMatch(JSON.stringify(payload), /local_token|corporate_token|BEGIN CERTIFICATE/);
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("browser install rejects an incompatible agent-browser before creating state", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-browser-cli-incompatible-agent-"));
  try {
    const anvilHome = join(temp, ".anvil");
    let buildCalled = false;
    await assert.rejects(
      runBrowserCli(["install", "--host", "codex", "--json"], {
        anvilCommand: "/opt/anvil/bin/anvil.ts",
        anvilHome,
        stdout: () => undefined,
        assertCanonical: async () => undefined,
        validateRegistrations: async () => {
          throw new Error("registration validation must not run after incompatible agent-browser");
        },
        run: async (command, args) => {
          assert.equal(command, "agent-browser");
          assert.deepEqual(args, ["--version"]);
          return { status: 0, stdout: "agent-browser 0.30.0\n", stderr: "" };
        },
        buildImage: async () => {
          buildCalled = true;
          throw new Error("build must not run");
        },
      }),
      (error: unknown) =>
        error instanceof BrowserConfigurationError && error.code === "AGENT_BROWSER_INCOMPATIBLE",
    );
    assert.equal(buildCalled, false);
    assert.deepEqual(await readBrowserState(anvilHome), { kind: "missing" });
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("browser install rejects an unavailable Docker daemon before creating state", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-browser-cli-missing-docker-"));
  try {
    const anvilHome = join(temp, ".anvil");
    await assert.rejects(
      runBrowserCli(["install", "--host", "codex", "--json"], {
        anvilCommand: "/opt/anvil/bin/anvil.ts",
        anvilHome,
        stdout: () => undefined,
        assertCanonical: async () => undefined,
        validateRegistrations: async () => undefined,
        run: async (command, args) => {
          if (command === "agent-browser") return { status: 0, stdout: "agent-browser 0.31.1\n", stderr: "" };
          assert.equal(command, "docker");
          assert.deepEqual(args, ["version", "--format", "{{.Server.Version}}"]);
          return { status: 1, stdout: "", stderr: "Docker daemon unavailable" };
        },
      }),
      (error: unknown) => error instanceof BrowserConfigurationError && error.code === "DOCKER_UNAVAILABLE",
    );
    assert.deepEqual(await readBrowserState(anvilHome), { kind: "missing" });
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("browser doctor reports a missing agent-browser executable without crashing", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-browser-cli-missing-agent-"));
  try {
    const anvilHome = join(temp, ".anvil");
    await ensureBrowserState({ anvilHome });
    const stdout = outputCapture();
    const code = await runBrowserCli(["doctor", "--json"], {
      anvilCommand: "/opt/anvil/bin/anvil.ts",
      anvilHome,
      stdout: stdout.write,
      readStatus: async (input) => ({
        mode: input.policy.mode,
        state: "ready",
        image_ref: input.policy.container.image_ref,
        renderer_status: "healthy",
        registration_status: "matches",
        diagnostics: [],
      }),
      registrationStatus: async () => ({ local: "matches", corporate: "matches" }),
      run: async () => {
        const error = new Error("spawn agent-browser ENOENT") as NodeJS.ErrnoException;
        error.code = "ENOENT";
        throw error;
      },
    });

    assert.equal(code, 1);
    const payload = JSON.parse(stdout.lines.join(""));
    assert.equal(payload.ok, false);
    assert.equal(payload.diagnostics.some((item: { code: string }) => item.code === "AGENT_BROWSER_MISSING"), true);
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("browser upgrade rewrites the pinned base and rebuilds the corporate image", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-browser-cli-upgrade-"));
  try {
    const anvilHome = join(temp, ".anvil");
    const pem = await readFile(fixturePath, "utf8");
    const ca = parseCorporateCa(pem, { kind: "file", path: fixturePath }, new Date("2027-01-01T00:00:00Z"));
    const installed = await installCorporateCa(ca, anvilHome);
    await ensureBrowserState({
      anvilHome,
      corporate: {
        imageRef: "anvil/browserless-corporate:ca-6eef4479ed5c-base-05f10074ec39",
        installedCaPath: installed.path,
        fingerprint: installed.fingerprint,
        source: ca.source,
      },
    });
    const upgradedBase = `ghcr.io/browserless/chromium@sha256:${"3".repeat(64)}`;
    let builtWith: string | undefined;
    const code = await runBrowserCli(["upgrade", "--image", upgradedBase, "--json"], {
      anvilCommand: "/opt/anvil/bin/anvil.ts",
      anvilHome,
      stdout: () => undefined,
      run: async (_command, args) =>
        args[0] === "pull" ? { status: 0, stdout: "pulled", stderr: "" } : { status: 1, stdout: "", stderr: "unexpected" },
      buildImage: async ({ installedCa, baseImage }) => {
        builtWith = baseImage;
        return {
          image_ref: `anvil/browserless-corporate:ca-${installedCa.fingerprint.slice(0, 12).toLowerCase()}-base-${"3".repeat(12)}`,
          build_context: join(temp, "removed-build-context"),
          ca_fingerprint: installedCa.fingerprint,
          base_image: baseImage!,
        };
      },
      reconcile: async (input) => ({
        mode: input.policy.mode,
        state: "ready",
        image_ref: input.policy.container.image_ref,
        renderer_status: "healthy",
        registration_status: "unknown",
        diagnostics: [],
      }),
    });
    assert.equal(code, 0);
    assert.equal(builtWith, upgradedBase);
    const upgraded = await readBrowserState(anvilHome);
    assert.equal(upgraded.kind, "ok");
    if (upgraded.kind === "ok") assert.equal(upgraded.config.base_image, upgradedBase);
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("browser uninstall removes renderers and exact registrations before deleting state", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-browser-cli-uninstall-"));
  try {
    const anvilHome = join(temp, ".anvil");
    await ensureBrowserState({ anvilHome });
    const removed: string[] = [];
    const code = await runBrowserCli(["uninstall", "--host", "codex", "--keep-images", "--json"], {
      anvilCommand: "/opt/anvil/bin/anvil.ts",
      anvilHome,
      stdout: () => undefined,
      assertCanonical: async () => undefined,
      registrationStatus: async () => ({ local: "matches", corporate: "matches" }),
      removeRenderer: async (input) => {
        removed.push(input.policy.mode);
        return true;
      },
      uninstallRegistrations: async () => undefined,
    });
    assert.equal(code, 0);
    assert.deepEqual(removed, ["local"]);
    assert.deepEqual(await readBrowserState(anvilHome), { kind: "missing" });
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("browser uninstall fails loudly when corporate image ownership cannot be inspected", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-browser-cli-uninstall-inspect-"));
  try {
    const anvilHome = join(temp, ".anvil");
    await ensureBrowserState({
      anvilHome,
      corporate: {
        imageRef: "anvil/browserless-corporate:ca-test-base-test",
        installedCaPath: join(anvilHome, "browser", "certs", "corporate-root.crt"),
        fingerprint: "A1".repeat(32),
        source: { kind: "file", path: "/tmp/test-root-ca.crt" },
      },
    });

    await assert.rejects(
      runBrowserCli(["uninstall", "--host", "codex", "--json"], {
        anvilCommand: "/opt/anvil/bin/anvil.ts",
        anvilHome,
        stdout: () => undefined,
        assertCanonical: async () => undefined,
        registrationStatus: async () => ({ local: "matches", corporate: "matches" }),
        removeRenderer: async () => false,
        uninstallRegistrations: async () => undefined,
        run: async () => ({ status: 1, stdout: "", stderr: "Docker daemon unavailable" }),
      }),
      (error: unknown) => error instanceof BrowserConfigurationError && error.code === "DOCKER_COMMAND_FAILED",
    );
    assert.equal((await readBrowserState(anvilHome)).kind, "ok");
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});
