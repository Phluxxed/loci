import assert from "node:assert/strict";
import { test } from "node:test";

import { createBrowserMcpPolicyGuard } from "../src/browser/mcp-guard.ts";

function parse(line: string): Record<string, unknown> {
  return JSON.parse(line) as Record<string, unknown>;
}

test("MCP policy guard hides escape-hatch tools and unsafe per-call fields", () => {
  const guard = createBrowserMcpPolicyGuard();
  const request = JSON.stringify({ jsonrpc: "2.0", id: 1, method: "tools/list", params: {} });
  assert.deepEqual(guard.clientLine(request), { kind: "forward", line: request });

  const response = JSON.stringify({
    jsonrpc: "2.0",
    id: 1,
    result: {
      tools: [
        { name: "agent_browser_get_cdp_url", inputSchema: { type: "object", properties: {} } },
        {
          name: "agent_browser_open",
          inputSchema: {
            type: "object",
            properties: {
              url: { type: "string" },
              extraArgs: { type: "array" },
              namespace: { type: "string" },
              restore: { type: "boolean" },
            },
          },
        },
      ],
    },
  });
  const guarded = guard.serverLine(response);
  const tools = ((parse(guarded.line).result as { tools: Array<Record<string, unknown>> }).tools);
  assert.deepEqual(tools.map((tool) => tool.name), ["agent_browser_open"]);
  const properties = (tools[0]?.inputSchema as { properties: Record<string, unknown> }).properties;
  assert.deepEqual(Object.keys(properties), ["url"]);
});

test("MCP policy guard rejects blocked tools and argument overrides without forwarding them", () => {
  const guard = createBrowserMcpPolicyGuard();
  const blockedTool = guard.clientLine(
    JSON.stringify({ jsonrpc: "2.0", id: "blocked", method: "tools/call", params: { name: "agent_browser_connect", arguments: {} } }),
  );
  assert.equal(blockedTool.kind, "respond");
  if (blockedTool.kind === "respond") {
    const response = parse(blockedTool.line);
    assert.equal(response.id, "blocked");
    assert.match((response.error as { message: string }).message, /policy rejected/i);
  }

  const unsafeArgs = guard.clientLine(
    JSON.stringify({
      jsonrpc: "2.0",
      id: 2,
      method: "tools/call",
      params: { name: "agent_browser_open", arguments: { url: "https://example.com", extraArgs: ["--ignore-https-errors"] } },
    }),
  );
  assert.equal(unsafeArgs.kind, "respond");

  const safe = JSON.stringify({
    jsonrpc: "2.0",
    id: 3,
    method: "tools/call",
    params: { name: "agent_browser_open", arguments: { url: "http://localhost:3000" } },
  });
  assert.deepEqual(guard.clientLine(safe), { kind: "forward", line: safe });
});

test("MCP policy guard refuses JSON-RPC batches instead of bypassing inspection", () => {
  const guard = createBrowserMcpPolicyGuard();
  const decision = guard.clientLine(
    JSON.stringify([
      { jsonrpc: "2.0", id: 1, method: "tools/call", params: { name: "agent_browser_open", arguments: {} } },
      { jsonrpc: "2.0", id: "two", method: "tools/list", params: {} },
    ]),
  );
  assert.equal(decision.kind, "respond");
  if (decision.kind === "respond") {
    const responses = JSON.parse(decision.line) as Array<{ id: string | number; error: { message: string } }>;
    assert.deepEqual(responses.map((response) => response.id), [1, "two"]);
    assert.equal(responses.every((response) => /policy rejected/i.test(response.error.message)), true);
  }
});

test("MCP policy guard never advertises a schema whose required argument it stripped", () => {
  const guard = createBrowserMcpPolicyGuard();
  const request = JSON.stringify({ jsonrpc: "2.0", id: 7, method: "tools/list", params: {} });
  guard.clientLine(request);

  const guarded = guard.serverLine(
    JSON.stringify({
      jsonrpc: "2.0",
      id: 7,
      result: {
        tools: [
          {
            name: "agent_browser_restore_only",
            inputSchema: {
              type: "object",
              properties: { restore: { type: "boolean" }, url: { type: "string" } },
              required: ["restore"],
            },
          },
          {
            name: "agent_browser_open",
            inputSchema: { type: "object", properties: { url: { type: "string" } }, required: ["url"] },
          },
        ],
      },
    }),
  );

  const tools = (parse(guarded.line).result as { tools: Array<Record<string, unknown>> }).tools;
  assert.deepEqual(tools.map((tool) => tool.name), ["agent_browser_open"]);
  for (const tool of tools) {
    const schema = tool.inputSchema as { properties?: Record<string, unknown>; required?: string[] };
    for (const required of schema.required ?? []) {
      assert.ok(required in (schema.properties ?? {}), `${String(tool.name)} requires missing ${required}`);
    }
  }
});

test("MCP policy guard keeps the page load state argument that only shares a blocked name", () => {
  const guard = createBrowserMcpPolicyGuard();
  guard.clientLine(JSON.stringify({ jsonrpc: "2.0", id: 8, method: "tools/list", params: {} }));

  const guarded = guard.serverLine(
    JSON.stringify({
      jsonrpc: "2.0",
      id: 8,
      result: {
        tools: [
          {
            name: "agent_browser_wait_for_load",
            inputSchema: {
              type: "object",
              properties: {
                state: { type: "string", enum: ["load", "domcontentloaded", "networkidle"] },
                restore: { type: "boolean" },
                session: { type: "string" },
              },
              required: ["state"],
            },
          },
        ],
      },
    }),
  );

  const tools = (parse(guarded.line).result as { tools: Array<Record<string, unknown>> }).tools;
  assert.deepEqual(tools.map((tool) => tool.name), ["agent_browser_wait_for_load"]);
  const properties = (tools[0]?.inputSchema as { properties: Record<string, unknown> }).properties;
  assert.deepEqual(Object.keys(properties), ["state", "session"]);

  const call = JSON.stringify({
    jsonrpc: "2.0",
    id: 9,
    method: "tools/call",
    params: { name: "agent_browser_wait_for_load", arguments: { state: "networkidle" } },
  });
  assert.deepEqual(guard.clientLine(call), { kind: "forward", line: call });

  const restoreCall = guard.clientLine(
    JSON.stringify({
      jsonrpc: "2.0",
      id: 10,
      method: "tools/call",
      params: { name: "agent_browser_wait_for_load", arguments: { state: "load", restore: true } },
    }),
  );
  assert.equal(restoreCall.kind, "respond");

  const otherToolState = guard.clientLine(
    JSON.stringify({
      jsonrpc: "2.0",
      id: 11,
      method: "tools/call",
      params: { name: "agent_browser_open", arguments: { url: "http://localhost:3000", state: "/tmp/state.json" } },
    }),
  );
  assert.equal(otherToolState.kind, "respond");
});
