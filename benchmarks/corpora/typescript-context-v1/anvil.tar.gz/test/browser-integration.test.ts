import assert from "node:assert/strict";
import { Client } from "@modelcontextprotocol/client";
import { StdioClientTransport } from "@modelcontextprotocol/client/stdio";
import { spawn } from "node:child_process";
import { mkdtemp, readFile, rm } from "node:fs/promises";
import { createServer } from "node:http";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { fileURLToPath } from "node:url";
import { test } from "node:test";

import {
  buildAgentBrowserEnvironment,
  buildBrowserMcpLaunch,
  readBrowserState,
  reconcileRenderer,
  removeRenderer,
  type BrowserMcpLaunch,
} from "../src/browser/index.ts";

type CommandResult = { status: number; stdout: string; stderr: string };

function agentEnvironment(launch: BrowserMcpLaunch): NodeJS.ProcessEnv {
  return buildAgentBrowserEnvironment(launch.env);
}

function runAgent(launch: BrowserMcpLaunch, args: string[]): Promise<CommandResult> {
  return new Promise((resolve, reject) => {
    const child = spawn("agent-browser", args, {
      env: agentEnvironment(launch),
      stdio: ["ignore", "pipe", "pipe"],
    });
    let stdout = "";
    let stderr = "";
    child.stdout.setEncoding("utf8").on("data", (chunk: string) => {
      stdout += chunk;
    });
    child.stderr.setEncoding("utf8").on("data", (chunk: string) => {
      stderr += chunk;
    });
    child.on("error", reject);
    child.on("close", (status, signal) => {
      if (signal) {
        reject(new Error(`agent-browser exited from signal ${signal}`));
        return;
      }
      resolve({ status: status ?? 1, stdout, stderr });
    });
  });
}

function boundedFailure(result: CommandResult): string {
  return `${result.stderr}\n${result.stdout}`.trim().slice(0, 800);
}

test(
  "Browser Eyes provides local screenshots, explicit egress, and renderer recovery",
  { skip: process.env.ANVIL_BROWSER_INTEGRATION !== "1", timeout: 120_000 },
  async () => {
    const anvilHome = process.env.ANVIL_HOME;
    assert.ok(anvilHome, "ANVIL_HOME must point at an installed Browser Eyes state.");
    const state = await readBrowserState(anvilHome);
    assert.equal(state.kind, "ok");
    if (state.kind !== "ok") return;

    const local = buildBrowserMcpLaunch("local", state);
    const corporate = buildBrowserMcpLaunch("corporate", state);
    const evidence = await mkdtemp(join(tmpdir(), "anvil-browser-integration-"));
    const localScreenshot = join(evidence, "local.png");
    const corporateScreenshot = join(evidence, "corporate.png");
    const server = createServer((_request, response) => {
      response.writeHead(200, { "content-type": "text/html; charset=utf-8" });
      response.end("<!doctype html><html><head><title>Anvil Local Proof</title></head><body><main>Browser Eyes local proof</main></body></html>");
    });

    await new Promise<void>((resolve, reject) => {
      server.once("error", reject);
      server.listen(0, "127.0.0.1", resolve);
    });
    const address = server.address();
    assert.ok(address && typeof address === "object");

    try {
      await reconcileRenderer({ policy: local.policy, token: local.token });
      await reconcileRenderer({ policy: corporate.policy, token: corporate.token });

      const localOpen = await runAgent(local, ["open", `http://localhost:${address.port}`]);
      assert.equal(localOpen.status, 0, boundedFailure(localOpen));
      const localTitle = await runAgent(local, ["get", "title"]);
      assert.equal(localTitle.status, 0, boundedFailure(localTitle));
      assert.match(localTitle.stdout, /Anvil Local Proof/);
      const localShot = await runAgent(local, ["screenshot", localScreenshot]);
      assert.equal(localShot.status, 0, boundedFailure(localShot));
      assert.deepEqual((await readFile(localScreenshot)).subarray(0, 8), Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]));

      const blocked = await runAgent(local, ["open", "https://example.com"]);
      assert.notEqual(blocked.status, 0, "Local mode unexpectedly allowed external navigation.");

      const corporateOpen = await runAgent(corporate, ["open", "https://example.com"]);
      assert.equal(corporateOpen.status, 0, boundedFailure(corporateOpen));
      const corporateTitle = await runAgent(corporate, ["get", "title"]);
      assert.equal(corporateTitle.status, 0, boundedFailure(corporateTitle));
      assert.match(corporateTitle.stdout, /Example Domain/);
      const corporateShot = await runAgent(corporate, ["screenshot", corporateScreenshot]);
      assert.equal(corporateShot.status, 0, boundedFailure(corporateShot));
      assert.deepEqual((await readFile(corporateScreenshot)).subarray(0, 8), Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]));

      await runAgent(local, ["close", "--all"]);
      assert.equal(await removeRenderer({ policy: local.policy, token: local.token }), true);
      const recovered = await reconcileRenderer({ policy: local.policy, token: local.token });
      assert.equal(recovered.state, "ready");
      assert.equal(recovered.renderer_status, "healthy");

      const environment = Object.fromEntries(
        Object.entries({ ...process.env, ANVIL_HOME: anvilHome }).filter(
          (entry): entry is [string, string] => entry[1] !== undefined,
        ),
      );
      const transport = new StdioClientTransport({
        command: process.execPath,
        args: [fileURLToPath(new URL("../bin/anvil.ts", import.meta.url)), "browser", "mcp", "serve", "--network-mode", "corporate"],
        env: environment,
      });
      const client = new Client({ name: "anvil-browser-integration", version: "1.0.0" });
      try {
        await client.connect(transport);
        let cursor: string | undefined;
        const tools: Array<{ name: string; inputSchema: { properties?: Record<string, unknown> } }> = [];
        do {
          const page = await client.listTools(cursor ? { cursor } : undefined);
          tools.push(...page.tools);
          cursor = page.nextCursor;
        } while (cursor);
        const names = tools.map((tool) => tool.name);
        assert.equal(names.includes("agent_browser_get_cdp_url"), false);
        assert.equal(names.includes("agent_browser_connect"), false);
        assert.equal(names.some((name) => name.startsWith("agent_browser_state_")), false);
        const openTool = tools.find((tool) => tool.name === "agent_browser_open");
        assert.ok(openTool);
        assert.equal("extraArgs" in (openTool.inputSchema.properties ?? {}), false);
        assert.equal("namespace" in (openTool.inputSchema.properties ?? {}), false);
        assert.equal("restore" in (openTool.inputSchema.properties ?? {}), false);

        const opened = await client.callTool({ name: "agent_browser_open", arguments: { url: "https://example.com" } });
        assert.equal(opened.isError, false, JSON.stringify(opened.content).slice(0, 800));
        const title = await client.callTool({ name: "agent_browser_get_title", arguments: {} });
        assert.match(JSON.stringify(title.content), /Example Domain/);
        await assert.rejects(
          client.callTool({
            name: "agent_browser_open",
            arguments: { url: "https://example.com", extraArgs: ["--ignore-https-errors"] },
          }),
          /policy rejected/i,
        );
      } finally {
        await client.close();
      }
    } finally {
      await Promise.allSettled([runAgent(local, ["close", "--all"]), runAgent(corporate, ["close", "--all"])]);
      await new Promise<void>((resolve) => server.close(() => resolve()));
      await rm(evidence, { recursive: true, force: true });
    }
  },
);
