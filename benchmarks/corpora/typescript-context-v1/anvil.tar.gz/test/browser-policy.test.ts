import assert from "node:assert/strict";
import { test } from "node:test";

import {
  BROWSERLESS_BASE_IMAGE,
  BrowserConfigurationError,
  buildBrowserPolicy,
  redactBrowserText,
} from "../src/browser/index.ts";

test("local browser policy is loopback-bound, local-only, ephemeral, and accepts development certificates", () => {
  const policy = buildBrowserPolicy({ mode: "local", hostPort: 48123 });

  assert.equal(policy.mode, "local");
  assert.equal(policy.container.name, "anvil-browser-local");
  assert.equal(policy.container.image_ref, BROWSERLESS_BASE_IMAGE);
  assert.equal(policy.container.bind_host, "127.0.0.1");
  assert.equal(policy.container.host_port, 48123);
  assert.equal(policy.container.restart_policy, "unless-stopped");
  assert.equal(policy.container.shm_size, "2g");
  assert.deepEqual(policy.browserless_launch, {
    args: ["--host-resolver-rules=MAP localhost host.docker.internal,MAP *.localhost host.docker.internal"],
    acceptInsecureCerts: true,
  });
  assert.deepEqual(policy.agent_browser.allowed_domains, ["localhost", "*.localhost", "host.docker.internal"]);
  assert.equal(policy.agent_browser.content_boundaries, true);
  assert.equal(policy.agent_browser.persist_state, false);
  assert.equal(policy.container.labels["io.anvil.browser.mode"], "local");
});

test("corporate browser policy requires pinned CA-backed image inputs and never disables TLS verification", () => {
  const policy = buildBrowserPolicy({
    mode: "corporate",
    hostPort: 48124,
    corporateImageRef: "anvil/browserless-corporate:sha256-abcdef123456",
    caFingerprint: "A1".repeat(32),
  });

  assert.equal(policy.mode, "corporate");
  assert.equal(policy.container.name, "anvil-browser-corporate");
  assert.equal(policy.container.image_ref, "anvil/browserless-corporate:sha256-abcdef123456");
  assert.deepEqual(policy.browserless_launch, {
    args: ["--host-resolver-rules=MAP localhost host.docker.internal,MAP *.localhost host.docker.internal"],
  });
  assert.equal("acceptInsecureCerts" in policy.browserless_launch, false);
  assert.equal("allowed_domains" in policy.agent_browser, false);
  assert.equal(policy.container.labels["io.anvil.browser.ca-fingerprint"], "A1".repeat(32));
});

test("corporate browser policy fails closed without a CA fingerprint or derived image", () => {
  assert.throws(
    () => buildBrowserPolicy({ mode: "corporate", hostPort: 48124 }),
    (error: unknown) => error instanceof BrowserConfigurationError && error.code === "CORPORATE_CA_MISSING",
  );
});

test("browser policy rejects latest images, invalid ports, and unknown network modes", () => {
  assert.throws(
    () => buildBrowserPolicy({ mode: "local", hostPort: 48123, imageRef: "ghcr.io/browserless/chromium:latest" }),
    (error: unknown) => error instanceof BrowserConfigurationError && error.code === "UNPINNED_IMAGE",
  );
  assert.throws(
    () => buildBrowserPolicy({ mode: "local", hostPort: 70000 }),
    (error: unknown) => error instanceof BrowserConfigurationError && error.code === "PORT_INVALID",
  );
  assert.throws(
    () => buildBrowserPolicy({ mode: "external" as "local", hostPort: 48123 }),
    (error: unknown) => error instanceof BrowserConfigurationError && error.code === "NETWORK_MODE_INVALID",
  );
});

test("browser diagnostics redact tokens, CDP URLs, and certificate bodies", () => {
  const input = [
    "ws://127.0.0.1:48123/?token=super-secret&launch=%7B%7D",
    "TOKEN=another-secret",
    "-----BEGIN CERTIFICATE-----\nprivate-ish-material\n-----END CERTIFICATE-----",
  ].join("\n");
  const redacted = redactBrowserText(input);

  assert.doesNotMatch(redacted, /super-secret|another-secret|private-ish-material/);
  assert.match(redacted, /token=\[REDACTED\]/);
  assert.match(redacted, /TOKEN=\[REDACTED\]/);
  assert.match(redacted, /\[REDACTED CERTIFICATE\]/);
});
