import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import test from "node:test";

const html = readFileSync(
  new URL("../docs/manifest-rings/manifest-ring.html", import.meta.url),
  "utf8",
);

function nodeOpacity(className) {
  const match = new RegExp(
    `\\.react-flow__node\\.${className} \\{ opacity: ([.0-9]+); \\}`,
  ).exec(html);

  assert.ok(match, `missing opacity rule for ${className}`);
  return Number(match[1]);
}

test("delivery-stream filters dim every non-selected node equally", () => {
  assert.equal(
    nodeOpacity("impl-match-support"),
    nodeOpacity("impl-match-none"),
  );
});

test("active progress styling follows the configured current stream", () => {
  assert.equal(
    /setProperty\('--impl-current', streams\[deliveryProgress\.currentStream\]\.color\)/.test(html),
    true,
    "the current highlight must be derived from deliveryProgress.currentStream",
  );
  assert.equal(
    /\.implementation-step\[data-progress-status="current"\][\s\S]*?var\(--impl-current\)/.test(html),
    true,
    "the current delivery step must use the current-stream color",
  );
  assert.equal(
    /\.implementation-gate\[data-gate-status="active"\][\s\S]*?var\(--impl-current\)/.test(html),
    true,
    "the active slice must use the current-stream color",
  );
});

test("auto-refresh watches the complete static document surface", () => {
  assert.equal(
    html.includes('id="manifest-document-refresh"'),
    true,
    "the page needs a document-level refresh watcher",
  );
  assert.equal(
    /querySelectorAll\('style, script, title, meta, link'\)/.test(html),
    true,
    "refresh must cover CSS, JavaScript, metadata, and embedded graph data",
  );
  assert.equal(
    /nextStaticSource !== baselineStaticSource/.test(html),
    true,
    "refresh must reload when the served static document changes",
  );
});

test("planning data adaptation cannot trigger the bundled reload loop", () => {
  assert.equal(
    html.includes(
      'document.documentElement.dataset.manifestSurface!=="planning"&&nn&&nn!==manifestLiveData',
    ),
    true,
    "the bundled graph-data watcher must not compare runtime-adapted Planning data with the raw document",
  );
});

test("completed delivery coverage is marked directly on graph nodes", () => {
  assert.equal(
    /deliveryProgress\.completedStreams\.has\(own\.primary\)/.test(html),
    true,
    "node completion must come from the canonical completed-stream set",
  );
  assert.equal(
    /gates\[selectedGate\]\.status === 'accepted'/.test(html),
    true,
    "accepted planning gates must expose their completion on covered nodes",
  );
  assert.equal(
    html.includes('class="implementation-owner__complete"'),
    true,
    "completed graph nodes need a visible completion marker",
  );
});
