import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import { test } from "node:test";
import { fileURLToPath } from "node:url";

import {
  evaluateBrainContext,
  type BrainContextEvaluationReport,
} from "../scripts/evaluate-brain-context.ts";

test("brain context evaluation report satisfies the deterministic WP0 contract", async () => {
  const report: BrainContextEvaluationReport = await evaluateBrainContext();
  const baseline = JSON.parse(await readFile(fileURLToPath(new URL("./fixtures/brain-context/evaluation-baseline.json", import.meta.url)), "utf8"));

  assert.equal(report.schema_version, 1);
  assert.deepEqual(report.tokenizer.encoding, "o200k_base");
  assert.ok(report.tokenizer.package_version);
  assert.equal(report.scenarios.length, 8);
  assert.deepEqual(
    report.scenarios.map((scenario) => scenario.id),
    [
      "generic-unknown-project",
      "instruction-system-audit",
      "explicit-rust-question",
      "skill-creation-repair",
      "known-anvil-workspace-startup",
      "lifecycle-startup",
      "lifecycle-resume",
      "lifecycle-clear-compact",
    ],
  );
  assert.deepEqual(
    report.scenarios.filter((scenario) => scenario.verdict === "known_failure").map((scenario) => scenario.issue_id),
    ["WP0-LANGUAGE-RELEVANCE"],
  );
  const byId = new Map(report.scenarios.map((scenario) => [scenario.id, scenario]));
  assert.ok(byId.get("instruction-system-audit")?.selected_page_paths.includes("patterns/rust.md"));
  assert.ok(byId.get("explicit-rust-question")?.selected_page_paths.includes("patterns/rust.md"));
  assert.ok(report.scenarios.every((scenario) => scenario.tokens.rendered_payload >= 0));
  assert.ok(report.scenarios.every((scenario) => scenario.provider_usage.status === "not_observed"));
  assert.equal(JSON.stringify(report), JSON.stringify(await evaluateBrainContext()));
  assert.deepEqual(report, baseline);
});
