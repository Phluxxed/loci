import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { EventEmitter } from 'node:events';
import { existsSync, mkdirSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { test } from 'node:test';
import { caseNames, keyRoot } from '../scripts/brain-frozen-cases.mjs';
import { buildCaseSequence, captureProcess, runSequence, validatePermissionProof } from '../scripts/brain-case-runner.mjs';

const temporary = () => mkdtempSync(join(tmpdir(), 'brain-case-runner-test-'));
const digest = path => createHash('sha256').update(readFileSync(path)).digest('hex');

class FakeClock {
  #now = 0;
  #timers = [];
  setTimeout = (fn, delay) => {
    const timer = { fn, at: this.#now + delay, active: true };
    this.#timers.push(timer);
    return timer;
  };
  clearTimeout = timer => { if (timer) timer.active = false; };
  advance(ms) {
    const until = this.#now + ms;
    for (;;) {
      const due = this.#timers.filter(timer => timer.active && timer.at <= until).sort((a, b) => a.at - b.at)[0];
      if (!due) break;
      this.#now = due.at; due.active = false; due.fn();
    }
    this.#now = until;
  }
}

const fakeProcess = ({ ignoreTerm = false } = {}) => {
  const child = new EventEmitter(), stdout = new EventEmitter(), stderr = new EventEmitter(), stdin = new EventEmitter();
  const signals = [];
  let started;
  const spawned = new Promise(resolve => { started = resolve; });
  child.pid = 42; child.stdout = stdout; child.stderr = stderr; child.stdin = stdin;
  stdin.end = input => { stdin.input = input; };
  const close = (code = 0, signal = null) => child.emit('close', code, signal);
  return { child, signals, close, spawned, runtime: {
    spawn: () => { started(); return child; },
    kill: (_pid, signal) => {
      signals.push(signal);
      if (signal === 'SIGKILL' || (signal === 'SIGTERM' && !ignoreTerm)) queueMicrotask(() => close(null, signal));
    },
  } };
};

test('buildCaseSequence is fixed, maps timeouts, and keeps expectations out of turns', () => {
  const sentinel = 'EXPECTATION-SENTINEL-MUST-NOT-REACH-A-TURN';
  const knowledge = ['k01', 'k02', 'k03', 'k04'].map(id => ({
    id, prompt: `knowledge prompt ${id}`, expected: sentinel, fixtureExplanation: sentinel,
  }));
  const operational = { cases: [
    { id: 'c05', prompt: 'conflict prompt', reportInstructions: sentinel },
    { id: 'c06', fresh_prompt: 'fresh recovery prompt', resume_prompt: 'resumed recovery prompt', expected: sentinel },
  ] };
  const sequence = ['k01:old', 'k01:current', 'k02:current', 'k02:old', 'k03:old', 'k03:current',
    'k04:current', 'k04:old', 'c05:current', 'c06:current:fresh', 'c06:current:exact-resume'];
  const turns = buildCaseSequence(knowledge, operational, {
    sequence,
    timeoutsSeconds: { knowledgeTurn: 7, conflictTurn: 11, recoveryFreshTurn: 13, recoveryResumedTurn: 17 },
  });

  assert.deepEqual(turns.map(turn => turn.key), sequence);
  assert.deepEqual(turns.map(turn => turn.name), ['k01-old', 'k01-current', 'k02-current', 'k02-old', 'k03-old', 'k03-current',
    'k04-current', 'k04-old', 'c05-current', 'c06-current', 'c06-current']);
  assert.deepEqual(turns.map(turn => turn.timeoutMs), [7000, 7000, 7000, 7000, 7000, 7000, 7000, 7000, 11000, 13000, 17000]);
  assert.deepEqual(turns.map(turn => turn.resume), [false, false, false, false, false, false, false, false, false, false, true]);
  assert.deepEqual(turns.slice(-2).map(turn => [turn.label, turn.prompt]), [
    ['fresh', 'fresh recovery prompt'], ['resumed', 'resumed recovery prompt'],
  ]);
  assert(!JSON.stringify(turns).includes(sentinel));
});

test('validatePermissionProof checks probe paths and every settings hash', () => {
  const root = temporary();
  try {
    for (const name of caseNames) {
      mkdirSync(join(root, name, 'captures'), { recursive: true });
      writeFileSync(join(root, name, 'settings.json'), JSON.stringify({ name }) + '\n');
    }
    const calls = [];
    const fileHash = path => { calls.push(path); return digest(path); };
    const probe = name => {
      const paths = [keyRoot, join(root, name, 'captures'), join(root, name, 'settings.json'), join(root, 'k02-current')];
      return { name, passed: true, status: 0, observed: { controlReadable: true,
        results: paths.map(path => ({ path, denied: true, code: 'EACCES' })) }, settingsHash: digest(join(root, name, 'settings.json')) };
    };
    const proof = { root, passed: true, modelRuns: 0, results: [probe('k01-old'), probe('c05-current')],
      settingsHashes: Object.fromEntries(caseNames.map(name => [name, digest(join(root, name, 'settings.json'))])) };

    validatePermissionProof(proof, root, fileHash);
    assert.deepEqual(calls, [
      join(root, 'k01-old', 'settings.json'), join(root, 'c05-current', 'settings.json'),
      ...caseNames.map(name => join(root, name, 'settings.json')),
    ]);

    writeFileSync(join(root, 'k04-old', 'settings.json'), 'changed\n');
    assert.throws(() => validatePermissionProof(proof, root, fileHash), /Permission-bound settings changed/);
    rmSync(join(root, 'k04-old', 'settings.json'));
    assert.throws(() => validatePermissionProof(proof, root, fileHash), /ENOENT/);
    assert.throws(() => validatePermissionProof({ ...proof, passed: false }, root, fileHash));
    assert.throws(() => validatePermissionProof({ ...proof, settingsHashes: { ...proof.settingsHashes, missing: 'fake' } }, root, fileHash));
  } finally {
    rmSync(root, { recursive: true, force: true });
  }
});

test('runSequence binds c06 resume to its exact fresh session and stops without retries', async () => {
  const turns = [
    { key: 'c05:current', name: 'c05-current', resume: false },
    { key: 'c06:current:fresh', name: 'c06-current', resume: false },
    { key: 'c06:current:exact-resume', name: 'c06-current', resume: true },
  ];
  const observed = [];
  const results = await runSequence(turns, async (turn, previous) => {
    observed.push([turn.key, previous?.sessionId ?? null]);
    return { sessionId: turn.resume ? previous.sessionId : turn.name === 'c06-current' ? 'session-c06' : 'session-c05' };
  });
  assert.deepEqual(observed, [['c05:current', null], ['c06:current:fresh', null], ['c06:current:exact-resume', 'session-c06']]);
  assert.equal(results.at(-1).sessionId, 'session-c06');
  await assert.rejects(runSequence([{ key: 'arbitrary:resume', name: 'arbitrary', resume: true }], async () => ({ sessionId: 'arbitrary' })), /No retries/);
  await assert.rejects(runSequence(turns.slice(1), async (turn, previous) => ({ sessionId: turn.resume ? 'wrong-session' : 'session-c06' })), /Recovery changed session/);

  let calls = 0;
  await assert.rejects(runSequence([
    { key: 'first', name: 'first', resume: false }, { key: 'second', name: 'second', resume: false }, { key: 'third', name: 'third', resume: false },
  ], async turn => { calls++; if (turn.key === 'second') throw new Error('first failure'); return { sessionId: turn.key }; }), /first failure/);
  assert.equal(calls, 2);
});

test('captureProcess preserves stdin bytes, stdout/stderr, and nonzero exit status with a fake process', async () => {
  const directory = temporary();
  try {
    const input = 'exact stdin → line 2\n';
    const clock = new FakeClock(), fake = fakeProcess();
    const resultPromise = captureProcess('fake', [], { input, directory, timeoutMs: 5000 }, { ...fake.runtime, ...clock });
    await fake.spawned;
    fake.child.stdout.emit('data', Buffer.from('OUT:' + input));
    fake.child.stderr.emit('data', Buffer.from('ERR'));
    fake.close(7);
    const result = await resultPromise;
    assert.equal(result.code, 7); assert.equal(result.signal, null); assert.equal(result.stopped, null);
    assert.equal(fake.child.stdin.input, input);
    assert.equal(readFileSync(join(directory, 'events.jsonl'), 'utf8'), 'OUT:' + input);
    assert.equal(readFileSync(join(directory, 'stderr.txt'), 'utf8'), 'ERR');
  } finally {
    rmSync(directory, { recursive: true, force: true });
  }
});

test('captureProcess keeps structured-progressing turns alive past the former total timeout', async () => {
  const timeoutDirectory = temporary();
  try {
    const clock = new FakeClock(), fake = fakeProcess();
    const resultPromise = captureProcess('fake', [], { input: '', directory: timeoutDirectory, timeoutMs: 100, idleTimeoutMs: 10 }, { ...fake.runtime, ...clock });
    await fake.spawned;
    for (let count = 0; count < 6; count++) {
      clock.advance(9);
      const event = JSON.stringify({ type: 'item.completed', item: { type: 'command_execution', status: 'completed' } }) + '\n';
      fake.child.stdout.emit('data', Buffer.from(event.slice(0, 17)));
      fake.child.stdout.emit('data', Buffer.from(event.slice(17)));
    }
    fake.close(0);
    const result = await resultPromise;
    assert.equal(result.stopped, null);
    assert.equal(result.code, 0);
  } finally {
    rmSync(timeoutDirectory, { recursive: true, force: true });
  }
});

test('captureProcess ignores stderr chatter and arbitrary stdout bytes for inactivity', async () => {
  const directory = temporary();
  try {
    const clock = new FakeClock(), fake = fakeProcess();
    const resultPromise = captureProcess('fake', [], { input: '', directory, timeoutMs: 100, idleTimeoutMs: 10 }, { ...fake.runtime, ...clock });
    await fake.spawned;
    fake.child.stderr.emit('data', Buffer.from('still chatting'));
    fake.child.stdout.emit('data', Buffer.from('not a structured progress event\n'));
    clock.advance(10);
    const result = await resultPromise;
    assert.equal(result.stopped, 'idle-timeout');
    assert.deepEqual(fake.signals, ['SIGTERM']);
  } finally {
    rmSync(directory, { recursive: true, force: true });
  }
});

test('captureProcess enforces the absolute cap despite continuing structured progress', async () => {
  const directory = temporary();
  try {
    const clock = new FakeClock(), fake = fakeProcess({ ignoreTerm: true });
    const resultPromise = captureProcess('fake', [], { input: '', directory, timeoutMs: 30, idleTimeoutMs: 10 }, { ...fake.runtime, ...clock });
    await fake.spawned;
    for (let count = 0; count < 3; count++) {
      clock.advance(9);
      fake.child.stdout.emit('data', Buffer.from('{"type":"item.completed"}\n'));
    }
    clock.advance(3);
    clock.advance(1500);
    const result = await resultPromise;
    assert.equal(result.stopped, 'timeout');
    assert.deepEqual(fake.signals, ['SIGTERM', 'SIGKILL']);
  } finally {
    rmSync(directory, { recursive: true, force: true });
  }
});

test('captureProcess preserves legacy timeout, output limits, and reserved files with fake processes', async () => {
  const timeoutDirectory = temporary();
  try {
    const clock = new FakeClock(), fake = fakeProcess();
    const resultPromise = captureProcess('fake', [], { input: '', directory: timeoutDirectory, timeoutMs: 50 }, { ...fake.runtime, ...clock });
    await fake.spawned; clock.advance(50);
    const result = await resultPromise;
    assert.equal(result.stopped, 'timeout');
  } finally {
    rmSync(timeoutDirectory, { recursive: true, force: true });
  }

  const boundedDirectory = temporary();
  try {
    const clock = new FakeClock(), fake = fakeProcess();
    const resultPromise = captureProcess('fake', [], { input: '', directory: boundedDirectory, timeoutMs: 5000, maxBytes: 32 }, { ...fake.runtime, ...clock });
    await fake.spawned; fake.child.stdout.emit('data', Buffer.from('o'.repeat(100))); fake.child.stderr.emit('data', Buffer.from('e'.repeat(100)));
    const result = await resultPromise;
    const saved = readFileSync(join(boundedDirectory, 'events.jsonl')).length + readFileSync(join(boundedDirectory, 'stderr.txt')).length;
    assert.equal(result.stopped, 'capture-limit'); assert(result.bytes > 32); assert(saved <= 32);
  } finally {
    rmSync(boundedDirectory, { recursive: true, force: true });
  }

  const reservedDirectory = temporary();
  try {
    const events = join(reservedDirectory, 'events.jsonl'); const stderr = join(reservedDirectory, 'stderr.txt');
    const marker = join(reservedDirectory, 'spawned');
    writeFileSync(events, 'existing-events'); writeFileSync(stderr, 'existing-stderr');
    const clock = new FakeClock(), fake = fakeProcess();
    await assert.rejects(captureProcess('fake', [], { input: '', directory: reservedDirectory, timeoutMs: 5000 }, { ...fake.runtime, ...clock }), /EEXIST/);
    assert.equal(readFileSync(events, 'utf8'), 'existing-events'); assert.equal(readFileSync(stderr, 'utf8'), 'existing-stderr');
    assert.equal(existsSync(marker), false);
  } finally {
    rmSync(reservedDirectory, { recursive: true, force: true });
  }
});
