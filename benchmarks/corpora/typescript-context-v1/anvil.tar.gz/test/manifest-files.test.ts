import assert from "node:assert/strict";
import { execFileSync } from "node:child_process";
import { cp, mkdir, mkdtemp, readFile, readdir, realpath, rm, symlink, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { afterEach, test } from "node:test";

import {
  createObjectiveFile,
  discoverObjectives,
  loadObjective,
  ManifestFileError,
  objectiveIdSchema,
  resolveRepository,
  startManifestViewServer,
  validateObjective,
  writeObjective,
} from "../src/manifest/index.ts";
import type { ObjectiveGraph } from "../src/manifest/index.ts";

const roots: string[] = [];

afterEach(async () => {
  await Promise.all(roots.splice(0).map((root) => rm(root, { recursive: true, force: true })));
});

async function gitRepository(): Promise<string> {
  const root = await mkdtemp(join(tmpdir(), "manifest-files-"));
  roots.push(root);
  execFileSync("git", ["init", "-q"], { cwd: root });
  return root;
}

const objective = {
  id: "obj_11111111111111111111111111111111",
  title: "Manifest V2",
  outcome: "The graph lives with the thing being built.",
  details: "Repository-owned Objective JSON.",
  phase: "implementation",
  workstreams: [{
    id: "ws_22222222222222222222222222222222",
    title: "Objective files",
    outcome: "Objective state is a reviewable Git diff.",
    details: "W2",
    tasks: [
      {
        id: "task_33333333333333333333333333333333",
        title: "First",
        outcome: "First prerequisite.",
        details: "",
        completionCriteria: ["First is complete."],
        dependencies: [],
        externalBlocker: null,
        completion: null,
        discontinued: null,
      },
      {
        id: "task_44444444444444444444444444444444",
        title: "Second",
        outcome: "Second prerequisite.",
        details: "",
        completionCriteria: ["Second is complete."],
        dependencies: [],
        externalBlocker: null,
        completion: null,
        discontinued: null,
      },
      {
        id: "task_55555555555555555555555555555555",
        title: "Dependent",
        outcome: "Both prerequisites are reflected in graph order.",
        details: "",
        completionCriteria: ["Dependencies serialize deterministically."],
        dependencies: [
          "task_44444444444444444444444444444444",
          "task_33333333333333333333333333333333",
        ],
        externalBlocker: null,
        completion: null,
        discontinued: null,
      },
    ],
  }],
} as const;

test("Objective files use the canonical repository path and deterministic JSON", async () => {
  const repository = await gitRepository();
  const validated = validateObjective(objective);
  assert.equal(validated.valid, true);
  if (!validated.valid) return;

  const created = await createObjectiveFile(repository, validated.graph);
  assert.equal(created.path, join(await realpath(repository), ".manifest", "objectives", `${objective.id}.json`));
  assert.deepEqual((await loadObjective(repository, validated.graph.id)).graph, {
    ...validated.graph,
    workstreams: [{
      ...validated.graph.workstreams[0]!,
      tasks: [
        validated.graph.workstreams[0]!.tasks[0]!,
        validated.graph.workstreams[0]!.tasks[1]!,
        {
          ...validated.graph.workstreams[0]!.tasks[2]!,
          dependencies: [
            validated.graph.workstreams[0]!.tasks[0]!.id,
            validated.graph.workstreams[0]!.tasks[1]!.id,
          ],
        },
      ],
    }],
  });
  const bytes = await readFile(created.path, "utf8");
  assert.equal(bytes.endsWith("\n"), true);
  assert.equal(bytes.endsWith("\n\n"), false);
  assert.match(bytes, /^\{\n  "id":/);
});

test("discovery isolates invalid Objective files and keeps valid Objectives usable", async () => {
  const repository = await gitRepository();
  const validated = validateObjective(objective);
  assert.equal(validated.valid, true);
  if (!validated.valid) return;
  const created = await createObjectiveFile(repository, validated.graph);
  const directory = join(await realpath(repository), ".manifest", "objectives");
  const mismatchedName = "obj_00000000000000000000000000000000.json";
  const malformedName = "obj_99999999999999999999999999999999.json";
  await writeFile(join(directory, mismatchedName), JSON.stringify(validated.graph), "utf8");
  await writeFile(join(directory, malformedName), "{ nope", "utf8");
  await writeFile(join(directory, "notes.txt"), "not an Objective", "utf8");
  await mkdir(join(directory, "nested"));
  await writeFile(join(directory, "nested", `${objective.id}.json`), JSON.stringify(validated.graph), "utf8");
  await writeFile(join(repository, `${objective.id}.json`), JSON.stringify(validated.graph), "utf8");

  const discovered = await discoverObjectives(repository);
  assert.deepEqual(discovered.map((item) => ({
    name: item.path.slice(directory.length + 1),
    valid: item.valid,
  })), [
    { name: mismatchedName, valid: false },
    { name: `${objective.id}.json`, valid: true },
    { name: malformedName, valid: false },
  ]);
  assert.equal(discovered[0]?.valid, false);
  if (discovered[0]?.valid === false) assert.match(discovered[0].problems[0]!.message, /does not match filename/);
  assert.equal(discovered[2]?.valid, false);
  if (discovered[2]?.valid === false) assert.match(discovered[2].problems[0]!.message, /Malformed JSON/);
  assert.equal((await loadObjective(repository, validated.graph.id)).path, created.path);
});

test("an invalid replacement leaves the existing Objective bytes untouched", async () => {
  const repository = await gitRepository();
  const validated = validateObjective(objective);
  assert.equal(validated.valid, true);
  if (!validated.valid) return;
  const created = await createObjectiveFile(repository, validated.graph);
  const before = await readFile(created.path, "utf8");
  const invalid = structuredClone(validated.graph);
  invalid.workstreams[0]!.tasks[0]!.dependencies = [invalid.workstreams[0]!.tasks[0]!.id];

  await assert.rejects(
    writeObjective(repository, invalid as ObjectiveGraph),
    (error: unknown) => {
      assert.equal(error instanceof Error && "code" in error ? error.code : undefined, "OBJECTIVE_GRAPH_INVALID");
      return true;
    },
  );
  assert.equal(await readFile(created.path, "utf8"), before);
  const replacement = { ...validated.graph, title: "Updated Objective" };
  await writeObjective(repository, replacement);
  assert.equal((await loadObjective(repository, validated.graph.id)).graph.title, "Updated Objective");
  assert.notEqual(await readFile(created.path, "utf8"), before);
  assert.deepEqual((await readdir(join(await realpath(repository), ".manifest", "objectives")))
    .filter((name) => name.includes(".tmp-")), []);
});

test("file operations reject non-roots, missing Objectives, and duplicate creation", async () => {
  await assert.rejects(
    discoverObjectives("relative/repository"),
    (error: unknown) => error instanceof Error && "code" in error && error.code === "REPOSITORY_INVALID",
  );
  const repository = await gitRepository();
  const validated = validateObjective(objective);
  assert.equal(validated.valid, true);
  if (!validated.valid) return;

  const missingId = objectiveIdSchema.parse("obj_99999999999999999999999999999999");
  await assert.rejects(
    loadObjective(repository, missingId),
    (error: unknown) => error instanceof Error && "code" in error && error.code === "OBJECTIVE_NOT_FOUND",
  );
  await createObjectiveFile(repository, validated.graph);
  await assert.rejects(
    createObjectiveFile(repository, validated.graph),
    (error: unknown) => error instanceof Error && "code" in error && error.code === "OBJECTIVE_EXISTS",
  );
});

test("repository identity resolves aliases, accepts linked worktrees, and keeps copies distinct", async () => {
  const repository = await gitRepository();
  const parent = await mkdtemp(join(tmpdir(), "manifest-root-alias-"));
  roots.push(parent);
  const alias = join(parent, "alias");
  await symlink(repository, alias, "dir");
  const canonical = await realpath(repository);
  assert.equal(await resolveRepository(alias), canonical);

  const copy = join(parent, "copy");
  await cp(repository, copy, { recursive: true });
  assert.equal(await resolveRepository(copy), await realpath(copy));
  assert.notEqual(await resolveRepository(copy), canonical);

  execFileSync("git", ["-c", "user.name=Manifest fixture", "-c", "user.email=manifest@example.invalid",
    "commit", "--allow-empty", "-qm", "Worktree fixture"], { cwd: repository });
  const worktree = join(parent, "worktree");
  execFileSync("git", ["worktree", "add", "--detach", "-q", worktree], { cwd: repository });
  assert.equal(await resolveRepository(worktree), await realpath(worktree));
  assert.notEqual(await resolveRepository(worktree), canonical);

  const validated = validateObjective(objective);
  assert.equal(validated.valid, true);
  if (!validated.valid) return;
  await createObjectiveFile(worktree, validated.graph);
  assert.equal((await loadObjective(worktree, validated.graph.id)).repository, await realpath(worktree));
  assert.equal((await discoverObjectives(worktree))[0]?.valid, true);
});

test("repository validation rejects fake Git entries and ignores inherited Git targeting", async () => {
  const repository = await gitRepository();
  const other = await gitRepository();
  const parent = await mkdtemp(join(tmpdir(), "manifest-invalid-root-"));
  roots.push(parent);
  const oldDir = process.env.GIT_DIR;
  const oldWorktree = process.env.GIT_WORK_TREE;
  process.env.GIT_DIR = join(repository, ".git");
  process.env.GIT_WORK_TREE = repository;
  try {
    assert.equal(await resolveRepository(other), await realpath(other));
    for (const fake of ["missing", "file", "directory", "bare"]) {
      const path = join(parent, fake);
      await mkdir(path);
      if (fake === "file") await writeFile(join(path, ".git"), "not a Git worktree");
      if (fake === "directory") await mkdir(join(path, ".git"));
      if (fake === "bare") execFileSync("git", ["init", "--bare", "-q", path], {
        env: Object.fromEntries(Object.entries(process.env).filter(([key]) => !key.startsWith("GIT_"))),
      });
      await assert.rejects(resolveRepository(path), (error: unknown) =>
        error instanceof ManifestFileError && error.code === "REPOSITORY_INVALID");
    }
    const nested = join(other, "nested");
    await mkdir(nested);
    await assert.rejects(resolveRepository(nested), (error: unknown) =>
      error instanceof ManifestFileError && error.code === "REPOSITORY_INVALID");
  } finally {
    if (oldDir === undefined) delete process.env.GIT_DIR;
    else process.env.GIT_DIR = oldDir;
    if (oldWorktree === undefined) delete process.env.GIT_WORK_TREE;
    else process.env.GIT_WORK_TREE = oldWorktree;
  }
});

test("Objective reads reject invalid identities and path traversal before reading files", async () => {
  const repository = await gitRepository();
  for (const id of ["../outside", "/outside", "..\\outside", "obj_bad", `${objective.id}/../../outside`, "%2e%2e%2foutside"]) {
    // Exercise the runtime boundary with callers that have bypassed the branded type.
    await assert.rejects(loadObjective(repository, id as ObjectiveGraph["id"]), (error: unknown) =>
      error instanceof ManifestFileError && error.code === "OBJECTIVE_GRAPH_INVALID");
  }
  assert.deepEqual(await discoverObjectives(repository), []);
});

test("Objective discovery and reads reject storage symlinks without exposing outside content", async () => {
  const outside = await gitRepository();
  const marker = "OUTSIDE-CONTENT-MUST-STAY-PRIVATE";
  const validated = validateObjective({ ...objective, title: marker });
  assert.equal(validated.valid, true);
  if (!validated.valid) return;
  const outsideFile = await createObjectiveFile(outside, validated.graph);
  const outsideBytes = await readFile(outsideFile.path, "utf8");
  for (const component of ["manifest", "objectives", "file"]) {
    const repository = await gitRepository();
    const directory = join(repository, ".manifest", "objectives");
    if (component === "manifest") {
      await symlink(join(outside, ".manifest"), join(repository, ".manifest"), "dir");
    } else if (component === "objectives") {
      await mkdir(join(repository, ".manifest"));
      await symlink(join(outside, ".manifest", "objectives"), directory, "dir");
    } else {
      await mkdir(directory, { recursive: true });
      await symlink(outsideFile.path, join(directory, `${objective.id}.json`), "file");
      const validId = objectiveIdSchema.parse("obj_99999999999999999999999999999999");
      await createObjectiveFile(repository, { ...validated.graph, id: validId, title: "Local Objective" });
    }
    await assert.rejects(loadObjective(repository, validated.graph.id), (error: unknown) => {
      assert.ok(error instanceof ManifestFileError);
      assert.equal(error.code, "OBJECTIVE_PATH_INVALID");
      assert.equal(error.message.includes(marker), false);
      return true;
    });
    if (component === "file") {
      const discovered = await discoverObjectives(repository);
      assert.deepEqual(discovered.map((item) => item.valid), [false, true]);
      assert.equal(JSON.stringify(discovered).includes(marker), false);
    } else {
      await assert.rejects(discoverObjectives(repository), (error: unknown) =>
        error instanceof ManifestFileError && error.code === "OBJECTIVE_PATH_INVALID");
    }
  }
  assert.equal(await readFile(outsideFile.path, "utf8"), outsideBytes);
});

test("Human server keeps its canonical startup root and uses confined Objective reads", async () => {
  const repository = await gitRepository();
  const other = await gitRepository();
  const parent = await mkdtemp(join(tmpdir(), "manifest-server-root-"));
  roots.push(parent);
  const alias = join(parent, "alias");
  await symlink(repository, alias, "dir");
  const validated = validateObjective(objective);
  assert.equal(validated.valid, true);
  if (!validated.valid) return;
  const local = await createObjectiveFile(repository, validated.graph);
  const marker = "OTHER-REPOSITORY-CONTENT";
  const external = await createObjectiveFile(other, { ...validated.graph, title: marker });
  const canonicalRepository = await realpath(repository);
  const canonicalOther = await realpath(other);
  const server = await startManifestViewServer({ repository: alias, port: 0 });
  try {
    const page = await fetch(`${server.url}/objectives/${objective.id}`, { redirect: "manual" });
    assert.equal(page.status, 302);
    const pageLocation = page.headers.get("location");
    assert.ok(pageLocation);
    const canonicalPage = new URL(pageLocation, server.url);
    assert.equal(canonicalPage.searchParams.get("repository"), canonicalRepository);
    assert.equal(canonicalPage.pathname, `/objectives/${objective.id}`);

    const qualifiedExternal = await fetch(`${server.url}/api/objectives/${objective.id}?repository=${encodeURIComponent(canonicalOther)}`);
    assert.equal(qualifiedExternal.status, 200);
    const qualifiedExternalBody = await qualifiedExternal.json();
    assert.equal(qualifiedExternalBody.objective.title, marker);
    assert.deepEqual(qualifiedExternalBody.target, { repository: canonicalOther, objectiveId: objective.id });

    await rm(alias);
    await symlink(other, alias, "dir");
    const url = `${server.url}/api/objectives/${objective.id}`;
    assert.equal((await (await fetch(url)).json()).objective.title, objective.title);
    await rm(local.path);
    await symlink(external.path, local.path, "file");
    const response = await fetch(url);
    assert.equal(response.status, 400);
    assert.equal((await response.text()).includes(marker), false);
    const discovered = await (await fetch(`${server.url}/api/objectives`)).json();
    assert.equal(discovered[0].valid, false);
    assert.equal(JSON.stringify(discovered).includes(marker), false);
  } finally {
    await server.close();
  }
});
