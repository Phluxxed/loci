import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import { existsSync } from "node:fs";
import { mkdir, mkdtemp, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { test } from "node:test";

import {
  deriveContinuityPaths,
  doctorContinuity,
  gitWorkspaceRef,
  initWorkspace,
  promoteContinuityEvent as promoteBoundContinuityEvent,
  recordContinuityEvent as recordBoundContinuityEvent,
} from "../src/continuity/index.ts";
import type {
  CurrentFrameInput,
  EventInput,
  PromoteContinuityEventInput,
  RecordContinuityEventInput,
} from "../src/continuity/index.ts";
import { bindWorkContext } from "../src/work-context/index.ts";
import type { WorkContextBinding } from "../src/work-context/index.ts";

const doctorBindings = new Map<string, WorkContextBinding>();

async function doctorBinding(cwd: string | undefined, stateRoot: string | undefined): Promise<WorkContextBinding> {
  assert.ok(cwd);
  assert.ok(stateRoot);
  const key = `${stateRoot}\0${cwd}`;
  const existing = doctorBindings.get(key);
  if (existing) return existing;
  const { binding } = await bindWorkContext({
    host: "test",
    sessionId: `doctor-${doctorBindings.size}`,
    cwd,
    lifecycle: "test",
    stateRoot,
  });
  doctorBindings.set(key, binding);
  return binding;
}

async function recordContinuityEvent(input: Omit<RecordContinuityEventInput, "binding"> & { cwd?: string }) {
  const { cwd, ...boundInput } = input;
  return recordBoundContinuityEvent({
    ...boundInput,
    binding: await doctorBinding(cwd, input.stateRoot),
  });
}

async function promoteContinuityEvent(input: Omit<PromoteContinuityEventInput, "binding"> & { cwd?: string }) {
  const { cwd, ...boundInput } = input;
  return promoteBoundContinuityEvent({
    ...boundInput,
    binding: await doctorBinding(cwd, input.stateRoot),
  });
}

function sampleFrameInput(overrides: Partial<CurrentFrameInput> = {}): CurrentFrameInput {
  return {
    operating_mode: "doctor-test",
    intent: "Verify continuity health diagnostics.",
    quality_bar: ["Continuity is not truth."],
    permission_envelope: {
      default: "follow current instruction",
      allowed_without_approval: ["read continuity state"],
      requires_approval: ["delete continuity history"],
    },
    active_decisions: [],
    open_questions: [],
    next_actions: [],
    continuity_notes: [],
    ...overrides,
  };
}

function sampleEventInput(overrides: Partial<EventInput> = {}): EventInput {
  return {
    type: "decision",
    status: "active",
    summary: "Doctor checks event-backed projections.",
    supersedes: [],
    resolves: [],
    related_events: [],
    ...overrides,
  };
}

function runGit(args: string[], cwd: string, env: Record<string, string> = {}): void {
  const result = spawnSync("git", args, {
    cwd,
    encoding: "utf8",
    env: {
      ...process.env,
      GIT_AUTHOR_NAME: "Anvil Test",
      GIT_AUTHOR_EMAIL: "anvil-test@example.com",
      GIT_COMMITTER_NAME: "Anvil Test",
      GIT_COMMITTER_EMAIL: "anvil-test@example.com",
      ...env,
    },
  });
  assert.equal(result.status, 0, result.stderr);
}

test("doctorContinuity reports healthy initialized continuity state", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-continuity-doctor-healthy-"));
  try {
    const repo = join(temp, "repo");
    const stateRoot = join(temp, "state");
    await mkdir(repo, { recursive: true });
    const paths = deriveContinuityPaths({ stateRoot, workspace: gitWorkspaceRef(repo, "repo") });
    await initWorkspace(paths, sampleFrameInput(), { now: () => "2026-06-03T00:00:00.000Z" });
    await recordContinuityEvent({
      cwd: repo,
      stateRoot,
      event: sampleEventInput({ summary: "Healthy decision has event lineage." }),
      id: () => "evt_doctor_healthy",
    });
    await promoteContinuityEvent({
      cwd: repo,
      stateRoot,
      eventId: "evt_doctor_healthy",
      target: "active_decisions",
    });

    const result = await doctorContinuity({ cwd: repo, stateRoot });

    assert.equal(result.status, "ok");
    assert.equal(result.findings.some((finding) => finding.code === "CURRENT_READABLE"), true);
    assert.equal(result.findings.some((finding) => finding.code === "EVENT_LOG_READABLE"), true);
    assert.equal(result.findings.some((finding) => finding.code === "PROJECTION_LINKS_VALID"), true);
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("doctorContinuity reports missing state without creating continuity files", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-continuity-doctor-missing-"));
  try {
    const repo = join(temp, "repo");
    const stateRoot = join(temp, "state");
    await mkdir(repo, { recursive: true });
    const paths = deriveContinuityPaths({ stateRoot, workspace: gitWorkspaceRef(repo, "repo") });

    const result = await doctorContinuity({ cwd: repo, stateRoot });

    assert.equal(result.status, "warning");
    assert.equal(result.findings.some((finding) => finding.code === "CURRENT_MISSING"), true);
    assert.equal(result.findings.some((finding) => finding.code === "EVENT_LOG_MISSING"), true);
    assert.equal(existsSync(paths.workspaceDir), false);
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("doctorContinuity reports malformed current frame with file path", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-continuity-doctor-current-"));
  try {
    const repo = join(temp, "repo");
    const stateRoot = join(temp, "state");
    await mkdir(repo, { recursive: true });
    const paths = deriveContinuityPaths({ stateRoot, workspace: gitWorkspaceRef(repo, "repo") });
    await initWorkspace(paths, sampleFrameInput(), { now: () => "2026-06-03T00:00:00.000Z" });
    await writeFile(paths.currentPath, "{ nope", "utf8");

    const result = await doctorContinuity({ cwd: repo, stateRoot });

    assert.equal(result.status, "error");
    const finding = result.findings.find((candidate) => candidate.code === "CURRENT_MALFORMED");
    assert.equal(finding?.path, paths.currentPath);
    assert.match(finding?.message ?? "", /Malformed JSON/);
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("doctorContinuity reports malformed event log with file path", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-continuity-doctor-events-"));
  try {
    const repo = join(temp, "repo");
    const stateRoot = join(temp, "state");
    await mkdir(repo, { recursive: true });
    const paths = deriveContinuityPaths({ stateRoot, workspace: gitWorkspaceRef(repo, "repo") });
    await initWorkspace(paths, sampleFrameInput(), { now: () => "2026-06-03T00:00:00.000Z" });
    await writeFile(paths.eventsPath, "{ nope\n", "utf8");

    const result = await doctorContinuity({ cwd: repo, stateRoot });

    assert.equal(result.status, "error");
    const finding = result.findings.find((candidate) => candidate.code === "EVENT_LOG_MALFORMED");
    assert.equal(finding?.path, paths.eventsPath);
    assert.match(finding?.message ?? "", /Malformed event JSON/);
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("doctorContinuity reports projection items linked to missing events", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-continuity-doctor-missing-link-"));
  try {
    const repo = join(temp, "repo");
    const stateRoot = join(temp, "state");
    await mkdir(repo, { recursive: true });
    const paths = deriveContinuityPaths({ stateRoot, workspace: gitWorkspaceRef(repo, "repo") });
    await initWorkspace(
      paths,
      sampleFrameInput({
        active_decisions: [{ event_id: "evt_missing_projection", summary: "Projection points nowhere." }],
      }),
      { now: () => "2026-06-03T00:00:00.000Z" },
    );

    const result = await doctorContinuity({ cwd: repo, stateRoot });

    assert.equal(result.status, "error");
    const finding = result.findings.find((candidate) => candidate.code === "PROJECTION_EVENT_MISSING");
    assert.equal(finding?.event_id, "evt_missing_projection");
    assert.equal(finding?.target, "active_decisions");
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("doctorContinuity reports active projections with newer git commits when staleness is enabled", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-continuity-doctor-stale-"));
  try {
    const repo = join(temp, "repo");
    const stateRoot = join(temp, "state");
    await mkdir(repo, { recursive: true });
    runGit(["init"], repo);

    const paths = deriveContinuityPaths({ stateRoot, workspace: gitWorkspaceRef(repo, "repo") });
    await initWorkspace(paths, sampleFrameInput(), { now: () => "2026-06-03T00:00:00.000Z" });
    await recordContinuityEvent({
      cwd: repo,
      stateRoot,
      event: sampleEventInput({ summary: "Decision recorded before a later commit." }),
      now: () => "2026-06-03T00:00:00.000Z",
      id: () => "evt_doctor_stale",
    });
    await promoteContinuityEvent({
      cwd: repo,
      stateRoot,
      eventId: "evt_doctor_stale",
      target: "active_decisions",
    });

    await writeFile(join(repo, "later.txt"), "later\n", "utf8");
    runGit(["add", "later.txt"], repo);
    runGit(["commit", "-m", "later commit"], repo, {
      GIT_AUTHOR_DATE: "2026-06-04T00:00:00Z",
      GIT_COMMITTER_DATE: "2026-06-04T00:00:00Z",
    });

    const result = await doctorContinuity({ cwd: repo, stateRoot, checkStaleness: true });

    assert.equal(result.status, "warning");
    const finding = result.findings.find((candidate) => candidate.code === "PROJECTION_STALE_AFTER_COMMIT");
    assert.equal(finding?.event_id, "evt_doctor_stale");
    assert.equal(finding?.target, "active_decisions");
    assert.match(finding?.message ?? "", /2026-06-03T00:00:00.000Z/);
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("doctorContinuity reports git failures when staleness cannot be computed", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-continuity-doctor-staleness-fail-"));
  try {
    const repo = join(temp, "repo");
    const stateRoot = join(temp, "state");
    await mkdir(repo, { recursive: true });
    const paths = deriveContinuityPaths({ stateRoot, workspace: gitWorkspaceRef(repo, "repo") });
    await initWorkspace(paths, sampleFrameInput(), { now: () => "2026-06-03T00:00:00.000Z" });
    await recordContinuityEvent({
      cwd: repo,
      stateRoot,
      event: sampleEventInput({ summary: "Decision recorded outside a git repo." }),
      now: () => "2026-06-03T00:00:00.000Z",
      id: () => "evt_doctor_git_fail",
    });
    await promoteContinuityEvent({
      cwd: repo,
      stateRoot,
      eventId: "evt_doctor_git_fail",
      target: "active_decisions",
    });

    const result = await doctorContinuity({ cwd: repo, stateRoot, checkStaleness: true });

    assert.equal(result.status, "warning");
    const finding = result.findings.find((candidate) => candidate.code === "STALENESS_CHECK_FAILED");
    assert.equal(finding?.event_id, "evt_doctor_git_fail");
    assert.match(finding?.message ?? "", /Could not compute staleness/);
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("continuity doctor CLI returns structured JSON", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-continuity-doctor-cli-"));
  try {
    const repo = join(temp, "repo");
    const stateRoot = join(temp, "state");
    await mkdir(repo, { recursive: true });
    const paths = deriveContinuityPaths({ stateRoot, workspace: gitWorkspaceRef(repo, "repo") });
    await initWorkspace(paths, sampleFrameInput(), { now: () => "2026-06-03T00:00:00.000Z" });

    const result = spawnSync(
      process.execPath,
      ["bin/anvil.ts", "continuity", "doctor", "--json", "--cwd", repo, "--state-root", stateRoot],
      { cwd: process.cwd(), encoding: "utf8" },
    );

    assert.equal(result.status, 0, result.stderr);
    const output = JSON.parse(result.stdout) as { status: string; findings: Array<{ code: string }> };
    assert.equal(output.status, "ok");
    assert.equal(output.findings.some((finding) => finding.code === "CURRENT_READABLE"), true);
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});
