import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import { resolve } from "node:path";
import { test } from "node:test";

const repoRoot = resolve(".");

function workContextBoundTools(source: string): string[] {
  const declaration = source.match(/const WORK_CONTEXT_BOUND_TOOLS = new Set\(\[([\s\S]*?)\]\);/);
  assert.ok(declaration, "WORK_CONTEXT_BOUND_TOOLS must remain a literal Set declaration");
  return Array.from(declaration[1].matchAll(/"([^"]+)"/g), ([, name]) => name);
}

test("Codex host setup documentation and project MCP config track the bound-tool contract", async () => {
  const [source, setup, config, hooks] = await Promise.all([
    readFile(resolve(repoRoot, "bin/anvil.ts"), "utf8"),
    readFile(resolve(repoRoot, "docs/MCP_SETUP.md"), "utf8"),
    readFile(resolve(repoRoot, ".codex/config.toml"), "utf8"),
    readFile(resolve(repoRoot, ".codex/hooks.json"), "utf8"),
  ]);
  const tools = workContextBoundTools(source);
  const matcher = `^mcp__anvil__(${tools.join("|")})$`;

  assert.equal(tools.length, 10);
  assert.ok(tools.every((name) => setup.includes(`- \`${name}\``)));
  assert.match(setup, new RegExp(`"matcher": "${matcher.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}"`));
  assert.match(setup, /"matcher": "startup\|resume\|clear\|compact"/);
  assert.match(setup, /"matcher": "\^Bash\$"/);
  assert.doesNotMatch(setup, /\banvil_maintenance_candidate_record\b/);
  assert.doesNotMatch(setup, /\bStop\b/);
  assert.match(setup, /anvil_session_bootstrap[\s\S]*anvil_brain_setup[\s\S]*`\/wikime`[\s\S]*`wiki_register`/);
  assert.match(setup, /do not clone or import `~\/\.anvil-brain\/codex`/);
  assert.match(config, /ANVIL_AGENT_ID = "codex"/);
  assert.match(config, /ANVIL_STATE_ROOT = "\/Users\/brummerv\/\.anvil\/state"/);
  assert.deepEqual(JSON.parse(hooks), { hooks: {} });
});
