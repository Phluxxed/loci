import assert from "node:assert/strict";
import { execFileSync } from "node:child_process";
import { mkdtemp, mkdir, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { afterEach, test } from "node:test";

import { deriveTaskCreation } from "../src/manifest/task-creation.ts";
import type { ObjectiveGraph, ObjectiveId, Task, TaskId, WorkstreamId } from "../src/manifest/model.ts";

const roots: string[] = [];

afterEach(async () => {
  await Promise.all(roots.splice(0).map((root) => rm(root, { recursive: true, force: true })));
});

const objectiveId = "obj_11111111111111111111111111111111" as ObjectiveId;
const firstWorkstreamId = "ws_22222222222222222222222222222222";
const secondWorkstreamId = "ws_33333333333333333333333333333333";
const baselineTaskId = "task_44444444444444444444444444444444";
const addedTaskId = "task_55555555555555555555555555555555";
const anotherTaskId = "task_66666666666666666666666666666666";
const notedParentTaskId = "task_77777777777777777777777777777777";
const notedChildTaskId = "task_88888888888888888888888888888888";
const unknownSiblingTaskId = "task_99999999999999999999999999999999";
const explicitImplementationTaskId = "task_aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";
const misleadingTaskId = "task_bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb";
const conflictingTaskId = "task_cccccccccccccccccccccccccccccccc";

async function gitRepository(): Promise<string> {
  const root = await mkdtemp(join(tmpdir(), "manifest-task-creation-"));
  roots.push(root);
  execFileSync("git", ["init", "-q"], { cwd: root });
  execFileSync("git", ["config", "user.name", "Manifest Tests"], { cwd: root });
  execFileSync("git", ["config", "user.email", "manifest-tests@example.invalid"], { cwd: root });
  return root;
}

function task(id: string, title = id, details = ""): Task {
  return {
    id: id as TaskId,
    title,
    outcome: `${title} outcome.`,
    details,
    completionCriteria: [],
    dependencies: [],
    externalBlocker: null,
    completion: null,
    discontinued: null,
    tasks: [],
  };
}

function graph(phase: ObjectiveGraph["phase"], tasks: readonly Task[], includeSecondWorkstream = false): ObjectiveGraph {
  const workstreams = [{
    id: firstWorkstreamId as WorkstreamId,
    title: "First Workstream",
    outcome: "The first Workstream contains the objective work.",
    details: "",
    tasks: [...tasks],
  }];
  if (includeSecondWorkstream) {
    workstreams.push({
      id: secondWorkstreamId as WorkstreamId,
      title: "Second Workstream",
      outcome: "The second Workstream receives moved work.",
      details: "",
      tasks: [],
    });
  }
  return {
    id: objectiveId,
    title: "Task creation metadata",
    outcome: "The view explains when Tasks entered the graph.",
    details: "",
    phase,
    workstreams,
  };
}

async function commitGraph(repository: string, value: ObjectiveGraph, message: string): Promise<void> {
  const directory = join(repository, ".manifest", "objectives");
  await mkdir(directory, { recursive: true });
  await writeFile(join(directory, `${objectiveId}.json`), JSON.stringify(value), "utf8");
  execFileSync("git", ["add", "--", `.manifest/objectives/${objectiveId}.json`], { cwd: repository });
  execFileSync("git", ["commit", "-q", "-m", message], { cwd: repository });
}

test("a Task added after a committed Planning-to-Implementation transition is marked Implementation", async () => {
  const repository = await gitRepository();
  const baseline = task(baselineTaskId, "Baseline Task");
  await commitGraph(repository, graph("planning", [baseline]), "planning baseline");
  await commitGraph(repository, graph("implementation", [baseline]), "accept implementation");

  const current = graph("implementation", [baseline, task(addedTaskId, "Implementation addition")]);
  assert.deepEqual(await deriveTaskCreation(repository, current), {
    [baselineTaskId]: "planning",
    [addedTaskId]: "implementation",
  });
});

test("a Task added in the same commit as the Planning-to-Implementation transition is unknown", async () => {
  const repository = await gitRepository();
  const baseline = task(baselineTaskId, "Baseline Task");
  await commitGraph(repository, graph("planning", [baseline]), "planning baseline");
  const transitionAddition = task(addedTaskId, "Transition addition");
  await commitGraph(repository, graph("implementation", [baseline, transitionAddition]), "accept and add");

  assert.deepEqual(await deriveTaskCreation(repository, graph("implementation", [baseline, transitionAddition])), {
    [baselineTaskId]: "planning",
    [addedTaskId]: "unknown",
  });
});

test("an uncommitted Task in a Planning graph is marked Planning when committed history is usable", async () => {
  const repository = await gitRepository();
  const baseline = task(baselineTaskId, "Baseline Task");
  await commitGraph(repository, graph("planning", [baseline]), "planning baseline");

  assert.deepEqual(await deriveTaskCreation(repository, graph("planning", [baseline, task(anotherTaskId)])), {
    [baselineTaskId]: "planning",
    [anotherTaskId]: "planning",
  });
});

test("first-established Task identity survives implementation addition, rename, and reparenting", async () => {
  const repository = await gitRepository();
  const baseline = task(baselineTaskId, "Baseline Task");
  await commitGraph(repository, graph("planning", [baseline], true), "planning baseline");
  await commitGraph(repository, graph("implementation", [baseline], true), "accept implementation");
  await commitGraph(
    repository,
    graph("implementation", [baseline, task(addedTaskId, "Added Task")], true),
    "implementation addition",
  );

  const renamed = task(addedTaskId, "Renamed and reparented Task");
  const current = graph("implementation", [baseline], true);
  current.workstreams[1]!.tasks.push(renamed);
  assert.deepEqual(await deriveTaskCreation(repository, current), {
    [baselineTaskId]: "planning",
    [addedTaskId]: "implementation",
  });
});

test("missing history leaves current Tasks explicitly unknown", async () => {
  const repository = await gitRepository();
  assert.deepEqual(await deriveTaskCreation(repository, graph("planning", [task(baselineTaskId)])), {
    [baselineTaskId]: "unknown",
  });
});

test("a malformed historical revision does not prove a later Task's origin", async () => {
  const repository = await gitRepository();
  const baseline = task(baselineTaskId, "Baseline Task");
  await commitGraph(repository, graph("planning", [baseline]), "planning baseline");
  const path = join(repository, ".manifest", "objectives", `${objectiveId}.json`);
  await writeFile(path, "{ malformed historical graph", "utf8");
  execFileSync("git", ["add", "--", `.manifest/objectives/${objectiveId}.json`], { cwd: repository });
  execFileSync("git", ["commit", "-q", "-m", "malformed revision"], { cwd: repository });

  const current = graph("implementation", [baseline, task(addedTaskId)]);
  assert.deepEqual(await deriveTaskCreation(repository, current), {
    [baselineTaskId]: "planning",
    [addedTaskId]: "unknown",
  });
});

test("explicit notes classify recursive additions in the first Implementation commit and survive movement", async () => {
  const repository = await gitRepository();
  const baseline = task(baselineTaskId, "Baseline Task");
  await commitGraph(repository, graph("planning", [baseline]), "planning baseline");

  const historicalParent = task(notedParentTaskId, "Late parent");
  historicalParent.tasks.push(task(notedChildTaskId, "Late child"));
  await commitGraph(
    repository,
    graph("implementation", [baseline, historicalParent, task(unknownSiblingTaskId, "Unknown sibling")]),
    "first implementation graph",
  );

  const notedParent = task(
    notedParentTaskId,
    "Late parent",
    "Supporting plan-change evidence.\r\n  Creation phase: Implementation. \r\n",
  );
  notedParent.tasks.push(task(notedChildTaskId, "Late child", "\nCreation phase: Implementation.\n"));
  const current = graph("implementation", [baseline, notedParent, task(unknownSiblingTaskId, "Unknown sibling")]);
  assert.deepEqual(await deriveTaskCreation(repository, current), {
    [baselineTaskId]: "planning",
    [notedParentTaskId]: "implementation",
    [notedChildTaskId]: "implementation",
    [unknownSiblingTaskId]: "unknown",
  });

  const movedParent = task(notedParentTaskId, "Renamed parent", "\tCreation phase: Implementation. \n");
  movedParent.tasks.push(task(notedChildTaskId, "Renamed child", "Creation phase: Implementation."));
  const moved = graph("implementation", [baseline], true);
  moved.workstreams[1]!.tasks.push(movedParent);
  assert.deepEqual(await deriveTaskCreation(repository, moved), {
    [baselineTaskId]: "planning",
    [notedParentTaskId]: "implementation",
    [notedChildTaskId]: "implementation",
  });
});

test("explicit notes classify current Tasks when Git history is unavailable", async () => {
  const repository = await mkdtemp(join(tmpdir(), "manifest-task-creation-no-git-"));
  roots.push(repository);

  assert.deepEqual(
    await deriveTaskCreation(repository, graph("implementation", [
      task(anotherTaskId, "Planning note", "  Creation phase: Planning.  "),
      task(explicitImplementationTaskId, "Implementation note", "\r\nCreation phase: Implementation.\r\n"),
    ])),
    {
      [anotherTaskId]: "planning",
      [explicitImplementationTaskId]: "implementation",
    },
  );
});

test("only standalone notes classify, conflicts stay unknown, and current notes refresh at the same HEAD", async () => {
  const repository = await gitRepository();
  await commitGraph(repository, graph("planning", [task(baselineTaskId, "Baseline Task")]), "planning baseline");

  const initial = graph("implementation", [
    task(baselineTaskId, "Baseline Task"),
    task(
      misleadingTaskId,
      "Misleading prose",
      "```md\nCreation phase: Implementation.\n```\nQuoted example: \"Creation phase: Implementation.\"\nCreation phase: Planning is discussed here.",
    ),
    task(
      conflictingTaskId,
      "Conflicting notes",
      "Creation phase: Planning.\nCreation phase: Implementation.",
    ),
    task(explicitImplementationTaskId, "Updated note", "Creation phase: Planning."),
  ]);
  assert.deepEqual(await deriveTaskCreation(repository, initial), {
    [baselineTaskId]: "planning",
    [misleadingTaskId]: "unknown",
    [conflictingTaskId]: "unknown",
    [explicitImplementationTaskId]: "planning",
  });

  const updated = graph("implementation", [
    task(baselineTaskId, "Baseline Task"),
    task(
      misleadingTaskId,
      "Misleading prose",
      "```md\nCreation phase: Implementation.\n```\nQuoted example: \"Creation phase: Implementation.\"\nCreation phase: Planning is discussed here.",
    ),
    task(
      conflictingTaskId,
      "Conflicting notes",
      "Creation phase: Planning.\nCreation phase: Implementation.",
    ),
    task(explicitImplementationTaskId, "Updated note", "Creation phase: Implementation."),
  ]);
  assert.deepEqual(await deriveTaskCreation(repository, updated), {
    [baselineTaskId]: "planning",
    [misleadingTaskId]: "unknown",
    [conflictingTaskId]: "unknown",
    [explicitImplementationTaskId]: "implementation",
  });
});
