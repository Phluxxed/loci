import assert from "node:assert/strict";
import { execFileSync } from "node:child_process";
import { mkdir, mkdtemp, realpath, rm, symlink, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { afterEach, test } from "node:test";

import {
  createObjectiveFile,
  discoverObjectives,
  startManifestViewServer,
  validateObjective,
} from "../src/manifest/index.ts";

const roots: string[] = [];

afterEach(async () => {
  await Promise.all(roots.splice(0).map((root) => rm(root, { recursive: true, force: true })));
});

async function gitRepository(): Promise<string> {
  const root = await mkdtemp(join(tmpdir(), "manifest-discovery-"));
  roots.push(root);
  execFileSync("git", ["init", "-q"], { cwd: root });
  return root;
}

async function emptyDirectory(): Promise<string> {
  const root = await mkdtemp(join(tmpdir(), "manifest-discovery-invalid-"));
  roots.push(root);
  return root;
}

function objective(title: string) {
  const result = validateObjective({
    id: "obj_11111111111111111111111111111111",
    title,
    outcome: "The repository owns the Objective graph.",
    details: "Discovery test fixture.",
    phase: "planning",
    workstreams: [{
      id: "ws_22222222222222222222222222222222",
      title: "Repository discovery",
      outcome: "The current repository is visible.",
      details: "",
      tasks: [{
        id: "task_33333333333333333333333333333333",
        title: "Discover Objective files",
        outcome: "The Objective is returned by the repository endpoint.",
        details: "",
        completionCriteria: ["The repository endpoint returns this Objective."],
        dependencies: [],
        externalBlocker: null,
        completion: null,
        discontinued: null,
      }],
    }],
  });
  assert.equal(result.valid, true);
  if (!result.valid) throw new Error("Discovery fixture must be valid.");
  return result.graph;
}

async function getJson(url: string): Promise<{ status: number; body: any }> {
  const response = await fetch(url);
  return { status: response.status, body: await response.json() };
}

function discoveryUrl(serverUrl: string, repository: string): string {
  return `${serverUrl}/api/objectives?repository=${encodeURIComponent(repository)}`;
}

test("explicit repository discovery sees Objective files created after startup", async () => {
  const repository = await gitRepository();
  const canonical = await realpath(repository);
  const server = await startManifestViewServer({ repository, host: "127.0.0.1", port: 0 });
  try {
    const before = await getJson(discoveryUrl(server.url, repository));
    assert.equal(before.status, 200);
    assert.deepEqual(before.body, { repository: canonical, objectives: [] });

    await createObjectiveFile(repository, objective("Created after startup"));

    const after = await getJson(discoveryUrl(server.url, repository));
    assert.equal(after.status, 200);
    assert.equal(after.body.repository, canonical);
    assert.deepEqual(after.body.objectives.map((item: any) => item.objective.title), ["Created after startup"]);
  } finally {
    await server.close();
  }
});

test("explicit discovery preserves exact malformed problems beside valid Objectives", async () => {
  const repository = await gitRepository();
  await createObjectiveFile(repository, objective("Valid sibling"));
  const directory = join(await realpath(repository), ".manifest", "objectives");
  const malformedPath = join(directory, "obj_99999999999999999999999999999999.json");
  await mkdir(directory, { recursive: true });
  await writeFile(malformedPath, "{ invalid", "utf8");

  const expected = await discoverObjectives(repository);
  const server = await startManifestViewServer({ repository, host: "127.0.0.1", port: 0 });
  try {
    const result = await getJson(discoveryUrl(server.url, repository));
    assert.equal(result.status, 200);
    assert.deepEqual(result.body.objectives, expected);
    assert.equal(result.body.objectives.some((item: any) => item.valid && item.objective.title === "Valid sibling"), true);
    const malformed = result.body.objectives.find((item: any) => !item.valid);
    assert.equal(malformed.path, malformedPath);
    assert.match(malformed.problems[0].message, /Malformed JSON/);

    const validId = result.body.objectives.find((item: any) => item.valid).objective.id;
    const validView = await getJson(`${server.url}/api/objectives/${validId}`);
    assert.equal(validView.status, 200);
    assert.equal(validView.body.objective.id, validId);
  } finally {
    await server.close();
  }
});

test("explicit roots remain distinct, aliases canonicalize, and startup discovery stays unchanged", async () => {
  const first = await gitRepository();
  const second = await gitRepository();
  await createObjectiveFile(first, objective("First repository"));
  await createObjectiveFile(second, objective("Second repository"));
  const alias = `${first}-alias`;
  roots.push(alias);
  await symlink(first, alias, "dir");
  const firstCanonical = await realpath(first);
  const secondCanonical = await realpath(second);
  const server = await startManifestViewServer({ repository: first, host: "127.0.0.1", port: 0 });
  try {
    const legacyBefore = await getJson(`${server.url}/api/objectives`);
    const [firstResult, secondResult, aliasResult] = await Promise.all([
      getJson(discoveryUrl(server.url, first)),
      getJson(discoveryUrl(server.url, second)),
      getJson(discoveryUrl(server.url, alias)),
    ]);
    assert.equal(firstResult.body.repository, firstCanonical);
    assert.equal(secondResult.body.repository, secondCanonical);
    assert.equal(aliasResult.body.repository, firstCanonical);
    assert.equal(firstResult.body.objectives[0].objective.title, "First repository");
    assert.equal(secondResult.body.objectives[0].objective.title, "Second repository");
    assert.equal(aliasResult.body.objectives[0].objective.title, "First repository");

    const legacyAfter = await getJson(`${server.url}/api/objectives`);
    assert.deepEqual(legacyAfter, legacyBefore);
  } finally {
    await server.close();
  }
});

test("empty or failed explicit roots return 400 without spoiling valid requests", async () => {
  const repository = await gitRepository();
  await createObjectiveFile(repository, objective("Still available"));
  const invalid = await emptyDirectory();
  const server = await startManifestViewServer({ repository, host: "127.0.0.1", port: 0 });
  try {
    const empty = await getJson(`${server.url}/api/objectives?repository=`);
    assert.equal(empty.status, 400);
    assert.match(empty.body.error.message, /absolute Git worktree root/);

    const [failed, valid] = await Promise.all([
      getJson(discoveryUrl(server.url, invalid)),
      getJson(discoveryUrl(server.url, repository)),
    ]);
    assert.equal(failed.status, 400);
    assert.match(failed.body.error.message, /not a Git worktree root/);
    assert.equal(valid.status, 200);
    assert.equal(valid.body.objectives[0].objective.title, "Still available");

    const subsequent = await getJson(discoveryUrl(server.url, repository));
    assert.equal(subsequent.status, 200);
    assert.equal(subsequent.body.objectives[0].objective.title, "Still available");
  } finally {
    await server.close();
  }
});
