import assert from 'node:assert/strict';
import { test } from 'node:test';
import { extractCaseTranscript, parseCaseEvents } from '../scripts/brain-case-evidence.mjs';

const jsonl = rows => rows.map(JSON.stringify).join('\n');

test('event evidence retains observable payloads but does not judge answers', () => {
  const action = { id: 'item-action', type: 'mcp_tool_call', tool: 'wiki_get_page', status: 'completed', result: { content: 'observed' } };
  const answer = { id: 'item-answer', type: 'agent_message', text: 'The observed answer.' };
  const warning = { id: 'item-warning', type: 'error', message: 'host warning' };
  const result = parseCaseEvents(jsonl([
    { type: 'thread.started', thread_id: 'case-1' },
    { type: 'item.completed', item: warning },
    { type: 'item.completed', item: action },
    { type: 'item.completed', item: answer },
    { type: 'turn.completed', usage: { input_tokens: 12, output_tokens: 3 } },
  ]), { expectedSessionId: 'case-1' });

  assert.equal(result.sessionId, 'case-1');
  assert.equal(result.completed, true);
  assert.deepEqual(result.usage, { input_tokens: 12, output_tokens: 3 });
  assert.deepEqual(result.items[1].item, action);
  assert.deepEqual(result.answers.map(({ item }) => item), [answer]);
  assert.deepEqual(result.errors.map(({ item }) => item), [warning]);
});

test('event evidence rejects malformed, failed, duplicate, and mismatched sessions', () => {
  assert.throws(() => parseCaseEvents('{'), /Malformed JSONL/);
  assert.throws(() => parseCaseEvents(jsonl([
    { type: 'thread.started', thread_id: 'one' }, { type: 'thread.started', thread_id: 'two' },
    { type: 'turn.completed' },
  ])), /Multiple distinct thread IDs/);
  assert.throws(() => parseCaseEvents(jsonl([
    { type: 'thread.started', thread_id: 'one' }, { type: 'turn.failed' },
  ])), /turn.failed/);
  assert.throws(() => parseCaseEvents(jsonl([
    { type: 'thread.started', thread_id: 'one' }, { type: 'turn.completed' },
  ]), { expectedSessionId: 'resumed-one' }), /different session/);
  assert.throws(() => parseCaseEvents(jsonl([
    { type: 'thread.started', thread_id: 'one' }, { type: 'turn.completed' }, { type: 'turn.completed' },
  ])), /exactly one/);
});

test('transcript evidence keeps only host-delivered fragments and resume delta', () => {
  const preview = 'Warning: truncated output (original token count: 4096)\n\n## Brain Context\n[truncated]\nFull hook output saved to: /tmp/spill.txt';
  const transcript = jsonl([
    { type: 'session_meta', payload: { id: 'case-1', cwd: '/case', base_instructions: 'actual base', cli_version: '0.153.4', source: 'exec', model: 'gpt-test', ignored: 'do not copy' } },
    { type: 'turn_context', payload: { model: 'gpt-test', token_budget: 1000, approval_policy: 'never', sandbox_policy: { network_access: false }, unrelated: 'omit' } },
    { type: 'response_item', payload: { type: 'message', role: 'developer', content: [{ type: 'input_text', text: 'ordinary developer direction' }] } },
    { type: 'response_item', payload: { type: 'message', role: 'developer', content: [{ type: 'input_text', text: preview }] } },
    { type: 'session_meta', payload: { id: 'case-1', cwd: '/case', source: 'resume' } },
    { type: 'response_item', payload: { type: 'message', role: 'developer', content: [{ type: 'input_text', text: '## Anvil Work Context\nactual host fragment' }] } },
  ]);
  const result = extractCaseTranscript(transcript, { sessionId: 'case-1', workspace: '/case', afterLine: 3 });

  assert.equal(result.lineCount, 6);
  assert.deepEqual(result.session, { line: 1, id: 'case-1', cwd: '/case', baseInstructions: 'actual base', cliVersion: '0.153.4', source: 'exec', model: 'gpt-test' });
  assert.deepEqual(result.turnContexts, []);
  assert.deepEqual(result.developerMessages.map(({ line }) => line), [4, 6]);
  assert.deepEqual(result.deliveredContext.map(({ text }) => text), [preview, '## Anvil Work Context\nactual host fragment']);
  assert.equal(result.deliveredContext[0].text.includes('upstream full body'), false);
  assert.equal(result.status, 'captured-host-messages');
});

test('transcript evidence remains unproven without delivered context and enforces exact resume identity', () => {
  const empty = jsonl([
    { type: 'session_meta', payload: { id: 'case-1', cwd: '/case' } },
    { type: 'response_item', payload: { type: 'message', role: 'developer', content: [{ type: 'input_text', text: 'not a hook' }] } },
  ]);
  assert.equal(extractCaseTranscript(empty, { sessionId: 'case-1', workspace: '/case' }).status, 'unproven');
  assert.throws(() => extractCaseTranscript(empty, { sessionId: 'wrong', workspace: '/case' }), /Wrong host session/);
  assert.throws(() => extractCaseTranscript(empty, { sessionId: 'case-1', workspace: '/wrong' }), /Wrong host workspace/);
  assert.throws(() => extractCaseTranscript(empty, { sessionId: 'case-1', workspace: '/case', afterLine: 3 }), /exceeds/);
  assert.throws(() => extractCaseTranscript(empty, { sessionId: 'case-1', workspace: '/case', afterLine: 1.5 }), /safe integer/);
  assert.throws(() => extractCaseTranscript(jsonl([
    { type: 'session_meta', payload: { id: 'case-1', cwd: '/case' } },
    { type: 'session_meta', payload: { id: 'different-resume', cwd: '/case' } },
  ]), { sessionId: 'case-1', workspace: '/case' }), /Wrong host session/);
  assert.throws(() => extractCaseTranscript(jsonl([
    { type: 'session_meta', payload: { id: 'case-1', cwd: '/case' } },
    { type: 'session_meta', payload: { id: 'case-1', cwd: '/different-resume' } },
  ]), { sessionId: 'case-1', workspace: '/case' }), /Wrong host workspace/);
});
