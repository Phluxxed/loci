import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import { mkdir, mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join, resolve } from "node:path";
import { test } from "node:test";

import { deriveContinuityPaths, initWorkspace } from "../src/continuity/index.ts";
import type { CurrentFrameInput } from "../src/continuity/index.ts";
import {
  bindWorkContext,
  doctorWorkContext,
  recordWorkContextRejection,
  supersedeWorkContextBinding,
} from "../src/work-context/index.ts";

const anvilBin = resolve("bin/anvil.ts");

function frameInput(): CurrentFrameInput {
  return {
    operating_mode: "work-context-doctor-test",
    intent: "Keep routing diagnostics read-only.",
    quality_bar: ["Current evidence wins."],
    permission_envelope: {
      default: "follow current instruction",
      allowed_without_approval: ["inspect routing"],
      requires_approval: ["move historical events"],
    },
    active_decisions: [],
    open_questions: [],
    next_actions: [],
    continuity_notes: [],
  };
}

test("Work Context doctor reports binding and Continuity health separately without writes", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-work-context-doctor-healthy-"));
  try {
    const workspace = join(temp, "improvements");
    const stateRoot = join(temp, "state");
    await mkdir(workspace, { recursive: true });
    const { binding } = await bindWorkContext({
      host: "codex",
      sessionId: "session-doctor-healthy",
      cwd: workspace,
      lifecycle: "SessionStart:startup",
      stateRoot,
    });
    const paths = deriveContinuityPaths({ stateRoot, workspace: binding.collaboration_space });
    await initWorkspace(paths, frameInput());
    const bindingPath = join(stateRoot, "work-context", "bindings", `${binding.id}.json`);
    const bindingBefore = await readFile(bindingPath, "utf8");
    const continuityBefore = await readFile(paths.currentPath, "utf8");

    const result = await doctorWorkContext({ bindingId: binding.id, stateRoot, cwd: workspace });

    assert.equal(result.status, "ok");
    assert.equal(result.binding.status, "active");
    assert.equal(result.binding.value?.collaboration_space.key, binding.collaboration_space.key);
    assert.equal(result.binding.value?.provenance.lifecycle, "SessionStart:startup");
    assert.equal(result.continuity.status, "ok");
    assert.equal(result.continuity.workspace_key, binding.collaboration_space.key);
    assert.equal(result.rejected_routing_attempts, 0);
    assert.equal(await readFile(bindingPath, "utf8"), bindingBefore);
    assert.equal(await readFile(paths.currentPath, "utf8"), continuityBefore);
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("Work Context doctor distinguishes missing, stale, superseded, mismatched, and orphaned bindings", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-work-context-doctor-failures-"));
  try {
    const first = join(temp, "first");
    const second = join(temp, "second");
    const orphan = join(temp, "orphan");
    const stateRoot = join(temp, "state");
    await mkdir(first, { recursive: true });
    await mkdir(second, { recursive: true });
    await mkdir(orphan, { recursive: true });

    const stale = await bindWorkContext({
      host: "codex",
      sessionId: "session-doctor-stale",
      cwd: first,
      lifecycle: "SessionStart:startup",
      stateRoot,
      now: () => "2026-07-16T00:00:00.000Z",
      maxAgeMs: 1_000,
    });
    const old = await bindWorkContext({
      host: "codex",
      sessionId: "session-doctor-old",
      cwd: second,
      lifecycle: "SessionStart:startup",
      stateRoot,
    });
    const replacement = await bindWorkContext({
      host: "codex",
      sessionId: "session-doctor-replacement",
      cwd: second,
      lifecycle: "SessionStart:startup",
      stateRoot,
    });
    await supersedeWorkContextBinding({
      bindingId: old.binding.id,
      replacementBindingId: replacement.binding.id,
      stateRoot,
    });
    const orphaned = await bindWorkContext({
      host: "codex",
      sessionId: "session-doctor-orphan",
      cwd: orphan,
      lifecycle: "SessionStart:startup",
      stateRoot,
    });
    await rm(orphan, { recursive: true, force: true });

    const missingResult = await doctorWorkContext({
      bindingId: "wctx_00000000000000000000000000000000",
      stateRoot,
    });
    const staleResult = await doctorWorkContext({
      bindingId: stale.binding.id,
      stateRoot,
      now: () => "2026-07-16T00:00:02.000Z",
    });
    const supersededResult = await doctorWorkContext({ bindingId: old.binding.id, stateRoot });
    const mismatchedResult = await doctorWorkContext({
      bindingId: replacement.binding.id,
      stateRoot,
      cwd: first,
    });
    const orphanedResult = await doctorWorkContext({ bindingId: orphaned.binding.id, stateRoot });

    assert.equal(missingResult.binding.status, "missing");
    assert.equal(staleResult.binding.status, "stale");
    assert.equal(supersededResult.binding.status, "superseded");
    assert.equal(mismatchedResult.binding.status, "mismatched");
    assert.equal(orphanedResult.binding.status, "orphaned");
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("Work Context doctor treats an invalid expiry timestamp as stale", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-work-context-doctor-invalid-expiry-"));
  try {
    const workspace = join(temp, "workspace");
    const stateRoot = join(temp, "state");
    await mkdir(workspace, { recursive: true });
    const { binding } = await bindWorkContext({
      host: "codex",
      sessionId: "session-doctor-invalid-expiry",
      cwd: workspace,
      lifecycle: "SessionStart:startup",
      stateRoot,
    });
    const bindingPath = join(stateRoot, "work-context", "bindings", `${binding.id}.json`);
    await writeFile(bindingPath, `${JSON.stringify({ ...binding, expires_at: "not-a-timestamp" }, null, 2)}\n`, "utf8");

    const result = await doctorWorkContext({ bindingId: binding.id, stateRoot });

    assert.equal(result.binding.status, "stale");
    assert.ok(result.findings.some((finding) => finding.code === "WORK_CONTEXT_STALE"));
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("Work Context doctor counts sanitized routing rejections and CLI returns the same status", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-work-context-doctor-rejections-"));
  try {
    const workspace = join(temp, "workspace");
    const stateRoot = join(temp, "state");
    await mkdir(workspace, { recursive: true });
    const { binding } = await bindWorkContext({
      host: "codex",
      sessionId: "session-doctor-rejections",
      cwd: workspace,
      lifecycle: "SessionStart:startup",
      stateRoot,
    });
    await recordWorkContextRejection({
      code: "WORK_CONTEXT_MISMATCH",
      operation: "anvil_continuity_record_event",
      bindingId: binding.id,
      host: "anvil_mcp",
      stateRoot,
      id: () => "wctx_reject_test",
    });
    const rejectionText = await readFile(join(stateRoot, "work-context", "rejections.jsonl"), "utf8");

    const result = await doctorWorkContext({ bindingId: binding.id, stateRoot });
    const cli = spawnSync(
      process.execPath,
      [anvilBin, "work-context", "doctor", "--binding-id", binding.id, "--state-root", stateRoot, "--json"],
      { cwd: resolve("."), encoding: "utf8" },
    );

    assert.equal(result.status, "warning");
    assert.equal(result.rejected_routing_attempts, 1);
    assert.doesNotMatch(rejectionText, /prompt|tool_input|summary/i);
    assert.equal(cli.status, 0, cli.stderr);
    assert.equal(JSON.parse(cli.stdout).rejected_routing_attempts, 1);
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});
