import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import { mkdir, mkdtemp, realpath, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join, resolve } from "node:path";
import { test } from "node:test";

import {
  currentSkillInvocationRecordSchema,
  legacySkillInvocationRecordSchema,
  readSkillInvocationsOutputSchema,
  recordBoundSkillInvocationOutputSchema,
  recordSkillInvocationOutputSchema,
  readSkillInvocations,
  recordBoundSkillInvocation,
  recordSkillInvocation,
  resolveSkillInvocationWorkspace,
  sampleSkillInvocationsOutputSchema,
  sampleSkillInvocations,
} from "../src/skill-invocations/index.ts";
import { bindWorkContext, WorkContextError } from "../src/work-context/index.ts";

test("bound skill evidence is attributed outside Continuity to the active workspace", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-skill-invocations-bound-"));
  try {
    const improvements = join(temp, "improvements");
    const stateRoot = join(temp, "state");
    await mkdir(improvements, { recursive: true });
    const { binding } = await bindWorkContext({
      host: "codex",
      sessionId: "session-skill-bound",
      cwd: improvements,
      lifecycle: "SessionStart:startup",
      stateRoot,
    });

    const result = await recordBoundSkillInvocation({
      binding,
      stateRoot,
      invocation: {
        skill: "agent-skills:using-agent-skills",
        trigger: "Engineering work selected its workflow.",
        outcome: "used",
        reason: "The selection workflow determined the implementation skills.",
      },
      id: () => "skill_inv_bound",
    });

    assert.doesNotThrow(() => recordBoundSkillInvocationOutputSchema.parse(result));
    assert.equal(result.record.workspace.root, await realpath(improvements));
    assert.equal(result.record.version, 2);
    assert.equal(result.record.host, "codex");
    assert.equal(result.record.session_id, "session-skill-bound");
    assert.equal(result.binding.id, binding.id);
    assert.match(result.paths.invocationsPath, /skill-invocations\/workspaces/);
    assert.doesNotMatch(result.paths.invocationsPath, /continuity\/workspaces/);
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("stale Work Context rejects bound skill evidence before writing", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-skill-invocations-bound-stale-"));
  try {
    const workspace = join(temp, "workspace");
    const stateRoot = join(temp, "state");
    await mkdir(workspace, { recursive: true });
    const { binding } = await bindWorkContext({
      host: "codex",
      sessionId: "session-skill-stale",
      cwd: workspace,
      lifecycle: "SessionStart:startup",
      stateRoot,
      now: () => "2026-07-16T00:00:00.000Z",
      maxAgeMs: 1_000,
    });

    await assert.rejects(
      () =>
        recordBoundSkillInvocation({
          binding,
          stateRoot,
          bindingNow: () => "2026-07-16T00:00:02.000Z",
          invocation: {
            skill: "agent-skills:using-agent-skills",
            trigger: "Must not write.",
            outcome: "used",
            reason: "The stale binding must reject this evidence before recording.",
          },
        }),
      (error: unknown) => error instanceof WorkContextError && error.code === "WORK_CONTEXT_STALE",
    );
    assert.equal((await readSkillInvocations({ cwd: workspace, stateRoot })).kind, "missing");
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

const anvilBin = resolve("bin/anvil.ts");

function runGit(args: string[], cwd: string): void {
  const result = spawnSync("git", args, { cwd, encoding: "utf8" });
  assert.equal(result.status, 0, result.stderr);
}

test("recordSkillInvocation appends bounded workspace-local records", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-skill-invocations-record-"));
  try {
    const repo = join(temp, "repo");
    const stateRoot = join(temp, "state");
    await mkdir(repo, { recursive: true });
    runGit(["init"], repo);

    const first = await recordSkillInvocation({
      cwd: repo,
      stateRoot,
      invocation: {
        skill: "spark-shape",
        trigger: "User brought a half-formed Anvil mechanism idea.",
        outcome: "used",
        reason: "Matched repo-local Spark -> Shape frontmatter.",
        host: "codex",
        session_id: "session-record-1",
        turn_id: "turn-record-1",
        message_id: "message-record-1",
      },
      now: () => "2026-06-09T04:00:00.000Z",
      id: () => "skill_invocation_1",
    });
    await recordSkillInvocation({
      cwd: repo,
      stateRoot,
      invocation: {
        skill: "agent-skills:test-driven-development",
        trigger: "Implementation work began after the shape was accepted.",
        outcome: "used",
        reason: "A failing test was written before the implementation.",
        host: "codex",
        session_id: "session-record-1",
        turn_id: "turn-record-2",
        message_id: "message-record-2",
      },
      now: () => "2026-06-09T04:01:00.000Z",
      id: () => "skill_invocation_2",
    });

    const paths = resolveSkillInvocationWorkspace({ cwd: repo, stateRoot });
    const read = await readSkillInvocations({ cwd: repo, stateRoot, limit: 1 });

    assert.doesNotThrow(() => recordSkillInvocationOutputSchema.parse(first));
    assert.doesNotThrow(() => readSkillInvocationsOutputSchema.parse(read));
    assert.equal(first.record.workspace.root, await realpath(repo));
    assert.equal(paths.invocationsPath.endsWith("invocations.jsonl"), true);
    assert.equal(read.kind, "ok");
    assert.equal(read.items.length, 1);
    assert.equal(read.items[0].id, "skill_invocation_2");
    assert.equal(read.items[0].outcome, "used");
    assert.equal(read.items[0].version, 2);
    assert.equal(read.items[0].session_id, "session-record-1");
    assert.equal(read.total, 2);
    assert.equal(read.truncated, true);
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("recordSkillInvocation rejects empty fields and oversized trigger text", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-skill-invocations-validate-"));
  try {
    const repo = join(temp, "repo");
    const stateRoot = join(temp, "state");
    await mkdir(repo, { recursive: true });
    runGit(["init"], repo);

    await assert.rejects(
      () =>
        recordSkillInvocation({
          cwd: repo,
          stateRoot,
          invocation: {
            skill: "",
            trigger: "valid trigger",
            outcome: "used",
            reason: "A concrete action occurred.",
            host: "codex",
            session_id: "session-validate",
          },
        }),
      /skill must be a non-empty string/,
    );

    await assert.rejects(
      () =>
        recordSkillInvocation({
          cwd: repo,
          stateRoot,
          invocation: {
            skill: "spark-shape",
            trigger: "x".repeat(501),
            outcome: "used",
            reason: "A concrete action occurred.",
            host: "codex",
            session_id: "session-validate",
          },
        }),
      /trigger must be 500 characters or fewer/,
    );

    await assert.rejects(
      () =>
        recordSkillInvocation({
          cwd: repo,
          stateRoot,
          invocation: {
            skill: "spark-shape",
            trigger: "A shaped idea required implementation.",
            reason: "The shape was carried into a bounded implementation.",
            host: "codex",
            session_id: "session-validate",
          } as never,
        }),
      /outcome must be one of used, missed, false_positive/,
    );

    await assert.rejects(
      () =>
        recordSkillInvocation({
          cwd: repo,
          stateRoot,
          invocation: {
            skill: "spark-shape",
            trigger: "A shaped idea required implementation.",
            outcome: "used",
            host: "codex",
            session_id: "session-validate",
          } as never,
        }),
      /reason must be a non-empty string/,
    );

    await assert.rejects(
      () => readSkillInvocations({ cwd: repo, stateRoot, limit: -1 }),
      /limit must be a non-negative integer/,
    );
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("skills CLI logs and reads invocation records", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-skill-invocations-cli-"));
  try {
    const repo = join(temp, "repo");
    const stateRoot = join(temp, "state");
    await mkdir(repo, { recursive: true });
    runGit(["init"], repo);

    const log = spawnSync(
      process.execPath,
      [
        anvilBin,
        "skills",
        "log",
        "--cwd",
        repo,
        "--state-root",
        stateRoot,
        "--skill",
        "spark-shape",
        "--trigger",
        "Vik asked whether skill trigger records should exist.",
        "--outcome",
        "used",
        "--reason",
        "Frontmatter trigger review.",
        "--host",
        "codex",
        "--session-id",
        "session-cli",
        "--json",
      ],
      { cwd: resolve("."), encoding: "utf8" },
    );
    assert.equal(log.status, 0, log.stderr);
    const logged = JSON.parse(log.stdout) as {
      record: { skill: string; trigger: string; version: number; session_id: string };
    };
    assert.equal(logged.record.skill, "spark-shape");
    assert.equal(logged.record.version, 2);
    assert.equal(logged.record.session_id, "session-cli");

    const read = spawnSync(
      process.execPath,
      [
        anvilBin,
        "skills",
        "invocations",
        "--cwd",
        repo,
        "--state-root",
        stateRoot,
        "--session-id",
        "session-cli",
        "--outcome",
        "used",
        "--json",
      ],
      { cwd: resolve("."), encoding: "utf8" },
    );
    assert.equal(read.status, 0, read.stderr);
    const output = JSON.parse(read.stdout) as { kind: "ok"; items: Array<{ skill: string }> };
    assert.equal(output.kind, "ok");
    assert.equal(output.items[0].skill, "spark-shape");

    const audit = spawnSync(
      process.execPath,
      [
        anvilBin,
        "skills",
        "audit-sample",
        "--cwd",
        repo,
        "--state-root",
        stateRoot,
        "--seed",
        "2026-W29",
        "--size",
        "1",
        "--json",
      ],
      { cwd: resolve("."), encoding: "utf8" },
    );
    assert.equal(audit.status, 0, audit.stderr);
    const auditOutput = JSON.parse(audit.stdout) as { kind: "ok"; eligible: number; items: Array<{ skill: string }> };
    assert.equal(auditOutput.kind, "ok");
    assert.equal(auditOutput.eligible, 1);
    assert.equal(auditOutput.items[0].skill, "spark-shape");
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("readSkillInvocations preserves v1 rows while filtering and paginating v2 evidence", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-skill-invocations-read-v2-"));
  try {
    const repo = join(temp, "repo");
    const stateRoot = join(temp, "state");
    await mkdir(repo, { recursive: true });
    runGit(["init"], repo);
    const paths = resolveSkillInvocationWorkspace({ cwd: repo, stateRoot });
    await mkdir(paths.workspaceDir, { recursive: true });
    await writeFile(
      paths.invocationsPath,
      `${JSON.stringify({
        version: 1,
        id: "skill_invocation_v1",
        created_at: "2026-06-09T04:00:00.000Z",
        workspace: paths.workspace,
        skill: "loci",
        trigger: "Legacy navigation evidence.",
        outcome: "used",
      })}\n`,
      "utf8",
    );

    for (const [index, outcome] of (["used", "false_positive", "used"] as const).entries()) {
      await recordSkillInvocation({
        cwd: repo,
        stateRoot,
        invocation: {
          skill: index === 1 ? "loci" : "agent-skills:using-agent-skills",
          trigger: `V2 evidence ${index}.`,
          outcome,
          reason: outcome === "false_positive" ? "Navigation did not contribute." : "The skill changed the work.",
          host: "codex",
          session_id: "session-v2",
          turn_id: `turn-${index}`,
          message_id: `message-${index}`,
        },
        now: () => `2026-07-17T04:0${index}:00.000Z`,
        id: () => `skill_invocation_v2_${index}`,
      });
    }

    const legacy = await readSkillInvocations({ cwd: repo, stateRoot, skill: "loci", limit: 10 });
    assert.doesNotThrow(() => readSkillInvocationsOutputSchema.parse(legacy));
    assert.equal(legacy.kind, "ok");
    assert.deepEqual(legacy.items.map((item) => item.version), [1, 2]);
    assert.equal(legacy.summary.total, 4);
    assert.equal(legacy.summary.matching, 2);
    assert.deepEqual(legacy.summary.outcomes, { used: 1, missed: 0, false_positive: 1 });

    const page = await readSkillInvocations({
      cwd: repo,
      stateRoot,
      session_id: "session-v2",
      limit: 1,
      offset: 1,
    });
    assert.equal(page.kind, "ok");
    assert.deepEqual(page.items.map((item) => item.id), ["skill_invocation_v2_1"]);
    assert.deepEqual(page.pagination, { offset: 1, limit: 1, returned: 1, next_offset: 2 });
    assert.equal(page.truncated, true);

    const countOnly = await readSkillInvocations({ cwd: repo, stateRoot, limit: 0 });
    assert.equal(countOnly.kind, "ok");
    assert.equal(countOnly.items.length, 0);
    assert.equal(countOnly.summary.total, 4);
    assert.equal(countOnly.pagination.next_offset, null);
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("sampleSkillInvocations returns a deterministic bounded sample of traceable v2 rows", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-skill-invocations-audit-"));
  try {
    const repo = join(temp, "repo");
    const stateRoot = join(temp, "state");
    await mkdir(repo, { recursive: true });
    runGit(["init"], repo);

    for (let index = 0; index < 6; index += 1) {
      await recordSkillInvocation({
        cwd: repo,
        stateRoot,
        invocation: {
          skill: index % 2 === 0 ? "loci" : "agent-skills:using-agent-skills",
          trigger: `Audit candidate ${index}.`,
          outcome: index === 4 ? "false_positive" : "used",
          reason: index === 4 ? "Navigation was unnecessary." : "The skill changed the work.",
          host: "codex",
          session_id: `session-audit-${Math.floor(index / 2)}`,
          turn_id: `turn-audit-${index}`,
        },
        now: () => `2026-07-17T05:0${index}:00.000Z`,
        id: () => `skill_invocation_audit_${index}`,
      });
    }

    const first = await sampleSkillInvocations({ cwd: repo, stateRoot, seed: "2026-W29", size: 3 });
    const second = await sampleSkillInvocations({ cwd: repo, stateRoot, seed: "2026-W29", size: 3 });
    assert.doesNotThrow(() => sampleSkillInvocationsOutputSchema.parse(first));
    assert.doesNotThrow(() => sampleSkillInvocationsOutputSchema.parse(second));
    assert.equal(first.kind, "ok");
    assert.equal(second.kind, "ok");
    assert.deepEqual(first.items.map((item) => item.id), second.items.map((item) => item.id));
    assert.equal(first.items.length, 3);
    assert.equal(first.eligible, 6);
    assert.equal(first.excluded_untraceable, 0);
    assert.equal(first.seed, "2026-W29");
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("skill invocation output schemas preserve strict legacy and failure variants", () => {
  const workspace = {
    key: `sha256_${"a".repeat(64)}`,
    kind: "git" as const,
    root: "/workspace",
    label: "workspace",
  };
  const envelope = {
    id: "skill_invocation_schema",
    created_at: "2026-08-21T00:00:00.000Z",
    workspace,
    skill: "loci",
    trigger: "Navigate the domain.",
    outcome: "used" as const,
  };

  assert.doesNotThrow(() => legacySkillInvocationRecordSchema.parse({ version: 1, ...envelope }));
  assert.doesNotThrow(() =>
    currentSkillInvocationRecordSchema.parse({
      version: 2,
      ...envelope,
      reason: "The skill located the exact implementation symbols.",
      host: "codex",
      session_id: "session-schema",
      turn_id: "turn-schema",
    }),
  );
  assert.throws(() => legacySkillInvocationRecordSchema.parse({ version: 1, ...envelope, host: "codex" }));

  for (const kind of ["missing", "malformed"] as const) {
    const failure = { kind, path: "/state/invocations.jsonl", message: `${kind} journal` };
    assert.doesNotThrow(() => readSkillInvocationsOutputSchema.parse(failure));
    assert.doesNotThrow(() => sampleSkillInvocationsOutputSchema.parse(failure));
    assert.throws(() => readSkillInvocationsOutputSchema.parse({ ...failure, extra: true }));
    assert.throws(() => sampleSkillInvocationsOutputSchema.parse({ ...failure, extra: true }));
  }
});
