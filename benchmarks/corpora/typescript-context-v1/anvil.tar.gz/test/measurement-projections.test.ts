import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import { appendFile, mkdir, mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { test } from "node:test";

import type { BrainRecallObservation } from "../src/brain-context/index.ts";
import { recordBrainUsage, resolveBrainUsageWorkspace } from "../src/brain-usage/index.ts";
import {
  advanceAnvilMeasurementProjections,
  readAnvilMeasurementProjectionSnapshot,
  reconcileAnvilMeasurementProjections,
} from "../src/measurement-projections/index.ts";
import {
  recordSkillInvocation,
  resolveSkillInvocationWorkspace,
} from "../src/skill-invocations/index.ts";
import { bindWorkContext } from "../src/work-context/index.ts";

const measurementsBin = join(process.cwd(), "bin", "anvil-measurements.ts");

function recallObservation(input: {
  totalMs: number;
  retrievalMs: number;
  renderOutcome?: "within_limit" | "truncated";
}): BrainRecallObservation {
  const renderOutcome = input.renderOutcome ?? "within_limit";
  const attempted = renderOutcome === "truncated" ? 600 : 400;
  return {
    phase: "render",
    timing: { total_ms: input.totalMs, retrieval_ms: input.retrievalMs },
    pages: {
      guidance_count: 1,
      compiler_evidence_count: 2,
      candidate_count: 1,
      supporting_count: 1,
      selected_count: 2,
      filtered_count: 0,
    },
    bytes: {
      guidance: 100,
      guidance_limit: 200,
      guidance_headroom: 100,
      retrieved_context: 200,
      framing: attempted - 300,
      attempted,
      rendered: renderOutcome === "truncated" ? 500 : attempted,
      payload_limit: 500,
      payload_headroom: 500 - attempted,
    },
    selection_outcome: "unchanged",
    render_outcome: renderOutcome,
    diagnostics: renderOutcome === "truncated" ? ["BRAIN_CONTEXT_TRUNCATED"] : [],
  };
}

test("incremental Anvil projections preserve cohort, denominator, and privacy semantics", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-measurement-projections-"));
  try {
    const workspace = join(temp, "workspace");
    const stateRoot = join(temp, "state");
    const projectionRoot = join(temp, "projections");
    await mkdir(workspace, { recursive: true });
    await bindWorkContext({
      host: "codex",
      sessionId: "session-projection",
      cwd: workspace,
      lifecycle: "SessionStart:test",
      stateRoot,
      now: () => "2026-07-22T00:00:00.000Z",
    });

    await recordBrainUsage({
      cwd: workspace,
      stateRoot,
      brainIdentity: { id: "agent:codex", agentId: "codex", wikiAlias: "rowan" },
      usage: {
        event: "recalled",
        trigger: "PRIVATE_BRAIN_TRIGGER_ONE",
        outcome: "PRIVATE_BRAIN_OUTCOME_ONE",
        session_id: "session-projection",
      },
      automaticRecallObservation: recallObservation({ totalMs: 120, retrievalMs: 80 }),
      now: () => "2026-07-22T01:00:00.000Z",
      id: () => "brain-projection-1",
    });
    await recordBrainUsage({
      cwd: workspace,
      stateRoot,
      brainIdentity: { id: "agent:codex", agentId: "codex", wikiAlias: "rowan" },
      usage: {
        event: "degraded",
        trigger: "PRIVATE_BRAIN_TRIGGER_TWO",
        outcome: "PRIVATE_BRAIN_OUTCOME_TWO",
        session_id: "session-projection",
      },
      automaticRecallObservation: recallObservation({
        totalMs: 240,
        retrievalMs: 180,
        renderOutcome: "truncated",
      }),
      now: () => "2026-07-22T02:00:00.000Z",
      id: () => "brain-projection-2",
    });

    await recordSkillInvocation({
      cwd: workspace,
      stateRoot,
      invocation: {
        skill: "agent-skills:test-driven-development",
        trigger: "PRIVATE_SKILL_TRIGGER_ONE",
        outcome: "used",
        reason: "PRIVATE_SKILL_REASON_ONE",
        host: "codex",
        session_id: "session-projection",
        turn_id: "turn-1",
        message_id: "message-1",
      },
      now: () => "2026-07-22T03:00:00.000Z",
      id: () => "skill-projection-1",
    });
    await recordSkillInvocation({
      cwd: workspace,
      stateRoot,
      invocation: {
        skill: "agent-skills:test-driven-development",
        trigger: "PRIVATE_SKILL_TRIGGER_TWO",
        outcome: "missed",
        reason: "PRIVATE_SKILL_REASON_TWO",
        host: "codex",
        session_id: "session-projection",
      },
      now: () => "2026-07-22T04:00:00.000Z",
      id: () => "skill-projection-2",
    });

    const advanced = await advanceAnvilMeasurementProjections({
      stateRoot,
      projectionRoot,
      now: () => "2026-07-22T05:00:00.000Z",
    });
    assert.equal(advanced.rows_processed, 4);
    assert.equal(advanced.journals_replayed, 0);

    const snapshot = await readAnvilMeasurementProjectionSnapshot({
      stateRoot,
      projectionRoot,
      now: () => "2026-07-22T05:00:00.000Z",
    });
    assert.equal(snapshot.schema_version, 1);
    assert.equal(snapshot.brain_recall_daily_v1.length, 1);
    const brain = snapshot.brain_recall_daily_v1[0]!;
    assert.deepEqual(brain.cohort, {
      brain_id: "agent:codex",
      workspace_id: brain.cohort.workspace_id,
      host: "codex",
      runtime: "unknown",
    });
    assert.deepEqual(brain.rates.operation_success, { numerator: 1, denominator: 2, value: 0.5 });
    assert.deepEqual(brain.rates.degradation, { numerator: 1, denominator: 2, value: 0.5 });
    assert.deepEqual(brain.coverage.instrumentation, { numerator: 2, denominator: 2, value: 1 });
    assert.deepEqual(brain.rates.truncation, { numerator: 1, denominator: 2, value: 0.5 });
    assert.deepEqual(brain.distributions.total_ms, { count: 2, min: 120, p50: 120, p95: 240, p99: 240, max: 240 });
    assert.equal(brain.counts.disabled, 0);
    assert.ok(brain.limitations.includes("BRAIN_USEFULNESS_NOT_MEASURED"));

    assert.equal(snapshot.skill_invocation_daily_v1.length, 2);
    const used = snapshot.skill_invocation_daily_v1.find((row) => row.cohort.recorded_outcome === "used")!;
    const missed = snapshot.skill_invocation_daily_v1.find((row) => row.cohort.recorded_outcome === "missed")!;
    assert.equal(used.cohort.host, "codex");
    assert.deepEqual(used.coverage.traceable_v2, { numerator: 1, denominator: 1, value: 1 });
    assert.deepEqual(missed.coverage.traceable_v2, { numerator: 0, denominator: 1, value: 0 });
    assert.deepEqual(used.rates.recorded_outcome_share, { numerator: 1, denominator: 2, value: 0.5 });
    assert.ok(used.limitations.includes("SKILL_ELIGIBLE_POPULATION_UNAVAILABLE"));

    const stored = await readFile(join(projectionRoot, "state-v1.json"), "utf8");
    assert.doesNotMatch(stored, /"source_hash"|"record_hashes"/);
    for (const privateValue of [
      "PRIVATE_BRAIN_TRIGGER_ONE",
      "PRIVATE_BRAIN_OUTCOME_ONE",
      "PRIVATE_SKILL_TRIGGER_ONE",
      "PRIVATE_SKILL_REASON_ONE",
    ]) {
      assert.doesNotMatch(stored, new RegExp(privateValue));
      assert.doesNotMatch(JSON.stringify(snapshot), new RegExp(privateValue));
    }

    const secondAdvance = await advanceAnvilMeasurementProjections({ stateRoot, projectionRoot });
    assert.equal(secondAdvance.rows_processed, 0);

    const brainPath = resolveBrainUsageWorkspace({ cwd: workspace, stateRoot }).usagePath;
    const beforePartial = snapshot.source_cutoff.journals.find((cursor) => cursor.canonical_path === brainPath)!;
    await appendFile(brainPath, "{\"version\":2", "utf8");
    const partialAdvance = await advanceAnvilMeasurementProjections({ stateRoot, projectionRoot });
    const afterPartial = partialAdvance.source_cutoff.journals.find((cursor) => cursor.canonical_path === brainPath)!;
    assert.equal(partialAdvance.rows_processed, 0);
    assert.equal(afterPartial.byte_offset, beforePartial.byte_offset);
    assert.equal(partialAdvance.skipped.trailing_partial_line, 1);
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("journal replacement replays safely and conflicting duplicate IDs fail closed", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-measurement-replay-"));
  try {
    const workspace = join(temp, "workspace");
    const stateRoot = join(temp, "state");
    const projectionRoot = join(temp, "projections");
    await mkdir(workspace, { recursive: true });
    const brainPaths = resolveBrainUsageWorkspace({ cwd: workspace, stateRoot });
    await mkdir(brainPaths.workspaceDir, { recursive: true });
    const base = {
      version: 2,
      id: "brain-replay-1",
      created_at: "2026-07-22T01:00:00.000Z",
      workspace: brainPaths.workspace,
      brain_id: "agent:codex",
      brain_alias: "rowan",
      brain_identity_status: "resolved",
      severity: "info",
      trigger: "excluded",
      session_id: "unknown-session",
    } as const;
    await writeFile(brainPaths.usagePath, `${JSON.stringify({ ...base, event: "recalled" })}\n`, "utf8");
    await advanceAnvilMeasurementProjections({ stateRoot, projectionRoot });

    await writeFile(
      brainPaths.usagePath,
      `${JSON.stringify({ ...base, id: "brain-replay-2", event: "disabled" })}\n`,
      "utf8",
    );
    const replayed = await advanceAnvilMeasurementProjections({ stateRoot, projectionRoot });
    assert.equal(replayed.journals_replayed, 1);
    const snapshot = await readAnvilMeasurementProjectionSnapshot({ stateRoot, projectionRoot });
    assert.equal(snapshot.brain_recall_daily_v1[0]!.counts.eligible, 0);
    assert.equal(snapshot.brain_recall_daily_v1[0]!.counts.disabled, 1);
    assert.deepEqual(snapshot.brain_recall_daily_v1[0]!.rates.operation_success, {
      numerator: 0,
      denominator: 0,
      value: null,
    });

    await writeFile(
      brainPaths.usagePath,
      `${JSON.stringify({ ...base, event: "recalled" })}\n${JSON.stringify({ ...base, event: "degraded" })}\n`,
      "utf8",
    );
    await assert.rejects(
      () => advanceAnvilMeasurementProjections({ stateRoot, projectionRoot }),
      /conflicting duplicate record id brain-replay-1/,
    );
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("bounded journal reconciliation is deterministic and excludes raw text", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-measurement-reconcile-"));
  try {
    const workspace = join(temp, "workspace");
    const stateRoot = join(temp, "state");
    const projectionRoot = join(temp, "projections");
    await mkdir(workspace, { recursive: true });
    const skillPaths = resolveSkillInvocationWorkspace({ cwd: workspace, stateRoot });
    await mkdir(skillPaths.workspaceDir, { recursive: true });
    const records = Array.from({ length: 205 }, (_, index) => ({
      version: 2,
      id: `skill-reconcile-${index}`,
      created_at: `2026-07-22T00:${String(index % 60).padStart(2, "0")}:00.000Z`,
      workspace: skillPaths.workspace,
      skill: "agent-skills:test-driven-development",
      trigger: `PRIVATE_RECONCILE_TRIGGER_${index}`,
      outcome: "used",
      reason: `PRIVATE_RECONCILE_REASON_${index}`,
      host: "codex",
      session_id: `session-${index}`,
      turn_id: `turn-${index}`,
      message_id: `message-${index}`,
    }));
    await writeFile(skillPaths.invocationsPath, `${records.map((record) => JSON.stringify(record)).join("\n")}\n`, "utf8");
    await advanceAnvilMeasurementProjections({ stateRoot, projectionRoot });

    const first = await reconcileAnvilMeasurementProjections({
      stateRoot,
      projectionRoot,
      seed: "d2.3-proof",
      maxSample: 200,
    });
    const second = await reconcileAnvilMeasurementProjections({
      stateRoot,
      projectionRoot,
      seed: "d2.3-proof",
      maxSample: 200,
    });
    assert.deepEqual(first, second);
    assert.equal(first.skill.eligible, 205);
    assert.equal(first.skill.sample_size, 200);
    assert.equal(first.skill.exact_matches, 200);
    assert.equal(first.skill.mismatches.length, 0);
    assert.equal(first.skill.skipped.sample_limit, 5);
    assert.doesNotMatch(JSON.stringify(first), /PRIVATE_RECONCILE_(?:TRIGGER|REASON)/);
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("measurement projection CLI verifies canonical journals and prints bounded JSON", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-measurement-cli-"));
  try {
    const workspace = join(temp, "workspace");
    const stateRoot = join(temp, "state");
    const projectionRoot = join(temp, "projections");
    await mkdir(workspace, { recursive: true });
    await recordSkillInvocation({
      cwd: workspace,
      stateRoot,
      invocation: {
        skill: "agent-skills:using-agent-skills",
        trigger: "PRIVATE_CLI_TRIGGER",
        outcome: "used",
        reason: "PRIVATE_CLI_REASON",
        host: "codex",
        session_id: "session-cli",
      },
      id: () => "skill-cli-1",
      now: () => "2026-07-22T01:00:00.000Z",
    });

    const result = spawnSync(
      process.execPath,
      [
        measurementsBin,
        "verify",
        "--state-root",
        stateRoot,
        "--projection-root",
        projectionRoot,
        "--seed",
        "cli-proof",
        "--max-sample",
        "20",
      ],
      { encoding: "utf8", cwd: process.cwd() },
    );
    assert.equal(result.status, 0, result.stderr);
    const output = JSON.parse(result.stdout) as {
      advance: { rows_processed: number };
      reconciliation: { seed: string; skill: { exact_matches: number; mismatches: string[] } };
    };
    assert.equal(output.advance.rows_processed, 1);
    assert.equal(output.reconciliation.seed, "cli-proof");
    assert.equal(output.reconciliation.skill.exact_matches, 1);
    assert.deepEqual(output.reconciliation.skill.mismatches, []);
    assert.doesNotMatch(result.stdout, /PRIVATE_CLI_(?:TRIGGER|REASON)/);
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("legacy journal rows stay explicitly labelled and separate from v2 coverage", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-measurement-legacy-"));
  try {
    const workspace = join(temp, "workspace");
    const stateRoot = join(temp, "state");
    const projectionRoot = join(temp, "projections");
    await mkdir(workspace, { recursive: true });
    const brainPaths = resolveBrainUsageWorkspace({ cwd: workspace, stateRoot });
    const skillPaths = resolveSkillInvocationWorkspace({ cwd: workspace, stateRoot });
    await mkdir(brainPaths.workspaceDir, { recursive: true });
    await mkdir(skillPaths.workspaceDir, { recursive: true });
    const legacyBrain = {
      version: 1,
      id: "brain-legacy-1",
      created_at: "2026-07-22T01:00:00.000Z",
      workspace: brainPaths.workspace,
      brain: "rowan-old-label",
      event: "recalled",
      trigger: "PRIVATE_LEGACY_BRAIN_TRIGGER",
      severity: "info",
    };
    const legacySkill = {
      version: 1,
      id: "skill-legacy-1",
      created_at: "2026-07-22T01:00:00.000Z",
      workspace: skillPaths.workspace,
      skill: "loci",
      trigger: "PRIVATE_LEGACY_SKILL_TRIGGER",
      outcome: "used",
    };
    const currentSkill = {
      version: 2,
      id: "skill-current-1",
      created_at: "2026-07-22T02:00:00.000Z",
      workspace: skillPaths.workspace,
      skill: "loci",
      trigger: "PRIVATE_CURRENT_SKILL_TRIGGER",
      outcome: "used",
      reason: "PRIVATE_CURRENT_SKILL_REASON",
      host: "codex",
      session_id: "unbound-session",
      turn_id: "turn-1",
    };
    await writeFile(brainPaths.usagePath, `${JSON.stringify(legacyBrain)}\n${JSON.stringify(legacyBrain)}\n`, "utf8");
    await writeFile(skillPaths.invocationsPath, `${JSON.stringify(legacySkill)}\n${JSON.stringify(currentSkill)}\n`, "utf8");

    await advanceAnvilMeasurementProjections({ stateRoot, projectionRoot });
    const snapshot = await readAnvilMeasurementProjectionSnapshot({ stateRoot, projectionRoot });
    assert.equal(snapshot.brain_recall_daily_v1[0]!.cohort.brain_id, "legacy:rowan-old-label");
    assert.equal(snapshot.brain_recall_daily_v1[0]!.counts.recalled, 1);
    const skill = snapshot.skill_invocation_daily_v1[0]!;
    assert.deepEqual(skill.counts, { recorded: 2, legacy: 1, v2: 1 });
    assert.deepEqual(skill.coverage.traceable_v2, { numerator: 1, denominator: 1, value: 1 });
    assert.equal(skill.cohort.host, "unknown");
    const proof = await reconcileAnvilMeasurementProjections({ stateRoot, projectionRoot });
    assert.equal(proof.brain.exact_matches, 1);
    assert.equal(proof.skill.exact_matches, 2);
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});
