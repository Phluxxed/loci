import assert from "node:assert/strict";
import { execFileSync } from "node:child_process";
import { mkdtemp, readFile, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { afterEach, test } from "node:test";

import {
  createManifestService,
  loadObjective,
  writeObjective,
} from "../src/manifest/index.ts";

const roots: string[] = [];

afterEach(async () => {
  await Promise.all(roots.splice(0).map((root) => rm(root, { recursive: true, force: true })));
});

async function gitRepository(): Promise<string> {
  const root = await mkdtemp(join(tmpdir(), "manifest-service-"));
  roots.push(root);
  execFileSync("git", ["init", "-q"], { cwd: root });
  return root;
}

function deterministicService() {
  const ids = {
    objective: ["obj_11111111111111111111111111111111"],
    workstream: ["ws_22222222222222222222222222222222", "ws_55555555555555555555555555555555"],
    task: ["task_33333333333333333333333333333333", "task_44444444444444444444444444444444"],
  };
  return createManifestService({ allocateIdentity: (kind) => ids[kind].shift()! });
}

test("service creates a Planning Objective and resolves request-local graph references atomically", async () => {
  const repository = await gitRepository();
  const service = deterministicService();
  const created = await service.createObjective(repository, {
    title: "Manifest V2",
    outcome: "Human and agent operate on one graph.",
  });

  assert.equal(created.graph.phase, "planning");
  assert.equal(created.view.objectiveId, created.objectiveId);
  const changed = await service.changeObjective(repository, created.objectiveId, {
    addWorkstreams: [{
      ref: "delivery",
      title: "Delivery",
      outcome: "The graph is delivered.",
      after: null,
    }],
    addTasks: [
      {
        ref: "first",
        workstream: "@delivery",
        title: "Build service",
        outcome: "The service owns graph I/O.",
        completionCriteria: ["Service tests pass."],
        after: null,
      },
      {
        ref: "second",
        workstream: "@delivery",
        title: "Expose MCP",
        outcome: "The agent can use the service.",
        completionCriteria: ["MCP tests pass."],
        after: "@first",
        dependencies: ["@first"],
      },
    ],
    update: [{ id: created.objectiveId, set: { phase: "implementation" } }],
  });

  assert.equal(changed.applied, true);
  if (!changed.applied) return;
  assert.deepEqual(changed.created, [
    { ref: "delivery", id: "ws_22222222222222222222222222222222" },
    { ref: "first", id: "task_33333333333333333333333333333333" },
    { ref: "second", id: "task_44444444444444444444444444444444" },
  ]);
  assert.equal(changed.graph.phase, "implementation");
  assert.deepEqual(changed.graph.workstreams[0]!.tasks[1]!.dependencies, [changed.graph.workstreams[0]!.tasks[0]!.id]);
  assert.doesNotMatch(await readFile(changed.path, "utf8"), /@delivery|@first|@second/);
});

test("reference or graph validation failures are normal results and leave Objective bytes unchanged", async () => {
  const repository = await gitRepository();
  const service = deterministicService();
  const created = await service.createObjective(repository, { title: "Manifest V2", outcome: "Changes are atomic." });
  const before = await readFile(created.path, "utf8");

  const rejected = await service.changeObjective(repository, created.objectiveId, {
    addWorkstreams: [{
      ref: "delivery",
      title: "Delivery",
      outcome: "Should not be partially written.",
      after: "@missing",
    }],
  });

  assert.equal(rejected.applied, false);
  if (rejected.applied) return;
  assert.match(rejected.problems[0]!.message, /Unknown request reference/);
  assert.equal(await readFile(created.path, "utf8"), before);
});

test("every orient and inquire call reloads the Objective file", async () => {
  const repository = await gitRepository();
  const service = deterministicService();
  const created = await service.createObjective(repository, { title: "Before", outcome: "Reads are current." });
  assert.equal((await service.orientObjective(repository, created.objectiveId)).graph.title, "Before");

  const loaded = await loadObjective(repository, created.objectiveId);
  await writeObjective(repository, { ...loaded.graph, title: "After" });

  assert.equal((await service.orientObjective(repository, created.objectiveId)).graph.title, "After");
  const inquiry = await service.inquireCurrentObjective(repository, created.objectiveId, { id: created.objectiveId });
  assert.equal(inquiry.result.outcome, "found");
  if (inquiry.result.outcome === "found") assert.equal(inquiry.result.entity.title, "After");
});
