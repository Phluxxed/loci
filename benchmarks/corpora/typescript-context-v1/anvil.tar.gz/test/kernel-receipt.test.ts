import assert from "node:assert/strict";
import { mkdtemp, readFile, readdir, rm, stat, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { test } from "node:test";

import {
  collaborationKernelRequired,
  recordCollaborationKernelDelivery,
} from "../src/brain-context/kernel-receipt.ts";

const snapshotDigest = "a".repeat(64);
const kernelDigest = "b".repeat(64);

test("lifecycle boundaries always require Collaboration Kernel delivery", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-kernel-receipt-"));
  try {
    for (const lifecycle of ["session_start", "resume", "clear", "compact"] as const) {
      assert.equal(
        await collaborationKernelRequired({
          lifecycle,
          host: "codex",
          sessionId: "session-1",
          snapshotDigest,
          stateRoot: join(temp, "state"),
        }),
        true,
      );
    }
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("a prompt suppresses an exactly matching previously delivered kernel", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-kernel-receipt-"));
  const stateRoot = join(temp, "state");
  const current = {
    lifecycle: "prompt" as const,
    host: "codex",
    sessionId: "session-1",
    snapshotDigest,
    stateRoot,
  };
  try {
    assert.equal(await collaborationKernelRequired(current), true);

    const first = await recordCollaborationKernelDelivery({ ...current, kernelDigest });

    assert.equal(first.lifecycleGeneration, 1);
    assert.equal(await collaborationKernelRequired(current), false);

    const second = await recordCollaborationKernelDelivery({ ...current, kernelDigest });
    assert.equal(second.lifecycleGeneration, 2);
    assert.equal(await collaborationKernelRequired(current), false);
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("prompt delivery is conservative for missing, changed, corrupt, or mismatched receipts", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-kernel-receipt-"));
  const stateRoot = join(temp, "state");
  const current = {
    lifecycle: "prompt" as const,
    host: "codex",
    sessionId: "session-1",
    snapshotDigest,
    stateRoot,
  };
  try {
    assert.equal(await collaborationKernelRequired({ ...current, host: undefined }), true);
    assert.equal(await collaborationKernelRequired({ ...current, sessionId: undefined }), true);
    assert.equal(await collaborationKernelRequired(current), true);

    await recordCollaborationKernelDelivery({ ...current, kernelDigest });
    assert.equal(
      await collaborationKernelRequired({ ...current, snapshotDigest: "c".repeat(64) }),
      true,
    );

    const receiptDirectory = join(stateRoot, "brain-context", "kernel-receipts");
    const receiptName = (await readdir(receiptDirectory)).find((name) => name.endsWith(".json"));
    assert.ok(receiptName);
    const path = join(receiptDirectory, receiptName);
    const receipt = JSON.parse(await readFile(path, "utf8")) as Record<string, unknown>;
    await writeFile(path, `${JSON.stringify({ ...receipt, host: "other-host" })}\n`, "utf8");
    assert.equal(await collaborationKernelRequired(current), true);

    await writeFile(path, "{not-json\n", "utf8");
    assert.equal(await collaborationKernelRequired(current), true);
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("delivery receipts stay private, bounded, and generation-safe under concurrent writes", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-kernel-receipt-"));
  const stateRoot = join(temp, "state");
  const delivery = {
    host: "codex",
    sessionId: "session-concurrent",
    snapshotDigest,
    kernelDigest,
    stateRoot,
  };
  try {
    const receipts = await Promise.all(
      Array.from({ length: 8 }, () => recordCollaborationKernelDelivery(delivery)),
    );
    assert.deepEqual(
      receipts.map((receipt) => receipt.lifecycleGeneration).sort((left, right) => left - right),
      [1, 2, 3, 4, 5, 6, 7, 8],
    );

    const receiptDirectory = join(stateRoot, "brain-context", "kernel-receipts");
    const names = await readdir(receiptDirectory);
    assert.equal(names.length, 1);
    const path = join(receiptDirectory, names[0]);
    const stored = JSON.parse(await readFile(path, "utf8")) as Record<string, unknown>;
    assert.deepEqual(Object.keys(stored).sort(), [
      "host",
      "kernel_digest",
      "lifecycle_generation",
      "session_id",
      "snapshot_digest",
    ]);
    assert.equal(stored.lifecycle_generation, 8);
    assert.equal((await stat(receiptDirectory)).mode & 0o777, 0o700);
    assert.equal((await stat(path)).mode & 0o777, 0o600);
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});
