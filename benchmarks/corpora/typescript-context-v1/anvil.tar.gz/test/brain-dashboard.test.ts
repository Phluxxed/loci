import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import { test } from "node:test";

import { buildBrainUsageLensGraph } from "../src/brain-usage/index.ts";
import type { BrainUsageMetricsOutput } from "../src/brain-usage/index.ts";
import { summarizeRecallMetrics } from "../src/brain-usage/recall-metrics.ts";

test("brain usage dashboard is a dark metrics shell with a separate graph link", async () => {
  const html = await readFile("docs/brain-usage-dashboard.html", "utf8");

  assert.match(html, /<div id="app"/);
  assert.match(html, /color-scheme: dark/);
  assert.match(html, /https:\/\/esm\.sh\/@arrow-js\/core/);
  assert.match(html, /import \{ reactive, html \}/);
  assert.doesNotMatch(html, /import React/);
  assert.doesNotMatch(html, /ReactFlow/);
  assert.doesNotMatch(html, /loadTraceGraphRuntime/);
  assert.doesNotMatch(html, /elkjs/);
  assert.match(html, /role="status"/);
  assert.match(html, /fetch\('\/api\/metrics'/);
  assert.match(html, /setInterval\(refreshMetrics, refreshMs\)/);
  assert.match(html, /href="\/graph"/);
  assert.match(html, /Open Graph/);
  assert.match(html, /const recallEvents = \['recalled', 'no_match', 'degraded', 'disabled'\]/);
  assert.match(html, /Automatic recall/);
  assert.match(html, /Context selected/);
  assert.match(html, /Agent outcomes/);
  assert.match(html, /Identity quality/);
  assert.match(html, /Stable ID/);
  assert.match(html, /Unresolved/);
  assert.match(html, /state\.metrics\.recall\.total/);
  assert.match(html, /Recall success/);
  assert.match(html, /Recall degradation/);
  assert.match(html, /Instrumentation coverage/);
  assert.match(html, /Diagnostic breakdown/);
  assert.match(html, /Workspace health/);
  assert.match(html, /48-hour recall trend/);
  assert.match(html, /30-day recall trend/);
  assert.match(html, /Payload size/);
  assert.match(html, /Headroom/);
  assert.match(html, /Component contribution/);
  assert.match(html, /Page selection/);
  assert.match(html, /Recall timing/);
  assert.match(html, /Selection and rendering/);
  assert.match(html, /state\.metrics\.recall\.success/);
  assert.match(html, /state\.metrics\.recall\.degradation/);
  assert.match(html, /state\.metrics\.recall\.diagnostics/);
  assert.match(html, /state\.metrics\.recall\.by_workspace/);
  assert.match(html, /state\.metrics\.recall\.trends\.hourly/);
  assert.match(html, /state\.metrics\.recall\.payload_bytes/);
  assert.match(html, /state\.metrics\.recall\.limit_bytes/);
  assert.match(html, /state\.metrics\.recall\.headroom_bytes/);
  assert.match(html, /Guidance limit/);
  assert.match(html, /Payload limit/);
  assert.match(html, /No instrumented samples/);
  assert.match(html, /Historical records remain included in rates/);
  assert.match(html, /Trace/);
  assert.match(html, /trigger_bucket/);
  assert.match(html, /prompt_excerpt/);
  assert.match(html, /prompt_raw/);
  assert.doesNotMatch(html, /<details open>/);
  assert.doesNotMatch(html, /trace-graph-canvas/);
  assert.doesNotMatch(html, /trace-link-layer/);
  assert.doesNotMatch(html, /trace-link/);
  assert.doesNotMatch(html, /<textarea/);
  assert.doesNotMatch(html, /type="file"/);
  assert.doesNotMatch(html, />Sample</);
  assert.doesNotMatch(html, />Load</);
  assert.doesNotMatch(html, /state\.metrics\.path/);
  assert.doesNotMatch(html, /\.anvil\/brain-usage/);
});

test("brain usage trace data is shaped for the Lens node graph", () => {
  const metrics: Extract<BrainUsageMetricsOutput, { kind: "ok" }> = {
    kind: "ok",
    path: "/tmp/brain-usage/workspaces",
    total: 2,
    by_event: {
      recalled: 0,
      no_match: 0,
      degraded: 0,
      disabled: 0,
      consulted: 0,
      used: 1,
      not_needed: 1,
      updated: 0,
      missed_update: 0,
      stale: 0,
      wrong: 0,
      blocked: 0,
      eval_failed: 0,
    },
    by_severity: { info: 2, warn: 0, error: 0 },
    by_brain: { "agent:codex": 1 },
    brain_aliases: { "agent:codex": "anvil-brain-codex" },
    brain_identity: {
      resolved_events: 1,
      legacy_normalized_events: 0,
      unresolved_events: 0,
      unassigned_events: 1,
      diagnostics: [],
    },
    by_trigger_bucket: { dashboard: 2 },
    recall: summarizeRecallMetrics([]),
    coverage: {
      total: 2,
      by_event: { consulted: 0, used: 1, not_needed: 1, blocked: 0 },
    },
    incidents: {
      total: 0,
      by_event: { updated: 0, missed_update: 0, stale: 0, wrong: 0, eval_failed: 0 },
    },
    trace: {
      projects: [
        {
          project_key: "repo-key",
          project_root: "/tmp/repo",
          project_label: "repo",
          total: 2,
          buckets: [
            {
              bucket: "dashboard",
              total: 2,
              sessions: [
                {
                  session_id: "session-1",
                  total: 2,
                  prompts: [
                    {
                      message_id: "message-1",
                      total: 2,
                      turn_id: "turn-1",
                      prompt_excerpt: "Make the dashboard readable.",
                      prompt_raw: "raw prompt should not be copied into graph nodes",
                      events: [
                        {
                          id: "event-1",
                          created_at: "2026-07-08T00:00:00.000Z",
                          project_key: "repo-key",
                          project_root: "/tmp/repo",
                          project_label: "repo",
                          event: "used",
                          severity: "info",
                          trigger: "Brain helped shape the dashboard.",
                          trigger_bucket: "dashboard",
                          brain_id: "agent:codex",
                          brain_alias: "anvil-brain-codex",
                          brain_identity_source: "recorded",
                          outcome: "Changed the UI.",
                          session_id: "session-1",
                          turn_id: "turn-1",
                          message_id: "message-1",
                          prompt_excerpt: "Make the dashboard readable.",
                          prompt_raw: "raw prompt should not be copied into graph nodes",
                        },
                        {
                          id: "event-2",
                          created_at: "2026-07-08T00:01:00.000Z",
                          project_key: "repo-key",
                          project_root: "/tmp/repo",
                          project_label: "repo",
                          event: "not_needed",
                          severity: "info",
                          trigger: "Repo evidence was enough.",
                          trigger_bucket: "dashboard",
                          brain_identity_source: "unassigned",
                          outcome: "Skipped Brain lookup.",
                          session_id: "session-1",
                          turn_id: "turn-1",
                          message_id: "message-1",
                          prompt_excerpt: "Make the dashboard readable.",
                          prompt_raw: "raw prompt should not be copied into graph nodes",
                        },
                      ],
                    },
                  ],
                },
              ],
            },
          ],
        },
      ],
      recent: [],
    },
    first_created_at: "2026-07-08T00:00:00.000Z",
    last_created_at: "2026-07-08T00:01:00.000Z",
  };

  const graph = buildBrainUsageLensGraph(metrics);

  assert.equal(graph.meta.title, "Brain Usage Trace");
  assert.equal(graph.meta.root, "brain:usage");
  assert.deepEqual(
    graph.edges.map((edge) => `${edge.source}->${edge.target}`),
    [
      "brain:usage->project:repo-key",
      "project:repo-key->project:repo-key:bucket:dashboard",
      "project:repo-key:bucket:dashboard->project:repo-key:bucket:dashboard:event:used",
      "project:repo-key:bucket:dashboard:event:used->project:repo-key:bucket:dashboard:event:used:prompt:message-1",
      "project:repo-key:bucket:dashboard:event:used:prompt:message-1->project:repo-key:bucket:dashboard:event:used:prompt:message-1:reason:event-1",
      "project:repo-key:bucket:dashboard->project:repo-key:bucket:dashboard:event:not_needed",
      "project:repo-key:bucket:dashboard:event:not_needed->project:repo-key:bucket:dashboard:event:not_needed:prompt:message-1",
      "project:repo-key:bucket:dashboard:event:not_needed:prompt:message-1->project:repo-key:bucket:dashboard:event:not_needed:prompt:message-1:reason:event-2",
    ],
  );
  assert.equal(graph.nodes.find((node) => node.id === "brain:usage")?.kind, "brain");
  assert.equal(graph.nodes.find((node) => node.id.endsWith(":event:not_needed"))?.state, "muted");
  assert.equal(JSON.stringify(graph).includes("raw prompt should not be copied"), false);

  const collisionMetrics = structuredClone(metrics);
  const sourceBucket = collisionMetrics.trace.projects[0]?.buckets[0];
  assert.ok(sourceBucket);
  const delimiterBucket = structuredClone(sourceBucket);
  delimiterBucket.bucket = `${sourceBucket.bucket}:event:used`;
  collisionMetrics.trace.projects[0]?.buckets.push(delimiterBucket);

  const collisionGraph = buildBrainUsageLensGraph(collisionMetrics);
  const nodeIds = collisionGraph.nodes.map((node) => node.id);
  assert.equal(new Set(nodeIds).size, nodeIds.length, "dynamic graph identifiers must not collide with structural delimiters");
});
