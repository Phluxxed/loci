import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import { test } from "node:test";

import { Client } from "@modelcontextprotocol/client";
import { StdioClientTransport } from "@modelcontextprotocol/client/stdio";

import {
  BLOCKED_ARGUMENTS,
  BLOCKED_TOOL_NAMES,
  BLOCKED_TOOL_PREFIXES,
  createBrowserMcpPolicyGuard,
} from "../src/browser/mcp-guard.ts";

// Pinned against agent-browser 0.31.1 (`agent-browser mcp --tools all`). These are the only
// denylist entries that match anything the upstream MCP surface actually exposes; every other
// entry guards a CLI-only flag or a tool that no longer exists. An upgrade that renames, adds,
// or drops one of these fails here, instead of silently widening browser policy or shipping a
// schema that makes a model provider reject every request in the session.
const UPSTREAM_BLOCKED_ARGUMENTS = [
  "extraArgs",
  "namespace",
  "restore",
  "restoreCheckFn",
  "restoreCheckText",
  "restoreCheckUrl",
  "restoreSave",
  "state",
];
const UPSTREAM_BLOCKED_TOOLS = ["agent_browser_get_cdp_url"];

type UpstreamSchema = { type?: string; properties?: Record<string, unknown>; required?: unknown };
type UpstreamTool = { name: string; inputSchema?: UpstreamSchema };

function agentBrowserInstalled(): boolean {
  return spawnSync("agent-browser", ["--version"], { stdio: "ignore" }).status === 0;
}

async function listUpstreamTools(): Promise<UpstreamTool[]> {
  const client = new Client({ name: "anvil-browser-policy-audit", version: "0.0.0" });
  const transport = new StdioClientTransport({ command: "agent-browser", args: ["mcp", "--tools", "all"] });
  try {
    await client.connect(transport);
    const { tools } = await client.listTools();
    return tools as unknown as UpstreamTool[];
  } finally {
    await client.close();
  }
}

function guardToolList(tools: UpstreamTool[]): UpstreamTool[] {
  const guard = createBrowserMcpPolicyGuard();
  guard.clientLine(JSON.stringify({ jsonrpc: "2.0", id: "audit", method: "tools/list", params: {} }));
  const guarded = guard.serverLine(JSON.stringify({ jsonrpc: "2.0", id: "audit", result: { tools } }));
  const message = JSON.parse(guarded.line) as { result: { tools: UpstreamTool[] } };
  return message.result.tools;
}

function schemaOf(tool: UpstreamTool): UpstreamSchema {
  return tool.inputSchema ?? {};
}

function requiredNames(schema: UpstreamSchema): string[] {
  return Array.isArray(schema.required) ? schema.required.filter((name): name is string => typeof name === "string") : [];
}

test(
  "browser policy still lines up with the installed agent-browser tool surface",
  { skip: agentBrowserInstalled() ? false : "agent-browser is not installed", timeout: 60_000 },
  async () => {
    const upstream = await listUpstreamTools();
    assert.ok(upstream.length > 0, "upstream exposed no tools");

    const exposedArguments = [...BLOCKED_ARGUMENTS].filter((argument) =>
      upstream.some((tool) => argument in (schemaOf(tool).properties ?? {})),
    );
    assert.deepEqual(
      exposedArguments.sort(),
      [...UPSTREAM_BLOCKED_ARGUMENTS].sort(),
      "agent-browser changed which blocked arguments it exposes — review BLOCKED_ARGUMENTS and re-pin",
    );

    const matchedTools = upstream
      .map((tool) => tool.name)
      .filter((name) => BLOCKED_TOOL_NAMES.has(name) || BLOCKED_TOOL_PREFIXES.some((prefix) => name.startsWith(prefix)));
    assert.deepEqual(
      matchedTools.sort(),
      [...UPSTREAM_BLOCKED_TOOLS].sort(),
      "agent-browser changed which blocked tools it exposes — review BLOCKED_TOOL_NAMES/PREFIXES and re-pin",
    );
  },
);

test(
  "guarded agent-browser schemas stay self-consistent for every installed tool",
  { skip: agentBrowserInstalled() ? false : "agent-browser is not installed", timeout: 60_000 },
  async () => {
    const guarded = guardToolList(await listUpstreamTools());
    assert.ok(guarded.length > 0, "guard emitted no tools");

    for (const tool of guarded) {
      const schema = schemaOf(tool);
      const properties = schema.properties ?? {};
      for (const required of requiredNames(schema)) {
        assert.ok(
          required in properties,
          `${tool.name} advertises required "${required}" that the guard stripped — the schema is invalid and poisons the session`,
        );
      }
      for (const argument of Object.keys(properties)) {
        const allowed = tool.name === "agent_browser_wait_for_load" && argument === "state";
        assert.ok(!BLOCKED_ARGUMENTS.has(argument) || allowed, `${tool.name} still exposes blocked argument ${argument}`);
      }
    }

    const waitForLoad = guarded.find((tool) => tool.name === "agent_browser_wait_for_load");
    assert.ok(waitForLoad, "agent_browser_wait_for_load was dropped — its required state argument is no longer allowed");
    assert.ok("state" in (schemaOf(waitForLoad).properties ?? {}), "wait_for_load lost its page load state argument");
  },
);
