#!/usr/bin/env node

import { appendFileSync } from "node:fs";
import { spawnSync } from "node:child_process";
import { fileURLToPath } from "node:url";

const args = process.argv.slice(2);
const invocationLog = process.env.ANVIL_TEST_COMPILER_INVOCATIONS;
if (invocationLog) {
  appendFileSync(invocationLog, `${JSON.stringify({ command: args[0] ?? null, args })}\n`, "utf8");
}

const fakeLlmWiki = fileURLToPath(new URL("./fixtures/brain-context/fake-llm-wiki.mjs", import.meta.url));
const result = spawnSync(process.execPath, [fakeLlmWiki, ...args], {
  cwd: process.cwd(),
  env: process.env,
  stdio: "inherit",
});

if (result.error) {
  process.stderr.write(`${result.error.message}\n`);
  process.exit(1);
}
process.exit(result.status ?? 1);
