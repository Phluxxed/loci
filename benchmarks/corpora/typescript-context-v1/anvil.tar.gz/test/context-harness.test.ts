import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import { cp, mkdir, mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { test } from "node:test";
import { fileURLToPath } from "node:url";

import { createContextHarness } from "../src/brain-context/harness.ts";
import { MAX_RETRIEVAL_LIMIT_SUMMARY, renderPromptEvidenceContext } from "../src/brain-context/render.ts";

const fixturesRoot = fileURLToPath(new URL("./fixtures/brain-context/", import.meta.url));
const fakeLlmWiki = join(fixturesRoot, "fake-llm-wiki.mjs");
const countingLlmWiki = fileURLToPath(new URL("./counting-llm-wiki.mjs", import.meta.url));

function runGit(cwd: string, args: string[]): void {
  const result = spawnSync("git", args, { cwd, encoding: "utf8" });
  assert.equal(result.status, 0, result.stderr);
}

async function createHarnessCase(input: {
  prompt: string;
  evidence: Array<Record<string, unknown>>;
  llmWikiBin?: string;
}): Promise<{
  temp: string;
  brainRoot: string;
  cwd: string;
  env: Record<string, string | undefined>;
  harness: ReturnType<typeof createContextHarness>;
}> {
  const temp = await mkdtemp(join(tmpdir(), "anvil-context-harness-case-"));
  const brainRoot = join(temp, "brain");
  const cwd = join(temp, "anvil_redux");
  const anvilHome = join(temp, ".anvil");
  await cp(join(fixturesRoot, "valid-known-project"), brainRoot, { recursive: true });
  await mkdir(cwd, { recursive: true });
  await mkdir(join(anvilHome, "agents", "codex"), { recursive: true });
  await writeFile(
    join(anvilHome, "agents", "codex", "config.json"),
    `${JSON.stringify({
      schema_version: 1,
      agent_id: "codex",
      brain_root: brainRoot,
      wiki_alias: "fixture-brain",
    })}\n`,
    "utf8",
  );
  runGit(cwd, ["init"]);
  await writeFile(
    join(brainRoot, "compiled-context.json"),
    `${JSON.stringify({ kind: "compiled_context", contract_version: "1", evidence: input.evidence })}\n`,
    "utf8",
  );
  await writeFile(
    join(brainRoot, "fake-llm-wiki.json"),
    `${JSON.stringify({ mode: "success", expected_question: input.prompt, expected_seeds: [] })}\n`,
    "utf8",
  );
  const env = {
    ANVIL_AGENT_ID: "codex",
    ANVIL_LLM_WIKI_BIN: input.llmWikiBin ?? fakeLlmWiki,
  };
  return {
    temp,
    brainRoot,
    cwd,
    env,
    harness: createContextHarness({
      anvilHome,
      homeDir: temp,
      stateRoot: join(temp, "state"),
      env,
      retrievalTimeoutMs: 2_000,
    }),
  };
}

async function configurePromptBudget(runtime: { brainRoot: string }, hardBytes: number): Promise<void> {
  const manifestPath = join(runtime.brainRoot, "brain-bootstrap.json");
  const manifest = JSON.parse(await readFile(manifestPath, "utf8"));
  manifest.budgets.prompt_recall_hard_bytes = hardBytes;
  manifest.budgets.prompt_recall_target_bytes = Math.min(
    manifest.budgets.prompt_recall_target_bytes,
    hardBytes,
  );
  await writeFile(manifestPath, `${JSON.stringify(manifest, null, 2)}\n`, "utf8");
}

async function configureFakeCompiler(
  runtime: { brainRoot: string },
  behavior: Record<string, unknown>,
): Promise<void> {
  await writeFile(
    join(runtime.brainRoot, "fake-llm-wiki.json"),
    `${JSON.stringify(behavior)}\n`,
    "utf8",
  );
}

async function configureManifestV2(runtime: { brainRoot: string }): Promise<void> {
  const manifestPath = join(runtime.brainRoot, "brain-bootstrap.json");
  const manifest = JSON.parse(await readFile(manifestPath, "utf8"));
  manifest.version = 2;
  delete manifest.projects;
  await writeFile(manifestPath, `${JSON.stringify(manifest, null, 2)}\n`, "utf8");
}

async function configureCompilerContext(
  runtime: { brainRoot: string },
  input: {
    prompt: string;
    evidence?: Array<Record<string, unknown>>;
    diagnostics?: Array<Record<string, unknown>>;
    omissions?: Array<Record<string, unknown>>;
    coverage?: Record<string, unknown>;
    budget?: Record<string, unknown>;
    stop?: Record<string, unknown>;
    continuation?: Record<string, unknown> | null;
    reporting?: Record<string, unknown>;
  },
): Promise<void> {
  await writeFile(
    join(runtime.brainRoot, "compiled-context.json"),
    `${JSON.stringify({
      kind: "compiled_context",
      contract_version: "3",
      wiki: { alias: "fixture-brain", schema_version: "1", runtime_contract: "2" },
      query: {
        question: input.prompt,
        shapes: ["lookup"],
        state_view: "current",
        resolved_seeds: [],
        project_resolution: { status: "not_requested" },
      },
      evidence: input.evidence ?? [],
      ...(input.omissions ? { omissions: input.omissions } : {}),
      ...(input.coverage ? { coverage: input.coverage } : {}),
      ...(input.budget ? { budget: input.budget } : {}),
      ...(input.stop ? { stop: input.stop } : {}),
      ...(input.continuation !== undefined ? { continuation: input.continuation } : {}),
      ...(input.diagnostics ? { diagnostics: input.diagnostics } : {}),
      ...(input.reporting ? { reporting: input.reporting } : {}),
    })}\n`,
    "utf8",
  );
  await configureFakeCompiler(runtime, {
    mode: "success",
    expected_question: input.prompt,
    expected_seeds: [],
  });
}

type CompilerInvocation = { command: string | null; args: string[] };

async function readCompilerInvocations(path: string): Promise<CompilerInvocation[]> {
  const content = await readFile(path, "utf8");
  return content.trim().length === 0
    ? []
    : content.trim().split("\n").map((line) => JSON.parse(line) as CompilerInvocation);
}

function compilerArgument(invocation: CompilerInvocation, name: string): number {
  const index = invocation.args.indexOf(name);
  assert.ok(index >= 0, `Expected ${name} in ${JSON.stringify(invocation.args)}`);
  const value = Number(invocation.args[index + 1]);
  assert.ok(Number.isSafeInteger(value), `Expected integer ${name} value in ${JSON.stringify(invocation.args)}`);
  return value;
}

test("planContext delivers exact compiled Prompt Evidence without rehydrating its complete page", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-context-harness-"));
  try {
    const brainRoot = join(temp, "brain");
    const cwd = join(temp, "anvil_redux");
    const anvilHome = join(temp, ".anvil");
    const prompt = "Which bounded operating rule applies?";
    await cp(join(fixturesRoot, "valid-known-project"), brainRoot, { recursive: true });
    await mkdir(cwd, { recursive: true });
    await mkdir(join(anvilHome, "agents", "codex"), { recursive: true });
    await writeFile(
      join(anvilHome, "agents", "codex", "config.json"),
      `${JSON.stringify({
        schema_version: 1,
        agent_id: "codex",
        brain_root: brainRoot,
        wiki_alias: "fixture-brain",
      })}\n`,
      "utf8",
    );
    runGit(cwd, ["init"]);
    await writeFile(
      join(brainRoot, "patterns", "support.md"),
      "# Support\n\nSelected operating rule.\n\nUNSELECTED SIBLING MATERIAL.\n",
      "utf8",
    );
    await writeFile(
      join(brainRoot, "compiled-context.json"),
      `${JSON.stringify({
        kind: "compiled_context",
        contract_version: "1",
        wiki: {
          alias: "fixture-brain",
          schema_version: "1",
          runtime_contract: "2",
        },
        query: {
          question: prompt,
          shapes: ["lookup"],
          state_view: "current",
          resolved_seeds: [],
        },
        evidence: [
          {
            id: "text:patterns/support.md#bounded-rule",
            provider: "text",
            route: "question_match",
            page: "patterns/support.md",
            source: null,
            locator: { section: "Bounded Rule", start_line: 3, end_line: 3 },
            content: "Selected operating rule.",
            roles: ["answer"],
            authored_state: "current",
            derived_flags: [],
            authority_signals: ["authored_current"],
            selection_reasons: ["question_match"],
            byte_cost: 401,
            truncated: false,
            atomic: false,
          },
        ],
        omissions: [],
        coverage: {
          required_roles: ["answer"],
          covered_roles: ["answer"],
          uncovered_roles: [],
        },
        budget: {
          limits: {
            target_bytes: 1024,
            max_bytes: 2048,
            target_items: 8,
            max_items: 12,
            max_estimated_tokens: null,
          },
          target_exceeded_for_coverage: false,
          evidence_bytes: 401,
          envelope_bytes: 900,
          items: 1,
          estimated_tokens: 101,
        },
        stop: { reason: "sufficient", sufficient: true, detail: "All required roles covered" },
        continuation: null,
        diagnostics: [],
        reporting: {
          omissions: { total: 0, returned: 0 },
          diagnostics: { total: 0, returned: 0 },
        },
      })}\n`,
      "utf8",
    );
    await writeFile(
      join(brainRoot, "fake-llm-wiki.json"),
      `${JSON.stringify({ mode: "success", expected_question: prompt, expected_seeds: [] })}\n`,
      "utf8",
    );

    const harness = createContextHarness({
      anvilHome,
      homeDir: temp,
      stateRoot: join(temp, "state"),
      env: { ANVIL_AGENT_ID: "codex", ANVIL_LLM_WIKI_BIN: fakeLlmWiki },
      retrievalTimeoutMs: 2_000,
    });
    const envelope = await harness.planContext({
      lifecycle: "prompt",
      cwd,
      prompt,
      host: "codex",
      sessionId: "session_exact_evidence",
      reservedBytes: 0,
    });

    assert.equal(envelope.contractVersion, "anvil-context-envelope/1");
    assert.equal(envelope.status, "ready", JSON.stringify(envelope.diagnostics));
    assert.match(envelope.receipt.snapshotDigest ?? "", /^[a-f0-9]{64}$/);
    assert.match(envelope.markdown, /Selected operating rule\./);
    assert.doesNotMatch(envelope.markdown, /UNSELECTED SIBLING MATERIAL/);
    assert.deepEqual(envelope.receipt.selectedEvidence.slice(-1), [
      {
        id: "text:patterns/support.md#bounded-rule",
        provider: "text",
        route: "question_match",
        page: "patterns/support.md",
        source: null,
        locator: { section: "Bounded Rule", start_line: 3, end_line: 3 },
        roles: ["answer"],
        authoredState: "current",
        derivedFlags: [],
        authoritySignals: ["authored_current"],
        selectionReasons: ["question_match"],
        byteCost: 401,
        truncated: false,
        atomic: false,
      },
    ]);
    assert.deepEqual(
      envelope.receipt.selectedEvidence.slice(0, 3).map((item) => item.roles),
      [["identity"], ["collaboration"], ["authority"]],
    );
    assert.equal(envelope.receipt.stop.reason, "sufficient");
    assert.equal(envelope.receipt.stop.sufficient, true);
    assert.equal(envelope.receipt.budget.renderedBytes, Buffer.byteLength(envelope.markdown, "utf8"));
    const serialized = JSON.stringify(envelope);
    assert.doesNotMatch(serialized, new RegExp(prompt));
    assert.doesNotMatch(serialized, new RegExp(brainRoot.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")));
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("planContext degrades instead of silently truncating a compiler-to-envelope budget violation", async () => {
  const prompt = "Return the bounded oversized evidence.";
  const runtime = await createHarnessCase({
    prompt,
    evidence: [
      {
        id: "text:patterns/support.md#oversized",
        page: "patterns/support.md",
        content: "x".repeat(4_000),
        byte_cost: 1,
      },
    ],
  });
  try {
    await configureFakeCompiler(runtime, {
      mode: "success",
      expected_question: prompt,
      expected_seeds: [],
      content_by_question: {
        "Provide the durable identity, collaboration, and current-project orientation required at session start.": "Compact kernel",
      },
    });
    const envelope = await runtime.harness.planContext({
      lifecycle: "prompt",
      cwd: runtime.cwd,
      prompt,
      host: "codex",
      sessionId: "session_budget_violation",
      reservedBytes: 0,
    });

    assert.equal(envelope.status, "partial");
    assert.deepEqual(envelope.diagnostics.map((diagnostic) => diagnostic.code), [
      "BRAIN_CONTEXT_BUDGET_VIOLATION",
    ]);
    assert.match(envelope.markdown, /BRAIN_CONTEXT_BUDGET_VIOLATION/);
    assert.doesNotMatch(envelope.markdown, /x{100}/);
    assert.equal(envelope.receipt.selectedEvidence.length, 3);
    assert.ok(envelope.receipt.selectedEvidence.every((item) => item.id.startsWith("kernel:")));
    assert.ok(envelope.receipt.budget.renderedBytes <= envelope.receipt.budget.hardBytes);
  } finally {
    await rm(runtime.temp, { recursive: true, force: true });
  }
});

test("planContext reserves outer and framing bytes and reports a true no-match as empty after kernel delivery", async () => {
  const prompt = "There is no durable match for this prompt.";
  const runtime = await createHarnessCase({ prompt, evidence: [] });
  try {
    const manifestPath = join(runtime.brainRoot, "brain-bootstrap.json");
    const manifest = JSON.parse(await readFile(manifestPath, "utf8"));
    manifest.prompt_guidance_pages = [];
    manifest.budgets.prompt_guidance_hard_bytes = 0;
    await writeFile(manifestPath, `${JSON.stringify(manifest, null, 2)}\n`, "utf8");
    await writeFile(
      join(runtime.brainRoot, "fake-llm-wiki.json"),
      `${JSON.stringify({
        mode: "success",
        expected_question: prompt,
        expected_seeds: [],
      })}\n`,
      "utf8",
    );

    await runtime.harness.planContext({
      lifecycle: "session_start",
      cwd: runtime.cwd,
      host: "codex",
      sessionId: "session_no_match",
      reservedBytes: 0,
    });
    const envelope = await runtime.harness.planContext({
      lifecycle: "prompt",
      cwd: runtime.cwd,
      prompt,
      host: "codex",
      sessionId: "session_no_match",
      reservedBytes: 128,
    });

    assert.equal(envelope.status, "empty", JSON.stringify(envelope.diagnostics));
    assert.equal(envelope.markdown, "");
    assert.equal(envelope.receipt.selectedEvidence.length, 0);
    assert.equal(envelope.receipt.stop.reason, "no_evidence");
    assert.doesNotMatch(envelope.markdown, /### Retrieval limits/i);
    assert.equal(envelope.receipt.budget.reservedBytes, 128);
    assert.equal(envelope.receipt.budget.hardBytes, 2_048);
    assert.equal(envelope.receipt.compilerBudget?.limits.targetBytes, 1_024);
    const baseFraming = { evidence: [], includeRoute: true, hardBytes: 2_048 };
    const limitFramingBytes = renderPromptEvidenceContext({
      ...baseFraming,
      retrievalLimits: MAX_RETRIEVAL_LIMIT_SUMMARY,
      includeRoleDisclaimer: true,
    }).attemptedBytes - renderPromptEvidenceContext(baseFraming).attemptedBytes;
    assert.equal(envelope.receipt.compilerBudget?.limits.maxBytes, 18_294 - limitFramingBytes);
    assert.equal(envelope.receipt.compilerBudget?.limits.maxContentBytes, 1_910 - limitFramingBytes);
  } finally {
    await rm(runtime.temp, { recursive: true, force: true });
  }
});

test("planContext rejects compiler output for a different wiki or question while retaining a valid kernel", async () => {
  const prompt = "Use only evidence compiled for this request.";
  const runtime = await createHarnessCase({ prompt, evidence: [] });
  try {
    await runtime.harness.planContext({
      lifecycle: "session_start",
      cwd: runtime.cwd,
      host: "codex",
      sessionId: "session_compiler_identity",
      reservedBytes: 0,
    });
    await writeFile(
      join(runtime.brainRoot, "compiled-context.json"),
      `${JSON.stringify({
        kind: "compiled_context",
        contract_version: "1",
        wiki: { alias: "another-brain", schema_version: "1", runtime_contract: "2" },
        query: {
          question: "A different question",
          shapes: ["lookup"],
          state_view: "current",
          resolved_seeds: [],
        },
        evidence: [],
      })}\n`,
      "utf8",
    );
    await writeFile(
      join(runtime.brainRoot, "fake-llm-wiki.json"),
      `${JSON.stringify({ mode: "success", preserve_query_identity: true })}\n`,
      "utf8",
    );

    const envelope = await runtime.harness.planContext({
      lifecycle: "prompt",
      cwd: runtime.cwd,
      prompt,
      host: "codex",
      sessionId: "session_compiler_identity",
      reservedBytes: 0,
    });

    assert.equal(envelope.status, "partial");
    assert.deepEqual(envelope.diagnostics.map((diagnostic) => diagnostic.code), ["BRAIN_RETRIEVAL_INVALID"]);
    assert.doesNotMatch(JSON.stringify(envelope), /A different question/);
  } finally {
    await rm(runtime.temp, { recursive: true, force: true });
  }
});

test("planContext preserves partial coverage, omissions, continuation, and provider degradation", async () => {
  const prompt = "How are the two durable systems related?";
  const runtime = await createHarnessCase({ prompt, evidence: [] });
  try {
    await writeFile(
      join(runtime.brainRoot, "compiled-context.json"),
      `${JSON.stringify({
        kind: "compiled_context",
        contract_version: "1",
        wiki: { alias: "fixture-brain", schema_version: "1", runtime_contract: "2" },
        query: { question: prompt, shapes: ["relationship"], state_view: "current", resolved_seeds: [] },
        evidence: [
          {
            id: "text:patterns/support.md#partial",
            provider: "text",
            route: "question_match",
            page: "patterns/support.md",
            source: null,
            locator: { section: "Partial" },
            content: "One endpoint is known.",
            roles: ["endpoint"],
            authored_state: "current",
            derived_flags: [],
            authority_signals: [],
            selection_reasons: ["covers:endpoint"],
            byte_cost: 300,
            truncated: false,
            atomic: false,
          },
        ],
        omissions: [{ candidate_id: "graph:bridge", reason: "byte_limit", estimated_bytes: 500 }],
        coverage: {
          required_roles: ["endpoint", "bridge"],
          covered_roles: ["endpoint"],
          uncovered_roles: ["bridge"],
        },
        budget: {
          limits: {
            target_bytes: 1024,
            max_bytes: 1024,
            target_items: 8,
            max_items: 12,
            max_estimated_tokens: null,
          },
          target_exceeded_for_coverage: false,
          evidence_bytes: 300,
          envelope_bytes: 800,
          items: 1,
          estimated_tokens: 75,
        },
        stop: { reason: "byte_budget_exhausted", sufficient: false, detail: "Bridge uncovered" },
        continuation: {
          reason: "hard_limit_reached",
          uncovered_roles: ["bridge"],
          remaining_candidate_ids: ["graph:bridge"],
        },
        diagnostics: [
          { code: "PROVIDER_FAILED", message: "Graph provider failed", provider: "graph", details: {} },
        ],
        reporting: {
          omissions: { total: 1, returned: 1 },
          diagnostics: { total: 1, returned: 1 },
        },
      })}\n`,
      "utf8",
    );

    const envelope = await runtime.harness.planContext({
      lifecycle: "prompt",
      cwd: runtime.cwd,
      prompt,
      host: "codex",
      sessionId: "session_partial",
      reservedBytes: 0,
    });

    assert.equal(envelope.status, "partial", JSON.stringify(envelope.diagnostics));
    assert.match(envelope.markdown, /One endpoint is known/);
    assert.deepEqual(envelope.receipt.coverage?.uncoveredRoles, ["bridge"]);
    assert.deepEqual(envelope.receipt.omissions, [
      { candidateId: "graph:bridge", reason: "byte_limit", estimatedBytes: 500 },
    ]);
    assert.deepEqual(envelope.receipt.continuation, {
      reason: "hard_limit_reached",
      uncovered_roles: ["bridge"],
      remaining_candidate_ids: ["graph:bridge"],
    });
    assert.equal(envelope.receipt.compilerDiagnostics[0]?.code, "PROVIDER_FAILED");
    assert.deepEqual(envelope.receipt.reporting, {
      omissions: { total: 1, returned: 1 },
      diagnostics: { total: 1, returned: 1 },
    });
  } finally {
    await rm(runtime.temp, { recursive: true, force: true });
  }
});

test("planContext falls back visibly to the validated last-known-good snapshot", async () => {
  const prompt = "Use the stable snapshot";
  const runtime = await createHarnessCase({
    prompt,
    evidence: [{ page: "patterns/support.md", content: "Stable snapshot evidence." }],
  });
  try {
    const request = {
      lifecycle: "prompt" as const,
      cwd: runtime.cwd,
      prompt,
      host: "codex",
      sessionId: "session_snapshot",
      reservedBytes: 0,
    };
    const current = await runtime.harness.planContext(request);
    assert.equal(current.status, "ready", JSON.stringify(current.diagnostics));

    await writeFile(
      join(runtime.brainRoot, "fake-llm-wiki.json"),
      `${JSON.stringify({ snapshot_publish_failure: true })}\n`,
      "utf8",
    );
    const fallback = await runtime.harness.planContext(request);

    assert.equal(fallback.status, "partial");
    assert.equal(fallback.receipt.snapshotDigest, current.receipt.snapshotDigest);
    assert.match(fallback.markdown, /Stable snapshot evidence/);
    assert.deepEqual(fallback.diagnostics.map((item) => item.code), ["BRAIN_SNAPSHOT_STALE"]);
  } finally {
    await rm(runtime.temp, { recursive: true, force: true });
  }
});

test("lifecycle planning emits an exact bounded Collaboration Kernel rather than complete core pages", async () => {
  const runtime = await createHarnessCase({
    prompt: "unused",
    evidence: [{
      page: "self-model/i-am-rowan.md",
      content: "Compact mandatory collaboration rule.",
      roles: ["identity"],
      byte_cost: 320,
    }],
  });
  try {
    await writeFile(
      join(runtime.brainRoot, "fake-llm-wiki.json"),
      `${JSON.stringify({
        mode: "success",
        expected_question: "Provide the durable identity, collaboration, and current-project orientation required at session start.",
        strict_kernel_expectations: true,
        expected_seeds: [
          "self-model/i-am-rowan.md",
          "self-model/working-with-vik.md",
          "self-model/brain-is-maintained-cognitive-wiki.md",
          "projects/anvil-redux.md",
        ],
        expected_target_bytes: 3072,
        expected_max_bytes: 20_480,
        expected_max_content_bytes: 4_096,
      })}\n`,
      "utf8",
    );
    const envelope = await runtime.harness.planContext({
      lifecycle: "session_start",
      cwd: runtime.cwd,
      host: "codex",
      sessionId: "session_kernel",
      reservedBytes: 0,
    });

    assert.equal(envelope.status, "ready", JSON.stringify(envelope.diagnostics));
    assert.match(envelope.markdown, /Compact mandatory collaboration rule/);
    assert.doesNotMatch(envelope.markdown, /I am Rowan, working through the Codex runtime/);
    assert.doesNotMatch(envelope.markdown, /### Retrieval limits/i);
    assert.doesNotMatch(envelope.markdown, /Evidence roles describe retrieval function/i);
    assert.ok(Buffer.byteLength(envelope.markdown, "utf8") <= 4096);
    assert.deepEqual(envelope.receipt.selectedEvidence.map((item) => item.id), ["kernel:0", "kernel:1", "kernel:2"]);
    assert.deepEqual(envelope.receipt.selectedEvidence.map((item) => item.roles), [["identity"], ["collaboration"], ["authority"]]);
    assert.equal(envelope.receipt.kernelBudget?.contentBytes, Buffer.byteLength("Compact mandatory collaboration rule.", "utf8"));
  } finally {
    await rm(runtime.temp, { recursive: true, force: true });
  }
});

test("kernel receipts suppress uninterrupted repetition and conservatively re-emit without retention proof", async () => {
  const prompt = "Find prompt-specific evidence";
  const kernelQuestion = "Provide the durable identity, collaboration, and current-project orientation required at session start.";
  const runtime = await createHarnessCase({
    prompt,
    evidence: [{ page: "patterns/support.md", content: "placeholder" }],
  });
  try {
    await writeFile(
      join(runtime.brainRoot, "fake-llm-wiki.json"),
      `${JSON.stringify({
        mode: "success",
        expected_question: prompt,
        content_by_question: {
          [kernelQuestion]: "KERNEL-ONLY-CONTEXT",
          [prompt]: "PROMPT-ONLY-EVIDENCE",
        },
      })}\n`,
      "utf8",
    );
    const base = {
      cwd: runtime.cwd,
      host: "codex",
      sessionId: "session_retained",
      reservedBytes: 0,
    };
    const startup = await runtime.harness.planContext({ ...base, lifecycle: "session_start" });
    assert.match(startup.markdown, /KERNEL-ONLY-CONTEXT/);
    assert.equal(startup.receipt.kernel.action, "emitted");

    const uninterrupted = await runtime.harness.planContext({ ...base, lifecycle: "prompt", prompt });
    assert.match(uninterrupted.markdown, /PROMPT-ONLY-EVIDENCE/);
    assert.doesNotMatch(uninterrupted.markdown, /KERNEL-ONLY-CONTEXT/);
    assert.equal(uninterrupted.receipt.kernel.action, "suppressed");

    const unknownRetention = await runtime.harness.planContext({
      ...base,
      lifecycle: "prompt",
      prompt,
      sessionId: "another_session",
    });
    assert.match(unknownRetention.markdown, /KERNEL-ONLY-CONTEXT/);
    assert.match(unknownRetention.markdown, /PROMPT-ONLY-EVIDENCE/);
    assert.equal(unknownRetention.receipt.kernel.action, "emitted");

    const resume = await runtime.harness.planContext({ ...base, lifecycle: "resume" });
    assert.match(resume.markdown, /KERNEL-ONLY-CONTEXT/);
    assert.equal(resume.receipt.kernel.action, "emitted");
  } finally {
    await rm(runtime.temp, { recursive: true, force: true });
  }
});

test("optional prompt retrieval failure remains partial when a valid kernel is retained or re-emitted", async () => {
  const prompt = "Fail this optional recall";
  const runtime = await createHarnessCase({
    prompt,
    evidence: [{ page: "self-model/i-am-rowan.md", content: "VALID-KERNEL" }],
  });
  try {
    await writeFile(
      join(runtime.brainRoot, "fake-llm-wiki.json"),
      `${JSON.stringify({ mode: "success", expected_question: prompt, failure_questions: [prompt] })}\n`,
      "utf8",
    );
    const base = { cwd: runtime.cwd, host: "codex", sessionId: "session_partial_recall", reservedBytes: 0 };
    const startup = await runtime.harness.planContext({ ...base, lifecycle: "session_start" });
    assert.equal(startup.status, "ready");

    const retained = await runtime.harness.planContext({ ...base, lifecycle: "prompt", prompt });
    assert.equal(retained.status, "partial");
    assert.equal(retained.receipt.kernel.action, "suppressed");
    assert.deepEqual(retained.diagnostics.map((item) => item.code), ["BRAIN_RETRIEVAL_FAILED"]);

    const reemitted = await runtime.harness.planContext({
      ...base,
      lifecycle: "prompt",
      prompt,
      sessionId: "session_without_receipt",
    });
    assert.equal(reemitted.status, "partial");
    assert.equal(reemitted.receipt.kernel.action, "emitted");
    assert.match(reemitted.markdown, /VALID-KERNEL/);
    assert.deepEqual(reemitted.diagnostics.map((item) => item.code), ["BRAIN_RETRIEVAL_FAILED"]);
  } finally {
    await rm(runtime.temp, { recursive: true, force: true });
  }
});

test("prompt planning prepares a required kernel before exactly one evidence compiler invocation", async () => {
  const prompt = "Allocate prompt evidence after the kernel.";
  const kernelQuestion = "Provide the durable identity, collaboration, and current-project orientation required at session start.";
  const runtime = await createHarnessCase({
    prompt,
    evidence: [{ page: "patterns/support.md", content: "PROMPT-EVIDENCE", byte_cost: 1 }],
    llmWikiBin: countingLlmWiki,
  });
  try {
    await configurePromptBudget(runtime, 16_384);
    const invocationLog = join(runtime.temp, "compiler-invocations.jsonl");
    runtime.env.ANVIL_TEST_COMPILER_INVOCATIONS = invocationLog;
    await configureFakeCompiler(runtime, {
      mode: "success",
      expected_question: prompt,
      expected_seeds: [],
      content_by_question: {
        [kernelQuestion]: "K".repeat(2_725),
        [prompt]: "PROMPT-EVIDENCE",
      },
    });

    const envelope = await runtime.harness.planContext({
      lifecycle: "prompt",
      cwd: runtime.cwd,
      prompt,
      host: "codex",
      sessionId: "session_kernel_first",
      reservedBytes: 0,
    });

    assert.equal(envelope.status, "ready", JSON.stringify(envelope.diagnostics));
    assert.equal(envelope.receipt.kernel.action, "emitted");
    const invocations = await readCompilerInvocations(invocationLog);
    assert.equal(invocations.filter((item) => item.command === "compile-kernel").length, 1);
    const promptInvocations = invocations.filter((item) => item.command === "compile-context");
    assert.equal(promptInvocations.length, 1, JSON.stringify(invocations));
    assert.ok(
      compilerArgument(promptInvocations[0]!, "--max-content-bytes") < 16_384,
      JSON.stringify(promptInvocations[0]),
    );
  } finally {
    await rm(runtime.temp, { recursive: true, force: true });
  }
});

test("retained kernels keep the full remaining budget while outer reservation is charged", async () => {
  const prompt = "Compare retained and required kernel allocation.";
  const kernelQuestion = "Provide the durable identity, collaboration, and current-project orientation required at session start.";
  const outerReservation = 317;
  const retained = await createHarnessCase({
    prompt,
    evidence: [{ page: "patterns/support.md", content: "PROMPT-EVIDENCE", byte_cost: 1 }],
    llmWikiBin: countingLlmWiki,
  });
  const required = await createHarnessCase({
    prompt,
    evidence: [{ page: "patterns/support.md", content: "PROMPT-EVIDENCE", byte_cost: 1 }],
    llmWikiBin: countingLlmWiki,
  });
  try {
    for (const runtime of [retained, required]) {
      await configurePromptBudget(runtime, 16_384);
      await configureFakeCompiler(runtime, {
        mode: "success",
        expected_question: prompt,
        expected_seeds: [],
        content_by_question: {
          [kernelQuestion]: "K".repeat(2_725),
          [prompt]: "PROMPT-EVIDENCE",
        },
      });
    }
    const retainedLog = join(retained.temp, "compiler-invocations.jsonl");
    const requiredLog = join(required.temp, "compiler-invocations.jsonl");
    retained.env.ANVIL_TEST_COMPILER_INVOCATIONS = retainedLog;
    required.env.ANVIL_TEST_COMPILER_INVOCATIONS = requiredLog;

    const startup = await retained.harness.planContext({
      lifecycle: "session_start",
      cwd: retained.cwd,
      host: "codex",
      sessionId: "session_retained_allocation",
      reservedBytes: 0,
    });
    const retainedWithoutOuter = await retained.harness.planContext({
      lifecycle: "prompt",
      cwd: retained.cwd,
      prompt,
      host: "codex",
      sessionId: "session_retained_allocation",
      reservedBytes: 0,
    });
    const retainedWithOuter = await retained.harness.planContext({
      lifecycle: "prompt",
      cwd: retained.cwd,
      prompt,
      host: "codex",
      sessionId: "session_retained_allocation",
      reservedBytes: outerReservation,
    });
    const requiredWithOuter = await required.harness.planContext({
      lifecycle: "prompt",
      cwd: required.cwd,
      prompt,
      host: "codex",
      sessionId: "session_required_allocation",
      reservedBytes: outerReservation,
    });

    for (const envelope of [retainedWithoutOuter, retainedWithOuter, requiredWithOuter]) {
      assert.equal(envelope.status, "ready", JSON.stringify(envelope.diagnostics));
    }
    assert.equal(startup.receipt.kernel.action, "emitted");
    assert.equal(retainedWithoutOuter.receipt.kernel.action, "suppressed");
    assert.equal(retainedWithOuter.receipt.kernel.action, "suppressed");
    assert.equal(requiredWithOuter.receipt.kernel.action, "emitted");

    const retainedInvocations = (await readCompilerInvocations(retainedLog))
      .filter((item) => item.command === "compile-context");
    const requiredInvocations = (await readCompilerInvocations(requiredLog))
      .filter((item) => item.command === "compile-context");
    assert.equal(retainedInvocations.length, 2);
    assert.equal(requiredInvocations.length, 1);
    const retainedMaxWithoutOuter = compilerArgument(retainedInvocations[0]!, "--max-content-bytes");
    const retainedMaxWithOuter = compilerArgument(retainedInvocations[1]!, "--max-content-bytes");
    const requiredMaxWithOuter = compilerArgument(requiredInvocations[0]!, "--max-content-bytes");
    assert.equal(retainedMaxWithoutOuter - retainedMaxWithOuter, outerReservation);
    assert.equal(
      retainedMaxWithOuter - requiredMaxWithOuter,
      Buffer.byteLength(startup.markdown, "utf8") + 2,
    );
  } finally {
    await rm(retained.temp, { recursive: true, force: true });
    await rm(required.temp, { recursive: true, force: true });
  }
});

test("a required valid kernel survives ordinary prompt retrieval failure", async () => {
  const prompt = "This prompt intentionally fails after kernel preparation.";
  const kernelQuestion = "Provide the durable identity, collaboration, and current-project orientation required at session start.";
  const runtime = await createHarnessCase({
    prompt,
    evidence: [{ page: "patterns/support.md", content: "PROMPT-EVIDENCE", byte_cost: 1 }],
    llmWikiBin: countingLlmWiki,
  });
  try {
    await configurePromptBudget(runtime, 16_384);
    const invocationLog = join(runtime.temp, "compiler-invocations.jsonl");
    runtime.env.ANVIL_TEST_COMPILER_INVOCATIONS = invocationLog;
    await configureFakeCompiler(runtime, {
      mode: "success",
      expected_question: prompt,
      expected_seeds: [],
      failure_questions: [prompt],
      content_by_question: { [kernelQuestion]: "VALID-KERNEL" },
    });

    const envelope = await runtime.harness.planContext({
      lifecycle: "prompt",
      cwd: runtime.cwd,
      prompt,
      host: "codex",
      sessionId: "session_kernel_survives_failure",
      reservedBytes: 0,
    });

    assert.equal(envelope.status, "partial", JSON.stringify(envelope.diagnostics));
    assert.equal(envelope.receipt.kernel.action, "emitted");
    assert.equal(envelope.receipt.kernel.reason, "prompt_retrieval_degraded");
    assert.match(envelope.markdown, /VALID-KERNEL/);
    assert.deepEqual(envelope.diagnostics.map((item) => item.code), ["BRAIN_RETRIEVAL_FAILED"]);
    assert.ok(envelope.receipt.selectedEvidence.some((item) => item.id === "kernel:0"));
    const invocations = (await readCompilerInvocations(invocationLog))
      .filter((item) => item.command === "compile-context");
    assert.equal(invocations.length, 1);
  } finally {
    await rm(runtime.temp, { recursive: true, force: true });
  }
});

test("a fitting kernel survives an impossible prompt allowance while an oversized kernel is suppressed", async () => {
  const prompt = "This prompt has no room after the mandatory kernel.";
  const kernelQuestion = "Provide the durable identity, collaboration, and current-project orientation required at session start.";
  const runtime = await createHarnessCase({
    prompt,
    evidence: [{ page: "patterns/support.md", content: "PROMPT-EVIDENCE", byte_cost: 1 }],
    llmWikiBin: countingLlmWiki,
  });
  try {
    const promptHardBytes = 16_384;
    await configurePromptBudget(runtime, promptHardBytes);
    const invocationLog = join(runtime.temp, "compiler-invocations.jsonl");
    runtime.env.ANVIL_TEST_COMPILER_INVOCATIONS = invocationLog;
    await configureFakeCompiler(runtime, {
      mode: "success",
      expected_question: prompt,
      expected_seeds: [],
      content_by_question: { [kernelQuestion]: "BOUNDARY-KERNEL" },
      failure_questions: [prompt],
    });

    const startup = await runtime.harness.planContext({
      lifecycle: "session_start",
      cwd: runtime.cwd,
      host: "codex",
      sessionId: "session_boundary_measurement",
      reservedBytes: 0,
    });
    const kernelBytes = Buffer.byteLength(startup.markdown, "utf8");
    assert.ok(kernelBytes > 0 && kernelBytes < promptHardBytes);

    for (const [label, reservedBytes, kernelFits] of [
      ["kernel-only", promptHardBytes - kernelBytes, true],
      ["kernel-plus-separator", promptHardBytes - kernelBytes - 2, true],
      ["kernel-too-large", promptHardBytes - kernelBytes + 1, false],
    ] as const) {
      const envelope = await runtime.harness.planContext({
        lifecycle: "prompt",
        cwd: runtime.cwd,
        prompt,
        host: "codex",
        sessionId: `session_boundary_${label}`,
        reservedBytes,
      });

      if (kernelFits) {
        assert.equal(envelope.status, "partial", `${label}: ${JSON.stringify(envelope.diagnostics)}`);
        assert.equal(envelope.receipt.kernel.action, "emitted");
        assert.equal(envelope.receipt.kernel.reason, "prompt_retrieval_degraded");
        assert.match(envelope.markdown, /BOUNDARY-KERNEL/);
        assert.deepEqual(envelope.diagnostics.map((item) => item.code), ["BRAIN_CONTEXT_BUDGET_VIOLATION"]);
        assert.equal(envelope.receipt.selectedEvidence.length, 3);
      } else {
        assert.equal(envelope.status, "degraded", `${label}: ${JSON.stringify(envelope.diagnostics)}`);
        assert.equal(envelope.receipt.kernel.action, "suppressed");
        assert.equal(envelope.receipt.kernel.reason, "budget_contract_violation");
        assert.doesNotMatch(envelope.markdown, /BOUNDARY-KERNEL/);
        assert.equal(envelope.receipt.selectedEvidence.length, 0);
      }
    }
    const promptInvocations = (await readCompilerInvocations(invocationLog))
      .filter((item) => item.command === "compile-context");
    assert.equal(promptInvocations.length, 0);
  } finally {
    await rm(runtime.temp, { recursive: true, force: true });
  }
});

test("Collaboration Kernel target and hard-ceiling boundaries are exact", async () => {
  for (const [contentBytes, status, diagnostics] of [
    [3_072, "ready", []],
    [3_073, "partial", ["BRAIN_KERNEL_TARGET_EXCEEDED"]],
    [4_096, "partial", ["BRAIN_KERNEL_TARGET_EXCEEDED"]],
    [4_097, "degraded", ["BRAIN_CONTEXT_BUDGET_VIOLATION"]],
  ] as const) {
    const content = "x".repeat(contentBytes);
    const runtime = await createHarnessCase({
      prompt: "unused",
      evidence: [{ content, byte_cost: Buffer.byteLength(content, "utf8") }],
    });
    try {
      const envelope = await runtime.harness.planContext({
        lifecycle: "session_start",
        cwd: runtime.cwd,
        host: "codex",
        sessionId: `kernel_${contentBytes}`,
        reservedBytes: 0,
      });
      assert.equal(envelope.status, status, `${contentBytes}: ${JSON.stringify(envelope.diagnostics)}`);
      assert.deepEqual(envelope.diagnostics.map((item) => item.code), diagnostics);
      if (contentBytes <= 4_096) assert.equal(envelope.receipt.kernelBudget?.contentBytes, contentBytes);
    } finally {
      await rm(runtime.temp, { recursive: true, force: true });
    }
  }
});

test("manifest v2 consumes compiler project resolution and preserves returned project evidence", async () => {
  const prompt = "What should I do next?";
  const runtime = await createHarnessCase({ prompt, evidence: [] });
  try {
    const manifestPath = join(runtime.brainRoot, "brain-bootstrap.json");
    const manifest = JSON.parse(await readFile(manifestPath, "utf8"));
    manifest.version = 2;
    delete manifest.projects;
    await writeFile(manifestPath, `${JSON.stringify(manifest, null, 2)}\n`, "utf8");
    await writeFile(
      join(runtime.brainRoot, "compiled-context.json"),
      `${JSON.stringify({
        kind: "compiled_context",
        contract_version: "3",
        query: {
          project_resolution: {
            status: "matched",
            project_id: "alpha",
            page: "projects/alpha.md",
            matched_by: "remote",
          },
        },
        evidence: [
          { page: "projects/alpha.md", content: "ALPHA PROJECT ORIENTATION" },
          { page: "projects/beta.md", content: "BETA EVIDENCE RETURNED BY COMPILER" },
        ],
      })}\n`,
      "utf8",
    );

    const envelope = await runtime.harness.planContext({
      lifecycle: "prompt",
      cwd: runtime.cwd,
      prompt,
      host: "codex",
      sessionId: "session-v2-matched",
      reservedBytes: 0,
    });

    assert.equal(envelope.status, "ready", JSON.stringify(envelope.diagnostics));
    assert.match(envelope.markdown, /current_project: `projects\/alpha\.md`/);
    assert.match(envelope.markdown, /ALPHA PROJECT ORIENTATION/);
    assert.match(envelope.markdown, /BETA EVIDENCE RETURNED BY COMPILER/);
    assert.equal(envelope.receipt.project, "projects/alpha.md");
    assert.equal(envelope.receipt.projectResolution?.status, "matched");
    const selectedPages = envelope.receipt.selectedEvidence.map((item) => item.page);
    assert.ok(selectedPages.includes("projects/alpha.md"));
    assert.ok(selectedPages.includes("projects/beta.md"));
  } finally {
    await rm(runtime.temp, { recursive: true, force: true });
  }
});

test("manifest v2 renders unknown and ambiguous compiler resolutions without guessing", async () => {
  for (const [label, projectResolution, diagnostics, expectedStatus] of [
    ["unknown", { status: "unknown" }, [], "partial"],
    [
      "ambiguous",
      {
        status: "ambiguous",
        matched_by: "remote",
        candidates: [
          { project_id: "alpha", page: "projects/alpha.md" },
          { project_id: "beta", page: "projects/beta.md" },
        ],
        candidate_count: 2,
      },
      [{ code: "PROJECT_IDENTITY_AMBIGUOUS", message: "Two projects match.", provider: null, details: {} }],
      "partial",
    ],
  ] as const) {
    const prompt = `Resolve ${label} workspace`;
    const runtime = await createHarnessCase({ prompt, evidence: [] });
    try {
      const manifestPath = join(runtime.brainRoot, "brain-bootstrap.json");
      const manifest = JSON.parse(await readFile(manifestPath, "utf8"));
      manifest.version = 2;
      delete manifest.projects;
      await writeFile(manifestPath, `${JSON.stringify(manifest, null, 2)}\n`, "utf8");
      await writeFile(
        join(runtime.brainRoot, "compiled-context.json"),
        `${JSON.stringify({
          kind: "compiled_context",
          contract_version: "3",
          query: { project_resolution: projectResolution },
          evidence: [],
          diagnostics,
        })}\n`,
        "utf8",
      );

      const envelope = await runtime.harness.planContext({
        lifecycle: "prompt",
        cwd: runtime.cwd,
        prompt,
        host: "codex",
        sessionId: `session-v2-${label}`,
        reservedBytes: 0,
      });

      assert.equal(envelope.status, expectedStatus, JSON.stringify(envelope.diagnostics));
      assert.match(envelope.markdown, /current_project: unknown_project/);
      assert.equal(envelope.receipt.project, undefined);
      assert.equal(envelope.receipt.projectResolution?.status, label);
      if (label === "ambiguous") {
        assert.deepEqual(envelope.diagnostics.map((item) => item.code), ["PROJECT_IDENTITY_AMBIGUOUS"]);
        assert.match(envelope.markdown, /PROJECT_IDENTITY_AMBIGUOUS/);
      }
    } finally {
      await rm(runtime.temp, { recursive: true, force: true });
    }
  }
});

test("ordinary prompt delivery keeps usable evidence with one source/provider retrieval-limit warning", async () => {
  const prompt = "Which supported rule applies to this change?";
  const content = "USABLE SOURCE-BACKED RULE — café 東京.";
  const runtime = await createHarnessCase({ prompt, evidence: [] });
  try {
    await configureManifestV2(runtime);
    await configureCompilerContext(runtime, {
      prompt,
      evidence: [{
        id: "text:patterns/support.md#rule",
        provider: "text",
        route: "question_match",
        page: "patterns/support.md",
        source: null,
        locator: { section: "Supported Rule" },
        content,
        roles: ["answer"],
        authored_state: "current",
        derived_flags: [],
        authority_signals: ["authored_current"],
        selection_reasons: ["question_match"],
        byte_cost: Buffer.byteLength(content, "utf8"),
        truncated: false,
        atomic: false,
      }],
      diagnostics: [
        {
          code: "SOURCE_NOT_FOUND",
          message: "The supporting source could not be loaded.",
          provider: "source",
          details: { source: "sources/missing.md" },
        },
        {
          code: "PROVIDER_FAILED",
          message: "A retrieval provider returned no supporting source.",
          provider: "graph",
          details: {},
        },
      ],
    });

    await runtime.harness.planContext({
      lifecycle: "session_start",
      cwd: runtime.cwd,
      host: "codex",
      sessionId: "session_warning_with_evidence",
      reservedBytes: 0,
    });
    const envelope = await runtime.harness.planContext({
      lifecycle: "prompt",
      cwd: runtime.cwd,
      prompt,
      host: "codex",
      sessionId: "session_warning_with_evidence",
      reservedBytes: 0,
    });

    assert.equal(envelope.status, "partial", JSON.stringify(envelope.diagnostics));
    assert.match(envelope.markdown, new RegExp(content));
    assert.equal((envelope.markdown.match(/^### Retrieval limits$/gim) ?? []).length, 1);
    assert.match(
      envelope.markdown,
      /Some sources or retrieval providers could not supply evidence; retrieval may be incomplete\./,
    );
    assert.match(
      envelope.markdown,
      /Evidence roles describe retrieval function, not whether this context is sufficient to answer\./,
    );
    assert.equal(envelope.receipt.selectedEvidence.length, 1);
    assert.equal(envelope.receipt.selectedEvidence[0]?.id, "text:patterns/support.md#rule");
    assert.deepEqual(envelope.receipt.coverage?.coveredRoles, ["answer"]);
    assert.deepEqual(envelope.receipt.compilerDiagnostics.map((item) => item.code), [
      "SOURCE_NOT_FOUND",
      "PROVIDER_FAILED",
    ]);
    assert.deepEqual(envelope.receipt.reporting?.diagnostics, { total: 2, returned: 2 });
    assert.equal(envelope.receipt.budget.renderedBytes, Buffer.byteLength(envelope.markdown, "utf8"));
  } finally {
    await rm(runtime.temp, { recursive: true, force: true });
  }
});

test("budget omissions stay visible with full role coverage while retaining useful evidence", async () => {
  const prompt = "Which rule should guide the bounded change?";
  const content = "RETAINED RULE EVIDENCE";
  const runtime = await createHarnessCase({ prompt, evidence: [] });
  try {
    await configureManifestV2(runtime);
    await configureCompilerContext(runtime, {
      prompt,
      evidence: [{
        id: "text:patterns/support.md#retained",
        provider: "text",
        route: "question_match",
        page: "patterns/support.md",
        source: null,
        locator: { section: "Retained Rule" },
        content,
        roles: ["answer"],
        authored_state: "current",
        derived_flags: [],
        authority_signals: ["authored_current"],
        selection_reasons: ["question_match"],
        byte_cost: Buffer.byteLength(content, "utf8"),
        truncated: false,
        atomic: false,
      }],
      omissions: [{
        candidate_id: "text:patterns/support.md#supplement",
        reason: "byte_limit",
        estimated_bytes: 347,
      }],
      coverage: {
        required_roles: ["answer"],
        covered_roles: ["answer"],
        uncovered_roles: [],
      },
      stop: {
        reason: "byte_budget_exhausted",
        sufficient: true,
        detail: "Required evidence roles were covered before the hard byte limit.",
      },
      continuation: {
        reason: "hard_limit_reached",
        remaining_candidate_ids: ["text:patterns/support.md#supplement"],
      },
      reporting: {
        omissions: { total: 1, returned: 1 },
        diagnostics: { total: 0, returned: 0 },
      },
    });

    await runtime.harness.planContext({
      lifecycle: "session_start",
      cwd: runtime.cwd,
      host: "codex",
      sessionId: "session_budget_omission",
      reservedBytes: 0,
    });
    const envelope = await runtime.harness.planContext({
      lifecycle: "prompt",
      cwd: runtime.cwd,
      prompt,
      host: "codex",
      sessionId: "session_budget_omission",
      reservedBytes: 0,
    });

    assert.notEqual(envelope.status, "degraded", JSON.stringify(envelope.diagnostics));
    assert.match(envelope.markdown, /RETAINED RULE EVIDENCE/);
    assert.equal((envelope.markdown.match(/^### Retrieval limits$/gim) ?? []).length, 1);
    assert.match(
      envelope.markdown,
      /Additional candidate evidence was omitted or shortened to fit the context limit\./,
    );
    assert.match(
      envelope.markdown,
      /Evidence roles describe retrieval function, not whether this context is sufficient to answer\./,
    );
    assert.deepEqual(envelope.receipt.coverage, {
      requiredRoles: ["answer"],
      coveredRoles: ["answer"],
      uncoveredRoles: [],
    });
    assert.deepEqual(envelope.receipt.omissions, [{
      candidateId: "text:patterns/support.md#supplement",
      reason: "byte_limit",
      estimatedBytes: 347,
    }]);
    assert.equal(envelope.receipt.stop.reason, "byte_budget_exhausted");
    assert.equal(envelope.receipt.stop.sufficient, true);
    assert.deepEqual(envelope.receipt.reporting?.omissions, { total: 1, returned: 1 });
    assert.equal(envelope.receipt.selectedEvidence.length, 1);
    assert.equal(envelope.receipt.selectedEvidence[0]?.id, "text:patterns/support.md#retained");
    assert.equal(envelope.receipt.budget.renderedBytes, Buffer.byteLength(envelope.markdown, "utf8"));
  } finally {
    await rm(runtime.temp, { recursive: true, force: true });
  }
});

test("fully compacted diagnostics disclose unavailable detail without inventing a category or count", async () => {
  const prompt = "What durable evidence applies here?";
  const content = "COMPACTED-DIAGNOSTICS EVIDENCE";
  const runtime = await createHarnessCase({ prompt, evidence: [] });
  try {
    await configureManifestV2(runtime);
    await configureCompilerContext(runtime, {
      prompt,
      evidence: [{
        id: "text:patterns/support.md#compacted",
        provider: "text",
        route: "question_match",
        page: "patterns/support.md",
        source: null,
        locator: { section: "Compacted" },
        content,
        roles: ["answer"],
        authored_state: "current",
        derived_flags: [],
        authority_signals: [],
        selection_reasons: ["question_match"],
        byte_cost: Buffer.byteLength(content, "utf8"),
        truncated: false,
        atomic: false,
      }],
      reporting: {
        omissions: { total: 0, returned: 0 },
        diagnostics: { total: 98, returned: 0 },
      },
    });

    await runtime.harness.planContext({
      lifecycle: "session_start",
      cwd: runtime.cwd,
      host: "codex",
      sessionId: "session_compacted_diagnostics",
      reservedBytes: 0,
    });
    const envelope = await runtime.harness.planContext({
      lifecycle: "prompt",
      cwd: runtime.cwd,
      prompt,
      host: "codex",
      sessionId: "session_compacted_diagnostics",
      reservedBytes: 0,
    });

    assert.match(envelope.markdown, /COMPACTED-DIAGNOSTICS EVIDENCE/);
    assert.equal((envelope.markdown.match(/^### Retrieval limits$/gim) ?? []).length, 1);
    assert.match(
      envelope.markdown,
      /Some diagnostic details were not returned; their categories are unavailable here\./,
    );
    assert.doesNotMatch(envelope.markdown, /\b98\b|SOURCE_NOT_FOUND|PROVIDER_FAILED|missing source/i);
    assert.deepEqual(envelope.receipt.reporting?.diagnostics, { total: 98, returned: 0 });
    assert.equal(envelope.receipt.selectedEvidence.length, 1);
    assert.equal(envelope.receipt.budget.renderedBytes, Buffer.byteLength(envelope.markdown, "utf8"));
  } finally {
    await rm(runtime.temp, { recursive: true, force: true });
  }
});

test("normal LOCI_GRAPH_PATH_REJECTED remains a graph finding rather than a provider failure", async () => {
  const prompt = "What related evidence is available?";
  const content = "GRAPH-FINDING WITH USABLE EVIDENCE";
  const runtime = await createHarnessCase({ prompt, evidence: [] });
  try {
    await configureManifestV2(runtime);
    await configureCompilerContext(runtime, {
      prompt,
      evidence: [{
        id: "text:patterns/support.md#graph-finding",
        provider: "text",
        route: "question_match",
        page: "patterns/support.md",
        source: null,
        locator: { section: "Graph Finding" },
        content,
        roles: ["answer"],
        authored_state: "current",
        derived_flags: [],
        authority_signals: [],
        selection_reasons: ["question_match"],
        byte_cost: Buffer.byteLength(content, "utf8"),
        truncated: false,
        atomic: false,
      }],
      diagnostics: [{
        code: "LOCI_GRAPH_PATH_REJECTED",
        message: "No evidenced graph path met the relationship query contract.",
        provider: "loci",
        details: { reason: "EVIDENCE_UNAVAILABLE" },
      }],
    });

    await runtime.harness.planContext({
      lifecycle: "session_start",
      cwd: runtime.cwd,
      host: "codex",
      sessionId: "session_graph_rejection",
      reservedBytes: 0,
    });
    const envelope = await runtime.harness.planContext({
      lifecycle: "prompt",
      cwd: runtime.cwd,
      prompt,
      host: "codex",
      sessionId: "session_graph_rejection",
      reservedBytes: 0,
    });

    assert.notEqual(envelope.status, "degraded", JSON.stringify(envelope.diagnostics));
    assert.match(envelope.markdown, /GRAPH-FINDING WITH USABLE EVIDENCE/);
    assert.doesNotMatch(envelope.markdown, /### Retrieval limits/i);
    assert.doesNotMatch(envelope.markdown, /could not supply evidence|retrieval may be incomplete|provider failure/i);
    assert.deepEqual(envelope.receipt.compilerDiagnostics.map((item) => item.code), [
      "LOCI_GRAPH_PATH_REJECTED",
    ]);
    assert.deepEqual(envelope.receipt.reporting?.diagnostics, { total: 1, returned: 1 });
    assert.equal(envelope.receipt.selectedEvidence.length, 1);
  } finally {
    await rm(runtime.temp, { recursive: true, force: true });
  }
});

test("an empty prompt retrieval plus provider failure stays partial without fabricating evidence", async () => {
  const prompt = "This prompt has no retrievable evidence.";
  const runtime = await createHarnessCase({
    prompt,
    evidence: [{
      page: "self-model/i-am-rowan.md",
      content: "KERNEL-ONLY AFTER EMPTY PROMPT RECALL",
      roles: ["identity"],
      byte_cost: 1,
    }],
  });
  try {
    await configureFakeCompiler(runtime, {
      mode: "success",
      expected_question: prompt,
      expected_seeds: [],
      failure_questions: [prompt],
    });
    await runtime.harness.planContext({
      lifecycle: "session_start",
      cwd: runtime.cwd,
      host: "codex",
      sessionId: "session_empty_provider_failure",
      reservedBytes: 0,
    });
    const envelope = await runtime.harness.planContext({
      lifecycle: "prompt",
      cwd: runtime.cwd,
      prompt,
      host: "codex",
      sessionId: "session_empty_provider_failure",
      reservedBytes: 0,
    });

    assert.equal(envelope.status, "partial", JSON.stringify(envelope.diagnostics));
    assert.notEqual(envelope.status, "ready");
    assert.equal(envelope.receipt.selectedEvidence.length, 0);
    assert.equal(envelope.receipt.stop.reason, "not_run");
    assert.deepEqual(envelope.diagnostics.map((item) => item.code), ["BRAIN_RETRIEVAL_FAILED"]);
    assert.match(envelope.markdown, /BRAIN_RETRIEVAL_FAILED|retrieval|provider/i);
  } finally {
    await rm(runtime.temp, { recursive: true, force: true });
  }
});

test("the combined Kernel and Prompt Evidence envelope fits exactly at its UTF-8 ceiling", async () => {
  const prompt = "Which UTF-8 rule applies?";
  const content = "UTF-8 RULE: café 東京 — retain this evidence.";
  const runtime = await createHarnessCase({ prompt, evidence: [] });
  try {
    await configureManifestV2(runtime);
    const hardBytes = 8_192;
    await configurePromptBudget(runtime, hardBytes);
    await configureCompilerContext(runtime, {
      prompt,
      evidence: [{
        id: "text:patterns/support.md#utf8",
        provider: "text",
        route: "question_match",
        page: "patterns/support.md",
        source: null,
        locator: { section: "UTF-8 Rule" },
        content,
        roles: ["answer"],
        authored_state: "current",
        derived_flags: [],
        authority_signals: ["authored_current"],
        selection_reasons: ["question_match"],
        byte_cost: Buffer.byteLength(content, "utf8"),
        truncated: false,
        atomic: false,
      }],
      omissions: [{
        candidate_id: "text:patterns/support.md#supplement",
        reason: "byte_limit",
        estimated_bytes: 173,
      }],
      diagnostics: [{
        code: "SOURCE_NOT_FOUND",
        message: "A supporting source was not available.",
        provider: "source",
        details: { source: "sources/missing.md" },
      }],
      stop: {
        reason: "byte_budget_exhausted",
        sufficient: true,
        detail: "All required evidence roles were covered before the hard limit.",
      },
      continuation: {
        reason: "hard_limit_reached",
        remaining_candidate_ids: ["text:patterns/support.md#supplement"],
      },
      reporting: {
        omissions: { total: 2, returned: 1 },
        diagnostics: { total: 2, returned: 1 },
      },
    });

    await runtime.harness.planContext({
      lifecycle: "session_start",
      cwd: runtime.cwd,
      host: "codex",
      sessionId: "session_exact_utf8_kernel_measure",
      reservedBytes: 0,
    });
    const wide = await runtime.harness.planContext({
      lifecycle: "prompt",
      cwd: runtime.cwd,
      prompt,
      host: "codex",
      sessionId: "session_exact_utf8_wide",
      reservedBytes: 0,
    });
    assert.notEqual(wide.status, "degraded", JSON.stringify(wide.diagnostics));
    const wideBytes = Buffer.byteLength(wide.markdown, "utf8");
    const reservedBytes = hardBytes - wideBytes;
    assert.ok(wideBytes > 0 && reservedBytes > 0);

    const exact = await runtime.harness.planContext({
      lifecycle: "prompt",
      cwd: runtime.cwd,
      prompt,
      host: "codex",
      sessionId: "session_exact_utf8_final",
      reservedBytes,
    });

    assert.notEqual(exact.status, "degraded", JSON.stringify(exact.diagnostics));
    assert.equal(exact.receipt.budget.hardBytes, hardBytes);
    assert.equal(exact.receipt.budget.reservedBytes, reservedBytes);
    assert.equal(exact.receipt.budget.renderedBytes + reservedBytes, hardBytes);
    assert.equal(Buffer.byteLength(exact.markdown, "utf8") + reservedBytes, hardBytes);
    assert.match(exact.markdown, /#### `self-model\/i-am-rowan\.md`/);
    assert.match(exact.markdown, /UTF-8 RULE: café 東京 — retain this evidence\./);
    assert.equal((exact.markdown.match(/^### Retrieval limits$/gim) ?? []).length, 1);
    assert.match(exact.markdown, /Some sources or retrieval providers could not supply evidence/);
    assert.match(exact.markdown, /Additional candidate evidence was omitted or shortened to fit the context limit/);
    assert.match(exact.markdown, /Some diagnostic details were not returned; their categories are unavailable here/);
    assert.match(exact.markdown, /Some omission details were not returned; their reasons are unavailable here/);
    assert.match(exact.markdown, /Evidence roles describe retrieval function, not whether this context is sufficient to answer\./);
    assert.equal(exact.receipt.selectedEvidence.length, 4);
    assert.equal(exact.receipt.selectedEvidence.at(-1)?.id, "text:patterns/support.md#utf8");
  } finally {
    await rm(runtime.temp, { recursive: true, force: true });
  }
});
