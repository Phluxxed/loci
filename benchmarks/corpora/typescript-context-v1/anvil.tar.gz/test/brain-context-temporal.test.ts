import assert from "node:assert/strict";
import { cp, mkdir, mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import { spawnSync } from "node:child_process";
import { join } from "node:path";
import { tmpdir } from "node:os";
import { test } from "node:test";
import { fileURLToPath } from "node:url";

import { BrainContextError } from "../src/brain-context/manifest.ts";
import { createContextHarness } from "../src/brain-context/harness.ts";
import { parseCompilerOutput, retrieveBrainContext } from "../src/brain-context/retrieve.ts";
import { parseTemporalQuery, type TemporalQuery, type TemporalQueryInput } from "../src/brain-context/temporal.ts";

const fixtureRoot = fileURLToPath(new URL("./fixtures/brain-context/", import.meta.url));
const countingCompiler = fileURLToPath(new URL("./counting-llm-wiki.mjs", import.meta.url));

type Invocation = { command: string; args: string[] };

async function makeCompilerFixture(): Promise<{
  root: string;
  invocationLog: string;
  cleanup: () => Promise<void>;
}> {
  const root = await mkdtemp(join(tmpdir(), "anvil-temporal-transport-"));
  const invocationLog = join(root, "invocations.jsonl");
  await writeFile(
    join(root, "fake-llm-wiki.json"),
    JSON.stringify({
      mode: "success",
      output: "compiled-context.json",
      expected_question: "Temporal transport question",
      expected_seeds: [],
    }) + "\n",
    "utf8",
  );
  await writeFile(
    join(root, "compiled-context.json"),
    JSON.stringify({
      kind: "compiled_context",
      contract_version: "3",
      wiki: { alias: "fixture-brain", schema_version: "1", runtime_contract: "3" },
      query: { project_resolution: { status: "unknown" } },
      evidence: [],
    }) + "\n",
    "utf8",
  );
  return {
    root,
    invocationLog,
    cleanup: () => rm(root, { recursive: true, force: true }),
  };
}

function runGit(cwd: string, args: string[]): void {
  const result = spawnSync("git", args, { cwd, encoding: "utf8" });
  assert.equal(result.status, 0, result.stderr);
}

async function invocations(path: string): Promise<Invocation[]> {
  const content = await readFile(path, "utf8").catch(() => "");
  return content.trim().length === 0
    ? []
    : content.trim().split("\n").map((line) => JSON.parse(line) as Invocation);
}

function retrieveInput(root: string, invocationLog: string, temporal: TemporalQueryInput | TemporalQuery | undefined) {
  return {
    brainRoot: root,
    wikiAlias: "fixture-brain",
    seeds: [],
    question: "Temporal transport question",
    targetBytes: 256,
    hardBytes: 1_024,
    env: {
      ANVIL_LLM_WIKI_BIN: countingCompiler,
      ANVIL_TEST_COMPILER_INVOCATIONS: invocationLog,
    },
    timeoutMs: 2_000,
    temporal,
  } as const;
}

function assertBrainRetrievalInvalid(error: unknown): boolean {
  assert.ok(error instanceof BrainContextError);
  assert.equal(error.code, "BRAIN_RETRIEVAL_INVALID");
  return true;
}

test("temporal transport emits exact flags for every supported view and preserves normalized echo", async () => {
  const fixture = await makeCompilerFixture();
  try {
    const cases = [
      {
        input: { view: "current", request_time: "2026-01-01T01:00:00+01:00" },
        expected: [
          "--temporal-view", "current",
          "--request-time", "2026-01-01T00:00:00Z",
          "--world-at", "2026-01-01T00:00:00Z",
          "--known-at", "2026-01-01T00:00:00Z",
        ],
      },
      {
        input: {
          view: "historical",
          request_time: "2026-02-01T00:00:00Z",
          world_at: "2025-06-01",
        },
        expected: [
          "--temporal-view", "historical",
          "--request-time", "2026-02-01T00:00:00Z",
          "--world-at", "2025-06-01",
          "--known-at", "2026-02-01T00:00:00Z",
        ],
      },
      {
        input: {
          view: "transition",
          request_time: "2026-03-01T00:00:00Z",
          transition: { from: "2025-01-01", to: "2025-02-01" },
        },
        expected: [
          "--temporal-view", "transition",
          "--request-time", "2026-03-01T00:00:00Z",
          "--known-at", "2026-03-01T00:00:00Z",
          "--transition-from", "2025-01-01",
          "--transition-to", "2025-02-01",
        ],
      },
      {
        input: { view: "lineage", request_time: "2026-04-01T00:00:00Z" },
        expected: [
          "--temporal-view", "lineage",
          "--request-time", "2026-04-01T00:00:00Z",
          "--known-at", "2026-04-01T00:00:00Z",
        ],
      },
      {
        input: { view: "conflict", request_time: "2026-05-01T00:00:00Z" },
        expected: [
          "--temporal-view", "conflict",
          "--request-time", "2026-05-01T00:00:00Z",
          "--known-at", "2026-05-01T00:00:00Z",
        ],
      },
    ] as const;

    for (const item of cases) {
      const result = await retrieveBrainContext(retrieveInput(fixture.root, fixture.invocationLog, item.input));
      const invocation = (await invocations(fixture.invocationLog)).at(-1)!;
      const temporalFlags = new Set([
        "--temporal-view",
        "--request-time",
        "--world-at",
        "--known-at",
        "--transition-from",
        "--transition-to",
      ]);
      const actualTemporalArgs: string[] = [];
      for (let index = 0; index < invocation.args.length; index += 1) {
        if (temporalFlags.has(invocation.args[index]!)) {
          actualTemporalArgs.push(invocation.args[index]!, invocation.args[index + 1]!);
        }
      }
      assert.deepEqual(actualTemporalArgs, item.expected);
      assert.deepEqual(result.query.temporal, parseTemporalQuery(item.input));
      assert.equal(result.contractVersion, "3");
    }
  } finally {
    await fixture.cleanup();
  }
});

test("temporal validation rejects unsupported combinations before invoking the compiler", async () => {
  const invalid = [
    { view: "historical", request_time: "2026-01-01T00:00:00Z" },
    {
      view: "transition",
      request_time: "2026-01-01T00:00:00Z",
      world_at: "2025-01-01",
      transition: { from: "2025-01-01", to: "2025-02-01" },
    },
    {
      view: "lineage",
      request_time: "2026-01-01T00:00:00Z",
      transition: { from: "2025-01-01", to: "2025-02-01" },
    },
    {
      view: "transition",
      request_time: "2026-01-01T00:00:00Z",
      transition: { from: "2025-02-01", to: "2025-01-01" },
    },
  ];
  for (const value of invalid) {
    assert.throws(() => parseTemporalQuery(value), assertBrainRetrievalInvalid);
  }
});

test("temporal instants align with the reader's whole-second precision", () => {
  const zeroFraction = parseTemporalQuery({
    view: "historical",
    request_time: "2026-01-01T00:00:00.000000Z",
    world_at: "2025-06-01T00:00:00.000000+00:00",
    known_at: "2026-01-01T00:00:00.000000Z",
  });
  assert.deepEqual(zeroFraction, {
    view: "historical",
    request_time: "2026-01-01T00:00:00Z",
    world_at: "2025-06-01T00:00:00Z",
    known_at: "2026-01-01T00:00:00Z",
  });
  assert.deepEqual(parseTemporalQuery({
    view: "transition",
    request_time: "2026-01-01T00:00:00Z",
    transition: { from: "2025-01-01", to: "2025-02-01" },
  }).transition, { from: "2025-01-01", to: "2025-02-01" });

  for (const value of [
    { view: "current", request_time: "2026-01-01T00:00:00.000001Z" },
    { view: "current", request_time: "2026-01-01T00:00:00Z", known_at: "2026-01-01T00:00:00.000001Z" },
    { view: "historical", request_time: "2026-01-01T00:00:00Z", world_at: "2025-06-01T00:00:00.000001Z" },
    {
      view: "transition",
      request_time: "2026-01-01T00:00:00Z",
      transition: { from: "2025-01-01T00:00:00.000001Z", to: "2025-02-01" },
    },
  ]) {
    assert.throws(() => parseTemporalQuery(value), assertBrainRetrievalInvalid);
  }
});

test("temporal response echo rejects missing, malformed, and mismatched values", async () => {
  const fixture = await makeCompilerFixture();
  const requested = { view: "historical", request_time: "2026-02-01T00:00:00Z", world_at: "2025-06-01" };
  try {
    const cases = [
      { query: { question: "Temporal transport question", shapes: ["lookup"], state_view: "current", resolved_seeds: [], project_resolution: { status: "unknown" } } },
      { query: { question: "Temporal transport question", shapes: ["lookup"], state_view: "current", resolved_seeds: [], project_resolution: { status: "unknown" }, temporal: { view: "historical", request_time: "not-an-instant", world_at: "2025-06-01" } } },
      { query: { question: "Temporal transport question", shapes: ["lookup"], state_view: "current", resolved_seeds: [], project_resolution: { status: "unknown" }, temporal: { view: "current", request_time: "2026-02-01T00:00:00Z" } } },
    ];
    for (const item of cases) {
      await writeFile(join(fixture.root, "compiled-context.json"), JSON.stringify({
        kind: "compiled_context",
        contract_version: "3",
        wiki: { alias: "fixture-brain", schema_version: "1", runtime_contract: "3" },
        query: item.query,
        evidence: [],
      }) + "\n", "utf8");
      await writeFile(join(fixture.root, "fake-llm-wiki.json"), JSON.stringify({
        mode: "success",
        output: "compiled-context.json",
        expected_question: "Temporal transport question",
        expected_seeds: [],
        preserve_query_identity: true,
      }) + "\n", "utf8");
      await assert.rejects(
        () => retrieveBrainContext(retrieveInput(fixture.root, fixture.invocationLog, requested)),
        assertBrainRetrievalInvalid,
      );
    }
  } finally {
    await fixture.cleanup();
  }
});

test("non-temporal direct retrieval remains contract 1 compatible", async () => {
  const fixture = await makeCompilerFixture();
  try {
    await writeFile(join(fixture.root, "compiled-context.json"), JSON.stringify({
      kind: "compiled_context",
      contract_version: "1",
      wiki: { alias: "fixture-brain", schema_version: "1", runtime_contract: "2" },
      query: {},
      evidence: [],
    }) + "\n", "utf8");
    await writeFile(join(fixture.root, "fake-llm-wiki.json"), JSON.stringify({
      mode: "success",
      output: "compiled-context.json",
      expected_question: "Temporal transport question",
      expected_seeds: [],
    }) + "\n", "utf8");
    const result = await retrieveBrainContext({
      ...retrieveInput(fixture.root, fixture.invocationLog, undefined),
      temporal: undefined,
    });
    assert.equal(result.contractVersion, "1");
    assert.equal(result.query.temporal, undefined);
    const invocation = (await invocations(fixture.invocationLog)).at(-1)!;
    assert.equal(invocation.args.includes("--temporal-view"), false);
    assert.equal(invocation.args.at(-1), "1");
  } finally {
    await fixture.cleanup();
  }
});

test("malformed temporal query metadata is rejected by the response parser", () => {
  assert.throws(
    () => parseCompilerOutput(JSON.stringify({
      kind: "compiled_context",
      contract_version: "3",
      wiki: { alias: "fixture-brain", schema_version: "1", runtime_contract: "3" },
      query: {
        question: "Temporal transport question",
        shapes: [],
        state_view: "current",
        resolved_seeds: [],
        project_resolution: { status: "unknown" },
        temporal: { view: "current", request_time: "invalid" },
      },
      evidence: [],
      omissions: [],
      coverage: { required_roles: [], covered_roles: [], uncovered_roles: [] },
      budget: {
        limits: { target_bytes: 1, max_bytes: 1, target_items: 1, max_items: 1, max_estimated_tokens: null },
        target_exceeded_for_coverage: false,
        evidence_bytes: 0,
        envelope_bytes: 0,
        items: 0,
        estimated_tokens: 0,
      },
      stop: { reason: "no_evidence", sufficient: false, detail: "No evidence" },
      continuation: null,
      diagnostics: [],
      reporting: { omissions: { total: 0, returned: 0 }, diagnostics: { total: 0, returned: 0 } },
    })),
    assertBrainRetrievalInvalid,
  );
});

test("contract-3 Context Harness defaults ordinary prompt recall to current and carries explicit history/lineage", async () => {
  const temp = await mkdtemp(join(tmpdir(), "anvil-temporal-harness-"));
  const brainRoot = join(temp, "brain");
  const cwd = join(temp, "anvil_redux");
  const anvilHome = join(temp, "anvil-home");
  try {
    await cp(join(fixtureRoot, "valid-known-project"), brainRoot, { recursive: true });
    await mkdir(cwd, { recursive: true });
    await mkdir(join(anvilHome, "agents", "codex"), { recursive: true });
    runGit(cwd, ["init"]);
    const manifestPath = join(brainRoot, "brain-bootstrap.json");
    const manifest = JSON.parse(await readFile(manifestPath, "utf8")) as Record<string, unknown>;
    manifest.version = 2;
    delete manifest.projects;
    const budgets = manifest.budgets as Record<string, unknown>;
    budgets.prompt_recall_target_bytes = 8_192;
    budgets.prompt_recall_hard_bytes = 16_384;
    await writeFile(manifestPath, JSON.stringify(manifest) + "\n", "utf8");
    const compiled = JSON.parse(await readFile(join(brainRoot, "compiled-context.json"), "utf8")) as Record<string, unknown>;
    compiled.contract_version = "3";
    compiled.wiki = { alias: "fixture-brain", schema_version: "1", runtime_contract: "3" };
    compiled.query = { project_resolution: { status: "unknown" } };
    await writeFile(join(brainRoot, "compiled-context.json"), JSON.stringify(compiled) + "\n", "utf8");
    await writeFile(
      join(brainRoot, "fake-llm-wiki.json"),
      JSON.stringify({
        mode: "success",
        output: "compiled-context.json",
        expected_question: "What should I recall?",
        expected_seeds: [],
      }) + "\n",
      "utf8",
    );
    await writeFile(
      join(anvilHome, "agents", "codex", "config.json"),
      JSON.stringify({
        schema_version: 1,
        agent_id: "codex",
        brain_root: brainRoot,
        wiki_alias: "fixture-brain",
      }) + "\n",
      "utf8",
    );
    const harness = createContextHarness({
      anvilHome,
      homeDir: temp,
      stateRoot: join(temp, "state"),
      env: { ANVIL_AGENT_ID: "codex", ANVIL_LLM_WIKI_BIN: fileURLToPath(new URL("./fixtures/brain-context/fake-llm-wiki.mjs", import.meta.url)) },
      retrievalTimeoutMs: 2_000,
    });
    const before = Date.now();
    const ordinary = await harness.planContext({
      lifecycle: "prompt",
      cwd,
      prompt: "What should I recall?",
      host: "codex",
      sessionId: "temporal_harness_ordinary",
      reservedBytes: 0,
    });
    const after = Date.now();
    assert.ok(ordinary.receipt.temporal);
    assert.equal(ordinary.receipt.temporal?.view, "current");
    assert.equal(ordinary.receipt.temporal?.world_at, ordinary.receipt.temporal?.request_time);
    assert.equal(ordinary.receipt.temporal?.known_at, ordinary.receipt.temporal?.request_time);
    assert.match(ordinary.receipt.temporal!.request_time, /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$/);
    assert.ok(Date.parse(ordinary.receipt.temporal!.request_time) >= before - 1_000);
    assert.ok(Date.parse(ordinary.receipt.temporal!.request_time) <= after + 1_000);

    const historical = await harness.planContext({
      lifecycle: "prompt",
      cwd,
      prompt: "What should I recall?",
      temporal: { view: "historical", request_time: "2026-02-01T00:00:00Z", world_at: "2025-06-01" },
      host: "codex",
      sessionId: "temporal_harness_historical",
      reservedBytes: 0,
    });
    assert.deepEqual(historical.receipt.temporal, {
      view: "historical",
      request_time: "2026-02-01T00:00:00Z",
      world_at: "2025-06-01",
      known_at: "2026-02-01T00:00:00Z",
    });

    const lineage = await harness.planContext({
      lifecycle: "prompt",
      cwd,
      prompt: "What should I recall?",
      temporal: { view: "lineage", request_time: "2026-03-01T00:00:00Z" },
      host: "codex",
      sessionId: "temporal_harness_lineage",
      reservedBytes: 0,
    });
    assert.deepEqual(lineage.receipt.temporal, {
      view: "lineage",
      request_time: "2026-03-01T00:00:00Z",
      known_at: "2026-03-01T00:00:00Z",
    });
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});
