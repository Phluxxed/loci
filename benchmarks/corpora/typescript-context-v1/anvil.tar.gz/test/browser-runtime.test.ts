import assert from "node:assert/strict";
import { test } from "node:test";

import {
  BrowserConfigurationError,
  buildBrowserPolicy,
  readRendererStatus,
  reconcileRenderer,
  removeRenderer,
  waitForRendererHealth,
} from "../src/browser/index.ts";
import type {
  BrowserCommandOptions,
  BrowserCommandResult,
  BrowserCommandRunner,
  BrowserLaunchPolicy,
} from "../src/browser/index.ts";

type RecordedCommand = { command: string; args: string[]; options?: BrowserCommandOptions };

const desiredImageId = `sha256:${"a".repeat(64)}`;
const previousImageId = `sha256:${"b".repeat(64)}`;

function inspectOutput(
  policy: BrowserLaunchPolicy,
  token: string,
  overrides: {
    imageRef?: string;
    imageId?: string;
    owner?: string;
    running?: boolean;
    hostPort?: number;
  } = {},
): string {
  return JSON.stringify([
    {
      Image: overrides.imageId ?? desiredImageId,
      State: { Running: overrides.running ?? true },
      Config: {
        Image: overrides.imageRef ?? policy.container.image_ref,
        Env: [`TOKEN=${token}`, `CONCURRENT=${policy.container.concurrent}`, `TIMEOUT=${policy.container.timeout_ms}`],
        Labels: {
          ...policy.container.labels,
          "io.anvil.browser.owner": overrides.owner ?? "anvil",
        },
      },
      HostConfig: {
        PortBindings: {
          "3000/tcp": [
            {
              HostIp: policy.container.bind_host,
              HostPort: String(overrides.hostPort ?? policy.container.host_port),
            },
          ],
        },
        RestartPolicy: { Name: policy.container.restart_policy },
        ShmSize: 2 * 1024 * 1024 * 1024,
      },
    },
  ]);
}

function fakeRunner(
  handler: (command: string, args: string[], options?: BrowserCommandOptions) => BrowserCommandResult,
  resolvedImageId = desiredImageId,
): { run: BrowserCommandRunner; commands: RecordedCommand[] } {
  const commands: RecordedCommand[] = [];
  return {
    commands,
    run: async (command, args, options) => {
      commands.push({ command, args, options });
      if (command === "docker" && args[0] === "image" && args[1] === "inspect") {
        return { status: 0, stdout: `${resolvedImageId}\n`, stderr: "" };
      }
      return handler(command, args, options);
    },
  };
}

test("readRendererStatus is read-only and reports a missing renderer", async () => {
  const policy = buildBrowserPolicy({ mode: "local", hostPort: 48123 });
  const fake = fakeRunner((_command, args) => {
    if (args[0] === "version") return { status: 0, stdout: "27.1.1", stderr: "" };
    if (args[0] === "inspect") return { status: 1, stdout: "", stderr: "No such object" };
    throw new Error(`Unexpected Docker command: ${args.join(" ")}`);
  });

  const status = await readRendererStatus({ policy, token: "local-secret", run: fake.run });

  assert.equal(status.state, "unconfigured");
  assert.equal(status.renderer_status, "missing");
  assert.deepEqual(
    fake.commands.map((command) => command.args[0]),
    ["version", "inspect"],
  );
});

test("reconcileRenderer replaces an owned container when its image tag resolves to a new image ID", async () => {
  const policy = buildBrowserPolicy({ mode: "local", hostPort: 48123 });
  const token = "local-secret";
  const fake = fakeRunner((_command, args) => {
    if (args[0] === "version") return { status: 0, stdout: "27.1.1", stderr: "" };
    if (args[0] === "inspect") {
      return { status: 0, stdout: inspectOutput(policy, token, { imageId: previousImageId }), stderr: "" };
    }
    if (args[0] === "rm" || args[0] === "run") return { status: 0, stdout: "ok", stderr: "" };
    throw new Error(`Unexpected Docker command: ${args.join(" ")}`);
  });

  const status = await reconcileRenderer({ policy, token, run: fake.run, waitUntilHealthy: async () => true });

  assert.equal(status.state, "ready");
  assert.deepEqual(
    fake.commands.map((command) => command.args[0]),
    ["version", "inspect", "image", "rm", "run"],
  );
});

test("reconcileRenderer creates a missing renderer without putting its token in command arguments", async () => {
  const policy = buildBrowserPolicy({ mode: "local", hostPort: 48123 });
  const fake = fakeRunner((_command, args, options) => {
    if (args[0] === "version") return { status: 0, stdout: "27.1.1", stderr: "" };
    if (args[0] === "inspect") return { status: 1, stdout: "", stderr: "No such object" };
    if (args[0] === "run") {
      assert.equal(args.includes("local-secret"), false);
      assert.equal(options?.env?.TOKEN, "local-secret");
      return { status: 0, stdout: "container-id", stderr: "" };
    }
    throw new Error(`Unexpected Docker command: ${args.join(" ")}`);
  });

  const status = await reconcileRenderer({
    policy,
    token: "local-secret",
    run: fake.run,
    waitUntilHealthy: async () => true,
  });

  assert.equal(status.state, "ready");
  assert.equal(status.renderer_status, "healthy");
  const runCommand = fake.commands.find((command) => command.args[0] === "run");
  assert.ok(runCommand);
  assert.equal(runCommand.args.includes("127.0.0.1:48123:3000"), true);
  assert.equal(runCommand.args.includes("--restart"), true);
  assert.equal(runCommand.args.includes("--shm-size"), true);
});

test("reconcileRenderer is a no-op when the owned running renderer matches", async () => {
  const policy = buildBrowserPolicy({ mode: "local", hostPort: 48123 });
  const token = "local-secret";
  const fake = fakeRunner((_command, args) => {
    if (args[0] === "version") return { status: 0, stdout: "27.1.1", stderr: "" };
    if (args[0] === "inspect") return { status: 0, stdout: inspectOutput(policy, token), stderr: "" };
    throw new Error(`Unexpected Docker command: ${args.join(" ")}`);
  });

  const status = await reconcileRenderer({ policy, token, run: fake.run, waitUntilHealthy: async () => true });

  assert.equal(status.state, "ready");
  assert.deepEqual(
    fake.commands.map((command) => command.args[0]),
    ["version", "inspect", "image"],
  );
});

test("reconcileRenderer replaces only an owned stale renderer", async () => {
  const policy = buildBrowserPolicy({ mode: "local", hostPort: 48123 });
  const token = "local-secret";
  const fake = fakeRunner((_command, args) => {
    if (args[0] === "version") return { status: 0, stdout: "27.1.1", stderr: "" };
    if (args[0] === "inspect") {
      return { status: 0, stdout: inspectOutput(policy, token, { hostPort: 49999 }), stderr: "" };
    }
    if (args[0] === "rm" || args[0] === "run") return { status: 0, stdout: "ok", stderr: "" };
    throw new Error(`Unexpected Docker command: ${args.join(" ")}`);
  });

  const status = await reconcileRenderer({ policy, token, run: fake.run, waitUntilHealthy: async () => true });

  assert.equal(status.state, "ready");
  assert.deepEqual(
    fake.commands.map((command) => command.args[0]),
    ["version", "inspect", "image", "rm", "run"],
  );
});

test("reconcileRenderer refuses to remove a container Anvil does not own", async () => {
  const policy = buildBrowserPolicy({ mode: "local", hostPort: 48123 });
  const token = "local-secret";
  const fake = fakeRunner((_command, args) => {
    if (args[0] === "version") return { status: 0, stdout: "27.1.1", stderr: "" };
    if (args[0] === "inspect") {
      return { status: 0, stdout: inspectOutput(policy, token, { owner: "someone-else" }), stderr: "" };
    }
    throw new Error(`Unexpected Docker command: ${args.join(" ")}`);
  });

  await assert.rejects(
    reconcileRenderer({ policy, token, run: fake.run, waitUntilHealthy: async () => true }),
    (error: unknown) => error instanceof BrowserConfigurationError && error.code === "RENDERER_UNOWNED",
  );
  assert.equal(fake.commands.some((command) => command.args[0] === "rm"), false);
});

test("renderer status reports Docker and health failures without pretending they are healthy", async () => {
  const policy = buildBrowserPolicy({ mode: "local", hostPort: 48123 });
  const unavailable = fakeRunner(() => ({ status: 1, stdout: "", stderr: "daemon unavailable" }));
  const unavailableStatus = await readRendererStatus({ policy, token: "secret", run: unavailable.run });
  assert.equal(unavailableStatus.state, "degraded");
  assert.equal(unavailableStatus.renderer_status, "unknown");
  assert.equal(unavailableStatus.diagnostics[0]?.code, "DOCKER_UNAVAILABLE");

  const unhealthy = fakeRunner((_command, args) => {
    if (args[0] === "version") return { status: 0, stdout: "27.1.1", stderr: "" };
    return { status: 0, stdout: inspectOutput(policy, "secret"), stderr: "" };
  });
  const unhealthyStatus = await readRendererStatus({
    policy,
    token: "secret",
    run: unhealthy.run,
    checkHealth: async () => false,
  });
  assert.equal(unhealthyStatus.state, "degraded");
  assert.equal(unhealthyStatus.renderer_status, "unhealthy");
  assert.equal(unhealthyStatus.diagnostics[0]?.code, "RENDERER_UNHEALTHY");

  const stale = fakeRunner((_command, args) => {
    if (args[0] === "version") return { status: 0, stdout: "27.1.1", stderr: "" };
    return { status: 0, stdout: inspectOutput(policy, "secret", { hostPort: 49999 }), stderr: "" };
  });
  const staleStatus = await readRendererStatus({ policy, token: "secret", run: stale.run });
  assert.equal(staleStatus.state, "stale");
  assert.equal(staleStatus.renderer_status, "unknown");
});

test("removeRenderer removes only an Anvil-owned container", async () => {
  const policy = buildBrowserPolicy({ mode: "local", hostPort: 48123 });
  const token = "local-secret";
  const owned = fakeRunner((_command, args) => {
    if (args[0] === "version") return { status: 0, stdout: "27.1.1", stderr: "" };
    if (args[0] === "inspect") return { status: 0, stdout: inspectOutput(policy, token), stderr: "" };
    if (args[0] === "rm") return { status: 0, stdout: "", stderr: "" };
    throw new Error(`Unexpected Docker command: ${args.join(" ")}`);
  });
  assert.equal(await removeRenderer({ policy, token, run: owned.run }), true);
  assert.equal(owned.commands.some((command) => command.args[0] === "rm"), true);

  const unowned = fakeRunner((_command, args) => {
    if (args[0] === "version") return { status: 0, stdout: "27.1.1", stderr: "" };
    return { status: 0, stdout: inspectOutput(policy, token, { owner: "someone-else" }), stderr: "" };
  });
  await assert.rejects(
    removeRenderer({ policy, token, run: unowned.run }),
    (error: unknown) => error instanceof BrowserConfigurationError && error.code === "RENDERER_UNOWNED",
  );
});

test("waitForRendererHealth polls through Browserless startup delay with a bounded attempt count", async () => {
  const policy = buildBrowserPolicy({ mode: "local", hostPort: 48123 });
  let checks = 0;
  let sleeps = 0;
  const healthy = await waitForRendererHealth(policy, "secret", {
    attempts: 5,
    intervalMs: 1,
    checkHealth: async () => {
      checks += 1;
      return checks === 3;
    },
    sleep: async () => {
      sleeps += 1;
    },
  });

  assert.equal(healthy, true);
  assert.equal(checks, 3);
  assert.equal(sleeps, 2);
});
