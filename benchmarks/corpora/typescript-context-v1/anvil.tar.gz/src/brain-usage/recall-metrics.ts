import { BRAIN_CONTEXT_DIAGNOSTIC_CODES } from "../brain-context/manifest.ts";
import type { BrainUsageRecallEvent, BrainUsageRecord } from "./index.ts";

const HOUR_MS = 60 * 60 * 1_000;
const DAY_MS = 24 * HOUR_MS;
const HOURLY_BUCKETS = 48;
const DAILY_BUCKETS = 30;
const ACTIVE_RECALL_EVENTS = ["recalled", "no_match", "degraded"] as const;

export type BrainUsageRate = {
  numerator: number;
  denominator: number;
  rate: number | null;
};

export type BrainUsageDistribution = {
  count: number;
  min?: number;
  p05?: number;
  p50?: number;
  p90?: number;
  p95?: number;
  p99?: number;
  max?: number;
};

export type BrainRecallDiagnosticMetrics = {
  events_with_diagnostics: number;
  by_code: Record<string, number>;
  rates_by_code: Record<string, BrainUsageRate>;
};

export type BrainRecallTimeBucket = {
  bucket_start: string;
  total: number;
  eligible_total: number;
  by_event: Record<BrainUsageRecallEvent, number>;
  success: BrainUsageRate;
  degradation: BrainUsageRate;
  diagnostics: Record<string, number>;
};

export type BrainRecallWorkspaceMetrics = {
  workspace: BrainUsageRecord["workspace"];
  total: number;
  eligible_total: number;
  by_event: Record<BrainUsageRecallEvent, number>;
  success: BrainUsageRate;
  degradation: BrainUsageRate;
  diagnostics: Record<string, number>;
  instrumented_records: number;
  instrumentation_coverage: number | null;
};

export type BrainRecallMetrics = {
  total: number;
  by_event: Record<BrainUsageRecallEvent, number>;
  eligible_total: number;
  success: BrainUsageRate;
  degradation: BrainUsageRate;
  diagnostics: BrainRecallDiagnosticMetrics;
  instrumentation: {
    instrumented_records: number;
    eligible_records: number;
    coverage: number | null;
  };
  by_workspace: BrainRecallWorkspaceMetrics[];
  trends: {
    hourly: BrainRecallTimeBucket[];
    daily: BrainRecallTimeBucket[];
  };
  payload_bytes: {
    attempted: BrainUsageDistribution;
    rendered: BrainUsageDistribution;
    guidance: BrainUsageDistribution;
    retrieved_context: BrainUsageDistribution;
    framing: BrainUsageDistribution;
  };
  limit_bytes: {
    guidance: BrainUsageDistribution;
    payload: BrainUsageDistribution;
  };
  headroom_bytes: {
    guidance: BrainUsageDistribution;
    payload: BrainUsageDistribution;
  };
  pages: {
    guidance: BrainUsageDistribution;
    compiler_evidence: BrainUsageDistribution;
    candidate: BrainUsageDistribution;
    supporting: BrainUsageDistribution;
    selected: BrainUsageDistribution;
    filtered: BrainUsageDistribution;
  };
  timing_ms: {
    total: BrainUsageDistribution;
    retrieval: BrainUsageDistribution;
  };
  by_phase: Record<"disabled" | "guidance_preflight" | "retrieval" | "render", number>;
  by_selection_outcome: Record<"not_run" | "unchanged" | "filtered", number>;
  by_render_outcome: Record<"disabled" | "guidance_rejected" | "within_limit" | "truncated" | "diagnostic", number>;
  overflow_stage: Record<"none" | "guidance" | "payload" | "unknown", number>;
};

function zeroRecallCounts(): Record<BrainUsageRecallEvent, number> {
  return { recalled: 0, no_match: 0, degraded: 0, disabled: 0 };
}

function rate(numerator: number, denominator: number): BrainUsageRate {
  return { numerator, denominator, rate: denominator === 0 ? null : numerator / denominator };
}

function isRecallRecord(record: BrainUsageRecord): boolean {
  return record.event === "recalled"
    || record.event === "no_match"
    || record.event === "degraded"
    || record.event === "disabled";
}

function isEligible(record: BrainUsageRecord): boolean {
  return (ACTIVE_RECALL_EVENTS as readonly string[]).includes(record.event);
}

function sortedRecord(counts: Map<string, number>): Record<string, number> {
  return Object.fromEntries(Array.from(counts.entries()).sort(([left], [right]) => left.localeCompare(right)));
}

function increment(counts: Map<string, number>, key: string): void {
  counts.set(key, (counts.get(key) ?? 0) + 1);
}

function diagnosticsForRecord(record: BrainUsageRecord): string[] {
  if (record.recall_observation !== undefined) return [...new Set(record.recall_observation.diagnostics)];
  const match = /(?:^|;\s*)diagnostic=([^;]+)/.exec(record.outcome ?? "");
  if (match?.[1] === undefined) return [];
  const known = new Set<string>(BRAIN_CONTEXT_DIAGNOSTIC_CODES);
  return [...new Set(match[1].split(",").map((code) => code.trim()).filter((code) => known.has(code)))];
}

function nearestRank(sorted: number[], percentile: number): number {
  return sorted[Math.max(0, Math.ceil(percentile * sorted.length) - 1)]!;
}

function distribution(values: number[], percentiles: Array<[keyof BrainUsageDistribution, number]>): BrainUsageDistribution {
  if (values.length === 0) return { count: 0 };
  const sorted = [...values].sort((left, right) => left - right);
  return {
    count: sorted.length,
    min: sorted[0],
    ...Object.fromEntries(percentiles.map(([key, percentile]) => [key, nearestRank(sorted, percentile)])),
    max: sorted.at(-1),
  };
}

function payloadDistribution(values: number[]): BrainUsageDistribution {
  return distribution(values, [["p50", 0.5], ["p90", 0.9], ["p95", 0.95], ["p99", 0.99]]);
}

function headroomDistribution(values: number[]): BrainUsageDistribution {
  return distribution(values, [["p05", 0.05], ["p50", 0.5], ["p95", 0.95]]);
}

function recallSummary(records: BrainUsageRecord[]): {
  total: number;
  eligibleTotal: number;
  byEvent: Record<BrainUsageRecallEvent, number>;
  success: BrainUsageRate;
  degradation: BrainUsageRate;
  diagnostics: Record<string, number>;
} {
  const byEvent = zeroRecallCounts();
  const diagnostics = new Map<string, number>();
  for (const record of records) {
    byEvent[record.event as BrainUsageRecallEvent] += 1;
    for (const code of diagnosticsForRecord(record)) increment(diagnostics, code);
  }
  const eligibleTotal = byEvent.recalled + byEvent.no_match + byEvent.degraded;
  return {
    total: records.length,
    eligibleTotal,
    byEvent,
    success: rate(byEvent.recalled + byEvent.no_match, eligibleTotal),
    degradation: rate(byEvent.degraded, eligibleTotal),
    diagnostics: sortedRecord(diagnostics),
  };
}

function workspaceMetrics(records: BrainUsageRecord[]): BrainRecallWorkspaceMetrics[] {
  const groups = new Map<string, BrainUsageRecord[]>();
  for (const record of records) {
    const group = groups.get(record.workspace.key) ?? [];
    group.push(record);
    groups.set(record.workspace.key, group);
  }
  return Array.from(groups.values())
    .map((group) => {
      const summary = recallSummary(group);
      const instrumentedRecords = group.filter((record) => isEligible(record) && record.recall_observation !== undefined).length;
      return {
        workspace: group[0]!.workspace,
        total: summary.total,
        eligible_total: summary.eligibleTotal,
        by_event: summary.byEvent,
        success: summary.success,
        degradation: summary.degradation,
        diagnostics: summary.diagnostics,
        instrumented_records: instrumentedRecords,
        instrumentation_coverage: summary.eligibleTotal === 0 ? null : instrumentedRecords / summary.eligibleTotal,
      };
    })
    .sort((left, right) =>
      (left.workspace.label ?? left.workspace.key).localeCompare(right.workspace.label ?? right.workspace.key)
      || left.workspace.key.localeCompare(right.workspace.key),
    );
}

function floorUtc(timestamp: number, widthMs: number): number {
  return Math.floor(timestamp / widthMs) * widthMs;
}

function timeBuckets(
  records: BrainUsageRecord[],
  anchor: number,
  widthMs: number,
  count: number,
): BrainRecallTimeBucket[] {
  const lastStart = floorUtc(anchor, widthMs);
  const firstStart = lastStart - (count - 1) * widthMs;
  const buckets = Array.from({ length: count }, (_, index) => ({
    start: firstStart + index * widthMs,
    records: [] as BrainUsageRecord[],
  }));
  for (const record of records) {
    const timestamp = Date.parse(record.created_at);
    const index = Math.floor((timestamp - firstStart) / widthMs);
    if (index >= 0 && index < buckets.length) buckets[index]!.records.push(record);
  }
  return buckets.map((bucket) => {
    const summary = recallSummary(bucket.records);
    return {
      bucket_start: new Date(bucket.start).toISOString(),
      total: summary.total,
      eligible_total: summary.eligibleTotal,
      by_event: summary.byEvent,
      success: summary.success,
      degradation: summary.degradation,
      diagnostics: summary.diagnostics,
    };
  });
}

function values(
  records: BrainUsageRecord[],
  read: (observation: NonNullable<BrainUsageRecord["recall_observation"]>) => number | undefined,
): number[] {
  return records.flatMap((record) => {
    if (record.recall_observation === undefined) return [];
    const value = read(record.recall_observation);
    return value === undefined ? [] : [value];
  });
}

export function summarizeRecallMetrics(allRecords: BrainUsageRecord[]): BrainRecallMetrics {
  const records = allRecords.filter(isRecallRecord);
  const eligibleRecords = records.filter(isEligible);
  const summary = recallSummary(records);
  const diagnosticsByCode = new Map<string, number>();
  let eventsWithDiagnostics = 0;
  for (const record of eligibleRecords) {
    const diagnostics = diagnosticsForRecord(record);
    if (diagnostics.length > 0) eventsWithDiagnostics += 1;
    for (const code of diagnostics) increment(diagnosticsByCode, code);
  }
  const byCode = sortedRecord(diagnosticsByCode);
  const instrumentedRecords = eligibleRecords.filter((record) => record.recall_observation !== undefined);
  const observed = instrumentedRecords;
  const anchor = records.length === 0
    ? 0
    : Math.max(...records.map((record) => Date.parse(record.created_at)));

  const byPhase = { disabled: 0, guidance_preflight: 0, retrieval: 0, render: 0 };
  const bySelectionOutcome = { not_run: 0, unchanged: 0, filtered: 0 };
  const byRenderOutcome = { disabled: 0, guidance_rejected: 0, within_limit: 0, truncated: 0, diagnostic: 0 };
  const overflowStage = { none: 0, guidance: 0, payload: 0, unknown: 0 };
  for (const record of observed) {
    const observation = record.recall_observation!;
    byPhase[observation.phase] += 1;
    bySelectionOutcome[observation.selection_outcome] += 1;
    byRenderOutcome[observation.render_outcome] += 1;
    if (observation.render_outcome === "guidance_rejected") overflowStage.guidance += 1;
    else if (observation.render_outcome === "truncated") overflowStage.payload += 1;
    else if (observation.render_outcome === "within_limit") overflowStage.none += 1;
    else overflowStage.unknown += 1;
  }

  return {
    total: summary.total,
    by_event: summary.byEvent,
    eligible_total: summary.eligibleTotal,
    success: summary.success,
    degradation: summary.degradation,
    diagnostics: {
      events_with_diagnostics: eventsWithDiagnostics,
      by_code: byCode,
      rates_by_code: Object.fromEntries(
        Object.entries(byCode).map(([code, count]) => [code, rate(count, summary.eligibleTotal)]),
      ),
    },
    instrumentation: {
      instrumented_records: instrumentedRecords.length,
      eligible_records: summary.eligibleTotal,
      coverage: summary.eligibleTotal === 0 ? null : instrumentedRecords.length / summary.eligibleTotal,
    },
    by_workspace: workspaceMetrics(records),
    trends: {
      hourly: records.length === 0 ? [] : timeBuckets(records, anchor, HOUR_MS, HOURLY_BUCKETS),
      daily: records.length === 0 ? [] : timeBuckets(records, anchor, DAY_MS, DAILY_BUCKETS),
    },
    payload_bytes: {
      attempted: payloadDistribution(values(observed, (observation) => observation.bytes.attempted)),
      rendered: payloadDistribution(values(observed, (observation) => observation.bytes.rendered)),
      guidance: payloadDistribution(values(observed, (observation) => observation.bytes.guidance)),
      retrieved_context: payloadDistribution(values(observed, (observation) => observation.bytes.retrieved_context)),
      framing: payloadDistribution(values(observed, (observation) => observation.bytes.framing)),
    },
    limit_bytes: {
      guidance: payloadDistribution(values(observed, (observation) => observation.bytes.guidance_limit)),
      payload: payloadDistribution(values(observed, (observation) => observation.bytes.payload_limit)),
    },
    headroom_bytes: {
      guidance: headroomDistribution(values(observed, (observation) => observation.bytes.guidance_headroom)),
      payload: headroomDistribution(values(observed, (observation) => observation.bytes.payload_headroom)),
    },
    pages: {
      guidance: payloadDistribution(values(observed, (observation) => observation.pages.guidance_count)),
      compiler_evidence: payloadDistribution(values(observed, (observation) => observation.pages.compiler_evidence_count)),
      candidate: payloadDistribution(values(observed, (observation) => observation.pages.candidate_count)),
      supporting: payloadDistribution(values(observed, (observation) => observation.pages.supporting_count)),
      selected: payloadDistribution(values(observed, (observation) => observation.pages.selected_count)),
      filtered: payloadDistribution(values(observed, (observation) => observation.pages.filtered_count)),
    },
    timing_ms: {
      total: payloadDistribution(values(observed, (observation) => observation.timing.total_ms)),
      retrieval: payloadDistribution(values(observed, (observation) => observation.timing.retrieval_ms)),
    },
    by_phase: byPhase,
    by_selection_outcome: bySelectionOutcome,
    by_render_outcome: byRenderOutcome,
    overflow_stage: overflowStage,
  };
}
