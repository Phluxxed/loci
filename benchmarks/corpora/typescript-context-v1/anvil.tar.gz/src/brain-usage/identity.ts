import { readFile, readdir } from "node:fs/promises";
import { homedir } from "node:os";
import { join } from "node:path";

import { agentConfigPath, resolveAgentIdentity, resolveAnvilHome, validateAgentId } from "../config/index.ts";

const WIKI_ALIAS_PATTERN = /^[a-z0-9][a-z0-9_-]{0,95}$/;

export type BrainUsageIdentityOptions = {
  anvilHome?: string;
  env?: Record<string, string | undefined>;
  homeDir?: string;
};

export type BrainUsageIdentity = {
  id: string;
  agentId: string;
  wikiAlias: string;
};

export type BrainUsageIdentityErrorCode =
  | "BRAIN_AGENT_ID_MISSING"
  | "BRAIN_AGENT_ID_MISMATCH"
  | "BRAIN_AGENT_ID_INVALID"
  | "BRAIN_CONFIG_MISSING"
  | "BRAIN_CONFIG_INVALID";

export type BrainUsageIdentityOperationErrorCode =
  | BrainUsageIdentityErrorCode
  | "BRAIN_IDENTITY_INVALID"
  | "BRAIN_IDENTITY_HINT_MISMATCH";

export class BrainUsageIdentityError extends Error {
  code: BrainUsageIdentityOperationErrorCode;

  constructor(code: BrainUsageIdentityOperationErrorCode, message: string) {
    super(`${code}: ${message}`);
    this.name = "BrainUsageIdentityError";
    this.code = code;
  }
}

export type BrainUsageIdentityResolution =
  | { kind: "resolved"; identity: BrainUsageIdentity }
  | { kind: "unresolved"; code: BrainUsageIdentityErrorCode; message: string };

export type BrainUsageIdentityRegistryDiagnostic = {
  code: BrainUsageIdentityErrorCode;
  agentId?: string;
  message: string;
};

export type BrainUsageIdentityRegistry = {
  identities: Map<string, BrainUsageIdentity>;
  labels: Map<string, string[]>;
  diagnostics: BrainUsageIdentityRegistryDiagnostic[];
};

type BrainConfigRead =
  | { kind: "resolved"; identity: BrainUsageIdentity }
  | { kind: "unresolved"; code: "BRAIN_CONFIG_MISSING" | "BRAIN_CONFIG_INVALID"; message: string };

function stableBrainId(agentId: string): string {
  return `agent:${validateAgentId(agentId)}`;
}

export function validateBrainUsageIdentity(identity: BrainUsageIdentity): BrainUsageIdentity {
  let agentId: string;
  try {
    agentId = validateAgentId(identity.agentId);
  } catch (error) {
    throw new BrainUsageIdentityError(
      "BRAIN_IDENTITY_INVALID",
      error instanceof Error ? error.message : String(error),
    );
  }
  if (!WIKI_ALIAS_PATTERN.test(identity.wikiAlias)) {
    throw new BrainUsageIdentityError("BRAIN_IDENTITY_INVALID", "brainIdentity.wikiAlias is invalid");
  }
  const id = stableBrainId(agentId);
  if (identity.id !== id) {
    throw new BrainUsageIdentityError("BRAIN_IDENTITY_INVALID", "brainIdentity.id must be the stable agent-scoped Brain id");
  }
  return { id, agentId, wikiAlias: identity.wikiAlias };
}

function parseBrainConfig(value: unknown, expectedAgentId: string): BrainUsageIdentity {
  if (typeof value !== "object" || value === null || Array.isArray(value)) {
    throw new Error("Brain config must be an object");
  }
  const record = value as Record<string, unknown>;
  if (record.schema_version !== 1) throw new Error("Brain config schema_version must be 1");
  if (record.agent_id !== expectedAgentId) throw new Error("Brain config agent_id does not match its config directory");
  if (typeof record.brain_root !== "string" || record.brain_root.trim().length === 0) {
    throw new Error("Brain config brain_root must be a non-empty string");
  }
  if (typeof record.wiki_alias !== "string" || !WIKI_ALIAS_PATTERN.test(record.wiki_alias)) {
    throw new Error("Brain config wiki_alias is invalid");
  }
  return validateBrainUsageIdentity({
    id: stableBrainId(expectedAgentId),
    agentId: expectedAgentId,
    wikiAlias: record.wiki_alias,
  });
}

async function readBrainConfig(path: string, expectedAgentId: string): Promise<BrainConfigRead> {
  let text: string;
  try {
    text = await readFile(path, "utf8");
  } catch (error) {
    if (typeof error === "object" && error !== null && "code" in error && error.code === "ENOENT") {
      return { kind: "unresolved", code: "BRAIN_CONFIG_MISSING", message: "No Brain config exists for this agent runtime." };
    }
    throw error;
  }

  try {
    return { kind: "resolved", identity: parseBrainConfig(JSON.parse(text), expectedAgentId) };
  } catch (error) {
    return {
      kind: "unresolved",
      code: "BRAIN_CONFIG_INVALID",
      message: error instanceof Error ? error.message : String(error),
    };
  }
}

export async function resolveCurrentBrainUsageIdentity(
  options: BrainUsageIdentityOptions = {},
): Promise<BrainUsageIdentityResolution> {
  let identity;
  try {
    identity = resolveAgentIdentity({ env: options.env });
  } catch (error) {
    return {
      kind: "unresolved",
      code: "BRAIN_AGENT_ID_INVALID",
      message: error instanceof Error ? error.message : String(error),
    };
  }
  if (identity.status === "missing" || identity.resolvedAgentId === undefined) {
    return {
      kind: "unresolved",
      code: "BRAIN_AGENT_ID_MISSING",
      message: "ANVIL_AGENT_ID is not configured for this agent runtime.",
    };
  }
  if (identity.status === "mismatch") {
    return {
      kind: "unresolved",
      code: "BRAIN_AGENT_ID_MISMATCH",
      message: "The requested agent identity does not match ANVIL_AGENT_ID.",
    };
  }

  const homeDir = options.homeDir ?? options.env?.HOME ?? homedir();
  const anvilHome = resolveAnvilHome({ anvilHome: options.anvilHome, env: options.env, homeDir });
  return readBrainConfig(agentConfigPath(anvilHome, identity.resolvedAgentId), identity.resolvedAgentId);
}

export async function loadBrainUsageIdentityRegistry(
  options: BrainUsageIdentityOptions = {},
): Promise<BrainUsageIdentityRegistry> {
  const homeDir = options.homeDir ?? options.env?.HOME ?? homedir();
  const anvilHome = resolveAnvilHome({ anvilHome: options.anvilHome, env: options.env, homeDir });
  const agentsRoot = join(anvilHome, "agents");
  let entries;
  try {
    entries = await readdir(agentsRoot, { withFileTypes: true });
  } catch (error) {
    if (typeof error === "object" && error !== null && "code" in error && error.code === "ENOENT") {
      return { identities: new Map(), labels: new Map(), diagnostics: [] };
    }
    throw error;
  }

  const identities = new Map<string, BrainUsageIdentity>();
  const labels = new Map<string, string[]>();
  const diagnostics: BrainUsageIdentityRegistryDiagnostic[] = [];

  for (const entry of entries.filter((candidate) => candidate.isDirectory()).sort((left, right) => left.name.localeCompare(right.name))) {
    let agentId: string;
    try {
      agentId = validateAgentId(entry.name);
    } catch (error) {
      diagnostics.push({
        code: "BRAIN_AGENT_ID_INVALID",
        agentId: entry.name,
        message: error instanceof Error ? error.message : String(error),
      });
      continue;
    }
    const result = await readBrainConfig(agentConfigPath(anvilHome, agentId), agentId);
    if (result.kind === "unresolved") {
      diagnostics.push({ code: result.code, agentId, message: result.message });
      continue;
    }
    identities.set(result.identity.id, result.identity);
    for (const label of [result.identity.id, result.identity.agentId, result.identity.wikiAlias]) {
      const ids = labels.get(label) ?? [];
      if (!ids.includes(result.identity.id)) ids.push(result.identity.id);
      labels.set(label, ids.sort());
    }
  }

  return { identities, labels, diagnostics };
}
