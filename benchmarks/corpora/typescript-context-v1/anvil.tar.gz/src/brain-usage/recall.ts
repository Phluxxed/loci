import { createHash } from "node:crypto";

import type { BrainContextResult } from "../brain-context/index.ts";
import { MAX_LIST_ITEMS, recordBrainUsage } from "./index.ts";
import type { BrainUsageRecallEvent } from "./index.ts";

export type PromptRecallLifecycle = {
  message_id?: unknown;
  session_id?: unknown;
  turn_id?: unknown;
};

export type RecordPromptRecallTelemetryInput = {
  cwd: string;
  stateRoot?: string;
  lifecycle: PromptRecallLifecycle;
  event: BrainUsageRecallEvent;
  durationMs?: number;
  brain?: BrainContextResult;
};

function optionalLifecycleId(value: unknown): string | undefined {
  return typeof value === "string" && value.trim().length > 0 ? value.trim() : undefined;
}

function stablePromptRecallUsageId(lifecycle: PromptRecallLifecycle): string | undefined {
  const sessionId = optionalLifecycleId(lifecycle.session_id);
  const promptId = optionalLifecycleId(lifecycle.message_id) ?? optionalLifecycleId(lifecycle.turn_id);
  if (sessionId === undefined || promptId === undefined) return undefined;
  const digest = createHash("sha256")
    .update(`prompt-recall-v1\0${sessionId}\0${promptId}`)
    .digest("hex")
    .slice(0, 24);
  return `brain_recall_${digest}`;
}

export type PromptRecallOutcomeInput = Readonly<{
  status: "ready" | "partial" | "empty" | "degraded";
  hasSupportingEvidence: boolean;
  hasRetrievalFailure: boolean;
}>;

export function promptRecallEvent(input: PromptRecallOutcomeInput): BrainUsageRecallEvent {
  if (input.status === "degraded") return "degraded";
  if (input.hasSupportingEvidence) return "recalled";
  return input.hasRetrievalFailure ? "degraded" : "no_match";
}

export async function recordPromptRecallTelemetry(input: RecordPromptRecallTelemetryInput): Promise<void> {
  const sessionId = optionalLifecycleId(input.lifecycle.session_id);
  const turnId = optionalLifecycleId(input.lifecycle.turn_id);
  const messageId = optionalLifecycleId(input.lifecycle.message_id);
  const selectedPages = input.brain?.selectedPages?.slice(0, MAX_LIST_ITEMS) ?? [];
  const diagnostics = input.brain?.diagnostics.map((diagnostic) => diagnostic.code) ?? [];
  const stableId = stablePromptRecallUsageId(input.lifecycle);
  const brainIdentity = input.brain?.brainAgentId !== undefined && input.brain.brainAlias !== undefined
    ? {
        id: `agent:${input.brain.brainAgentId}`,
        agentId: input.brain.brainAgentId,
        wikiAlias: input.brain.brainAlias,
      }
    : undefined;
  const outcomeParts = [
    ...(input.durationMs !== undefined ? [`retrieval_ms=${input.durationMs}`] : []),
    `selected_pages=${selectedPages.length}`,
    ...(diagnostics.length > 0 ? [`diagnostic=${diagnostics.join(",")}`] : []),
  ];

  await recordBrainUsage({
    cwd: input.cwd,
    stateRoot: input.stateRoot,
    ...(stableId !== undefined ? { id: () => stableId } : {}),
    ...(brainIdentity !== undefined ? { brainIdentity } : {}),
    ...(input.brain?.recallObservation !== undefined
      ? { automaticRecallObservation: input.brain.recallObservation }
      : {}),
    usage: {
      event: input.event,
      trigger: "Automatic prompt-specific Brain recall.",
      trigger_bucket: "brain-recall",
      severity: input.event === "degraded" ? "warn" : "info",
      outcome: outcomeParts.join("; "),
      ...(selectedPages.length > 0 ? { pages: selectedPages } : {}),
      ...(sessionId !== undefined ? { session_id: sessionId } : {}),
      ...(turnId !== undefined ? { turn_id: turnId } : {}),
      ...(messageId !== undefined ? { message_id: messageId } : {}),
    },
  });
}
