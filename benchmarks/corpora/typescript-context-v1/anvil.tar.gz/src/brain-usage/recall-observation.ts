import type { BrainRecallObservation } from "../brain-context/index.ts";
import {
  BRAIN_CONTEXT_DIAGNOSTIC_CODES,
  type BrainContextDiagnosticCode,
} from "../brain-context/manifest.ts";

const RECALL_PHASES = ["disabled", "guidance_preflight", "retrieval", "render"] as const;
const SELECTION_OUTCOMES = ["not_run", "unchanged", "filtered"] as const;
const RENDER_OUTCOMES = ["disabled", "guidance_rejected", "within_limit", "truncated", "diagnostic"] as const;
const MAX_DIAGNOSTICS = 20;

function objectValue(value: unknown, field: string): Record<string, unknown> {
  if (typeof value !== "object" || value === null || Array.isArray(value)) {
    throw new Error(`${field} must be an object`);
  }
  return value as Record<string, unknown>;
}

function exactKeys(record: Record<string, unknown>, allowed: readonly string[], field: string): void {
  const allowedSet = new Set(allowed);
  const unknown = Object.keys(record).filter((key) => !allowedSet.has(key));
  if (unknown.length > 0) throw new Error(`${field} contains unsupported fields: ${unknown.join(", ")}`);
}

function safeInteger(value: unknown, field: string, signed = false): number {
  if (!Number.isSafeInteger(value) || (!signed && (value as number) < 0)) {
    throw new Error(`${field} must be ${signed ? "a" : "a non-negative"} safe integer`);
  }
  return value as number;
}

function optionalSafeInteger(value: unknown, field: string, signed = false): number | undefined {
  return value === undefined ? undefined : safeInteger(value, field, signed);
}

function enumValue<const Values extends readonly string[]>(
  value: unknown,
  values: Values,
  field: string,
): Values[number] {
  if (typeof value !== "string" || !(values as readonly string[]).includes(value)) {
    throw new Error(`${field} is invalid`);
  }
  return value as Values[number];
}

function diagnosticCodes(value: unknown): BrainContextDiagnosticCode[] {
  if (!Array.isArray(value) || value.length > MAX_DIAGNOSTICS) {
    throw new Error(`recall_observation.diagnostics must contain at most ${MAX_DIAGNOSTICS} diagnostic codes`);
  }
  const diagnostics = value.map((code) => {
    if (
      typeof code !== "string"
      || !(BRAIN_CONTEXT_DIAGNOSTIC_CODES as readonly string[]).includes(code)
    ) {
      throw new Error("recall_observation.diagnostics contains an invalid diagnostic code");
    }
    return code as BrainContextDiagnosticCode;
  });
  if (new Set(diagnostics).size !== diagnostics.length) {
    throw new Error("recall_observation.diagnostics must not contain duplicate codes");
  }
  return diagnostics;
}

export function validateBrainRecallObservation(value: unknown): BrainRecallObservation {
  const record = objectValue(value, "recall_observation");
  exactKeys(
    record,
    ["phase", "timing", "pages", "bytes", "selection_outcome", "render_outcome", "diagnostics"],
    "recall_observation",
  );

  const timingRecord = objectValue(record.timing, "recall_observation.timing");
  exactKeys(timingRecord, ["total_ms", "retrieval_ms"], "recall_observation.timing");
  const totalMs = safeInteger(timingRecord.total_ms, "recall_observation.timing.total_ms");
  const retrievalMs = optionalSafeInteger(
    timingRecord.retrieval_ms,
    "recall_observation.timing.retrieval_ms",
  );

  const pagesRecord = objectValue(record.pages, "recall_observation.pages");
  exactKeys(
    pagesRecord,
    [
      "guidance_count",
      "compiler_evidence_count",
      "candidate_count",
      "supporting_count",
      "selected_count",
      "filtered_count",
    ],
    "recall_observation.pages",
  );
  const guidanceCount = safeInteger(pagesRecord.guidance_count, "recall_observation.pages.guidance_count");
  const compilerEvidenceCount = optionalSafeInteger(
    pagesRecord.compiler_evidence_count,
    "recall_observation.pages.compiler_evidence_count",
  );
  const candidateCount = optionalSafeInteger(
    pagesRecord.candidate_count,
    "recall_observation.pages.candidate_count",
  );
  const supportingCount = optionalSafeInteger(
    pagesRecord.supporting_count,
    "recall_observation.pages.supporting_count",
  );
  const selectedCount = optionalSafeInteger(
    pagesRecord.selected_count,
    "recall_observation.pages.selected_count",
  );
  const filteredCount = optionalSafeInteger(
    pagesRecord.filtered_count,
    "recall_observation.pages.filtered_count",
  );

  const bytesRecord = objectValue(record.bytes, "recall_observation.bytes");
  exactKeys(
    bytesRecord,
    [
      "guidance",
      "guidance_limit",
      "guidance_headroom",
      "retrieved_context",
      "framing",
      "attempted",
      "rendered",
      "payload_limit",
      "payload_headroom",
    ],
    "recall_observation.bytes",
  );
  const guidance = safeInteger(bytesRecord.guidance, "recall_observation.bytes.guidance");
  const guidanceLimit = safeInteger(bytesRecord.guidance_limit, "recall_observation.bytes.guidance_limit");
  const guidanceHeadroom = safeInteger(
    bytesRecord.guidance_headroom,
    "recall_observation.bytes.guidance_headroom",
    true,
  );
  const retrievedContext = optionalSafeInteger(
    bytesRecord.retrieved_context,
    "recall_observation.bytes.retrieved_context",
  );
  const framing = optionalSafeInteger(bytesRecord.framing, "recall_observation.bytes.framing");
  const attempted = optionalSafeInteger(bytesRecord.attempted, "recall_observation.bytes.attempted");
  const rendered = safeInteger(bytesRecord.rendered, "recall_observation.bytes.rendered");
  const payloadLimit = safeInteger(bytesRecord.payload_limit, "recall_observation.bytes.payload_limit");
  const payloadHeadroom = optionalSafeInteger(
    bytesRecord.payload_headroom,
    "recall_observation.bytes.payload_headroom",
    true,
  );

  const phase = enumValue(record.phase, RECALL_PHASES, "recall_observation.phase");
  const selectionOutcome = enumValue(
    record.selection_outcome,
    SELECTION_OUTCOMES,
    "recall_observation.selection_outcome",
  );
  const renderOutcome = enumValue(record.render_outcome, RENDER_OUTCOMES, "recall_observation.render_outcome");
  const diagnostics = diagnosticCodes(record.diagnostics);

  if (retrievalMs !== undefined && retrievalMs > totalMs) {
    throw new Error("recall_observation.timing.retrieval_ms must not exceed total_ms");
  }
  if (guidanceHeadroom !== guidanceLimit - guidance) {
    throw new Error("recall_observation.bytes.guidance_headroom must equal guidance_limit - guidance");
  }
  if (guidanceLimit > payloadLimit) {
    throw new Error("recall_observation.bytes.guidance_limit must not exceed payload_limit");
  }
  if (rendered > payloadLimit) {
    throw new Error("recall_observation.bytes.rendered must not exceed payload_limit");
  }
  if ((attempted === undefined) !== (payloadHeadroom === undefined)) {
    throw new Error("recall_observation.bytes.attempted and payload_headroom must appear together");
  }
  if (attempted !== undefined && payloadHeadroom !== payloadLimit - attempted) {
    throw new Error("recall_observation.bytes.payload_headroom must equal payload_limit - attempted");
  }
  if (attempted !== undefined) {
    if (retrievedContext === undefined || framing === undefined) {
      throw new Error("recall_observation.bytes.attempted requires retrieved_context and framing");
    }
    if (attempted !== guidance + retrievedContext + framing) {
      throw new Error("recall_observation.bytes.attempted must equal guidance + retrieved_context + framing");
    }
  }
  if (compilerEvidenceCount !== undefined && candidateCount !== undefined && compilerEvidenceCount < candidateCount) {
    throw new Error("recall_observation.pages.compiler_evidence_count must be at least candidate_count");
  }
  if (candidateCount !== undefined && supportingCount !== undefined && filteredCount !== undefined
    && candidateCount !== supportingCount + filteredCount) {
    throw new Error("recall_observation.pages.candidate_count must equal supporting_count + filtered_count");
  }
  if (selectedCount !== undefined && supportingCount !== undefined
    && selectedCount !== guidanceCount + supportingCount) {
    throw new Error("recall_observation.pages.selected_count must equal guidance_count + supporting_count");
  }
  if (selectionOutcome === "filtered" && (filteredCount === undefined || filteredCount === 0)) {
    throw new Error("recall_observation.selection_outcome filtered requires a positive filtered_count");
  }
  if (selectionOutcome === "unchanged" && filteredCount !== 0) {
    throw new Error("recall_observation.selection_outcome unchanged requires filtered_count 0");
  }
  if (renderOutcome === "guidance_rejected") {
    if (phase !== "guidance_preflight" || guidance <= guidanceLimit || attempted !== undefined) {
      throw new Error("recall_observation guidance rejection is inconsistent with its phase or byte values");
    }
    if (!diagnostics.includes("BRAIN_PROMPT_GUIDANCE_TOO_LARGE")) {
      throw new Error("recall_observation guidance rejection requires BRAIN_PROMPT_GUIDANCE_TOO_LARGE");
    }
  }
  if (renderOutcome === "within_limit") {
    if (phase !== "render" || attempted === undefined || attempted > payloadLimit || rendered !== attempted) {
      throw new Error("recall_observation within-limit render is inconsistent with its phase or byte values");
    }
  }
  if (renderOutcome === "truncated") {
    if (phase !== "render" || attempted === undefined || attempted <= payloadLimit || rendered > payloadLimit) {
      throw new Error("recall_observation truncated render is inconsistent with its phase or byte values");
    }
  }
  if (renderOutcome === "disabled" && phase !== "disabled") {
    throw new Error("recall_observation disabled render requires the disabled phase");
  }

  return {
    phase,
    timing: {
      total_ms: totalMs,
      ...(retrievalMs !== undefined ? { retrieval_ms: retrievalMs } : {}),
    },
    pages: {
      guidance_count: guidanceCount,
      ...(compilerEvidenceCount !== undefined ? { compiler_evidence_count: compilerEvidenceCount } : {}),
      ...(candidateCount !== undefined ? { candidate_count: candidateCount } : {}),
      ...(supportingCount !== undefined ? { supporting_count: supportingCount } : {}),
      ...(selectedCount !== undefined ? { selected_count: selectedCount } : {}),
      ...(filteredCount !== undefined ? { filtered_count: filteredCount } : {}),
    },
    bytes: {
      guidance,
      guidance_limit: guidanceLimit,
      guidance_headroom: guidanceHeadroom,
      ...(retrievedContext !== undefined ? { retrieved_context: retrievedContext } : {}),
      ...(framing !== undefined ? { framing } : {}),
      ...(attempted !== undefined ? { attempted } : {}),
      rendered,
      payload_limit: payloadLimit,
      ...(payloadHeadroom !== undefined ? { payload_headroom: payloadHeadroom } : {}),
    },
    selection_outcome: selectionOutcome,
    render_outcome: renderOutcome,
    diagnostics,
  };
}
