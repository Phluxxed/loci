import { randomUUID } from "node:crypto";
import { appendFile, mkdir, readFile, readdir } from "node:fs/promises";
import { homedir } from "node:os";
import { dirname, join, resolve } from "node:path";

import { z } from "zod";

import { resolveContinuityWorkspace } from "../continuity/index.ts";
import type { ContinuityWorkspaceOptions, WorkspaceRef } from "../continuity/index.ts";
import {
  assertActiveWorkContextBinding,
  resolveWorkContextStateRoot,
  workContextBindingViewSchema,
  workContextBindingView,
  workspaceRefSchema,
} from "../work-context/index.ts";
import type { WorkContextBinding, WorkContextBindingView } from "../work-context/index.ts";
import {
  BrainUsageIdentityError,
  loadBrainUsageIdentityRegistry,
  resolveCurrentBrainUsageIdentity,
  validateBrainUsageIdentity,
} from "./identity.ts";
import type {
  BrainUsageIdentity,
  BrainUsageIdentityErrorCode,
  BrainUsageIdentityRegistry,
} from "./identity.ts";
import { validateBrainRecallObservation } from "./recall-observation.ts";
import type { BrainRecallObservation } from "../brain-context/index.ts";
import { BRAIN_CONTEXT_DIAGNOSTIC_CODES } from "../brain-context/manifest.ts";
import { summarizeRecallMetrics } from "./recall-metrics.ts";
import type { BrainRecallMetrics } from "./recall-metrics.ts";

export const BRAIN_USAGE_SCHEMA_VERSION = 2;
export const LEGACY_BRAIN_USAGE_SCHEMA_VERSION = 1;
export const MAX_BRAIN_NAME_CHARS = 128;
export const MAX_TRIGGER_CHARS = 500;
export const MAX_OUTCOME_CHARS = 500;
export const MAX_PAGE_CHARS = 200;
export const MAX_RELATED_CHARS = 200;
export const MAX_TRACE_ID_CHARS = 200;
export const MAX_TRIGGER_BUCKET_CHARS = 160;
export const MAX_PROMPT_EXCERPT_CHARS = 1000;
export const MAX_PROMPT_RAW_CHARS = 12000;
export const MAX_LIST_ITEMS = 20;
export const DEFAULT_BRAIN_USAGE_LIMIT = 20;
export const MAX_BRAIN_USAGE_LIMIT = 200;
export const DEFAULT_TRIGGER_BUCKET = "uncategorized";
export const AUTO_TRIGGER_BUCKET_FALLBACK = "general";
export const DEFAULT_SESSION_ID = "unknown-session";
const BRAIN_IDENTITY_ERROR_CODES = [
  "BRAIN_AGENT_ID_MISSING",
  "BRAIN_AGENT_ID_MISMATCH",
  "BRAIN_AGENT_ID_INVALID",
  "BRAIN_CONFIG_MISSING",
  "BRAIN_CONFIG_INVALID",
] as const satisfies readonly BrainUsageIdentityErrorCode[];

export const BRAIN_USAGE_EVENTS = [
  "recalled",
  "no_match",
  "degraded",
  "disabled",
  "consulted",
  "used",
  "not_needed",
  "updated",
  "missed_update",
  "stale",
  "wrong",
  "blocked",
  "eval_failed",
] as const;

export const BRAIN_USAGE_RECALL_EVENTS = ["recalled", "no_match", "degraded", "disabled"] as const;
export const BRAIN_USAGE_COVERAGE_EVENTS = ["consulted", "used", "not_needed", "blocked"] as const;
export const BRAIN_USAGE_INCIDENT_EVENTS = ["updated", "missed_update", "stale", "wrong", "eval_failed"] as const;

export const BRAIN_USAGE_SEVERITIES = ["info", "warn", "error"] as const;

export type BrainUsageEvent = (typeof BRAIN_USAGE_EVENTS)[number];
export type BrainUsageRecallEvent = (typeof BRAIN_USAGE_RECALL_EVENTS)[number];
export type BrainUsageCoverageEvent = (typeof BRAIN_USAGE_COVERAGE_EVENTS)[number];
export type BrainUsageIncidentEvent = (typeof BRAIN_USAGE_INCIDENT_EVENTS)[number];
export type BrainUsageSeverity = (typeof BRAIN_USAGE_SEVERITIES)[number];
export type BrainUsageIdentityStatus = "resolved" | "unresolved";
export type BrainUsageIdentitySource = "recorded" | "legacy_config_match" | "unresolved" | "unassigned";

export type BrainUsageInput = {
  event: BrainUsageEvent;
  trigger: string;
  brain?: string;
  pages?: string[];
  related?: string[];
  outcome?: string;
  severity?: BrainUsageSeverity;
  trigger_bucket?: string;
  session_id?: string;
  turn_id?: string;
  message_id?: string;
  mcp_call_id?: string;
  prompt_excerpt?: string;
  prompt_raw?: string;
};

export type BrainUsageRecord = Required<Pick<BrainUsageInput, "severity">> &
  Omit<BrainUsageInput, "severity" | "brain"> & {
    version: typeof BRAIN_USAGE_SCHEMA_VERSION | typeof LEGACY_BRAIN_USAGE_SCHEMA_VERSION;
    id: string;
    created_at: string;
    workspace: WorkspaceRef;
    brain?: string;
    brain_id?: string;
    brain_alias?: string;
    brain_identity_status?: BrainUsageIdentityStatus;
    brain_identity_error?: BrainUsageIdentityErrorCode;
    recall_observation?: BrainRecallObservation;
  };

export type BrainUsagePaths = {
  workspace: WorkspaceRef;
  stateRoot: string;
  brainUsageRoot: string;
  workspaceDir: string;
  usagePath: string;
};

export type BrainUsageWorkspaceOptions = ContinuityWorkspaceOptions & {
  anvilHome?: string;
  env?: Record<string, string | undefined>;
  homeDir?: string;
};

type Clock = () => string;
type IdGenerator = () => string;

export type RecordBrainUsageInput = BrainUsageWorkspaceOptions & {
  usage: BrainUsageInput;
  brainIdentity?: BrainUsageIdentity;
  automaticRecallObservation?: BrainRecallObservation;
  now?: Clock;
  id?: IdGenerator;
};

export type RecordBrainUsageOutput = {
  paths: BrainUsagePaths;
  record: BrainUsageRecord;
};

export type RecordBoundBrainUsageInput = Pick<BrainUsageWorkspaceOptions, "anvilHome" | "env" | "homeDir"> & {
  binding: WorkContextBinding;
  stateRoot?: string;
  bindingNow?: Clock;
  usage: BrainUsageInput;
  now?: Clock;
  id?: IdGenerator;
};

export type RecordBoundBrainUsageOutput = RecordBrainUsageOutput & {
  binding: WorkContextBindingView;
};

export type ReadBrainUsageInput = BrainUsageWorkspaceOptions & {
  limit?: number;
  scope?: BrainUsageSummaryScope;
};

export type ReadBrainUsageOutput =
  | { kind: "ok"; path: string; items: BrainUsageRecord[]; total: number; truncated: boolean }
  | { kind: "missing"; path: string; message: string }
  | { kind: "malformed"; path: string; message: string };

export type BrainMaintenanceClosureOutput =
  | {
      kind: "ok";
      path: string;
      session_id: string;
      incidents: BrainUsageRecord[];
      unresolved: BrainUsageRecord[];
    }
  | { kind: "missing"; path: string; message: string }
  | { kind: "malformed"; path: string; message: string };

type BrainUsageRecordReadOutput =
  | { kind: "ok"; path: string; records: BrainUsageRecord[] }
  | { kind: "missing"; path: string; message: string }
  | { kind: "malformed"; path: string; message: string };

export type BrainUsageTraceEvent = {
  id: string;
  created_at: string;
  project_key: string;
  project_root: string;
  project_label?: string;
  event: BrainUsageEvent;
  severity: BrainUsageSeverity;
  trigger: string;
  trigger_bucket: string;
  brain_id?: string;
  brain_alias?: string;
  brain_recorded_alias?: string;
  brain_identity_source: BrainUsageIdentitySource;
  brain_identity_error?: string;
  pages?: string[];
  related?: string[];
  outcome?: string;
  session_id?: string;
  turn_id?: string;
  message_id?: string;
  mcp_call_id?: string;
  prompt_excerpt?: string;
  prompt_raw?: string;
};

export type BrainUsageTracePrompt = {
  message_id: string;
  total: number;
  turn_id?: string;
  prompt_excerpt?: string;
  prompt_raw?: string;
  events: BrainUsageTraceEvent[];
};

export type BrainUsageTraceSession = {
  session_id: string;
  total: number;
  prompts: BrainUsageTracePrompt[];
};

export type BrainUsageTraceBucket = {
  bucket: string;
  total: number;
  sessions: BrainUsageTraceSession[];
};

export type BrainUsageTraceProject = {
  project_key: string;
  project_root: string;
  project_label?: string;
  total: number;
  buckets: BrainUsageTraceBucket[];
};

export type BrainUsageTraceOutput = {
  projects: BrainUsageTraceProject[];
  recent: BrainUsageTraceEvent[];
};

export type BrainUsageMetricsOutput =
  | {
      kind: "ok";
      path: string;
      total: number;
      by_event: Record<BrainUsageEvent, number>;
      by_severity: Record<BrainUsageSeverity, number>;
      by_brain: Record<string, number>;
      brain_aliases: Record<string, string>;
      brain_identity: {
        resolved_events: number;
        legacy_normalized_events: number;
        unresolved_events: number;
        unassigned_events: number;
        diagnostics: Array<{ code: string; label?: string; agent_id?: string; count: number }>;
      };
      by_trigger_bucket: Record<string, number>;
      recall: BrainRecallMetrics;
      coverage: {
        total: number;
        by_event: Record<BrainUsageCoverageEvent, number>;
      };
      incidents: {
        total: number;
        by_event: Record<BrainUsageIncidentEvent, number>;
      };
      trace: BrainUsageTraceOutput;
      first_created_at?: string;
      last_created_at?: string;
    }
  | { kind: "missing"; path: string; message: string }
  | { kind: "malformed"; path: string; message: string };

const nonNegativeIntegerSchema = z.number().int().nonnegative();
const signedIntegerSchema = z.number().int();

export const brainUsageEventSchema = z.enum(BRAIN_USAGE_EVENTS);
export const brainUsageRecallEventSchema = z.enum(BRAIN_USAGE_RECALL_EVENTS);
export const brainUsageCoverageEventSchema = z.enum(BRAIN_USAGE_COVERAGE_EVENTS);
export const brainUsageIncidentEventSchema = z.enum(BRAIN_USAGE_INCIDENT_EVENTS);
export const brainUsageSeveritySchema = z.enum(BRAIN_USAGE_SEVERITIES);
export const brainUsageIdentityStatusSchema = z.enum(["resolved", "unresolved"]);
export const brainUsageIdentitySourceSchema = z.enum([
  "recorded",
  "legacy_config_match",
  "unresolved",
  "unassigned",
]);
export const brainUsageIdentityErrorCodeSchema = z.enum(BRAIN_IDENTITY_ERROR_CODES);

export const brainRecallObservationSchema = z.object({
  phase: z.enum(["disabled", "guidance_preflight", "retrieval", "render"]),
  timing: z.object({
    total_ms: nonNegativeIntegerSchema,
    retrieval_ms: nonNegativeIntegerSchema.optional(),
  }).strict(),
  pages: z.object({
    guidance_count: nonNegativeIntegerSchema,
    compiler_evidence_count: nonNegativeIntegerSchema.optional(),
    candidate_count: nonNegativeIntegerSchema.optional(),
    supporting_count: nonNegativeIntegerSchema.optional(),
    selected_count: nonNegativeIntegerSchema.optional(),
    filtered_count: nonNegativeIntegerSchema.optional(),
  }).strict(),
  bytes: z.object({
    guidance: nonNegativeIntegerSchema,
    guidance_limit: nonNegativeIntegerSchema,
    guidance_headroom: signedIntegerSchema,
    retrieved_context: nonNegativeIntegerSchema.optional(),
    framing: nonNegativeIntegerSchema.optional(),
    attempted: nonNegativeIntegerSchema.optional(),
    rendered: nonNegativeIntegerSchema,
    payload_limit: nonNegativeIntegerSchema,
    payload_headroom: signedIntegerSchema.optional(),
  }).strict(),
  selection_outcome: z.enum(["not_run", "unchanged", "filtered"]),
  render_outcome: z.enum(["disabled", "guidance_rejected", "within_limit", "truncated", "diagnostic"]),
  diagnostics: z.array(z.enum(BRAIN_CONTEXT_DIAGNOSTIC_CODES)),
}).strict();

export const brainUsageRecordSchema = z.object({
  version: z.union([z.literal(LEGACY_BRAIN_USAGE_SCHEMA_VERSION), z.literal(BRAIN_USAGE_SCHEMA_VERSION)]),
  id: z.string(),
  created_at: z.string(),
  workspace: workspaceRefSchema,
  event: brainUsageEventSchema,
  trigger: z.string(),
  pages: z.array(z.string()).optional(),
  related: z.array(z.string()).optional(),
  outcome: z.string().optional(),
  severity: brainUsageSeveritySchema,
  trigger_bucket: z.string().optional(),
  session_id: z.string().optional(),
  turn_id: z.string().optional(),
  message_id: z.string().optional(),
  mcp_call_id: z.string().optional(),
  prompt_excerpt: z.string().optional(),
  prompt_raw: z.string().optional(),
  brain: z.string().optional(),
  brain_id: z.string().optional(),
  brain_alias: z.string().optional(),
  brain_identity_status: brainUsageIdentityStatusSchema.optional(),
  brain_identity_error: brainUsageIdentityErrorCodeSchema.optional(),
  recall_observation: brainRecallObservationSchema.optional(),
}).strict();

export const brainUsagePathsSchema = z.object({
  workspace: workspaceRefSchema,
  stateRoot: z.string(),
  brainUsageRoot: z.string(),
  workspaceDir: z.string(),
  usagePath: z.string(),
}).strict();

export const recordBrainUsageOutputSchema = z.object({
  paths: brainUsagePathsSchema,
  record: brainUsageRecordSchema,
}).strict();

export const recordBoundBrainUsageOutputSchema = z.object({
  paths: brainUsagePathsSchema,
  record: brainUsageRecordSchema,
  binding: workContextBindingViewSchema,
}).strict();

const missingBrainUsageOutputSchema = z.object({
  kind: z.literal("missing"),
  path: z.string(),
  message: z.string(),
}).strict();

const malformedBrainUsageOutputSchema = z.object({
  kind: z.literal("malformed"),
  path: z.string(),
  message: z.string(),
}).strict();

export const readBrainUsageOutputSchema = z.discriminatedUnion("kind", [
  z.object({
    kind: z.literal("ok"),
    path: z.string(),
    items: z.array(brainUsageRecordSchema),
    total: nonNegativeIntegerSchema,
    truncated: z.boolean(),
  }).strict(),
  missingBrainUsageOutputSchema,
  malformedBrainUsageOutputSchema,
]);

export const brainUsageTraceEventSchema = z.object({
  id: z.string(),
  created_at: z.string(),
  project_key: z.string(),
  project_root: z.string(),
  project_label: z.string().optional(),
  event: brainUsageEventSchema,
  severity: brainUsageSeveritySchema,
  trigger: z.string(),
  trigger_bucket: z.string(),
  brain_id: z.string().optional(),
  brain_alias: z.string().optional(),
  brain_recorded_alias: z.string().optional(),
  brain_identity_source: brainUsageIdentitySourceSchema,
  brain_identity_error: z.string().optional(),
  pages: z.array(z.string()).optional(),
  related: z.array(z.string()).optional(),
  outcome: z.string().optional(),
  session_id: z.string().optional(),
  turn_id: z.string().optional(),
  message_id: z.string().optional(),
  mcp_call_id: z.string().optional(),
  prompt_excerpt: z.string().optional(),
  prompt_raw: z.string().optional(),
}).strict();

export const brainUsageTracePromptSchema = z.object({
  message_id: z.string(),
  total: nonNegativeIntegerSchema,
  turn_id: z.string().optional(),
  prompt_excerpt: z.string().optional(),
  prompt_raw: z.string().optional(),
  events: z.array(brainUsageTraceEventSchema),
}).strict();

export const brainUsageTraceSessionSchema = z.object({
  session_id: z.string(),
  total: nonNegativeIntegerSchema,
  prompts: z.array(brainUsageTracePromptSchema),
}).strict();

export const brainUsageTraceBucketSchema = z.object({
  bucket: z.string(),
  total: nonNegativeIntegerSchema,
  sessions: z.array(brainUsageTraceSessionSchema),
}).strict();

export const brainUsageTraceProjectSchema = z.object({
  project_key: z.string(),
  project_root: z.string(),
  project_label: z.string().optional(),
  total: nonNegativeIntegerSchema,
  buckets: z.array(brainUsageTraceBucketSchema),
}).strict();

export const brainUsageTraceOutputSchema = z.object({
  projects: z.array(brainUsageTraceProjectSchema),
  recent: z.array(brainUsageTraceEventSchema),
}).strict();

export const brainUsageEventCountsSchema = z.record(brainUsageEventSchema, nonNegativeIntegerSchema);
export const brainUsageRecallEventCountsSchema = z.record(brainUsageRecallEventSchema, nonNegativeIntegerSchema);
export const brainUsageCoverageEventCountsSchema = z.record(brainUsageCoverageEventSchema, nonNegativeIntegerSchema);
export const brainUsageIncidentEventCountsSchema = z.record(brainUsageIncidentEventSchema, nonNegativeIntegerSchema);
export const brainUsageSeverityCountsSchema = z.record(brainUsageSeveritySchema, nonNegativeIntegerSchema);
export const brainUsageNamedCountsSchema = z.record(z.string(), nonNegativeIntegerSchema);

export const brainUsageRateSchema = z.object({
  numerator: nonNegativeIntegerSchema,
  denominator: nonNegativeIntegerSchema,
  rate: z.number().nullable(),
}).strict();

export const brainUsageDistributionSchema = z.object({
  count: nonNegativeIntegerSchema,
  min: z.number().optional(),
  p05: z.number().optional(),
  p50: z.number().optional(),
  p90: z.number().optional(),
  p95: z.number().optional(),
  p99: z.number().optional(),
  max: z.number().optional(),
}).strict();

const brainRecallSummarySchema = z.object({
  total: nonNegativeIntegerSchema,
  eligible_total: nonNegativeIntegerSchema,
  by_event: brainUsageRecallEventCountsSchema,
  success: brainUsageRateSchema,
  degradation: brainUsageRateSchema,
  diagnostics: brainUsageNamedCountsSchema,
}).strict();

export const brainRecallMetricsSchema = z.object({
  total: nonNegativeIntegerSchema,
  by_event: brainUsageRecallEventCountsSchema,
  eligible_total: nonNegativeIntegerSchema,
  success: brainUsageRateSchema,
  degradation: brainUsageRateSchema,
  diagnostics: z.object({
    events_with_diagnostics: nonNegativeIntegerSchema,
    by_code: brainUsageNamedCountsSchema,
    rates_by_code: z.record(z.string(), brainUsageRateSchema),
  }).strict(),
  instrumentation: z.object({
    instrumented_records: nonNegativeIntegerSchema,
    eligible_records: nonNegativeIntegerSchema,
    coverage: z.number().nullable(),
  }).strict(),
  by_workspace: z.array(brainRecallSummarySchema.extend({
    workspace: workspaceRefSchema,
    instrumented_records: nonNegativeIntegerSchema,
    instrumentation_coverage: z.number().nullable(),
  }).strict()),
  trends: z.object({
    hourly: z.array(brainRecallSummarySchema.extend({ bucket_start: z.string() }).strict()),
    daily: z.array(brainRecallSummarySchema.extend({ bucket_start: z.string() }).strict()),
  }).strict(),
  payload_bytes: z.object({
    attempted: brainUsageDistributionSchema,
    rendered: brainUsageDistributionSchema,
    guidance: brainUsageDistributionSchema,
    retrieved_context: brainUsageDistributionSchema,
    framing: brainUsageDistributionSchema,
  }).strict(),
  limit_bytes: z.object({
    guidance: brainUsageDistributionSchema,
    payload: brainUsageDistributionSchema,
  }).strict(),
  headroom_bytes: z.object({
    guidance: brainUsageDistributionSchema,
    payload: brainUsageDistributionSchema,
  }).strict(),
  pages: z.object({
    guidance: brainUsageDistributionSchema,
    compiler_evidence: brainUsageDistributionSchema,
    candidate: brainUsageDistributionSchema,
    supporting: brainUsageDistributionSchema,
    selected: brainUsageDistributionSchema,
    filtered: brainUsageDistributionSchema,
  }).strict(),
  timing_ms: z.object({
    total: brainUsageDistributionSchema,
    retrieval: brainUsageDistributionSchema,
  }).strict(),
  by_phase: z.record(z.enum(["disabled", "guidance_preflight", "retrieval", "render"]), nonNegativeIntegerSchema),
  by_selection_outcome: z.record(z.enum(["not_run", "unchanged", "filtered"]), nonNegativeIntegerSchema),
  by_render_outcome: z.record(
    z.enum(["disabled", "guidance_rejected", "within_limit", "truncated", "diagnostic"]),
    nonNegativeIntegerSchema,
  ),
  overflow_stage: z.record(z.enum(["none", "guidance", "payload", "unknown"]), nonNegativeIntegerSchema),
}).strict();

export const brainUsageIdentityMetricsSchema = z.object({
  resolved_events: nonNegativeIntegerSchema,
  legacy_normalized_events: nonNegativeIntegerSchema,
  unresolved_events: nonNegativeIntegerSchema,
  unassigned_events: nonNegativeIntegerSchema,
  diagnostics: z.array(z.object({
    code: z.string(),
    label: z.string().optional(),
    agent_id: z.string().optional(),
    count: nonNegativeIntegerSchema,
  }).strict()),
}).strict();

export const brainUsageMetricsOutputSchema = z.discriminatedUnion("kind", [
  z.object({
    kind: z.literal("ok"),
    path: z.string(),
    total: nonNegativeIntegerSchema,
    by_event: brainUsageEventCountsSchema,
    by_severity: brainUsageSeverityCountsSchema,
    by_brain: brainUsageNamedCountsSchema,
    brain_aliases: z.record(z.string(), z.string()),
    brain_identity: brainUsageIdentityMetricsSchema,
    by_trigger_bucket: brainUsageNamedCountsSchema,
    recall: brainRecallMetricsSchema,
    coverage: z.object({
      total: nonNegativeIntegerSchema,
      by_event: brainUsageCoverageEventCountsSchema,
    }).strict(),
    incidents: z.object({
      total: nonNegativeIntegerSchema,
      by_event: brainUsageIncidentEventCountsSchema,
    }).strict(),
    trace: brainUsageTraceOutputSchema,
    first_created_at: z.string().optional(),
    last_created_at: z.string().optional(),
  }).strict(),
  missingBrainUsageOutputSchema,
  malformedBrainUsageOutputSchema,
]);

const _brainUsageRecordSchemaMatchesType: z.ZodType<BrainUsageRecord> = brainUsageRecordSchema;
const _recordBrainUsageOutputSchemaMatchesType: z.ZodType<RecordBrainUsageOutput> = recordBrainUsageOutputSchema;
const _recordBoundBrainUsageOutputSchemaMatchesType: z.ZodType<RecordBoundBrainUsageOutput> = recordBoundBrainUsageOutputSchema;
const _readBrainUsageOutputSchemaMatchesType: z.ZodType<ReadBrainUsageOutput> = readBrainUsageOutputSchema;
const _brainUsageTraceOutputSchemaMatchesType: z.ZodType<BrainUsageTraceOutput> = brainUsageTraceOutputSchema;
const _brainRecallMetricsSchemaMatchesType: z.ZodType<BrainRecallMetrics> = brainRecallMetricsSchema;
const _brainUsageMetricsOutputSchemaMatchesType: z.ZodType<BrainUsageMetricsOutput> = brainUsageMetricsOutputSchema;

export type BrainUsageSummaryScope = "workspace" | "all";

export type SummarizeBrainUsageInput = BrainUsageWorkspaceOptions & {
  scope?: BrainUsageSummaryScope;
};

export type BrainUsageLensGraphNode = {
  id: string;
  label: string;
  kind?: string;
  state?: "primary" | "muted" | "inactive";
  sublabel?: string;
  body?: string;
  data?: Record<string, unknown>;
};

export type BrainUsageLensGraphEdge = {
  id: string;
  source: string;
  target: string;
  label?: string;
};

export type BrainUsageLensGraph = {
  nodes: BrainUsageLensGraphNode[];
  edges: BrainUsageLensGraphEdge[];
  meta: {
    title: string;
    direction: "RIGHT";
    root: string;
  };
};

type BrainUsageMetricsOk = Extract<BrainUsageMetricsOutput, { kind: "ok" }>;

function nowIso(): string {
  return new Date().toISOString();
}

function newUsageId(): string {
  const stamp = new Date().toISOString().slice(0, 10).replace(/-/g, "");
  return `brain_use_${stamp}_${randomUUID().replace(/-/g, "").slice(0, 12)}`;
}

function boundedString(value: unknown, field: string, maxChars: number): string {
  if (typeof value !== "string" || value.trim().length === 0) {
    throw new Error(`${field} must be a non-empty string`);
  }
  const trimmed = value.trim();
  if (trimmed.length > maxChars) throw new Error(`${field} must be ${maxChars} characters or fewer`);
  return trimmed;
}

function validateOptionalString(value: unknown, field: string, maxChars: number): string | undefined {
  if (value === undefined) return undefined;
  return boundedString(value, field, maxChars);
}

function validateStringList(value: unknown, field: string, maxChars: number): string[] | undefined {
  if (value === undefined) return undefined;
  if (!Array.isArray(value)) throw new Error(`${field} must be a list`);
  if (value.length > MAX_LIST_ITEMS) throw new Error(`${field} must have ${MAX_LIST_ITEMS} items or fewer`);
  return value.map((item, index) => boundedString(item, `${field}[${index}]`, maxChars));
}

function triggerBucketText(input: Pick<BrainUsageInput, "brain" | "trigger" | "outcome" | "pages" | "related">): string {
  return [
    input.brain,
    input.trigger,
    input.outcome,
    ...(input.pages ?? []),
    ...(input.related ?? []),
  ]
    .filter((value): value is string => value !== undefined)
    .join(" ")
    .toLowerCase();
}

function hasAny(text: string, patterns: RegExp[]): boolean {
  return patterns.some((pattern) => pattern.test(text));
}

function classifyTriggerBucket(input: Pick<BrainUsageInput, "event" | "brain" | "trigger" | "outcome" | "pages" | "related">): string {
  const text = triggerBucketText(input);

  if ((BRAIN_USAGE_RECALL_EVENTS as readonly string[]).includes(input.event)) return "brain-recall";
  if (input.event === "stale" || input.event === "wrong" || input.event === "missed_update" || input.event === "eval_failed") {
    return "brain-quality";
  }
  if (input.event === "blocked") return "blocked";
  if (hasAny(text, [/\bcontinuity\b/, /\bcompact\b/, /\bprojection\b/, /\bpromot/, /\bretir/, /\bbootstrap\b/])) {
    return "continuity";
  }
  if (hasAny(text, [/\bdashboard\b/, /\bmetrics?\b/, /\btrace\b/, /\btelemetry\b/, /\bjournal\b/, /\busage\b/])) {
    return "metrics-dashboard";
  }
  if (hasAny(text, [/\bskill/, /\binvocation\b/])) return "skills";
  if (hasAny(text, [/\bsteward\b/, /\bwiki\b/, /\brender\b/, /\bsubpage\b/, /\bpage\b/, /\bmemory\b/])) {
    return "brain-maintenance";
  }
  if (hasAny(text, [/\bimplement/, /\bcommit\b/, /\bcode\b/, /\brepo\b/, /\bfeature\b/, /\bslice\b/, /\btest\b/])) {
    return "implementation";
  }
  if (hasAny(text, [/\borient/, /\bcontext\b/, /\bconsult/, /\bread\b/, /\bmanual\b/])) return "orientation";
  if (input.event === "updated") return "brain-maintenance";
  if (input.event === "not_needed") return "not-needed";
  return AUTO_TRIGGER_BUCKET_FALLBACK;
}

function validateEvent(value: unknown): BrainUsageEvent {
  if (BRAIN_USAGE_EVENTS.includes(value as BrainUsageEvent)) return value as BrainUsageEvent;
  throw new Error(`event must be one of ${BRAIN_USAGE_EVENTS.join(", ")}`);
}

function validateSeverity(value: unknown): BrainUsageSeverity {
  if (value === undefined) return "info";
  if (BRAIN_USAGE_SEVERITIES.includes(value as BrainUsageSeverity)) return value as BrainUsageSeverity;
  throw new Error(`severity must be one of ${BRAIN_USAGE_SEVERITIES.join(", ")}`);
}

function normalizeLimit(value: number | undefined): number {
  if (value === undefined) return DEFAULT_BRAIN_USAGE_LIMIT;
  if (!Number.isInteger(value) || value < 0) throw new Error("limit must be a non-negative integer");
  return Math.min(MAX_BRAIN_USAGE_LIMIT, value);
}

function validateUsageInput(input: BrainUsageInput): Required<Pick<BrainUsageInput, "severity">> &
  Omit<BrainUsageInput, "severity"> {
  const brain = validateOptionalString(input.brain, "brain", MAX_BRAIN_NAME_CHARS);
  const pages = validateStringList(input.pages, "pages", MAX_PAGE_CHARS);
  const related = validateStringList(input.related, "related", MAX_RELATED_CHARS);
  const outcome = validateOptionalString(input.outcome, "outcome", MAX_OUTCOME_CHARS);
  const triggerBucket = validateOptionalString(input.trigger_bucket, "trigger_bucket", MAX_TRIGGER_BUCKET_CHARS);
  const sessionId = validateOptionalString(input.session_id, "session_id", MAX_TRACE_ID_CHARS);
  const turnId = validateOptionalString(input.turn_id, "turn_id", MAX_TRACE_ID_CHARS);
  const messageId = validateOptionalString(input.message_id, "message_id", MAX_TRACE_ID_CHARS);
  const mcpCallId = validateOptionalString(input.mcp_call_id, "mcp_call_id", MAX_TRACE_ID_CHARS);
  const promptExcerpt = validateOptionalString(input.prompt_excerpt, "prompt_excerpt", MAX_PROMPT_EXCERPT_CHARS);
  const promptRaw = validateOptionalString(input.prompt_raw, "prompt_raw", MAX_PROMPT_RAW_CHARS);
  const validated = {
    event: validateEvent(input.event),
    trigger: boundedString(input.trigger, "trigger", MAX_TRIGGER_CHARS),
    severity: validateSeverity(input.severity),
    ...(brain !== undefined ? { brain } : {}),
    ...(pages !== undefined ? { pages } : {}),
    ...(related !== undefined ? { related } : {}),
    ...(outcome !== undefined ? { outcome } : {}),
    ...(triggerBucket !== undefined ? { trigger_bucket: triggerBucket } : {}),
    ...(sessionId !== undefined ? { session_id: sessionId } : {}),
    ...(turnId !== undefined ? { turn_id: turnId } : {}),
    ...(messageId !== undefined ? { message_id: messageId } : {}),
    ...(mcpCallId !== undefined ? { mcp_call_id: mcpCallId } : {}),
    ...(promptExcerpt !== undefined ? { prompt_excerpt: promptExcerpt } : {}),
    ...(promptRaw !== undefined ? { prompt_raw: promptRaw } : {}),
  };

  return {
    ...validated,
    trigger_bucket: triggerBucket ?? classifyTriggerBucket(validated),
  };
}

function validateBrainIdentitySnapshot(identity: BrainUsageIdentity): BrainUsageIdentity {
  const id = boundedString(identity.id, "brainIdentity.id", MAX_BRAIN_NAME_CHARS);
  const agentId = boundedString(identity.agentId, "brainIdentity.agentId", MAX_BRAIN_NAME_CHARS);
  const wikiAlias = boundedString(identity.wikiAlias, "brainIdentity.wikiAlias", MAX_BRAIN_NAME_CHARS);
  return validateBrainUsageIdentity({ id, agentId, wikiAlias });
}

function eventMayBeUnassigned(event: BrainUsageEvent): boolean {
  return event === "not_needed" || event === "disabled";
}

async function identityFieldsForRecord(
  input: RecordBrainUsageInput,
  event: BrainUsageEvent,
  compatibilityHint: string | undefined,
): Promise<Pick<BrainUsageRecord, "brain_id" | "brain_alias" | "brain_identity_status" | "brain_identity_error">> {
  if (eventMayBeUnassigned(event) && compatibilityHint === undefined && input.brainIdentity === undefined) return {};

  const resolution = input.brainIdentity === undefined
    ? await resolveCurrentBrainUsageIdentity({ anvilHome: input.anvilHome, env: input.env, homeDir: input.homeDir })
    : { kind: "resolved" as const, identity: validateBrainIdentitySnapshot(input.brainIdentity) };

  if (resolution.kind === "unresolved") {
    return {
      brain_identity_status: "unresolved",
      brain_identity_error: resolution.code,
    };
  }

  const identity = resolution.identity;
  if (
    compatibilityHint !== undefined
    && compatibilityHint !== identity.id
    && compatibilityHint !== identity.agentId
    && compatibilityHint !== identity.wikiAlias
  ) {
    throw new BrainUsageIdentityError(
      "BRAIN_IDENTITY_HINT_MISMATCH",
      `caller label ${JSON.stringify(compatibilityHint)} does not match the configured Brain`,
    );
  }
  return {
    brain_id: identity.id,
    brain_alias: identity.wikiAlias,
    brain_identity_status: "resolved",
  };
}

function validateWorkspace(value: unknown, lineNumber: number, path: string): WorkspaceRef {
  if (typeof value !== "object" || value === null || Array.isArray(value)) {
    throw new Error(`Invalid brain usage record on line ${lineNumber} in ${path}: workspace must be an object`);
  }
  const workspace = value as Record<string, unknown>;
  if (typeof workspace.key !== "string" || workspace.key.trim().length === 0) {
    throw new Error(`Invalid brain usage record on line ${lineNumber} in ${path}: workspace.key must be a non-empty string`);
  }
  if (workspace.kind !== "git" && workspace.kind !== "directory") {
    throw new Error(`Invalid brain usage record on line ${lineNumber} in ${path}: workspace.kind must be git or directory`);
  }
  if (typeof workspace.root !== "string" || workspace.root.trim().length === 0) {
    throw new Error(`Invalid brain usage record on line ${lineNumber} in ${path}: workspace.root must be a non-empty string`);
  }
  return {
    key: workspace.key,
    kind: workspace.kind,
    root: workspace.root,
    ...(typeof workspace.label === "string" ? { label: workspace.label } : {}),
  };
}

export function validateBrainUsageRecord(value: unknown, lineNumber: number, path: string): BrainUsageRecord {
  if (typeof value !== "object" || value === null || Array.isArray(value)) {
    throw new Error(`Invalid brain usage record on line ${lineNumber} in ${path}: record must be an object`);
  }
  const record = value as Record<string, unknown>;
  if (record.version !== LEGACY_BRAIN_USAGE_SCHEMA_VERSION && record.version !== BRAIN_USAGE_SCHEMA_VERSION) {
    throw new Error(
      `Invalid brain usage record on line ${lineNumber} in ${path}: version must be ${LEGACY_BRAIN_USAGE_SCHEMA_VERSION} or ${BRAIN_USAGE_SCHEMA_VERSION}`,
    );
  }
  const version = record.version;
  if (version === BRAIN_USAGE_SCHEMA_VERSION && record.brain !== undefined) {
    throw new Error(`Invalid brain usage record on line ${lineNumber} in ${path}: version 2 records must not use legacy brain labels`);
  }
  if (version === LEGACY_BRAIN_USAGE_SCHEMA_VERSION && record.recall_observation !== undefined) {
    throw new Error(`Invalid brain usage record on line ${lineNumber} in ${path}: version 1 records cannot contain recall observations`);
  }
  const body = validateUsageInput({
    event: record.event as BrainUsageEvent,
    brain: version === LEGACY_BRAIN_USAGE_SCHEMA_VERSION ? record.brain as string | undefined : undefined,
    trigger: record.trigger as string,
    pages: record.pages as string[] | undefined,
    related: record.related as string[] | undefined,
    outcome: record.outcome as string | undefined,
    severity: record.severity as BrainUsageSeverity,
    trigger_bucket: record.trigger_bucket as string | undefined,
    session_id: record.session_id as string | undefined,
    turn_id: record.turn_id as string | undefined,
    message_id: record.message_id as string | undefined,
    mcp_call_id: record.mcp_call_id as string | undefined,
    prompt_excerpt: record.prompt_excerpt as string | undefined,
    prompt_raw: record.prompt_raw as string | undefined,
  });
  if (typeof record.id !== "string" || record.id.trim().length === 0) {
    throw new Error(`Invalid brain usage record on line ${lineNumber} in ${path}: id must be a non-empty string`);
  }
  if (typeof record.created_at !== "string" || Number.isNaN(Date.parse(record.created_at))) {
    throw new Error(`Invalid brain usage record on line ${lineNumber} in ${path}: created_at must be an ISO timestamp`);
  }

  const brainId = validateOptionalString(record.brain_id, "brain_id", MAX_BRAIN_NAME_CHARS);
  const brainAlias = validateOptionalString(record.brain_alias, "brain_alias", MAX_BRAIN_NAME_CHARS);
  const identityStatus = validateOptionalString(record.brain_identity_status, "brain_identity_status", 32);
  const identityError = validateOptionalString(record.brain_identity_error, "brain_identity_error", 64);
  if (version === LEGACY_BRAIN_USAGE_SCHEMA_VERSION && [brainId, brainAlias, identityStatus, identityError].some((item) => item !== undefined)) {
    throw new Error(`Invalid brain usage record on line ${lineNumber} in ${path}: version 1 records cannot contain version 2 identity fields`);
  }
  if (identityStatus !== undefined && identityStatus !== "resolved" && identityStatus !== "unresolved") {
    throw new Error(`Invalid brain usage record on line ${lineNumber} in ${path}: brain_identity_status is invalid`);
  }
  if (identityStatus === "resolved" && (brainId === undefined || brainAlias === undefined || identityError !== undefined)) {
    throw new Error(`Invalid brain usage record on line ${lineNumber} in ${path}: resolved identity requires id and alias only`);
  }
  if (identityStatus === "resolved" && brainId !== undefined && brainAlias !== undefined) {
    const prefix = "agent:";
    const agentId = brainId.startsWith(prefix) ? brainId.slice(prefix.length) : "";
    try {
      validateBrainUsageIdentity({ id: brainId, agentId, wikiAlias: brainAlias });
    } catch (error) {
      throw new Error(
        `Invalid brain usage record on line ${lineNumber} in ${path}: ${error instanceof Error ? error.message : String(error)}`,
      );
    }
  }
  if (
    identityStatus === "unresolved"
    && (brainId !== undefined
      || brainAlias !== undefined
      || identityError === undefined
      || !(BRAIN_IDENTITY_ERROR_CODES as readonly string[]).includes(identityError))
  ) {
    throw new Error(`Invalid brain usage record on line ${lineNumber} in ${path}: unresolved identity requires one known error code`);
  }
  if (identityStatus === undefined && (brainId !== undefined || brainAlias !== undefined || identityError !== undefined)) {
    throw new Error(`Invalid brain usage record on line ${lineNumber} in ${path}: identity fields require brain_identity_status`);
  }
  if (version === BRAIN_USAGE_SCHEMA_VERSION && identityStatus === undefined && !eventMayBeUnassigned(body.event)) {
    throw new Error(
      `Invalid brain usage record on line ${lineNumber} in ${path}: ${body.event} records require resolved or unresolved Brain identity`,
    );
  }
  const recallObservation = record.recall_observation === undefined
    ? undefined
    : validateBrainRecallObservation(record.recall_observation);
  if (recallObservation !== undefined && !(BRAIN_USAGE_RECALL_EVENTS as readonly string[]).includes(body.event)) {
    throw new Error(
      `Invalid brain usage record on line ${lineNumber} in ${path}: recall_observation is allowed only on automatic recall events`,
    );
  }

  return {
    version,
    id: record.id,
    created_at: record.created_at,
    workspace: validateWorkspace(record.workspace, lineNumber, path),
    ...body,
    ...(brainId !== undefined ? { brain_id: brainId } : {}),
    ...(brainAlias !== undefined ? { brain_alias: brainAlias } : {}),
    ...(identityStatus !== undefined ? { brain_identity_status: identityStatus as BrainUsageIdentityStatus } : {}),
    ...(identityError !== undefined ? { brain_identity_error: identityError as BrainUsageIdentityErrorCode } : {}),
    ...(recallObservation !== undefined ? { recall_observation: recallObservation } : {}),
  };
}

function zeroCounts<const Events extends readonly string[]>(events: Events): Record<Events[number], number> {
  return Object.fromEntries(events.map((event) => [event, 0])) as Record<Events[number], number>;
}

function incrementCount(counts: Record<string, number>, key: string): void {
  counts[key] = (counts[key] ?? 0) + 1;
}

function countSort<T extends { total: number }>(key: (value: T) => string): (left: T, right: T) => number {
  return (left, right) => right.total - left.total || key(left).localeCompare(key(right));
}

function countLabel(total: number): string {
  return `${total} event${total === 1 ? "" : "s"}`;
}

function compactText(value: string | undefined, maxChars = 140): string | undefined {
  const text = value?.replace(/\s+/g, " ").trim();
  if (text === undefined || text.length === 0) return undefined;
  return text.length > maxChars ? `${text.slice(0, maxChars - 3)}...` : text;
}

type ProjectedBrainIdentity = {
  source: BrainUsageIdentitySource;
  id?: string;
  alias?: string;
  recordedAlias?: string;
  error?: string;
  legacyLabel?: string;
};

function projectBrainIdentity(record: BrainUsageRecord, registry: BrainUsageIdentityRegistry): ProjectedBrainIdentity {
  if (record.version === BRAIN_USAGE_SCHEMA_VERSION) {
    if (record.brain_identity_status === "resolved" && record.brain_id !== undefined && record.brain_alias !== undefined) {
      const alias = registry.identities.get(record.brain_id)?.wikiAlias ?? record.brain_alias;
      return {
        source: "recorded",
        id: record.brain_id,
        alias,
        ...(alias !== record.brain_alias ? { recordedAlias: record.brain_alias } : {}),
      };
    }
    if (record.brain_identity_status === "unresolved") {
      return { source: "unresolved", error: record.brain_identity_error ?? "BRAIN_IDENTITY_UNRESOLVED" };
    }
    return { source: "unassigned" };
  }

  if (record.brain === undefined) return { source: "unassigned" };
  const matchingIds = registry.labels.get(record.brain) ?? [];
  if (matchingIds.length === 0) {
    return { source: "unresolved", error: "LEGACY_BRAIN_IDENTITY_UNKNOWN", legacyLabel: record.brain };
  }
  if (matchingIds.length > 1) {
    return { source: "unresolved", error: "LEGACY_BRAIN_IDENTITY_AMBIGUOUS", legacyLabel: record.brain };
  }
  const identity = registry.identities.get(matchingIds[0]);
  if (identity === undefined) {
    return { source: "unresolved", error: "LEGACY_BRAIN_IDENTITY_UNKNOWN", legacyLabel: record.brain };
  }
  return {
    source: "legacy_config_match",
    id: identity.id,
    alias: identity.wikiAlias,
    recordedAlias: record.brain,
    legacyLabel: record.brain,
  };
}

function traceEvent(record: BrainUsageRecord, identity: ProjectedBrainIdentity): BrainUsageTraceEvent {
  const triggerBucket = record.trigger_bucket ?? classifyTriggerBucket(record);
  return {
    id: record.id,
    created_at: record.created_at,
    project_key: record.workspace.key,
    project_root: record.workspace.root,
    ...(record.workspace.label !== undefined ? { project_label: record.workspace.label } : {}),
    event: record.event,
    severity: record.severity,
    trigger: record.trigger,
    trigger_bucket: triggerBucket,
    ...(identity.id !== undefined ? { brain_id: identity.id } : {}),
    ...(identity.alias !== undefined ? { brain_alias: identity.alias } : {}),
    ...(identity.recordedAlias !== undefined ? { brain_recorded_alias: identity.recordedAlias } : {}),
    brain_identity_source: identity.source,
    ...(identity.error !== undefined ? { brain_identity_error: identity.error } : {}),
    ...(record.pages !== undefined ? { pages: record.pages } : {}),
    ...(record.related !== undefined ? { related: record.related } : {}),
    ...(record.outcome !== undefined ? { outcome: record.outcome } : {}),
    ...(record.session_id !== undefined ? { session_id: record.session_id } : {}),
    ...(record.turn_id !== undefined ? { turn_id: record.turn_id } : {}),
    ...(record.message_id !== undefined ? { message_id: record.message_id } : {}),
    ...(record.mcp_call_id !== undefined ? { mcp_call_id: record.mcp_call_id } : {}),
    ...(record.prompt_excerpt !== undefined ? { prompt_excerpt: record.prompt_excerpt } : {}),
    ...(record.prompt_raw !== undefined ? { prompt_raw: record.prompt_raw } : {}),
  };
}

function eventSortIndex(eventName: string): number {
  const index = BRAIN_USAGE_EVENTS.indexOf(eventName as BrainUsageEvent);
  return index === -1 ? Number.MAX_SAFE_INTEGER : index;
}

function lensEventState(event: Pick<BrainUsageTraceEvent, "event" | "severity">): "primary" | "muted" | "inactive" {
  if (event.severity === "error" || event.event === "wrong" || event.event === "eval_failed") return "inactive";
  if (event.severity === "warn" || ["blocked", "missed_update", "not_needed", "stale"].includes(event.event)) {
    return "muted";
  }
  return "primary";
}

function strongestLensState(states: Array<"primary" | "muted" | "inactive">): "primary" | "muted" | "inactive" {
  if (states.includes("inactive")) return "inactive";
  if (states.includes("muted")) return "muted";
  return "primary";
}

function projectTraceLabel(project: BrainUsageTraceProject): string {
  return project.project_label ?? project.project_root ?? project.project_key;
}

function promptTitle(prompt: BrainUsageTracePrompt, fallback: string): string {
  return compactText(prompt.prompt_excerpt, 82) ?? prompt.message_id ?? prompt.turn_id ?? fallback;
}

function eventReference(event: BrainUsageTraceEvent): string | undefined {
  const pages = event.pages !== undefined && event.pages.length > 0 ? `Pages: ${event.pages.join(", ")}` : "";
  const related = event.related !== undefined && event.related.length > 0 ? `Related: ${event.related.join(", ")}` : "";
  return compactText([pages, related].filter(Boolean).join(" | "), 180);
}

function groupBy<T>(items: T[], keyFn: (item: T) => string): Array<{ key: string; items: T[] }> {
  const groups = new Map<string, { key: string; items: T[] }>();
  for (const item of items) {
    const key = keyFn(item) || "unknown";
    const group = groups.get(key) ?? { key, items: [] };
    group.items.push(item);
    groups.set(key, group);
  }
  return Array.from(groups.values());
}

function graphIdSegment(value: string): string {
  return encodeURIComponent(value);
}

function collectProjectTraceItems(project: BrainUsageTraceProject): Array<{
  bucket: BrainUsageTraceBucket;
  session: BrainUsageTraceSession;
  prompt: BrainUsageTracePrompt;
  event: BrainUsageTraceEvent;
}> {
  const items: Array<{
    bucket: BrainUsageTraceBucket;
    session: BrainUsageTraceSession;
    prompt: BrainUsageTracePrompt;
    event: BrainUsageTraceEvent;
  }> = [];
  for (const bucket of project.buckets) {
    for (const session of bucket.sessions) {
      for (const prompt of session.prompts) {
        for (const event of prompt.events) {
          items.push({ bucket, session, prompt, event });
        }
      }
    }
  }
  return items;
}

export function buildBrainUsageLensGraph(metrics: BrainUsageMetricsOk): BrainUsageLensGraph {
  const rootId = "brain:usage";
  const nodes: BrainUsageLensGraphNode[] = [
    {
      id: rootId,
      label: "Brain",
      kind: "brain",
      sublabel: countLabel(metrics.total),
      data: {
        brains: metrics.by_brain,
        brain_aliases: metrics.brain_aliases,
        brain_identity: metrics.brain_identity,
      },
    },
  ];
  const edges: BrainUsageLensGraphEdge[] = [];

  function addEdge(source: string, target: string, label: string): void {
    edges.push({ id: `edge:${edges.length + 1}`, source, target, label });
  }

  for (const project of metrics.trace.projects) {
    const projectId = `project:${graphIdSegment(project.project_key)}`;
    nodes.push({
      id: projectId,
      label: projectTraceLabel(project),
      kind: "project",
      sublabel: countLabel(project.total),
      data: {
        project_key: project.project_key,
        project_root: project.project_root,
      },
    });
    addEdge(rootId, projectId, "project");

    const bucketGroups = groupBy(collectProjectTraceItems(project), ({ bucket }) => bucket.bucket || DEFAULT_TRIGGER_BUCKET)
      .sort((left, right) => right.items.length - left.items.length || left.key.localeCompare(right.key));

    for (const bucketGroup of bucketGroups) {
      const bucketId = `${projectId}:bucket:${graphIdSegment(bucketGroup.key)}`;
      nodes.push({
        id: bucketId,
        label: bucketGroup.key,
        kind: "bucket",
        sublabel: countLabel(bucketGroup.items.length),
      });
      addEdge(projectId, bucketId, "bucket");

      const eventGroups = groupBy(bucketGroup.items, ({ event }) => event.event)
        .sort((left, right) => right.items.length - left.items.length || eventSortIndex(left.key) - eventSortIndex(right.key) || left.key.localeCompare(right.key));

      for (const eventGroup of eventGroups) {
        const eventId = `${bucketId}:event:${graphIdSegment(eventGroup.key)}`;
        const eventStates = eventGroup.items.map(({ event }) => lensEventState(event));
        const eventState = strongestLensState(eventStates);
        nodes.push({
          id: eventId,
          label: eventGroup.key,
          kind: "event",
          state: eventState,
          sublabel: countLabel(eventGroup.items.length),
          body: BRAIN_USAGE_INCIDENT_EVENTS.includes(eventGroup.key as BrainUsageIncidentEvent) ? "incident" : "coverage",
        });
        addEdge(bucketId, eventId, "event");

        const promptGroups = groupBy(
          eventGroup.items,
          ({ prompt, event }) => prompt.message_id || prompt.turn_id || event.message_id || event.turn_id || event.id,
        ).sort((left, right) => right.items.length - left.items.length || left.key.localeCompare(right.key));

        for (const promptGroup of promptGroups) {
          const first = promptGroup.items[0];
          if (first === undefined) continue;
          const promptId = `${eventId}:prompt:${graphIdSegment(promptGroup.key)}`;
          nodes.push({
            id: promptId,
            label: promptTitle(first.prompt, promptGroup.key),
            kind: "prompt",
            sublabel: `${first.session.session_id} / ${first.prompt.message_id || first.prompt.turn_id || promptGroup.key}`,
            body: compactText(first.prompt.prompt_excerpt, 260),
            data: {
              session_id: first.session.session_id,
              message_id: first.prompt.message_id,
              turn_id: first.prompt.turn_id,
              total: promptGroup.items.length,
            },
          });
          addEdge(eventId, promptId, "prompt");

          for (const { event } of promptGroup.items) {
            const reasonTitle = compactText(event.outcome || event.trigger || event.id, 82) ?? event.id;
            const reasonDetail = eventReference(event);
            const reasonId = `${promptId}:reason:${graphIdSegment(event.id)}`;
            nodes.push({
              id: reasonId,
              label: reasonTitle,
              kind: "reason",
              state: lensEventState(event),
              sublabel: event.created_at || event.severity,
              body: compactText([event.trigger, reasonDetail].filter(Boolean).join("\n"), 500),
              data: {
                id: event.id,
                event: event.event,
                severity: event.severity,
                trigger_bucket: event.trigger_bucket,
                brain_id: event.brain_id,
                brain_alias: event.brain_alias,
                brain_recorded_alias: event.brain_recorded_alias,
                brain_identity_source: event.brain_identity_source,
                brain_identity_error: event.brain_identity_error,
                mcp_call_id: event.mcp_call_id,
                pages: event.pages,
                related: event.related,
              },
            });
            addEdge(promptId, reasonId, "reason");
          }
        }
      }
    }
  }

  return {
    nodes,
    edges,
    meta: { title: "Brain Usage Trace", direction: "RIGHT", root: rootId },
  };
}

function buildTrace(records: BrainUsageRecord[], identities: Map<BrainUsageRecord, ProjectedBrainIdentity>): BrainUsageTraceOutput {
  type PromptAccumulator = BrainUsageTracePrompt;
  type SessionAccumulator = Omit<BrainUsageTraceSession, "prompts"> & { promptMap: Map<string, PromptAccumulator> };
  type BucketAccumulator = Omit<BrainUsageTraceBucket, "sessions"> & { sessionMap: Map<string, SessionAccumulator> };
  type ProjectAccumulator = Omit<BrainUsageTraceProject, "buckets"> & { bucketMap: Map<string, BucketAccumulator> };

  const projectMap = new Map<string, ProjectAccumulator>();

  for (const record of records) {
    const bucketName = record.trigger_bucket ?? classifyTriggerBucket(record);
    const sessionId = record.session_id ?? DEFAULT_SESSION_ID;
    const promptId = record.message_id ?? record.turn_id ?? record.id;
    const event = traceEvent(record, identities.get(record) ?? { source: "unassigned" });

    let project = projectMap.get(record.workspace.key);
    if (project === undefined) {
      project = {
        project_key: record.workspace.key,
        project_root: record.workspace.root,
        ...(record.workspace.label !== undefined ? { project_label: record.workspace.label } : {}),
        total: 0,
        bucketMap: new Map(),
      };
      projectMap.set(record.workspace.key, project);
    }
    project.total += 1;

    let bucket = project.bucketMap.get(bucketName);
    if (bucket === undefined) {
      bucket = { bucket: bucketName, total: 0, sessionMap: new Map() };
      project.bucketMap.set(bucketName, bucket);
    }
    bucket.total += 1;

    let session = bucket.sessionMap.get(sessionId);
    if (session === undefined) {
      session = { session_id: sessionId, total: 0, promptMap: new Map() };
      bucket.sessionMap.set(sessionId, session);
    }
    session.total += 1;

    let prompt = session.promptMap.get(promptId);
    if (prompt === undefined) {
      prompt = {
        message_id: promptId,
        total: 0,
        ...(record.turn_id !== undefined ? { turn_id: record.turn_id } : {}),
        ...(record.prompt_excerpt !== undefined ? { prompt_excerpt: record.prompt_excerpt } : {}),
        ...(record.prompt_raw !== undefined ? { prompt_raw: record.prompt_raw } : {}),
        events: [],
      };
      session.promptMap.set(promptId, prompt);
    }
    prompt.total += 1;
    if (prompt.turn_id === undefined && record.turn_id !== undefined) prompt.turn_id = record.turn_id;
    if (prompt.prompt_excerpt === undefined && record.prompt_excerpt !== undefined) prompt.prompt_excerpt = record.prompt_excerpt;
    if (prompt.prompt_raw === undefined && record.prompt_raw !== undefined) prompt.prompt_raw = record.prompt_raw;
    prompt.events.push(event);
  }

  const projects = Array.from(projectMap.values())
    .map((project) => ({
      project_key: project.project_key,
      project_root: project.project_root,
      ...(project.project_label !== undefined ? { project_label: project.project_label } : {}),
      total: project.total,
      buckets: Array.from(project.bucketMap.values())
        .map((bucket) => ({
          bucket: bucket.bucket,
          total: bucket.total,
          sessions: Array.from(bucket.sessionMap.values())
            .map((session) => ({
              session_id: session.session_id,
              total: session.total,
              prompts: Array.from(session.promptMap.values()).sort(countSort((prompt) => prompt.message_id)),
            }))
            .sort(countSort((session) => session.session_id)),
        }))
        .sort(countSort((bucket) => bucket.bucket)),
    }))
    .sort(countSort((project) => project.project_key));

  return {
    projects,
    recent: records
      .slice(-20)
      .reverse()
      .map((record) => traceEvent(record, identities.get(record) ?? { source: "unassigned" })),
  };
}

async function readBrainUsageRecords(input: BrainUsageWorkspaceOptions = {}): Promise<BrainUsageRecordReadOutput> {
  const paths = resolveBrainUsageWorkspace(input);
  let text;
  try {
    text = await readFile(paths.usagePath, "utf8");
  } catch (error) {
    if (typeof error === "object" && error !== null && "code" in error && error.code === "ENOENT") {
      return { kind: "missing", path: paths.usagePath, message: `${paths.usagePath} does not exist` };
    }
    const message = error instanceof Error ? error.message : String(error);
    return { kind: "malformed", path: paths.usagePath, message };
  }

  return parseBrainUsageRecords(text, paths.usagePath);
}

function parseBrainUsageRecords(text: string, path: string): BrainUsageRecordReadOutput {
  const records: BrainUsageRecord[] = [];
  const lines = text.split("\n").filter((line) => line.trim().length > 0);
  for (const [index, line] of lines.entries()) {
    try {
      records.push(validateBrainUsageRecord(JSON.parse(line), index + 1, path));
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      return { kind: "malformed", path, message };
    }
  }
  return { kind: "ok", path, records };
}

function compareBrainUsageRecords(left: BrainUsageRecord, right: BrainUsageRecord): number {
  return Date.parse(left.created_at) - Date.parse(right.created_at) || left.id.localeCompare(right.id);
}

async function readAllBrainUsageRecords(input: BrainUsageWorkspaceOptions = {}): Promise<BrainUsageRecordReadOutput> {
  const paths = resolveBrainUsageWorkspace(input);
  const workspacesRoot = join(paths.brainUsageRoot, "workspaces");
  let entries;
  try {
    entries = await readdir(workspacesRoot, { withFileTypes: true });
  } catch (error) {
    if (typeof error === "object" && error !== null && "code" in error && error.code === "ENOENT") {
      return { kind: "missing", path: workspacesRoot, message: `${workspacesRoot} does not exist` };
    }
    const message = error instanceof Error ? error.message : String(error);
    return { kind: "malformed", path: workspacesRoot, message };
  }

  const records: BrainUsageRecord[] = [];
  for (const entry of entries.filter((candidate) => candidate.isDirectory()).sort((left, right) => left.name.localeCompare(right.name))) {
    const usagePath = join(workspacesRoot, entry.name, "usage.jsonl");
    let text;
    try {
      text = await readFile(usagePath, "utf8");
    } catch (error) {
      if (typeof error === "object" && error !== null && "code" in error && error.code === "ENOENT") continue;
      const message = error instanceof Error ? error.message : String(error);
      return { kind: "malformed", path: usagePath, message };
    }
    const parsed = parseBrainUsageRecords(text, usagePath);
    if (parsed.kind !== "ok") return parsed;
    records.push(...parsed.records);
  }

  return { kind: "ok", path: workspacesRoot, records: records.sort(compareBrainUsageRecords) };
}

export function resolveBrainUsageWorkspace(options: BrainUsageWorkspaceOptions = {}): BrainUsagePaths {
  const env = options.env ?? process.env;
  const homeDir = options.homeDir ?? env.HOME ?? homedir();
  const stateRoot = resolve(options.stateRoot ?? env.ANVIL_STATE_ROOT ?? join(homeDir, ".anvil", "state"));
  const continuityPaths = resolveContinuityWorkspace({ cwd: options.cwd, stateRoot });
  const brainUsageRoot = join(continuityPaths.stateRoot, "brain-usage");
  const workspaceDir = join(brainUsageRoot, "workspaces", continuityPaths.workspace.key);
  return {
    workspace: continuityPaths.workspace,
    stateRoot: continuityPaths.stateRoot,
    brainUsageRoot,
    workspaceDir,
    usagePath: join(workspaceDir, "usage.jsonl"),
  };
}

export async function recordBrainUsage(input: RecordBrainUsageInput): Promise<RecordBrainUsageOutput> {
  const paths = resolveBrainUsageWorkspace(input);
  const now = (input.now ?? nowIso)();
  const validatedUsage = validateUsageInput(input.usage);
  const { brain: compatibilityHint, ...usage } = validatedUsage;
  const recallObservation = input.automaticRecallObservation === undefined
    ? undefined
    : validateBrainRecallObservation(input.automaticRecallObservation);
  if (recallObservation !== undefined && !(BRAIN_USAGE_RECALL_EVENTS as readonly string[]).includes(usage.event)) {
    throw new Error("automaticRecallObservation is allowed only on automatic recall events");
  }
  const identityFields = await identityFieldsForRecord(input, usage.event, compatibilityHint);
  const record: BrainUsageRecord = {
    version: BRAIN_USAGE_SCHEMA_VERSION,
    id: (input.id ?? newUsageId)(),
    created_at: now,
    workspace: paths.workspace,
    ...usage,
    ...identityFields,
    ...(recallObservation !== undefined ? { recall_observation: recallObservation } : {}),
  };

  try {
    const existing = await readFile(paths.usagePath, "utf8");
    const parsed = parseBrainUsageRecords(existing, paths.usagePath);
    if (parsed.kind === "ok") {
      const matchingRecord = parsed.records.find((candidate) => candidate.id === record.id);
      if (matchingRecord !== undefined) return { paths, record: matchingRecord };
    }
  } catch (error) {
    if (!(typeof error === "object" && error !== null && "code" in error && error.code === "ENOENT")) throw error;
  }

  await mkdir(dirname(paths.usagePath), { recursive: true });
  await appendFile(paths.usagePath, `${JSON.stringify(record)}\n`, "utf8");
  return { paths, record };
}

export async function recordBoundBrainUsage(input: RecordBoundBrainUsageInput): Promise<RecordBoundBrainUsageOutput> {
  const binding = assertActiveWorkContextBinding(input.binding, input.bindingNow);
  const result = await recordBrainUsage({
    cwd: binding.collaboration_space.root,
    stateRoot: resolveWorkContextStateRoot(input.stateRoot),
    anvilHome: input.anvilHome,
    env: input.env,
    homeDir: input.homeDir,
    usage: { ...input.usage, session_id: binding.session_id },
    ...(input.now ? { now: input.now } : {}),
    ...(input.id ? { id: input.id } : {}),
  });
  return { ...result, binding: workContextBindingView(binding) };
}

export async function readBrainUsage(input: ReadBrainUsageInput = {}): Promise<ReadBrainUsageOutput> {
  const limit = normalizeLimit(input.limit);
  const result = input.scope === "all" ? await readAllBrainUsageRecords(input) : await readBrainUsageRecords(input);
  if (result.kind !== "ok") return result;

  const items = limit === 0 ? [] : result.records.slice(-limit);
  return { kind: "ok", path: result.path, items, total: result.records.length, truncated: result.records.length > items.length };
}

function isBrainMaintenanceIncident(record: BrainUsageRecord): boolean {
  return record.event === "stale" || record.event === "wrong" || record.event === "missed_update";
}

function isBrainMaintenanceResolution(record: BrainUsageRecord): boolean {
  return record.event === "updated" || record.event === "not_needed";
}

export async function readBrainMaintenanceClosure(
  input: BrainUsageWorkspaceOptions & { sessionId: string },
): Promise<BrainMaintenanceClosureOutput> {
  const result = await readBrainUsageRecords(input);
  if (result.kind !== "ok") return result;

  const incidents: BrainUsageRecord[] = [];
  const unresolved = new Map<string, BrainUsageRecord>();
  for (const record of result.records) {
    if (record.session_id !== input.sessionId) continue;
    if (isBrainMaintenanceIncident(record)) {
      incidents.push(record);
      unresolved.set(record.id, record);
      continue;
    }
    if (!isBrainMaintenanceResolution(record)) continue;
    for (const relatedId of record.related ?? []) unresolved.delete(relatedId);
  }

  return {
    kind: "ok",
    path: result.path,
    session_id: input.sessionId,
    incidents,
    unresolved: [...unresolved.values()],
  };
}

export async function summarizeBrainUsage(input: SummarizeBrainUsageInput = {}): Promise<BrainUsageMetricsOutput> {
  const result = input.scope === "all" ? await readAllBrainUsageRecords(input) : await readBrainUsageRecords(input);
  if (result.kind !== "ok") return result;
  const records = [...result.records].sort(compareBrainUsageRecords);
  const registry = await loadBrainUsageIdentityRegistry({ anvilHome: input.anvilHome, env: input.env, homeDir: input.homeDir });

  const byEvent = zeroCounts(BRAIN_USAGE_EVENTS);
  const coverageByEvent = zeroCounts(BRAIN_USAGE_COVERAGE_EVENTS);
  const incidentByEvent = zeroCounts(BRAIN_USAGE_INCIDENT_EVENTS);
  const bySeverity = zeroCounts(BRAIN_USAGE_SEVERITIES);
  const byBrain: Record<string, number> = {};
  const brainAliases: Record<string, string> = {};
  const byTriggerBucket: Record<string, number> = {};
  const projectedIdentities = new Map<BrainUsageRecord, ProjectedBrainIdentity>();
  const identityDiagnostics = new Map<string, { code: string; label?: string; agent_id?: string; count: number }>();
  let resolvedIdentityEvents = 0;
  let legacyNormalizedEvents = 0;
  let unresolvedIdentityEvents = 0;
  let unassignedIdentityEvents = 0;

  const addIdentityDiagnostic = (code: string, label?: string, agentId?: string): void => {
    const key = `${code}\u0000${label ?? ""}\u0000${agentId ?? ""}`;
    const existing = identityDiagnostics.get(key);
    if (existing !== undefined) {
      existing.count += 1;
      return;
    }
    identityDiagnostics.set(key, {
      code,
      ...(label !== undefined ? { label } : {}),
      ...(agentId !== undefined ? { agent_id: agentId } : {}),
      count: 1,
    });
  };

  for (const diagnostic of registry.diagnostics) {
    addIdentityDiagnostic(diagnostic.code, undefined, diagnostic.agentId);
  }

  for (const record of records) {
    const identity = projectBrainIdentity(record, registry);
    projectedIdentities.set(record, identity);
    byEvent[record.event] += 1;
    bySeverity[record.severity] += 1;
    if (identity.id !== undefined && identity.alias !== undefined) {
      byBrain[identity.id] = (byBrain[identity.id] ?? 0) + 1;
      brainAliases[identity.id] = identity.alias;
      resolvedIdentityEvents += 1;
      if (identity.source === "legacy_config_match") legacyNormalizedEvents += 1;
    } else if (identity.source === "unresolved") {
      unresolvedIdentityEvents += 1;
      addIdentityDiagnostic(identity.error ?? "BRAIN_IDENTITY_UNRESOLVED", identity.legacyLabel);
    } else {
      unassignedIdentityEvents += 1;
    }
    incrementCount(byTriggerBucket, record.trigger_bucket ?? classifyTriggerBucket(record));
    if ((BRAIN_USAGE_COVERAGE_EVENTS as readonly string[]).includes(record.event)) {
      coverageByEvent[record.event as BrainUsageCoverageEvent] += 1;
    }
    if ((BRAIN_USAGE_INCIDENT_EVENTS as readonly string[]).includes(record.event)) {
      incidentByEvent[record.event as BrainUsageIncidentEvent] += 1;
    }
  }

  const coverageTotal = BRAIN_USAGE_COVERAGE_EVENTS.reduce((total, event) => total + coverageByEvent[event], 0);
  const incidentTotal = BRAIN_USAGE_INCIDENT_EVENTS.reduce((total, event) => total + incidentByEvent[event], 0);

  return {
    kind: "ok",
    path: result.path,
    total: records.length,
    by_event: byEvent,
    by_severity: bySeverity,
    by_brain: byBrain,
    brain_aliases: brainAliases,
    brain_identity: {
      resolved_events: resolvedIdentityEvents,
      legacy_normalized_events: legacyNormalizedEvents,
      unresolved_events: unresolvedIdentityEvents,
      unassigned_events: unassignedIdentityEvents,
      diagnostics: Array.from(identityDiagnostics.values()).sort(
        (left, right) => left.code.localeCompare(right.code)
          || (left.label ?? "").localeCompare(right.label ?? "")
          || (left.agent_id ?? "").localeCompare(right.agent_id ?? ""),
      ),
    },
    by_trigger_bucket: byTriggerBucket,
    recall: summarizeRecallMetrics(records),
    coverage: { total: coverageTotal, by_event: coverageByEvent },
    incidents: { total: incidentTotal, by_event: incidentByEvent },
    trace: buildTrace(records, projectedIdentities),
    ...(records[0] !== undefined ? { first_created_at: records[0].created_at } : {}),
    ...(records.at(-1) !== undefined ? { last_created_at: records.at(-1)?.created_at } : {}),
  };
}
