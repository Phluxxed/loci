import type { BrowserCommandRunner } from "./corporate-ca.ts";
import { runBrowserCommand } from "./docker.ts";
import {
  BrowserConfigurationError,
  redactBrowserText,
  type BrowserLaunchPolicy,
  type BrowserProfileStatus,
} from "./policy.ts";

type DockerInspect = {
  Image?: unknown;
  State?: { Running?: unknown };
  Config?: {
    Image?: unknown;
    Env?: unknown;
    Labels?: unknown;
  };
  HostConfig?: {
    PortBindings?: unknown;
    RestartPolicy?: { Name?: unknown };
    ShmSize?: unknown;
  };
};

export type RendererStatusInput = {
  policy: BrowserLaunchPolicy;
  token: string;
  run?: BrowserCommandRunner;
  checkHealth?: (policy: BrowserLaunchPolicy, token: string) => Promise<boolean>;
};

export type ReconcileRendererInput = RendererStatusInput & {
  waitUntilHealthy?: (policy: BrowserLaunchPolicy, token: string) => Promise<boolean>;
};

type ActualRenderer =
  | { kind: "missing" }
  | { kind: "present"; inspect: DockerInspect; owned: boolean; matches: boolean; running: boolean };

function diagnostic(
  code: BrowserProfileStatus["diagnostics"][number]["code"],
  message: string,
  remediation?: string,
): BrowserProfileStatus["diagnostics"][number] {
  return { code, severity: "error", message: message.slice(0, 240), ...(remediation ? { remediation: remediation.slice(0, 240) } : {}) };
}

function baseStatus(policy: BrowserLaunchPolicy): BrowserProfileStatus {
  return {
    mode: policy.mode,
    state: "unconfigured",
    image_ref: policy.container.image_ref,
    renderer_status: "missing",
    registration_status: "unknown",
    ...(policy.container.labels["io.anvil.browser.ca-fingerprint"]
      ? { ca_fingerprint: policy.container.labels["io.anvil.browser.ca-fingerprint"] }
      : {}),
    diagnostics: [],
  };
}

function envHas(value: unknown, expected: string): boolean {
  return Array.isArray(value) && value.some((entry) => entry === expected);
}

function matchesDesired(
  inspect: DockerInspect,
  policy: BrowserLaunchPolicy,
  token: string,
  desiredImageId: string,
): boolean {
  const labels = inspect.Config?.Labels;
  if (typeof labels !== "object" || labels === null) return false;
  const labelRecord = labels as Record<string, unknown>;
  for (const [key, value] of Object.entries(policy.container.labels)) {
    if (labelRecord[key] !== value) return false;
  }

  const portBindings = inspect.HostConfig?.PortBindings;
  if (typeof portBindings !== "object" || portBindings === null) return false;
  const binding = (portBindings as Record<string, unknown>)["3000/tcp"];
  if (!Array.isArray(binding) || binding.length !== 1 || typeof binding[0] !== "object" || binding[0] === null) return false;
  const bindingRecord = binding[0] as Record<string, unknown>;

  return (
    inspect.Image === desiredImageId &&
    inspect.Config?.Image === policy.container.image_ref &&
    envHas(inspect.Config?.Env, `TOKEN=${token}`) &&
    envHas(inspect.Config?.Env, `CONCURRENT=${policy.container.concurrent}`) &&
    envHas(inspect.Config?.Env, `TIMEOUT=${policy.container.timeout_ms}`) &&
    bindingRecord.HostIp === policy.container.bind_host &&
    bindingRecord.HostPort === String(policy.container.host_port) &&
    inspect.HostConfig?.RestartPolicy?.Name === policy.container.restart_policy &&
    inspect.HostConfig?.ShmSize === 2 * 1024 * 1024 * 1024
  );
}

function parseInspect(stdout: string): Omit<Extract<ActualRenderer, { kind: "present" }>, "matches"> {
  let parsed: unknown;
  try {
    parsed = JSON.parse(stdout);
  } catch {
    throw new BrowserConfigurationError("DOCKER_COMMAND_FAILED", "Docker inspect returned malformed JSON.");
  }
  if (!Array.isArray(parsed) || parsed.length !== 1 || typeof parsed[0] !== "object" || parsed[0] === null) {
    throw new BrowserConfigurationError("DOCKER_COMMAND_FAILED", "Docker inspect returned an unexpected container shape.");
  }
  const inspect = parsed[0] as DockerInspect;
  const labels = inspect.Config?.Labels;
  const owned = typeof labels === "object" && labels !== null && (labels as Record<string, unknown>)["io.anvil.browser.owner"] === "anvil";
  return {
    kind: "present",
    inspect,
    owned,
    running: inspect.State?.Running === true,
  };
}

async function dockerAvailable(run: BrowserCommandRunner): Promise<boolean> {
  try {
    const result = await run("docker", ["version", "--format", "{{.Server.Version}}"]);
    return result.status === 0 && result.stdout.trim().length > 0;
  } catch {
    return false;
  }
}

async function inspectRenderer(
  policy: BrowserLaunchPolicy,
  token: string,
  run: BrowserCommandRunner,
  compareDesired = true,
): Promise<ActualRenderer> {
  const result = await run("docker", ["inspect", policy.container.name]);
  if (result.status !== 0) {
    if (/no such (object|container)/i.test(result.stderr)) return { kind: "missing" };
    throw new BrowserConfigurationError(
      "DOCKER_COMMAND_FAILED",
      `Docker inspect failed: ${redactBrowserText(result.stderr).slice(0, 240)}`,
    );
  }
  const actual = parseInspect(result.stdout);
  if (!actual.owned || !compareDesired) return { ...actual, matches: false };

  const imageResult = await run("docker", ["image", "inspect", policy.container.image_ref, "--format", "{{.Id}}"]);
  if (imageResult.status !== 0) {
    throw new BrowserConfigurationError(
      "DOCKER_COMMAND_FAILED",
      `Docker image inspect failed: ${redactBrowserText(imageResult.stderr).slice(0, 240)}`,
    );
  }
  const desiredImageId = imageResult.stdout.trim();
  if (!/^sha256:[a-f0-9]{64}$/.test(desiredImageId)) {
    throw new BrowserConfigurationError("DOCKER_COMMAND_FAILED", "Docker image inspect returned an unexpected image ID.");
  }
  return { ...actual, matches: matchesDesired(actual.inspect, policy, token, desiredImageId) };
}

async function defaultHealthCheck(policy: BrowserLaunchPolicy, token: string): Promise<boolean> {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 2_000);
  try {
    const response = await fetch(
      `http://${policy.container.bind_host}:${policy.container.host_port}/json/version?token=${encodeURIComponent(token)}`,
      { signal: controller.signal },
    );
    return response.ok;
  } catch {
    return false;
  } finally {
    clearTimeout(timeout);
  }
}

export async function waitForRendererHealth(
  policy: BrowserLaunchPolicy,
  token: string,
  options: {
    attempts?: number;
    intervalMs?: number;
    checkHealth?: (policy: BrowserLaunchPolicy, token: string) => Promise<boolean>;
    sleep?: (milliseconds: number) => Promise<void>;
  } = {},
): Promise<boolean> {
  const attempts = options.attempts ?? 60;
  const intervalMs = options.intervalMs ?? 500;
  const checkHealth = options.checkHealth ?? defaultHealthCheck;
  const sleep = options.sleep ?? ((milliseconds: number) => new Promise<void>((resolve) => setTimeout(resolve, milliseconds)));
  for (let attempt = 0; attempt < attempts; attempt += 1) {
    if (await checkHealth(policy, token)) return true;
    if (attempt + 1 < attempts) await sleep(intervalMs);
  }
  return false;
}

export async function readRendererStatus(input: RendererStatusInput): Promise<BrowserProfileStatus> {
  const run = input.run ?? runBrowserCommand;
  const status = baseStatus(input.policy);
  if (!(await dockerAvailable(run))) {
    return {
      ...status,
      state: "degraded",
      renderer_status: "unknown",
      diagnostics: [diagnostic("DOCKER_UNAVAILABLE", "Docker daemon is unavailable.", "Start Docker Desktop and rerun browser doctor.")],
    };
  }

  let actual: ActualRenderer;
  try {
    actual = await inspectRenderer(input.policy, input.token, run);
  } catch (error) {
    const message = error instanceof Error ? error.message : "Docker inspect failed.";
    return {
      ...status,
      state: "degraded",
      renderer_status: "unknown",
      diagnostics: [diagnostic("DOCKER_COMMAND_FAILED", message)],
    };
  }
  if (actual.kind === "missing") return status;
  if (!actual.owned) {
    return {
      ...status,
      state: "degraded",
      renderer_status: actual.running ? "unknown" : "stopped",
      diagnostics: [diagnostic("RENDERER_UNOWNED", `Container ${input.policy.container.name} is not owned by Anvil.`)],
    };
  }
  if (!actual.matches) {
    return {
      ...status,
      state: "stale",
      renderer_status: actual.running ? "unknown" : "stopped",
      diagnostics: [diagnostic("RENDERER_SPEC_STALE", "Renderer container does not match the pinned Anvil spec.")],
    };
  }
  if (!actual.running) return { ...status, state: "stopped", renderer_status: "stopped" };

  const healthy = await (input.checkHealth ?? defaultHealthCheck)(input.policy, input.token);
  if (!healthy) {
    return {
      ...status,
      state: "degraded",
      renderer_status: "unhealthy",
      diagnostics: [diagnostic("RENDERER_UNHEALTHY", "Renderer container is running but its CDP health endpoint failed.")],
    };
  }
  return { ...status, state: "ready", renderer_status: "healthy" };
}

function dockerRunArgs(policy: BrowserLaunchPolicy): string[] {
  const args = [
    "run",
    "--detach",
    "--name",
    policy.container.name,
    "--restart",
    policy.container.restart_policy,
    "--shm-size",
    policy.container.shm_size,
    "--publish",
    `${policy.container.bind_host}:${policy.container.host_port}:${policy.container.container_port}`,
    "--env",
    "TOKEN",
    "--env",
    `CONCURRENT=${policy.container.concurrent}`,
    "--env",
    `TIMEOUT=${policy.container.timeout_ms}`,
  ];
  for (const [key, value] of Object.entries(policy.container.labels).sort(([left], [right]) => left.localeCompare(right))) {
    args.push("--label", `${key}=${value}`);
  }
  args.push(policy.container.image_ref);
  return args;
}

async function runDockerOrThrow(
  run: BrowserCommandRunner,
  args: string[],
  token?: string,
): Promise<void> {
  const result = await run("docker", args, token ? { env: { TOKEN: token } } : undefined);
  if (result.status === 0) return;
  const detail = redactBrowserText(result.stderr).slice(0, 240);
  const code = /port is already allocated|address already in use/i.test(detail) ? "PORT_UNAVAILABLE" : "DOCKER_COMMAND_FAILED";
  throw new BrowserConfigurationError(code, `Docker ${args[0]} failed: ${detail}`);
}

export async function reconcileRenderer(input: ReconcileRendererInput): Promise<BrowserProfileStatus> {
  const run = input.run ?? runBrowserCommand;
  const waitUntilHealthy =
    input.waitUntilHealthy ??
    ((policy: BrowserLaunchPolicy, token: string) =>
      waitForRendererHealth(policy, token, { ...(input.checkHealth ? { checkHealth: input.checkHealth } : {}) }));
  if (!(await dockerAvailable(run))) {
    throw new BrowserConfigurationError("DOCKER_UNAVAILABLE", "Docker daemon is unavailable.");
  }

  const actual = await inspectRenderer(input.policy, input.token, run);
  if (actual.kind === "present" && !actual.owned) {
    throw new BrowserConfigurationError("RENDERER_UNOWNED", `Refusing to replace unowned container ${input.policy.container.name}.`);
  }

  if (actual.kind === "present" && actual.matches && actual.running) {
    const healthy = await waitUntilHealthy(input.policy, input.token);
    if (healthy) return { ...baseStatus(input.policy), state: "ready", renderer_status: "healthy" };
    await runDockerOrThrow(run, ["rm", "--force", input.policy.container.name]);
  } else if (actual.kind === "present" && actual.matches) {
    await runDockerOrThrow(run, ["start", input.policy.container.name]);
    const healthy = await waitUntilHealthy(input.policy, input.token);
    if (healthy) return { ...baseStatus(input.policy), state: "ready", renderer_status: "healthy" };
    throw new BrowserConfigurationError("RENDERER_UNHEALTHY", "Renderer did not become healthy after start.");
  } else if (actual.kind === "present") {
    await runDockerOrThrow(run, ["rm", "--force", input.policy.container.name]);
  }

  await runDockerOrThrow(run, dockerRunArgs(input.policy), input.token);
  const healthy = await waitUntilHealthy(input.policy, input.token);
  if (!healthy) throw new BrowserConfigurationError("RENDERER_UNHEALTHY", "Renderer did not become healthy after creation.");
  return { ...baseStatus(input.policy), state: "ready", renderer_status: "healthy" };
}

export async function removeRenderer(input: RendererStatusInput): Promise<boolean> {
  const run = input.run ?? runBrowserCommand;
  if (!(await dockerAvailable(run))) {
    throw new BrowserConfigurationError("DOCKER_UNAVAILABLE", "Docker daemon is unavailable.");
  }
  const actual = await inspectRenderer(input.policy, input.token, run, false);
  if (actual.kind === "missing") return false;
  if (!actual.owned) {
    throw new BrowserConfigurationError("RENDERER_UNOWNED", `Refusing to remove unowned container ${input.policy.container.name}.`);
  }
  await runDockerOrThrow(run, ["rm", "--force", input.policy.container.name]);
  return true;
}
