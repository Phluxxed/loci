import { X509Certificate, randomUUID } from "node:crypto";
import { lstat, mkdir, readFile, rename, rm, chmod, writeFile } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import { isAbsolute, join, relative, resolve, sep } from "node:path";

import {
  BROWSERLESS_BASE_IMAGE,
  CORPORATE_IMAGE_RECIPE_VERSION,
  BrowserConfigurationError,
  redactBrowserText,
} from "./policy.ts";

export type BrowserCommandResult = {
  status: number | null;
  stdout: string;
  stderr: string;
};

export type BrowserCommandOptions = {
  cwd?: string;
  env?: Record<string, string | undefined>;
};

export type BrowserCommandRunner = (
  command: string,
  args: string[],
  options?: BrowserCommandOptions,
) => Promise<BrowserCommandResult>;

export type CorporateCaSource =
  | { kind: "file"; path: string }
  | { kind: "keychain"; label: string; keychain: string };

export type CorporateCa = {
  pem: string;
  fingerprint: string;
  subject: string;
  valid_from: string;
  valid_to: string;
  source: CorporateCaSource;
};

export type InstalledCorporateCa = {
  path: string;
  fingerprint: string;
};

export type CorporateImageBuildOutput = {
  image_ref: string;
  build_context: string;
  ca_fingerprint: string;
  base_image: string;
};

const MAX_CA_BYTES = 128 * 1024;
const CERTIFICATE_PATTERN = /-----BEGIN CERTIFICATE-----[\s\S]*?-----END CERTIFICATE-----/g;

function certificateBlocks(value: string): string[] {
  return value.match(CERTIFICATE_PATTERN) ?? [];
}

function invalidCa(message: string): BrowserConfigurationError {
  return new BrowserConfigurationError("CORPORATE_CA_INVALID", message);
}

export function parseCorporateCa(value: string, source: CorporateCaSource, now = new Date()): CorporateCa {
  if (Buffer.byteLength(value, "utf8") > MAX_CA_BYTES) throw invalidCa("Corporate CA file exceeds 128 KiB.");

  const blocks = certificateBlocks(value);
  if (blocks.length === 0) throw invalidCa("Corporate CA source does not contain a PEM certificate.");
  if (blocks.length > 1) {
    throw new BrowserConfigurationError("CORPORATE_CA_AMBIGUOUS", "Corporate CA source contains multiple certificates.");
  }

  let certificate: X509Certificate;
  try {
    certificate = new X509Certificate(blocks[0]);
  } catch (error) {
    const detail = error instanceof Error ? redactBrowserText(error.message) : "unknown certificate parse error";
    throw invalidCa(`Corporate CA is not a valid X.509 certificate: ${detail}`);
  }

  if (!certificate.ca) throw invalidCa("Selected corporate certificate is not a CA certificate.");

  const validFrom = new Date(certificate.validFrom);
  const validTo = new Date(certificate.validTo);
  if (!Number.isFinite(validFrom.getTime()) || !Number.isFinite(validTo.getTime())) {
    throw invalidCa("Corporate CA validity dates are malformed.");
  }
  if (now < validFrom || now > validTo) throw invalidCa("Corporate CA is outside its validity period.");

  return {
    pem: `${blocks[0]}\n`,
    fingerprint: certificate.fingerprint256.replaceAll(":", "").toUpperCase(),
    subject: certificate.subject,
    valid_from: validFrom.toISOString(),
    valid_to: validTo.toISOString(),
    source,
  };
}

export async function loadCorporateCaFile(path: string, now = new Date()): Promise<CorporateCa> {
  if (!isAbsolute(path) || path.includes("\0")) throw invalidCa("Corporate CA path must be an absolute local path.");

  let value: string;
  try {
    value = await readFile(path, "utf8");
  } catch (error) {
    const detail = error instanceof Error ? redactBrowserText(error.message) : "unknown read error";
    throw invalidCa(`Unable to read corporate CA file: ${detail}`);
  }
  return parseCorporateCa(value, { kind: "file", path }, now);
}

export async function discoverCorporateCa(
  input: { label: string; keychains: string[]; now?: Date },
  run: BrowserCommandRunner,
): Promise<CorporateCa> {
  const label = input.label.trim();
  if (label.length === 0 || label.length > 200 || label.includes("\0")) throw invalidCa("Corporate CA Keychain label is invalid.");
  if (input.keychains.length === 0 || input.keychains.some((path) => !isAbsolute(path) || path.includes("\0"))) {
    throw invalidCa("Corporate CA discovery requires absolute Keychain paths.");
  }

  const candidates: CorporateCa[] = [];
  for (const keychain of input.keychains) {
    const result = await run("security", ["find-certificate", "-a", "-c", label, "-p", keychain]);
    if (result.status !== 0 && result.stdout.trim().length === 0) continue;
    if (result.status !== 0) {
      throw invalidCa(`Keychain lookup failed for ${keychain}: ${redactBrowserText(result.stderr).slice(0, 240)}`);
    }
    for (const block of certificateBlocks(result.stdout)) {
      candidates.push(
        parseCorporateCa(
          `${block}\n`,
          { kind: "keychain", label, keychain },
          input.now,
        ),
      );
    }
  }

  if (candidates.length === 0) {
    throw new BrowserConfigurationError("CORPORATE_CA_MISSING", `No corporate CA named ${label} was found in the selected Keychains.`);
  }
  if (candidates.length > 1) {
    const choices = candidates.map((candidate) => `${candidate.source.kind === "keychain" ? candidate.source.keychain : "file"} (${candidate.fingerprint})`);
    throw new BrowserConfigurationError(
      "CORPORATE_CA_AMBIGUOUS",
      `Multiple corporate CA candidates matched ${label}: ${choices.join(", ")}`,
    );
  }
  return candidates[0];
}

async function rejectSymlinkOrNonDirectory(path: string): Promise<void> {
  try {
    const info = await lstat(path);
    if (info.isSymbolicLink() || !info.isDirectory()) throw invalidCa(`Unsafe corporate CA state directory: ${path}`);
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code === "ENOENT") return;
    throw error;
  }
}

export async function installCorporateCa(ca: CorporateCa, anvilHome: string): Promise<InstalledCorporateCa> {
  if (!isAbsolute(anvilHome) || anvilHome.includes("\0")) throw invalidCa("Anvil home must be an absolute local path.");

  const browserDir = join(anvilHome, "browser");
  const certificateDir = join(browserDir, "certs");
  const targetPath = join(certificateDir, "corporate-root.crt");
  for (const path of [anvilHome, browserDir, certificateDir]) await rejectSymlinkOrNonDirectory(path);
  try {
    const targetInfo = await lstat(targetPath);
    if (targetInfo.isSymbolicLink() || !targetInfo.isFile()) throw invalidCa(`Unsafe corporate CA target: ${targetPath}`);
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code !== "ENOENT") throw error;
  }

  await mkdir(certificateDir, { recursive: true, mode: 0o700 });
  await chmod(browserDir, 0o700);
  await chmod(certificateDir, 0o700);

  const temporaryPath = join(certificateDir, `.corporate-root.${randomUUID()}.tmp`);
  try {
    await writeFile(temporaryPath, ca.pem, { encoding: "utf8", mode: 0o600, flag: "wx" });
    await rename(temporaryPath, targetPath);
    await chmod(targetPath, 0o600);
  } catch (error) {
    await rm(temporaryPath, { force: true });
    throw error;
  }

  return { path: targetPath, fingerprint: ca.fingerprint };
}

export async function buildCorporateImage(input: {
  installedCa: InstalledCorporateCa;
  anvilHome: string;
  baseImage?: string;
  run: BrowserCommandRunner;
}): Promise<CorporateImageBuildOutput> {
  const anvilHome = resolve(input.anvilHome);
  const certificateDir = resolve(anvilHome, "browser", "certs");
  const certificatePath = resolve(input.installedCa.path);
  const certificateRelative = relative(certificateDir, certificatePath);
  if (certificateRelative.startsWith("..") || certificateRelative.includes(`..${sep}`) || !isAbsolute(input.installedCa.path)) {
    throw invalidCa("Installed corporate CA path is outside Anvil browser state.");
  }

  const pem = await readFile(certificatePath, "utf8");
  const parsed = parseCorporateCa(pem, { kind: "file", path: certificatePath });
  if (parsed.fingerprint !== input.installedCa.fingerprint) {
    throw new BrowserConfigurationError("CORPORATE_CA_STALE", "Installed corporate CA fingerprint changed before image build.");
  }

  const baseImage = input.baseImage ?? BROWSERLESS_BASE_IMAGE;
  if (!/@sha256:[a-f0-9]{64}$/i.test(baseImage)) {
    throw new BrowserConfigurationError("UNPINNED_IMAGE", "Corporate image build requires a digest-pinned Browserless base image.");
  }

  const fingerprintPrefix = parsed.fingerprint.slice(0, 12).toLowerCase();
  const baseDigestPrefix = baseImage.match(/@sha256:([a-f0-9]{12})/i)?.[1]?.toLowerCase();
  if (!baseDigestPrefix) throw new BrowserConfigurationError("UNPINNED_IMAGE", "Unable to derive Browserless base digest label.");
  const imageRef = `anvil/browserless-corporate:ca-${fingerprintPrefix}-base-${baseDigestPrefix}-r${CORPORATE_IMAGE_RECIPE_VERSION}`;
  const buildRoot = join(anvilHome, "browser", "build");
  const buildContext = join(buildRoot, fingerprintPrefix);
  await rejectSymlinkOrNonDirectory(buildRoot);
  await rm(buildContext, { recursive: true, force: true });
  await mkdir(buildContext, { recursive: true, mode: 0o700 });

  try {
    const dockerfile = await readFile(fileURLToPath(new URL("./assets/Dockerfile.corporate", import.meta.url)), "utf8");
    await writeFile(join(buildContext, "Dockerfile"), dockerfile, { encoding: "utf8", mode: 0o600 });
    await writeFile(join(buildContext, "corporate-root.crt"), parsed.pem, { encoding: "utf8", mode: 0o600 });
    const result = await input.run(
      "docker",
      [
        "build",
        "--build-arg",
        `BROWSERLESS_IMAGE=${baseImage}`,
        "--build-arg",
        `ANVIL_CA_FINGERPRINT=${parsed.fingerprint}`,
        "--build-arg",
        `ANVIL_BROWSER_RECIPE_VERSION=${CORPORATE_IMAGE_RECIPE_VERSION}`,
        "--tag",
        imageRef,
        ".",
      ],
      { cwd: buildContext },
    );
    if (result.status !== 0) {
      throw new BrowserConfigurationError(
        "DOCKER_COMMAND_FAILED",
        `Corporate browser image build failed: ${redactBrowserText(result.stderr).slice(0, 240)}`,
      );
    }
  } finally {
    await rm(buildContext, { recursive: true, force: true });
  }

  return {
    image_ref: imageRef,
    build_context: buildContext,
    ca_fingerprint: parsed.fingerprint,
    base_image: baseImage,
  };
}
