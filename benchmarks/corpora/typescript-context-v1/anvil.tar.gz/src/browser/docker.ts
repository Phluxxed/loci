import { spawn } from "node:child_process";

import type { BrowserCommandOptions, BrowserCommandResult, BrowserCommandRunner } from "./corporate-ca.ts";

const MAX_COMMAND_OUTPUT_BYTES = 64 * 1024;

function appendBounded(current: string, chunk: Buffer | string): string {
  if (Buffer.byteLength(current, "utf8") >= MAX_COMMAND_OUTPUT_BYTES) return current;
  const remaining = MAX_COMMAND_OUTPUT_BYTES - Buffer.byteLength(current, "utf8");
  return current + Buffer.from(chunk).subarray(0, remaining).toString("utf8");
}

export const runBrowserCommand: BrowserCommandRunner = async (
  command: string,
  args: string[],
  options: BrowserCommandOptions = {},
): Promise<BrowserCommandResult> =>
  new Promise((resolve, reject) => {
    const child = spawn(command, args, {
      cwd: options.cwd,
      env: { ...process.env, ...options.env },
      stdio: ["ignore", "pipe", "pipe"],
    });
    let stdout = "";
    let stderr = "";
    child.stdout.on("data", (chunk) => {
      stdout = appendBounded(stdout, chunk);
    });
    child.stderr.on("data", (chunk) => {
      stderr = appendBounded(stderr, chunk);
    });
    child.on("error", reject);
    child.on("close", (status) => resolve({ status, stdout, stderr }));
  });
