import { homedir } from "node:os";
import { dirname, join, resolve } from "node:path";

import {
  buildCorporateImage,
  discoverCorporateCa,
  installCorporateCa,
  loadCorporateCaFile,
  type BrowserCommandRunner,
  type BrowserCommandResult,
  type CorporateCa,
  type CorporateImageBuildOutput,
  type InstalledCorporateCa,
} from "./corporate-ca.ts";
import {
  installCodexBrowserRegistrations,
  readCodexBrowserRegistrationStatus,
  uninstallCodexBrowserRegistrations,
  validateCodexBrowserRegistrations,
  type CodexBrowserRegistrationStatus,
} from "./codex.ts";
import { runBrowserCommand } from "./docker.ts";
import { serveBrowserMcp } from "./mcp.ts";
import {
  AGENT_BROWSER_COMPATIBLE_VERSION,
  CORPORATE_IMAGE_RECIPE_VERSION,
  BrowserConfigurationError,
  buildBrowserPolicy,
  redactBrowserText,
  type BrowserDiagnostic,
  type BrowserLaunchPolicy,
  type BrowserNetworkMode,
  type BrowserProfileStatus,
} from "./policy.ts";
import { readRendererStatus, reconcileRenderer, removeRenderer } from "./runtime.ts";
import {
  ensureBrowserState,
  readBrowserState,
  removeBrowserState,
  type BrowserState,
  type BrowserStateRead,
} from "./state.ts";

type BrowserCliFlags = {
  _: string[];
  json: boolean;
  keepImages: boolean;
  host?: string;
  corporateCa?: string;
  corporateCaKeychainLabel?: string;
  corporateCaKeychain?: string;
  networkMode?: string;
  image?: string;
};

type Reconcile = typeof reconcileRenderer;
type ReadStatus = typeof readRendererStatus;
type RemoveRenderer = typeof removeRenderer;

export type BrowserCliDependencies = {
  anvilCommand: string;
  anvilHome?: string;
  homeDir?: string;
  stdout?: (value: string) => void;
  run?: BrowserCommandRunner;
  assertCanonical?: (anvilCommand: string, run: BrowserCommandRunner) => Promise<void>;
  buildImage?: (input: {
    installedCa: InstalledCorporateCa;
    anvilHome: string;
    baseImage?: string;
    run: BrowserCommandRunner;
  }) => Promise<CorporateImageBuildOutput>;
  reconcile?: Reconcile;
  readStatus?: ReadStatus;
  removeRenderer?: RemoveRenderer;
  installRegistrations?: typeof installCodexBrowserRegistrations;
  validateRegistrations?: typeof validateCodexBrowserRegistrations;
  registrationStatus?: typeof readCodexBrowserRegistrationStatus;
  uninstallRegistrations?: typeof uninstallCodexBrowserRegistrations;
  serveMcp?: typeof serveBrowserMcp;
};

export type BrowserCapabilityStatus = {
  schema_version: 1;
  capability_status: "unconfigured" | "ready" | "degraded";
  local?: BrowserProfileStatus;
  corporate?: BrowserProfileStatus;
  registrations: CodexBrowserRegistrationStatus;
  diagnostics: BrowserDiagnostic[];
};

export function browserCliUsage(): string {
  return [
    "Usage:",
    "  anvil browser install --host codex [--corporate-ca <pem>] [--corporate-ca-keychain-label <label>] [--corporate-ca-keychain <path>] [--json]",
    "  anvil browser status [--json]",
    "  anvil browser doctor [--json]",
    "  anvil browser mcp serve --network-mode local|corporate",
    "  anvil browser upgrade --image <digest-pinned-ref> [--json]",
    "  anvil browser uninstall --host codex [--keep-images] [--json]",
  ].join("\n");
}

function cliError(message: string): BrowserConfigurationError {
  return new BrowserConfigurationError("BROWSER_CLI_INVALID", message);
}

function parseBrowserFlags(args: string[]): BrowserCliFlags {
  const flags: BrowserCliFlags = { _: [], json: false, keepImages: false };
  const stringFlags: Record<string, keyof BrowserCliFlags> = {
    host: "host",
    "corporate-ca": "corporateCa",
    "corporate-ca-keychain-label": "corporateCaKeychainLabel",
    "corporate-ca-keychain": "corporateCaKeychain",
    "network-mode": "networkMode",
    image: "image",
  };
  for (let index = 0; index < args.length; index += 1) {
    const arg = args[index]!;
    if (!arg.startsWith("--")) {
      flags._.push(arg);
      continue;
    }
    if (arg === "--json") {
      flags.json = true;
      continue;
    }
    if (arg === "--keep-images") {
      flags.keepImages = true;
      continue;
    }
    const target = stringFlags[arg.slice(2)];
    if (!target) throw cliError(`Unknown browser flag ${arg}.`);
    const value = args[index + 1];
    if (!value || value.startsWith("--")) throw cliError(`Missing value for ${arg}.`);
    (flags as Record<string, unknown>)[target] = value;
    index += 1;
  }
  return flags;
}

function browserMode(value: string | undefined): BrowserNetworkMode {
  if (value === "local" || value === "corporate") return value;
  throw cliError("--network-mode must be local or corporate.");
}

function output(value: unknown, json: boolean, write: (value: string) => void): void {
  if (json) {
    write(`${JSON.stringify(value, null, 2)}\n`);
    return;
  }
  if (typeof value === "string") write(`${value}\n`);
  else write(`${JSON.stringify(value, null, 2)}\n`);
}

function profileFor(mode: BrowserNetworkMode, state: BrowserState): { policy: BrowserLaunchPolicy; token: string } | undefined {
  if (mode === "local") {
    return {
      policy: buildBrowserPolicy({ mode, hostPort: state.config.local.host_port, imageRef: state.config.base_image }),
      token: state.secrets.local_token,
    };
  }
  const corporate = state.config.corporate;
  if (corporate.status !== "configured" || !corporate.image_ref || !corporate.ca_fingerprint) return undefined;
  return {
    policy: buildBrowserPolicy({
      mode,
      hostPort: corporate.host_port,
      corporateImageRef: corporate.image_ref,
      caFingerprint: corporate.ca_fingerprint,
    }),
    token: state.secrets.corporate_token,
  };
}

function unconfiguredCorporateStatus(): BrowserProfileStatus {
  return {
    mode: "corporate",
    state: "unconfigured",
    renderer_status: "missing",
    registration_status: "unknown",
    diagnostics: [
      {
        code: "CORPORATE_CA_MISSING",
        severity: "warning",
        message: "Corporate browser profile has no selected CA.",
        remediation: "Rerun browser install with an explicit corporate CA source.",
      },
    ],
  };
}

async function readCapabilityStatus(
  anvilHome: string,
  anvilCommand: string,
  dependencies: BrowserCliDependencies,
): Promise<BrowserCapabilityStatus> {
  const stateRead = await readBrowserState(anvilHome);
  if (stateRead.kind === "missing") {
    return {
      schema_version: 1,
      capability_status: "unconfigured",
      registrations: { local: "unknown", corporate: "unknown" },
      diagnostics: [],
    };
  }
  if (stateRead.kind === "invalid") {
    return {
      schema_version: 1,
      capability_status: "degraded",
      registrations: { local: "unknown", corporate: "unknown" },
      diagnostics: [{ code: "BROWSER_STATE_INVALID", severity: "error", message: stateRead.message }],
    };
  }

  const run = dependencies.run ?? runBrowserCommand;
  const readStatus = dependencies.readStatus ?? readRendererStatus;
  const localProfile = profileFor("local", stateRead)!;
  const corporateProfile = profileFor("corporate", stateRead);
  const [local, corporate] = await Promise.all([
    readStatus({ ...localProfile, run }),
    corporateProfile ? readStatus({ ...corporateProfile, run }) : Promise.resolve(unconfiguredCorporateStatus()),
  ]);
  let registrations: CodexBrowserRegistrationStatus;
  try {
    registrations = await (dependencies.registrationStatus ?? readCodexBrowserRegistrationStatus)({ anvilCommand, run });
  } catch {
    registrations = { local: "unknown", corporate: "unknown" };
  }
  local.registration_status = registrations.local;
  corporate.registration_status = registrations.corporate;
  const diagnostics = [...local.diagnostics, ...corporate.diagnostics];
  const registrationsReady = registrations.local === "matches" && registrations.corporate === "matches";
  if (!registrationsReady) {
    diagnostics.push({
      code: "CODEX_REGISTRATION_DRIFT",
      severity: "error",
      message: `Codex browser registrations are not ready (local: ${registrations.local}; corporate: ${registrations.corporate}).`,
      remediation: "Run browser install from the canonical Anvil checkout, then restart Codex.",
    });
  }
  const ready =
    local.state === "ready" &&
    (corporateProfile ? corporate.state === "ready" : true) &&
    registrationsReady;
  return {
    schema_version: 1,
    capability_status: ready ? "ready" : "degraded",
    local,
    corporate,
    registrations,
    diagnostics,
  };
}

async function assertCanonicalCheckout(anvilCommand: string, run: BrowserCommandRunner): Promise<void> {
  const result = await run("git", [
    "-C",
    dirname(anvilCommand),
    "rev-parse",
    "--path-format=absolute",
    "--git-dir",
    "--git-common-dir",
  ]);
  const paths = result.stdout
    .trim()
    .split("\n")
    .map((value) => resolve(value));
  if (result.status !== 0 || paths.length !== 2 || paths[0] !== paths[1]) {
    throw new BrowserConfigurationError(
      "CODEX_REGISTRATION_DRIFT",
      "Permanent Codex browser registration must be run from the canonical Anvil checkout, not a linked worktree.",
    );
  }
}

async function selectedCorporateCa(
  flags: BrowserCliFlags,
  homeDir: string,
  run: BrowserCommandRunner,
): Promise<CorporateCa | undefined> {
  if (flags.corporateCa && flags.corporateCaKeychainLabel) {
    throw cliError("Choose either --corporate-ca or --corporate-ca-keychain-label, not both.");
  }
  if (flags.corporateCaKeychain && !flags.corporateCaKeychainLabel) {
    throw cliError("--corporate-ca-keychain requires --corporate-ca-keychain-label.");
  }
  if (flags.corporateCa) return loadCorporateCaFile(resolve(flags.corporateCa));
  if (!flags.corporateCaKeychainLabel) return undefined;
  const keychains = flags.corporateCaKeychain
    ? [resolve(flags.corporateCaKeychain)]
    : [join(homeDir, "Library", "Keychains", "login.keychain-db"), "/Library/Keychains/System.keychain"];
  return discoverCorporateCa({ label: flags.corporateCaKeychainLabel, keychains }, run);
}

async function readAgentBrowserVersion(run: BrowserCommandRunner): Promise<BrowserCommandResult> {
  try {
    return await run("agent-browser", ["--version"]);
  } catch {
    return { status: null, stdout: "", stderr: "agent-browser is not executable" };
  }
}

async function assertAgentBrowserCompatible(run: BrowserCommandRunner): Promise<void> {
  const version = await readAgentBrowserVersion(run);
  if (version.status !== 0) {
    throw new BrowserConfigurationError(
      "AGENT_BROWSER_MISSING",
      "agent-browser is not executable. Install the compatible release before Browser Eyes setup.",
    );
  }
  const found = version.stdout.trim();
  if (found !== `agent-browser ${AGENT_BROWSER_COMPATIBLE_VERSION}`) {
    throw new BrowserConfigurationError(
      "AGENT_BROWSER_INCOMPATIBLE",
      `Expected agent-browser ${AGENT_BROWSER_COMPATIBLE_VERSION}; found ${found.slice(0, 120) || "an unknown version"}.`,
    );
  }
}

async function assertDockerAvailable(run: BrowserCommandRunner): Promise<void> {
  let version: BrowserCommandResult;
  try {
    version = await run("docker", ["version", "--format", "{{.Server.Version}}"]);
  } catch {
    throw new BrowserConfigurationError("DOCKER_UNAVAILABLE", "Docker daemon is unavailable.");
  }
  if (version.status !== 0 || version.stdout.trim().length === 0) {
    throw new BrowserConfigurationError("DOCKER_UNAVAILABLE", "Docker daemon is unavailable.");
  }
}

async function installCommand(flags: BrowserCliFlags, dependencies: BrowserCliDependencies, anvilHome: string): Promise<unknown> {
  if (flags._.length !== 1 || flags.host !== "codex") throw cliError("browser install requires --host codex.");
  const run = dependencies.run ?? runBrowserCommand;
  await (dependencies.assertCanonical ?? assertCanonicalCheckout)(dependencies.anvilCommand, run);
  await assertAgentBrowserCompatible(run);
  await (dependencies.validateRegistrations ?? validateCodexBrowserRegistrations)({
    anvilCommand: dependencies.anvilCommand,
    run,
  });
  await assertDockerAvailable(run);
  const ca = await selectedCorporateCa(flags, dependencies.homeDir ?? homedir(), run);
  let corporate:
    | {
        imageRef: string;
        installedCaPath: string;
        fingerprint: string;
        source: CorporateCa["source"];
      }
    | undefined;
  if (ca) {
    const installedCa = await installCorporateCa(ca, anvilHome);
    const built = await (dependencies.buildImage ?? buildCorporateImage)({ installedCa, anvilHome, run });
    corporate = {
      imageRef: built.image_ref,
      installedCaPath: installedCa.path,
      fingerprint: installedCa.fingerprint,
      source: ca.source,
    };
  }
  const state = await ensureBrowserState({ anvilHome, ...(corporate ? { corporate } : {}) });
  const reconcile = dependencies.reconcile ?? reconcileRenderer;
  const modes: BrowserNetworkMode[] = ["local"];
  if (state.config.corporate.status === "configured") modes.push("corporate");
  const reconciled: BrowserProfileStatus[] = [];
  for (const mode of modes) {
    const selected = profileFor(mode, state)!;
    reconciled.push(await reconcile({ ...selected, run }));
  }
  const registration = await (dependencies.installRegistrations ?? installCodexBrowserRegistrations)({
    anvilCommand: dependencies.anvilCommand,
    run,
  });
  return {
    schema_version: 1,
    operation: "install",
    profiles: reconciled.map((profile) => ({ mode: profile.mode, state: profile.state, renderer_status: profile.renderer_status })),
    corporate_ca_status: state.config.corporate.status,
    registrations: registration.status,
  };
}

async function doctorCommand(dependencies: BrowserCliDependencies, anvilHome: string): Promise<unknown> {
  const run = dependencies.run ?? runBrowserCommand;
  const status = await readCapabilityStatus(anvilHome, dependencies.anvilCommand, dependencies);
  const diagnostics = [...status.diagnostics];
  const version = await readAgentBrowserVersion(run);
  const versionText = version.stdout.trim();
  if (version.status !== 0) {
    diagnostics.push({
      code: "AGENT_BROWSER_MISSING",
      severity: "error",
      message: "agent-browser is not executable.",
      remediation: "Install the compatible agent-browser release and rerun browser doctor.",
    });
  } else if (versionText !== `agent-browser ${AGENT_BROWSER_COMPATIBLE_VERSION}`) {
    diagnostics.push({
      code: "AGENT_BROWSER_INCOMPATIBLE",
      severity: "error",
      message: `Expected agent-browser ${AGENT_BROWSER_COMPATIBLE_VERSION}; found ${versionText.slice(0, 120)}.`,
    });
  }

  const state = await readBrowserState(anvilHome);
  if (state.kind === "ok" && state.config.corporate.status === "configured") {
    try {
      const ca = await loadCorporateCaFile(state.config.corporate.installed_ca_path!);
      if (ca.fingerprint !== state.config.corporate.ca_fingerprint) {
        diagnostics.push({ code: "CORPORATE_CA_STALE", severity: "error", message: "Installed corporate CA fingerprint no longer matches config." });
      }
    } catch (error) {
      diagnostics.push({
        code: "CORPORATE_CA_STALE",
        severity: "error",
        message: error instanceof Error ? error.message.slice(0, 240) : "Installed corporate CA could not be verified.",
      });
    }
  }
  return { schema_version: 1, ok: diagnostics.every((item) => item.severity !== "error"), status, diagnostics };
}

async function upgradeCommand(flags: BrowserCliFlags, dependencies: BrowserCliDependencies, anvilHome: string): Promise<unknown> {
  if (flags._.length !== 1 || !flags.image) throw cliError("browser upgrade requires --image <digest-pinned-ref>.");
  if (!/@sha256:[a-f0-9]{64}$/i.test(flags.image)) {
    throw new BrowserConfigurationError("UNPINNED_IMAGE", "Browser upgrade image must use an immutable SHA-256 digest.");
  }
  const current = await readBrowserState(anvilHome);
  if (current.kind !== "ok") throw new BrowserConfigurationError("BROWSER_STATE_INVALID", "Browser Eyes must be installed before upgrade.");
  const run = dependencies.run ?? runBrowserCommand;
  const pull = await run("docker", ["pull", flags.image]);
  if (pull.status !== 0) {
    throw new BrowserConfigurationError("DOCKER_COMMAND_FAILED", `Docker pull failed: ${redactBrowserText(pull.stderr).slice(0, 240)}`);
  }

  let corporate:
    | {
        imageRef: string;
        installedCaPath: string;
        fingerprint: string;
        source: CorporateCa["source"];
      }
    | undefined;
  if (current.config.corporate.status === "configured") {
    const installedCa: InstalledCorporateCa = {
      path: current.config.corporate.installed_ca_path!,
      fingerprint: current.config.corporate.ca_fingerprint!,
    };
    const built = await (dependencies.buildImage ?? buildCorporateImage)({
      installedCa,
      anvilHome,
      baseImage: flags.image,
      run,
    });
    corporate = {
      imageRef: built.image_ref,
      installedCaPath: installedCa.path,
      fingerprint: installedCa.fingerprint,
      source: current.config.corporate.source!,
    };
  }

  const updated = await ensureBrowserState({ anvilHome, baseImage: flags.image, ...(corporate ? { corporate } : {}) });
  const reconcile = dependencies.reconcile ?? reconcileRenderer;
  try {
    await reconcile({ ...profileFor("local", updated)!, run });
    const corporateProfile = profileFor("corporate", updated);
    if (corporateProfile) await reconcile({ ...corporateProfile, run });
  } catch (error) {
    const previousCorporate =
      current.config.corporate.status === "configured"
        ? {
            imageRef: current.config.corporate.image_ref!,
            installedCaPath: current.config.corporate.installed_ca_path!,
            fingerprint: current.config.corporate.ca_fingerprint!,
            source: current.config.corporate.source!,
          }
        : undefined;
    await ensureBrowserState({
      anvilHome,
      baseImage: current.config.base_image,
      ...(previousCorporate ? { corporate: previousCorporate } : {}),
    });
    throw error;
  }
  return { schema_version: 1, operation: "upgrade", base_image: flags.image, corporate_image: corporate?.imageRef ?? null };
}

async function removeCorporateImage(state: BrowserState, run: BrowserCommandRunner): Promise<boolean> {
  if (state.config.corporate.status !== "configured" || !state.config.corporate.image_ref) return false;
  const inspect = await run("docker", ["image", "inspect", state.config.corporate.image_ref, "--format", "{{json .Config.Labels}}"]);
  if (inspect.status !== 0) {
    if (/no such (image|object)/i.test(inspect.stderr)) return false;
    throw new BrowserConfigurationError(
      "DOCKER_COMMAND_FAILED",
      `Corporate browser image inspection failed: ${redactBrowserText(inspect.stderr).slice(0, 240)}`,
    );
  }
  let labels: unknown;
  try {
    labels = JSON.parse(inspect.stdout);
  } catch {
    throw new BrowserConfigurationError("DOCKER_COMMAND_FAILED", "Corporate browser image labels are malformed.");
  }
  if (
    typeof labels !== "object" ||
    labels === null ||
    (labels as Record<string, unknown>)["io.anvil.browser.owner"] !== "anvil" ||
    (labels as Record<string, unknown>)["io.anvil.browser.ca-fingerprint"] !== state.config.corporate.ca_fingerprint ||
    (labels as Record<string, unknown>)["io.anvil.browser.base-image"] !== state.config.base_image ||
    (labels as Record<string, unknown>)["io.anvil.browser.recipe-version"] !== String(CORPORATE_IMAGE_RECIPE_VERSION)
  ) {
    throw new BrowserConfigurationError("DOCKER_COMMAND_FAILED", "Refusing to remove a corporate browser image not owned by this Anvil state.");
  }
  const removed = await run("docker", ["image", "rm", state.config.corporate.image_ref]);
  if (removed.status !== 0) {
    throw new BrowserConfigurationError("DOCKER_COMMAND_FAILED", `Docker image removal failed: ${redactBrowserText(removed.stderr).slice(0, 240)}`);
  }
  return true;
}

async function uninstallCommand(flags: BrowserCliFlags, dependencies: BrowserCliDependencies, anvilHome: string): Promise<unknown> {
  if (flags._.length !== 1 || flags.host !== "codex") throw cliError("browser uninstall requires --host codex.");
  const run = dependencies.run ?? runBrowserCommand;
  await (dependencies.assertCanonical ?? assertCanonicalCheckout)(dependencies.anvilCommand, run);
  const registrations = await (dependencies.registrationStatus ?? readCodexBrowserRegistrationStatus)({
    anvilCommand: dependencies.anvilCommand,
    run,
  });
  if (registrations.local === "drifted" || registrations.corporate === "drifted") {
    throw new BrowserConfigurationError("CODEX_REGISTRATION_DRIFT", "Refusing uninstall while Codex browser registrations are drifted.");
  }

  const stateRead: BrowserStateRead = await readBrowserState(anvilHome);
  const removedProfiles: BrowserNetworkMode[] = [];
  let imageRemoved = false;
  if (stateRead.kind === "ok") {
    for (const mode of ["local", "corporate"] as const) {
      const selected = profileFor(mode, stateRead);
      if (selected && (await (dependencies.removeRenderer ?? removeRenderer)({ ...selected, run }))) removedProfiles.push(mode);
    }
    if (!flags.keepImages) imageRemoved = await removeCorporateImage(stateRead, run);
  } else if (stateRead.kind === "invalid") {
    throw new BrowserConfigurationError("BROWSER_STATE_INVALID", stateRead.message);
  }
  await (dependencies.uninstallRegistrations ?? uninstallCodexBrowserRegistrations)({
    anvilCommand: dependencies.anvilCommand,
    run,
  });
  const stateRemoved = await removeBrowserState(anvilHome);
  return { schema_version: 1, operation: "uninstall", removed_profiles: removedProfiles, image_removed: imageRemoved, state_removed: stateRemoved };
}

export async function runBrowserCli(args: string[], dependencies: BrowserCliDependencies): Promise<number> {
  const flags = parseBrowserFlags(args);
  const write = dependencies.stdout ?? ((value: string) => process.stdout.write(value));
  const anvilHome = resolve(dependencies.anvilHome ?? join(dependencies.homeDir ?? homedir(), ".anvil"));
  const command = flags._[0];
  if (!command || command === "help") {
    write(`${browserCliUsage()}\n`);
    return 0;
  }
  if (command === "install") {
    output(await installCommand(flags, dependencies, anvilHome), flags.json, write);
    return 0;
  }
  if (command === "status" && flags._.length === 1) {
    output(await readCapabilityStatus(anvilHome, dependencies.anvilCommand, dependencies), flags.json, write);
    return 0;
  }
  if (command === "doctor" && flags._.length === 1) {
    const result = await doctorCommand(dependencies, anvilHome);
    output(result, flags.json, write);
    return (result as { ok: boolean }).ok ? 0 : 1;
  }
  if (command === "mcp" && flags._[1] === "serve" && flags._.length === 2) {
    return (dependencies.serveMcp ?? serveBrowserMcp)({ mode: browserMode(flags.networkMode), anvilHome });
  }
  if (command === "upgrade") {
    output(await upgradeCommand(flags, dependencies, anvilHome), flags.json, write);
    return 0;
  }
  if (command === "uninstall") {
    output(await uninstallCommand(flags, dependencies, anvilHome), flags.json, write);
    return 0;
  }
  throw cliError(browserCliUsage());
}
