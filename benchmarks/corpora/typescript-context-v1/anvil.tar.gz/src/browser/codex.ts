import { isAbsolute } from "node:path";

import type { BrowserCommandRunner } from "./corporate-ca.ts";
import { runBrowserCommand } from "./docker.ts";
import { BrowserConfigurationError, redactBrowserText } from "./policy.ts";

export type DesiredCodexBrowserRegistration = {
  name: "agent-browser" | "agent-browser-corporate";
  command: string;
  args: string[];
};

export type CodexBrowserRegistrationStatus = {
  local: "missing" | "matches" | "drifted" | "unknown";
  corporate: "missing" | "matches" | "drifted" | "unknown";
};

type CodexRegistration = {
  name: string;
  enabled: boolean;
  disabled_reason: string | null;
  enabled_tools: string[] | null;
  disabled_tools: string[] | null;
  startup_timeout_sec: number | null;
  tool_timeout_sec: number | null;
  transport: {
    type: "stdio";
    command: string;
    args: string[];
    env: Record<string, string> | null;
    env_vars: string[];
    cwd: string | null;
  };
};

type RegistrationRead = { kind: "missing" } | { kind: "ok"; registration: CodexRegistration };

export function desiredCodexBrowserRegistrations(anvilCommand: string): DesiredCodexBrowserRegistration[] {
  if (!isAbsolute(anvilCommand) || anvilCommand.includes("\0")) {
    throw new BrowserConfigurationError("CODEX_REGISTRATION_DRIFT", "Canonical Anvil command must be an absolute local path.");
  }
  return [
    {
      name: "agent-browser",
      command: anvilCommand,
      args: ["browser", "mcp", "serve", "--network-mode", "local"],
    },
    {
      name: "agent-browser-corporate",
      command: anvilCommand,
      args: ["browser", "mcp", "serve", "--network-mode", "corporate"],
    },
  ];
}

function isRegistration(value: unknown): value is CodexRegistration {
  if (typeof value !== "object" || value === null) return false;
  const record = value as Record<string, unknown>;
  if (typeof record.name !== "string" || typeof record.transport !== "object" || record.transport === null) return false;
  const transport = record.transport as Record<string, unknown>;
  const stringListOrNull = (entry: unknown): entry is string[] | null =>
    entry === null || (Array.isArray(entry) && entry.every((item) => typeof item === "string"));
  return (
    typeof record.enabled === "boolean" &&
    (record.disabled_reason === null || typeof record.disabled_reason === "string") &&
    stringListOrNull(record.enabled_tools) &&
    stringListOrNull(record.disabled_tools) &&
    (record.startup_timeout_sec === null || typeof record.startup_timeout_sec === "number") &&
    (record.tool_timeout_sec === null || typeof record.tool_timeout_sec === "number") &&
    transport.type === "stdio" &&
    typeof transport.command === "string" &&
    Array.isArray(transport.args) &&
    transport.args.every((arg) => typeof arg === "string") &&
    (transport.env === null ||
      (typeof transport.env === "object" &&
        transport.env !== null &&
        Object.values(transport.env).every((entry) => typeof entry === "string"))) &&
    Array.isArray(transport.env_vars) &&
    transport.env_vars.every((entry) => typeof entry === "string") &&
    (transport.cwd === null || typeof transport.cwd === "string")
  );
}

async function readRegistration(name: string, run: BrowserCommandRunner): Promise<RegistrationRead> {
  let result;
  try {
    result = await run("codex", ["mcp", "get", name, "--json"]);
  } catch (error) {
    const detail = error instanceof Error ? redactBrowserText(error.message).slice(0, 240) : "unknown command failure";
    throw new BrowserConfigurationError("CODEX_REGISTRATION_DRIFT", `Unable to execute Codex MCP registration read for ${name}: ${detail}`);
  }
  if (result.status !== 0) {
    const escapedName = name.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    const missing = [
      new RegExp(`no mcp server named ['\"]?${escapedName}['\"]? found`, "i"),
      new RegExp(`mcp server ['\"]?${escapedName}['\"]? not found`, "i"),
      new RegExp(`${escapedName}[^\\n]*does not exist`, "i"),
    ].some((pattern) => pattern.test(result.stderr));
    if (missing) return { kind: "missing" };
    throw new BrowserConfigurationError(
      "CODEX_REGISTRATION_DRIFT",
      `Unable to read Codex MCP registration ${name}: ${redactBrowserText(result.stderr).slice(0, 240)}`,
    );
  }
  let parsed: unknown;
  try {
    parsed = JSON.parse(result.stdout);
  } catch {
    throw new BrowserConfigurationError("CODEX_REGISTRATION_DRIFT", `Codex MCP registration ${name} returned malformed JSON.`);
  }
  if (!isRegistration(parsed)) {
    throw new BrowserConfigurationError("CODEX_REGISTRATION_DRIFT", `Codex MCP registration ${name} has an unsupported transport shape.`);
  }
  if (parsed.name !== name) {
    throw new BrowserConfigurationError("CODEX_REGISTRATION_DRIFT", `Codex MCP registration ${name} returned a mismatched name.`);
  }
  return { kind: "ok", registration: parsed };
}

function hasRestorableMetadata(registration: CodexRegistration): boolean {
  return (
    registration.enabled === true &&
    registration.disabled_reason === null &&
    registration.enabled_tools === null &&
    registration.disabled_tools === null &&
    registration.startup_timeout_sec === null &&
    registration.tool_timeout_sec === null &&
    (registration.transport.env === null || Object.keys(registration.transport.env).length === 0) &&
    registration.transport.env_vars.length === 0 &&
    registration.transport.cwd === null
  );
}

function matchesDesired(read: RegistrationRead, desired: DesiredCodexBrowserRegistration): boolean {
  return (
    read.kind === "ok" &&
    read.registration.transport.command === desired.command &&
    JSON.stringify(read.registration.transport.args) === JSON.stringify(desired.args) &&
    hasRestorableMetadata(read.registration)
  );
}

function ensureRestorable(read: RegistrationRead): void {
  if (read.kind === "missing") return;
  if (!hasRestorableMetadata(read.registration)) {
    throw new BrowserConfigurationError(
      "CODEX_REGISTRATION_DRIFT",
      `Existing registration ${read.registration.name} contains metadata Anvil cannot safely round-trip.`,
    );
  }
}

async function readRestorableRegistrations(
  desired: DesiredCodexBrowserRegistration[],
  run: BrowserCommandRunner,
): Promise<Map<string, RegistrationRead>> {
  const snapshots = new Map<string, RegistrationRead>();
  for (const entry of desired) {
    const snapshot = await readRegistration(entry.name, run);
    ensureRestorable(snapshot);
    snapshots.set(entry.name, snapshot);
  }
  return snapshots;
}

export async function validateCodexBrowserRegistrations(input: {
  anvilCommand: string;
  run?: BrowserCommandRunner;
}): Promise<void> {
  const run = input.run ?? runBrowserCommand;
  await readRestorableRegistrations(desiredCodexBrowserRegistrations(input.anvilCommand), run);
}

async function removeRegistration(name: string, run: BrowserCommandRunner): Promise<void> {
  const result = await run("codex", ["mcp", "remove", name]);
  if (result.status !== 0) {
    throw new BrowserConfigurationError(
      "CODEX_REGISTRATION_DRIFT",
      `Unable to remove Codex MCP registration ${name}: ${redactBrowserText(result.stderr).slice(0, 240)}`,
    );
  }
}

async function addRegistration(
  registration: { name: string; command: string; args: string[] },
  run: BrowserCommandRunner,
): Promise<void> {
  const result = await run("codex", ["mcp", "add", registration.name, "--", registration.command, ...registration.args]);
  if (result.status !== 0) {
    throw new BrowserConfigurationError(
      "CODEX_REGISTRATION_DRIFT",
      `Unable to add Codex MCP registration ${registration.name}: ${redactBrowserText(result.stderr).slice(0, 240)}`,
    );
  }
}

async function restoreRegistrations(
  snapshots: Map<string, RegistrationRead>,
  run: BrowserCommandRunner,
): Promise<void> {
  for (const [name, snapshot] of snapshots) {
    const current = await readRegistration(name, run);
    if (current.kind === "ok") await removeRegistration(name, run);
    if (snapshot.kind === "ok") {
      await addRegistration(
        {
          name,
          command: snapshot.registration.transport.command,
          args: snapshot.registration.transport.args,
        },
        run,
      );
    }
  }
}

export async function readCodexBrowserRegistrationStatus(input: {
  anvilCommand: string;
  run?: BrowserCommandRunner;
}): Promise<CodexBrowserRegistrationStatus> {
  const run = input.run ?? runBrowserCommand;
  const desired = desiredCodexBrowserRegistrations(input.anvilCommand);
  const reads = await Promise.all(desired.map((entry) => readRegistration(entry.name, run)));
  const status = reads.map((read, index) => (read.kind === "missing" ? "missing" : matchesDesired(read, desired[index]) ? "matches" : "drifted"));
  return { local: status[0]!, corporate: status[1]! };
}

export async function installCodexBrowserRegistrations(input: {
  anvilCommand: string;
  run?: BrowserCommandRunner;
}): Promise<{ changed: boolean; status: CodexBrowserRegistrationStatus }> {
  const run = input.run ?? runBrowserCommand;
  const desired = desiredCodexBrowserRegistrations(input.anvilCommand);
  const snapshots = await readRestorableRegistrations(desired, run);
  const mismatches = desired.filter((entry) => !matchesDesired(snapshots.get(entry.name)!, entry));
  if (mismatches.length === 0) {
    return { changed: false, status: { local: "matches", corporate: "matches" } };
  }

  try {
    for (const entry of mismatches) {
      if (snapshots.get(entry.name)?.kind === "ok") await removeRegistration(entry.name, run);
      await addRegistration(entry, run);
      const verified = await readRegistration(entry.name, run);
      if (!matchesDesired(verified, entry)) {
        throw new BrowserConfigurationError("CODEX_REGISTRATION_DRIFT", `Codex MCP registration ${entry.name} did not verify after write.`);
      }
    }
  } catch (error) {
    try {
      await restoreRegistrations(snapshots, run);
    } catch (rollbackError) {
      const rollbackMessage = rollbackError instanceof Error ? rollbackError.message : "unknown rollback failure";
      throw new BrowserConfigurationError(
        "CODEX_REGISTRATION_DRIFT",
        `Codex MCP registration failed and rollback also failed: ${rollbackMessage}`,
      );
    }
    const message = error instanceof Error ? error.message : "Codex MCP registration failed.";
    throw new BrowserConfigurationError("CODEX_REGISTRATION_DRIFT", `${message} Prior registrations were restored.`);
  }

  return { changed: true, status: await readCodexBrowserRegistrationStatus({ anvilCommand: input.anvilCommand, run }) };
}

export async function uninstallCodexBrowserRegistrations(input: {
  anvilCommand: string;
  run?: BrowserCommandRunner;
}): Promise<void> {
  const run = input.run ?? runBrowserCommand;
  const desired = desiredCodexBrowserRegistrations(input.anvilCommand);
  const reads = await Promise.all(desired.map((entry) => readRegistration(entry.name, run)));
  for (let index = 0; index < desired.length; index += 1) {
    const read = reads[index]!;
    if (read.kind === "ok" && !matchesDesired(read, desired[index]!)) {
      throw new BrowserConfigurationError("CODEX_REGISTRATION_DRIFT", `Refusing to remove drifted registration ${desired[index]!.name}.`);
    }
  }
  for (let index = 0; index < desired.length; index += 1) {
    if (reads[index]!.kind === "ok") await removeRegistration(desired[index]!.name, run);
  }
}
