import { createHash } from "node:crypto";
import { spawn } from "node:child_process";
import { createInterface } from "node:readline";

import { createBrowserMcpPolicyGuard } from "./mcp-guard.ts";
import { buildBrowserPolicy, BrowserConfigurationError, type BrowserLaunchPolicy, type BrowserNetworkMode } from "./policy.ts";
import { readBrowserState, type BrowserState, type BrowserStateRead } from "./state.ts";
import { reconcileRenderer, type ReconcileRendererInput } from "./runtime.ts";

export type BrowserMcpLaunch = {
  command: "agent-browser";
  args: ["mcp", "--tools", "all"];
  env: Record<string, string | undefined>;
  policy: BrowserLaunchPolicy;
  token: string;
};

export type BrowserMcpDependencies = {
  readState?: (anvilHome: string) => Promise<BrowserStateRead>;
  reconcile?: (input: ReconcileRendererInput) => ReturnType<typeof reconcileRenderer>;
  spawnMcp?: (command: string, args: string[], env: Record<string, string | undefined>) => Promise<number>;
};

function selectedPolicy(mode: BrowserNetworkMode, state: BrowserState): { policy: BrowserLaunchPolicy; token: string } {
  if (mode === "local") {
    return {
      policy: buildBrowserPolicy({
        mode,
        hostPort: state.config.local.host_port,
        imageRef: state.config.base_image,
      }),
      token: state.secrets.local_token,
    };
  }
  const corporate = state.config.corporate;
  if (corporate.status !== "configured" || !corporate.image_ref || !corporate.ca_fingerprint) {
    throw new BrowserConfigurationError(
      "CORPORATE_CA_MISSING",
      "Corporate browser mode is not configured. Run browser install with an explicit corporate CA source.",
    );
  }
  return {
    policy: buildBrowserPolicy({
      mode,
      hostPort: corporate.host_port,
      corporateImageRef: corporate.image_ref,
      caFingerprint: corporate.ca_fingerprint,
    }),
    token: state.secrets.corporate_token,
  };
}

export function buildBrowserMcpLaunch(mode: BrowserNetworkMode, state: BrowserState): BrowserMcpLaunch {
  const { policy, token } = selectedPolicy(mode, state);
  const cdp = new URL(`ws://${policy.container.bind_host}:${policy.container.host_port}/`);
  cdp.searchParams.set("token", token);
  cdp.searchParams.set("launch", JSON.stringify(policy.browserless_launch));
  const namespaceToken = createHash("sha256").update(token).digest("hex").slice(0, 12);

  return {
    command: "agent-browser",
    args: ["mcp", "--tools", "all"],
    policy,
    token,
    env: {
      AGENT_BROWSER_CDP: cdp.toString(),
      AGENT_BROWSER_NAMESPACE: `anvil-browser-${mode}-${namespaceToken}`,
      AGENT_BROWSER_CONTENT_BOUNDARIES: "true",
      ...(policy.agent_browser.allowed_domains
        ? { AGENT_BROWSER_ALLOWED_DOMAINS: policy.agent_browser.allowed_domains.join(",") }
        : {}),
    },
  };
}

export function buildAgentBrowserEnvironment(
  overrides: Record<string, string | undefined>,
  inherited: NodeJS.ProcessEnv = process.env,
): NodeJS.ProcessEnv {
  const env: NodeJS.ProcessEnv = { ...inherited };
  for (const key of Object.keys(env)) {
    if (key.startsWith("AGENT_BROWSER_") || /^(http|https|all|no)_proxy$/i.test(key)) delete env[key];
  }
  for (const [key, value] of Object.entries(overrides)) {
    if (value === undefined) delete env[key];
    else env[key] = value;
  }
  return env;
}

async function spawnMcp(command: string, args: string[], overrides: Record<string, string | undefined>): Promise<number> {
  return new Promise((resolve, reject) => {
    const child = spawn(command, args, {
      env: buildAgentBrowserEnvironment(overrides),
      stdio: ["pipe", "pipe", "inherit"],
    });
    const guard = createBrowserMcpPolicyGuard();
    const clientLines = createInterface({ input: process.stdin, crlfDelay: Infinity });
    const serverLines = createInterface({ input: child.stdout, crlfDelay: Infinity });
    clientLines.on("line", (line) => {
      const decision = guard.clientLine(line);
      if (decision.kind === "forward") child.stdin.write(`${decision.line}\n`);
      else process.stdout.write(`${decision.line}\n`);
    });
    clientLines.on("close", () => child.stdin.end());
    serverLines.on("line", (line) => {
      const decision = guard.serverLine(line);
      process.stdout.write(`${decision.line}\n`);
    });
    child.on("error", reject);
    child.on("close", (status, signal) => {
      clientLines.close();
      serverLines.close();
      if (signal) {
        reject(new Error(`agent-browser MCP exited from signal ${signal}`));
        return;
      }
      resolve(status ?? 1);
    });
  });
}

export async function serveBrowserMcp(
  input: { mode: BrowserNetworkMode; anvilHome: string },
  dependencies: BrowserMcpDependencies = {},
): Promise<number> {
  const stateRead = await (dependencies.readState ?? readBrowserState)(input.anvilHome);
  if (stateRead.kind !== "ok") {
    throw new BrowserConfigurationError(
      "BROWSER_STATE_INVALID",
      stateRead.kind === "missing" ? "Browser Eyes is not installed." : stateRead.message,
    );
  }
  const state: BrowserState = stateRead;
  const launch = buildBrowserMcpLaunch(input.mode, state);
  await (dependencies.reconcile ?? reconcileRenderer)({ policy: launch.policy, token: launch.token });
  return (dependencies.spawnMcp ?? spawnMcp)(launch.command, launch.args, launch.env);
}
