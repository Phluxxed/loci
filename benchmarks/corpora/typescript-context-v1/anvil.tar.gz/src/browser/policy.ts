export const BROWSER_SCHEMA_VERSION = 1;
export const CORPORATE_IMAGE_RECIPE_VERSION = 1;
export const AGENT_BROWSER_COMPATIBLE_VERSION = "0.31.1";
export const BROWSERLESS_BASE_IMAGE =
  "ghcr.io/browserless/chromium@sha256:05f10074ec39bc9161881c8ccc79304f98e713bb9c97dc0140e35fd3877374b7";

export type BrowserNetworkMode = "local" | "corporate";

export type BrowserErrorCode =
  | "DOCKER_UNAVAILABLE"
  | "AGENT_BROWSER_MISSING"
  | "AGENT_BROWSER_INCOMPATIBLE"
  | "RENDERER_UNHEALTHY"
  | "RENDERER_SPEC_STALE"
  | "RENDERER_UNOWNED"
  | "DOCKER_COMMAND_FAILED"
  | "BROWSER_STATE_INVALID"
  | "BROWSER_CLI_INVALID"
  | "PORT_UNAVAILABLE"
  | "PORT_INVALID"
  | "NETWORK_MODE_INVALID"
  | "UNPINNED_IMAGE"
  | "CORPORATE_CA_MISSING"
  | "CORPORATE_CA_AMBIGUOUS"
  | "CORPORATE_CA_INVALID"
  | "CORPORATE_CA_STALE"
  | "CORPORATE_TLS_UNTRUSTED"
  | "CODEX_REGISTRATION_DRIFT";

export type BrowserDiagnostic = {
  code: BrowserErrorCode;
  severity: "info" | "warning" | "error";
  message: string;
  remediation?: string;
};

export type BrowserProfileStatus = {
  mode: BrowserNetworkMode;
  state: "unconfigured" | "stopped" | "ready" | "degraded" | "stale";
  image_ref?: string;
  renderer_status: "missing" | "stopped" | "healthy" | "unhealthy" | "unknown";
  registration_status: "missing" | "matches" | "drifted" | "unknown";
  ca_fingerprint?: string;
  diagnostics: BrowserDiagnostic[];
};

export type BrowserPolicyInput = {
  mode: BrowserNetworkMode;
  hostPort: number;
  imageRef?: string;
  corporateImageRef?: string;
  caFingerprint?: string;
};

export type BrowserLaunchPolicy = {
  mode: BrowserNetworkMode;
  container: {
    name: string;
    image_ref: string;
    bind_host: "127.0.0.1";
    host_port: number;
    container_port: 3000;
    restart_policy: "unless-stopped";
    shm_size: "2g";
    concurrent: 2;
    timeout_ms: 300_000;
    labels: Record<string, string>;
  };
  browserless_launch: {
    args: string[];
    acceptInsecureCerts?: true;
  };
  agent_browser: {
    tools: "all";
    content_boundaries: true;
    persist_state: false;
    allowed_domains?: string[];
  };
};

export class BrowserConfigurationError extends Error {
  readonly code: BrowserErrorCode;

  constructor(code: BrowserErrorCode, message: string) {
    super(message);
    this.name = "BrowserConfigurationError";
    this.code = code;
  }
}

const LOCAL_ALLOWED_DOMAINS = ["localhost", "*.localhost", "host.docker.internal"];
const HOST_RESOLVER_RULES = "--host-resolver-rules=MAP localhost host.docker.internal,MAP *.localhost host.docker.internal";
const CA_FINGERPRINT_PATTERN = /^[A-F0-9]{64}$/;

function validatePort(port: number): void {
  if (!Number.isInteger(port) || port < 1_024 || port > 65_535) {
    throw new BrowserConfigurationError("PORT_INVALID", "Browser renderer port must be an integer from 1024 to 65535.");
  }
}

function validatePinnedImage(imageRef: string): void {
  const lastSegment = imageRef.split("/").at(-1) ?? "";
  const hasDigest = /@sha256:[a-f0-9]{64}$/i.test(imageRef);
  const hasVersionedTag = lastSegment.includes(":") && !/:latest$/i.test(lastSegment);
  if (!hasDigest && !hasVersionedTag) {
    throw new BrowserConfigurationError("UNPINNED_IMAGE", "Browser renderer image must use an immutable digest or versioned tag.");
  }
}

function validateMode(mode: string): asserts mode is BrowserNetworkMode {
  if (mode !== "local" && mode !== "corporate") {
    throw new BrowserConfigurationError("NETWORK_MODE_INVALID", `Unknown browser network mode: ${mode}`);
  }
}

export function buildBrowserPolicy(input: BrowserPolicyInput): BrowserLaunchPolicy {
  validateMode(input.mode);
  validatePort(input.hostPort);

  const corporate = input.mode === "corporate";
  if (corporate && (!input.corporateImageRef || !input.caFingerprint)) {
    throw new BrowserConfigurationError(
      "CORPORATE_CA_MISSING",
      "Corporate browser mode requires a derived image and corporate CA fingerprint.",
    );
  }
  if (corporate && !CA_FINGERPRINT_PATTERN.test(input.caFingerprint ?? "")) {
    throw new BrowserConfigurationError("CORPORATE_CA_MISSING", "Corporate CA fingerprint must be 64 uppercase hexadecimal characters.");
  }

  const imageRef = corporate ? input.corporateImageRef! : (input.imageRef ?? BROWSERLESS_BASE_IMAGE);
  validatePinnedImage(imageRef);

  const labels: Record<string, string> = {
    "io.anvil.browser.owner": "anvil",
    "io.anvil.browser.schema": String(BROWSER_SCHEMA_VERSION),
    "io.anvil.browser.mode": input.mode,
    "io.anvil.browser.image-ref": imageRef,
  };
  if (corporate) labels["io.anvil.browser.ca-fingerprint"] = input.caFingerprint!;

  return {
    mode: input.mode,
    container: {
      name: corporate ? "anvil-browser-corporate" : "anvil-browser-local",
      image_ref: imageRef,
      bind_host: "127.0.0.1",
      host_port: input.hostPort,
      container_port: 3000,
      restart_policy: "unless-stopped",
      shm_size: "2g",
      concurrent: 2,
      timeout_ms: 300_000,
      labels,
    },
    browserless_launch: {
      args: [HOST_RESOLVER_RULES],
      ...(corporate ? {} : { acceptInsecureCerts: true as const }),
    },
    agent_browser: {
      tools: "all",
      content_boundaries: true,
      persist_state: false,
      ...(corporate ? {} : { allowed_domains: [...LOCAL_ALLOWED_DOMAINS] }),
    },
  };
}

export function redactBrowserText(value: string): string {
  return value
    .replace(/-----BEGIN CERTIFICATE-----[\s\S]*?-----END CERTIFICATE-----/g, "[REDACTED CERTIFICATE]")
    .replace(/([?&]token=)[^&\s]+/gi, "$1[REDACTED]")
    .replace(/\b(TOKEN=)[^\s]+/g, "$1[REDACTED]");
}
