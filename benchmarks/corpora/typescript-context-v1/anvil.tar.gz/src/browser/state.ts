import { randomBytes, randomUUID } from "node:crypto";
import { chmod, lstat, mkdir, readFile, rename, rm, writeFile } from "node:fs/promises";
import { isAbsolute, join, resolve } from "node:path";

import type { CorporateCaSource } from "./corporate-ca.ts";
import { BROWSERLESS_BASE_IMAGE, BROWSER_SCHEMA_VERSION, BrowserConfigurationError } from "./policy.ts";

export const DEFAULT_LOCAL_BROWSER_PORT = 48_131;
export const DEFAULT_CORPORATE_BROWSER_PORT = 48_132;

export type BrowserStatePaths = {
  root: string;
  config: string;
  secrets: string;
};

export type BrowserRuntimeConfig = {
  schema_version: 1;
  base_image: string;
  local: { host_port: number };
  corporate: {
    host_port: number;
    status: "unconfigured" | "configured";
    image_ref?: string;
    ca_fingerprint?: string;
    installed_ca_path?: string;
    source?: CorporateCaSource;
  };
};

export type BrowserRuntimeSecrets = {
  schema_version: 1;
  local_token: string;
  corporate_token: string;
};

export type BrowserState = {
  paths: BrowserStatePaths;
  config: BrowserRuntimeConfig;
  secrets: BrowserRuntimeSecrets;
};

export type BrowserStateRead = { kind: "missing" } | { kind: "invalid"; message: string } | ({ kind: "ok" } & BrowserState);

const TOKEN_PATTERN = /^[a-f0-9]{64}$/;
const FINGERPRINT_PATTERN = /^[A-F0-9]{64}$/;

function stateError(message: string): BrowserConfigurationError {
  return new BrowserConfigurationError("BROWSER_STATE_INVALID", message);
}

export function resolveBrowserStatePaths(anvilHome: string): BrowserStatePaths {
  if (!isAbsolute(anvilHome) || anvilHome.includes("\0")) throw stateError("Anvil home must be an absolute local path.");
  const root = join(resolve(anvilHome), "browser");
  return { root, config: join(root, "config.json"), secrets: join(root, "secrets.json") };
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function validPort(value: unknown): value is number {
  return Number.isInteger(value) && Number(value) >= 1_024 && Number(value) <= 65_535;
}

function validBaseImage(value: unknown): value is string {
  return typeof value === "string" && /@sha256:[a-f0-9]{64}$/i.test(value);
}

function validSource(value: unknown): value is CorporateCaSource {
  if (!isRecord(value) || typeof value.kind !== "string") return false;
  if (value.kind === "file") return typeof value.path === "string" && isAbsolute(value.path);
  return (
    value.kind === "keychain" &&
    typeof value.label === "string" &&
    value.label.length > 0 &&
    typeof value.keychain === "string" &&
    isAbsolute(value.keychain)
  );
}

function parseConfig(value: unknown): BrowserRuntimeConfig | undefined {
  if (!isRecord(value) || value.schema_version !== BROWSER_SCHEMA_VERSION || !validBaseImage(value.base_image)) return undefined;
  if (!isRecord(value.local) || !validPort(value.local.host_port)) return undefined;
  if (!isRecord(value.corporate) || !validPort(value.corporate.host_port)) return undefined;
  if (value.corporate.status !== "unconfigured" && value.corporate.status !== "configured") return undefined;

  if (value.corporate.status === "configured") {
    if (
      typeof value.corporate.image_ref !== "string" ||
      /:latest$/i.test(value.corporate.image_ref) ||
      typeof value.corporate.ca_fingerprint !== "string" ||
      !FINGERPRINT_PATTERN.test(value.corporate.ca_fingerprint) ||
      typeof value.corporate.installed_ca_path !== "string" ||
      !isAbsolute(value.corporate.installed_ca_path) ||
      !validSource(value.corporate.source)
    ) {
      return undefined;
    }
  }
  return value as BrowserRuntimeConfig;
}

function parseSecrets(value: unknown): BrowserRuntimeSecrets | undefined {
  if (!isRecord(value) || value.schema_version !== BROWSER_SCHEMA_VERSION) return undefined;
  if (typeof value.local_token !== "string" || !TOKEN_PATTERN.test(value.local_token)) return undefined;
  if (typeof value.corporate_token !== "string" || !TOKEN_PATTERN.test(value.corporate_token)) return undefined;
  return value as BrowserRuntimeSecrets;
}

async function readJson(path: string): Promise<{ kind: "missing" } | { kind: "ok"; value: unknown } | { kind: "invalid" }> {
  try {
    return { kind: "ok", value: JSON.parse(await readFile(path, "utf8")) };
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code === "ENOENT") return { kind: "missing" };
    return { kind: "invalid" };
  }
}

export async function readBrowserState(anvilHome: string): Promise<BrowserStateRead> {
  let paths: BrowserStatePaths;
  try {
    paths = resolveBrowserStatePaths(anvilHome);
  } catch (error) {
    return { kind: "invalid", message: error instanceof Error ? error.message : "Browser state path is invalid." };
  }
  const [configRead, secretsRead] = await Promise.all([readJson(paths.config), readJson(paths.secrets)]);
  if (configRead.kind === "missing" && secretsRead.kind === "missing") return { kind: "missing" };
  if (configRead.kind !== "ok" || secretsRead.kind !== "ok") {
    return { kind: "invalid", message: "Browser config and secrets must both exist and contain valid JSON." };
  }
  const config = parseConfig(configRead.value);
  const secrets = parseSecrets(secretsRead.value);
  if (!config || !secrets) return { kind: "invalid", message: "Browser config or secrets failed schema validation." };
  return { kind: "ok", paths, config, secrets };
}

async function rejectUnsafeExisting(path: string, expected: "directory" | "file"): Promise<void> {
  try {
    const info = await lstat(path);
    if (info.isSymbolicLink()) throw stateError(`Browser state path must not be a symlink: ${path}`);
    if (expected === "directory" && !info.isDirectory()) throw stateError(`Browser state directory is not a directory: ${path}`);
    if (expected === "file" && !info.isFile()) throw stateError(`Browser state file is not a file: ${path}`);
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code === "ENOENT") return;
    throw error;
  }
}

async function writeJsonAtomic(path: string, value: unknown): Promise<void> {
  const temporaryPath = `${path}.${randomUUID()}.tmp`;
  try {
    await writeFile(temporaryPath, `${JSON.stringify(value, null, 2)}\n`, { encoding: "utf8", mode: 0o600, flag: "wx" });
    await rename(temporaryPath, path);
    await chmod(path, 0o600);
  } catch (error) {
    await rm(temporaryPath, { force: true });
    throw error;
  }
}

export async function ensureBrowserState(input: {
  anvilHome: string;
  baseImage?: string;
  randomToken?: () => string;
  corporate?: {
    imageRef: string;
    installedCaPath: string;
    fingerprint: string;
    source: CorporateCaSource;
  };
}): Promise<BrowserState> {
  const paths = resolveBrowserStatePaths(input.anvilHome);
  await rejectUnsafeExisting(resolve(input.anvilHome), "directory");
  await rejectUnsafeExisting(paths.root, "directory");
  await rejectUnsafeExisting(paths.config, "file");
  await rejectUnsafeExisting(paths.secrets, "file");

  const existing = await readBrowserState(input.anvilHome);
  if (existing.kind === "invalid") throw stateError(existing.message);
  const baseImage = input.baseImage ?? (existing.kind === "ok" ? existing.config.base_image : BROWSERLESS_BASE_IMAGE);
  if (!validBaseImage(baseImage)) {
    throw new BrowserConfigurationError("UNPINNED_IMAGE", "Browserless base image must use an immutable SHA-256 digest.");
  }

  const randomToken = input.randomToken ?? (() => randomBytes(32).toString("hex"));
  const secrets: BrowserRuntimeSecrets =
    existing.kind === "ok"
      ? existing.secrets
      : { schema_version: 1, local_token: randomToken(), corporate_token: randomToken() };
  if (!parseSecrets(secrets)) throw stateError("Generated browser tokens failed validation.");

  const config: BrowserRuntimeConfig = {
    schema_version: 1,
    base_image: baseImage,
    local: { host_port: existing.kind === "ok" ? existing.config.local.host_port : DEFAULT_LOCAL_BROWSER_PORT },
    corporate: input.corporate
      ? {
          host_port: existing.kind === "ok" ? existing.config.corporate.host_port : DEFAULT_CORPORATE_BROWSER_PORT,
          status: "configured",
          image_ref: input.corporate.imageRef,
          ca_fingerprint: input.corporate.fingerprint,
          installed_ca_path: input.corporate.installedCaPath,
          source: input.corporate.source,
        }
      : existing.kind === "ok"
        ? existing.config.corporate
        : { host_port: DEFAULT_CORPORATE_BROWSER_PORT, status: "unconfigured" },
  };
  if (!parseConfig(config)) throw stateError("Browser configuration failed schema validation.");

  await mkdir(paths.root, { recursive: true, mode: 0o700 });
  await chmod(paths.root, 0o700);
  await writeJsonAtomic(paths.secrets, secrets);
  await writeJsonAtomic(paths.config, config);
  return { paths, config, secrets };
}

export async function removeBrowserState(anvilHome: string): Promise<boolean> {
  const paths = resolveBrowserStatePaths(anvilHome);
  await rejectUnsafeExisting(paths.root, "directory");
  const existing = await readBrowserState(anvilHome);
  if (existing.kind === "missing") return false;
  if (existing.kind === "invalid") throw stateError(existing.message);
  await rm(paths.root, { recursive: true, force: false });
  return true;
}
