type JsonRecord = Record<string, unknown>;

export type BrowserMcpGuardDecision =
  | { kind: "forward"; line: string }
  | { kind: "respond"; line: string };

export const BLOCKED_TOOL_NAMES = new Set([
  "agent_browser_batch",
  "agent_browser_chat",
  "agent_browser_connect",
  "agent_browser_doctor",
  "agent_browser_get_cdp_url",
  "agent_browser_inspect",
  "agent_browser_install",
  "agent_browser_profiles",
  "agent_browser_upgrade",
]);

export const BLOCKED_TOOL_PREFIXES = [
  "agent_browser_auth_",
  "agent_browser_clipboard_",
  "agent_browser_dashboard_",
  "agent_browser_plugin_",
  "agent_browser_session",
  "agent_browser_state_",
  "agent_browser_stream_",
];

export const BLOCKED_ARGUMENTS = new Set([
  "actionPolicy",
  "allowedDomains",
  "args",
  "autoConnect",
  "executablePath",
  "extension",
  "extraArgs",
  "ignoreHttpsErrors",
  "initScript",
  "namespace",
  "profile",
  "proxy",
  "proxyBypass",
  "restore",
  "restoreCheckFn",
  "restoreCheckText",
  "restoreCheckUrl",
  "restoreSave",
  "state",
]);

// Blocked argument names that are harmless on a specific tool. `state` is the storage-state file
// everywhere except wait_for_load, where it is the page load state (load|domcontentloaded|networkidle).
const ALLOWED_TOOL_ARGUMENTS = new Map<string, ReadonlySet<string>>([
  ["agent_browser_wait_for_load", new Set(["state"])],
]);

function isRecord(value: unknown): value is JsonRecord {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function isBlockedTool(name: string): boolean {
  return BLOCKED_TOOL_NAMES.has(name) || BLOCKED_TOOL_PREFIXES.some((prefix) => name.startsWith(prefix));
}

function isBlockedArgument(toolName: string, argument: string): boolean {
  if (!BLOCKED_ARGUMENTS.has(argument)) return false;
  return ALLOWED_TOOL_ARGUMENTS.get(toolName)?.has(argument) !== true;
}

function advertisesMissingRequirement(schema: JsonRecord): boolean {
  if (!Array.isArray(schema.required)) return false;
  const properties = isRecord(schema.properties) ? schema.properties : {};
  return schema.required.some((name) => typeof name !== "string" || !(name in properties));
}

function requestIdKey(value: unknown): string | undefined {
  return typeof value === "string" || typeof value === "number" ? JSON.stringify(value) : undefined;
}

function rejectionPayload(id: unknown): JsonRecord {
  return {
    jsonrpc: "2.0",
    id: typeof id === "string" || typeof id === "number" ? id : null,
    error: {
      code: -32602,
      message: "Browser Eyes policy rejected an unsafe browser tool or per-call policy override.",
    },
  };
}

function rejection(id: unknown): BrowserMcpGuardDecision {
  return { kind: "respond", line: JSON.stringify(rejectionPayload(id)) };
}

function filterTool(tool: unknown): unknown | undefined {
  if (!isRecord(tool) || typeof tool.name !== "string") return tool;
  if (isBlockedTool(tool.name)) return undefined;
  if (!isRecord(tool.inputSchema)) return tool;
  if (isRecord(tool.inputSchema.properties)) {
    for (const argument of BLOCKED_ARGUMENTS) {
      if (isBlockedArgument(tool.name, argument)) delete tool.inputSchema.properties[argument];
    }
  }
  // A tool that still requires an argument the policy strips is uncallable anyway, and advertising
  // the contradictory schema makes model providers reject every request for the rest of the session.
  if (advertisesMissingRequirement(tool.inputSchema)) return undefined;
  return tool;
}

function filterToolListResponse(message: JsonRecord): void {
  if (!isRecord(message.result) || !Array.isArray(message.result.tools)) return;
  message.result.tools = message.result.tools.map(filterTool).filter((tool) => tool !== undefined);
}

export function createBrowserMcpPolicyGuard(): {
  clientLine: (line: string) => BrowserMcpGuardDecision;
  serverLine: (line: string) => { kind: "forward"; line: string };
} {
  const toolListRequestIds = new Set<string>();
  return {
    clientLine(line) {
      let message: unknown;
      try {
        message = JSON.parse(line);
      } catch {
        return { kind: "forward", line };
      }
      if (Array.isArray(message)) {
        return {
          kind: "respond",
          line: JSON.stringify(message.map((entry) => rejectionPayload(isRecord(entry) ? entry.id : null))),
        };
      }
      if (!isRecord(message)) return { kind: "forward", line };

      const idKey = requestIdKey(message.id);
      if (message.method === "tools/list" && idKey) toolListRequestIds.add(idKey);
      if (message.method !== "tools/call") return { kind: "forward", line };
      if (!isRecord(message.params) || typeof message.params.name !== "string") return rejection(message.id);
      if (isBlockedTool(message.params.name)) return rejection(message.id);
      if (isRecord(message.params.arguments)) {
        for (const argument of Object.keys(message.params.arguments)) {
          if (isBlockedArgument(message.params.name, argument)) return rejection(message.id);
        }
      }
      return { kind: "forward", line };
    },
    serverLine(line) {
      let message: unknown;
      try {
        message = JSON.parse(line);
      } catch {
        return { kind: "forward", line };
      }
      if (!isRecord(message)) return { kind: "forward", line };
      const idKey = requestIdKey(message.id);
      if (!idKey || !toolListRequestIds.delete(idKey)) return { kind: "forward", line };
      filterToolListResponse(message);
      return { kind: "forward", line: JSON.stringify(message) };
    },
  };
}
