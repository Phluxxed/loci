import type { BrainUsageRecallEvent } from "../brain-usage/index.ts";
import type { BrainRecallObservation } from "../brain-context/index.ts";
import type { SkillInvocationOutcome } from "../skill-invocations/index.ts";

export const ANVIL_MEASUREMENT_PROJECTION_SCHEMA_VERSION = 1 as const;

export type ProjectionRate = {
  numerator: number;
  denominator: number;
  value: number | null;
};

export type ProjectionDistribution = {
  count: number;
  min?: number;
  p50?: number;
  p95?: number;
  p99?: number;
  max?: number;
};

export type JournalFamily = "brain" | "skill";

export type JournalCursorV1 = {
  workspace_id: string;
  canonical_path: string;
  prefix_hash: string;
  byte_offset: number;
  last_record_id: string | null;
};

export type BrainProjectionContributionV1 = {
  family: "brain";
  source_path: string;
  record_id: string;
  bucket_start: string;
  bucket_end: string;
  brain_id: string;
  workspace_id: string;
  host: string;
  runtime: "unknown";
  event: BrainUsageRecallEvent;
  observation?: Pick<BrainRecallObservation, "timing" | "render_outcome" | "diagnostics">;
};

export type SkillProjectionContributionV1 = {
  family: "skill";
  source_path: string;
  record_id: string;
  bucket_start: string;
  bucket_end: string;
  skill: string;
  recorded_outcome: SkillInvocationOutcome;
  workspace_id: string;
  host: string;
  runtime: "unknown";
  version: 1 | 2;
  has_session_id: boolean;
  has_turn_id: boolean;
  has_message_id: boolean;
};

export type ProjectionContributionV1 = BrainProjectionContributionV1 | SkillProjectionContributionV1;

export type StoredAnvilMeasurementProjectionStateV1 = {
  schema_version: typeof ANVIL_MEASUREMENT_PROJECTION_SCHEMA_VERSION;
  binding_fingerprint: string;
  journals: Record<string, JournalCursorV1>;
  record_ids: Record<string, true>;
  contributions: Record<string, ProjectionContributionV1>;
};

export type BrainRecallProjectionRowV1 = {
  schema_version: 1;
  projection: "brain_recall_daily_v1";
  generated_at: string;
  source_cutoff: { binding_fingerprint: string; journals: JournalCursorV1[] };
  bucket: { start: string; end: string };
  cohort: {
    brain_id: string;
    workspace_id: string;
    host: string;
    runtime: string;
  };
  counts: {
    recalled: number;
    no_match: number;
    degraded: number;
    disabled: number;
    eligible: number;
  };
  rates: {
    operation_success: ProjectionRate;
    degradation: ProjectionRate;
    truncation: ProjectionRate;
    diagnostics_by_code: Record<string, ProjectionRate>;
  };
  coverage: {
    instrumentation: ProjectionRate;
  };
  distributions: {
    total_ms: ProjectionDistribution;
    retrieval_ms: ProjectionDistribution;
  };
  limitations: string[];
};

export type SkillInvocationProjectionRowV1 = {
  schema_version: 1;
  projection: "skill_invocation_daily_v1";
  generated_at: string;
  source_cutoff: { binding_fingerprint: string; journals: JournalCursorV1[] };
  bucket: { start: string; end: string };
  cohort: {
    skill: string;
    recorded_outcome: SkillInvocationOutcome;
    workspace_id: string;
    host: string;
    runtime: string;
  };
  counts: {
    recorded: number;
    legacy: number;
    v2: number;
  };
  rates: {
    recorded_outcome_share: ProjectionRate;
  };
  coverage: {
    traceable_v2: ProjectionRate;
    message_v2: ProjectionRate;
  };
  limitations: string[];
};

export type AnvilMeasurementProjectionSnapshotV1 = {
  schema_version: 1;
  generated_at: string;
  source_cutoff: { binding_fingerprint: string; journals: JournalCursorV1[] };
  brain_recall_daily_v1: BrainRecallProjectionRowV1[];
  skill_invocation_daily_v1: SkillInvocationProjectionRowV1[];
};

export type ProjectionSkipCounts = {
  trailing_partial_line: number;
  non_recall_brain_record: number;
};

export type AdvanceAnvilMeasurementProjectionOutput = {
  rows_processed: number;
  journals_replayed: number;
  source_cutoff: { binding_fingerprint: string; journals: JournalCursorV1[] };
  skipped: ProjectionSkipCounts;
};

export type ReconciliationFamily = {
  eligible: number;
  sample_size: number;
  exact_matches: number;
  mismatches: string[];
  skipped: Record<string, number>;
};

export type AnvilMeasurementProjectionReconciliation = {
  schema_version: 1;
  seed: string;
  source_cutoff: { binding_fingerprint: string; journals: JournalCursorV1[] };
  brain: ReconciliationFamily;
  skill: ReconciliationFamily;
};
