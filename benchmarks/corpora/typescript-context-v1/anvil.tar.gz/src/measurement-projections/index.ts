import { createHash, randomUUID } from "node:crypto";
import { mkdir, readFile, readdir, rename, rm, writeFile } from "node:fs/promises";
import { dirname, join, resolve } from "node:path";
import { setTimeout as sleep } from "node:timers/promises";

import {
  BRAIN_USAGE_RECALL_EVENTS,
  validateBrainUsageRecord,
} from "../brain-usage/index.ts";
import type { BrainUsageRecord, BrainUsageRecallEvent } from "../brain-usage/index.ts";
import { validateSkillInvocationRecord } from "../skill-invocations/index.ts";
import type { SkillInvocationRecord } from "../skill-invocations/index.ts";
import {
  readStoredWorkContextBinding,
  resolveWorkContextStateRoot,
  workspaceKeyForRoot,
} from "../work-context/index.ts";
import type {
  AdvanceAnvilMeasurementProjectionOutput,
  AnvilMeasurementProjectionReconciliation,
  AnvilMeasurementProjectionSnapshotV1,
  BrainProjectionContributionV1,
  BrainRecallProjectionRowV1,
  JournalCursorV1,
  JournalFamily,
  ProjectionContributionV1,
  ProjectionDistribution,
  ProjectionRate,
  ProjectionSkipCounts,
  ReconciliationFamily,
  SkillInvocationProjectionRowV1,
  SkillProjectionContributionV1,
  StoredAnvilMeasurementProjectionStateV1,
} from "./model.ts";

export type AnvilMeasurementProjectionOptions = {
  stateRoot?: string;
  projectionRoot?: string;
  now?: () => string;
};

export type ReconcileAnvilMeasurementProjectionOptions = AnvilMeasurementProjectionOptions & {
  seed?: string;
  maxSample?: number;
};

type JournalDescriptor = {
  family: JournalFamily;
  workspaceId: string;
  path: string;
};

type TrustedBindings = {
  fingerprint: string;
  hostsByWorkspaceSession: Map<string, Set<string>>;
};

const STATE_FILE = "state-v1.json";
const LOCK_DIR = "writer.lock";
const LOCK_TIMEOUT_MS = 5_000;
const LOCK_RETRY_MS = 20;
const DEFAULT_RECONCILIATION_SAMPLE = 200;
const MAX_RECONCILIATION_SAMPLE = 200;

function sha256(value: string | Buffer): string {
  return createHash("sha256").update(value).digest("hex");
}

function nowIso(): string {
  return new Date().toISOString();
}

function isNodeError(error: unknown): error is NodeJS.ErrnoException {
  return typeof error === "object" && error !== null && "code" in error;
}

function roots(options: AnvilMeasurementProjectionOptions): { stateRoot: string; projectionRoot: string; statePath: string } {
  const stateRoot = resolveWorkContextStateRoot(options.stateRoot);
  const projectionRoot = resolve(options.projectionRoot ?? join(stateRoot, "measurement-projections", "anvil-v1"));
  return { stateRoot, projectionRoot, statePath: join(projectionRoot, STATE_FILE) };
}

function emptyState(bindingFingerprint: string): StoredAnvilMeasurementProjectionStateV1 {
  return {
    schema_version: 1,
    binding_fingerprint: bindingFingerprint,
    journals: {},
    record_ids: {},
    contributions: {},
  };
}

async function readState(statePath: string, bindingFingerprint = sha256("")): Promise<StoredAnvilMeasurementProjectionStateV1> {
  let text: string;
  try {
    text = await readFile(statePath, "utf8");
  } catch (error) {
    if (isNodeError(error) && error.code === "ENOENT") return emptyState(bindingFingerprint);
    throw error;
  }
  let value: unknown;
  try {
    value = JSON.parse(text);
  } catch (error) {
    throw new Error(`Anvil measurement projection state is malformed: ${String(error)}`);
  }
  if (typeof value !== "object" || value === null || Array.isArray(value)) {
    throw new Error("Anvil measurement projection state is malformed");
  }
  const state = value as Partial<StoredAnvilMeasurementProjectionStateV1> & {
    record_hashes?: Record<string, string>;
  };
  const storedRecordIds = state.record_ids ?? state.record_hashes;
  if (
    state.schema_version !== 1
    || typeof state.binding_fingerprint !== "string"
    || typeof state.journals !== "object"
    || state.journals === null
    || typeof storedRecordIds !== "object"
    || storedRecordIds === null
    || typeof state.contributions !== "object"
    || state.contributions === null
  ) {
    throw new Error("Anvil measurement projection state is malformed or unsupported");
  }
  const contributions = Object.fromEntries(
    Object.entries(state.contributions).map(([key, contribution]) => {
      const { source_hash: _legacySourceHash, ...safeContribution } = contribution as ProjectionContributionV1 & {
        source_hash?: string;
      };
      return [key, safeContribution as ProjectionContributionV1];
    }),
  );
  return {
    schema_version: 1,
    binding_fingerprint: state.binding_fingerprint,
    journals: state.journals as Record<string, JournalCursorV1>,
    record_ids: Object.fromEntries(Object.keys(storedRecordIds).map((key) => [key, true])),
    contributions,
  };
}

async function writeStateAtomic(statePath: string, state: StoredAnvilMeasurementProjectionStateV1): Promise<void> {
  await mkdir(dirname(statePath), { recursive: true, mode: 0o700 });
  const temporaryPath = `${statePath}.${process.pid}.${randomUUID()}.tmp`;
  await writeFile(temporaryPath, `${JSON.stringify(state, null, 2)}\n`, { encoding: "utf8", mode: 0o600 });
  await rename(temporaryPath, statePath);
}

async function withWriterLock<T>(projectionRoot: string, operation: () => Promise<T>): Promise<T> {
  const lockPath = join(projectionRoot, LOCK_DIR);
  const deadline = Date.now() + LOCK_TIMEOUT_MS;
  await mkdir(projectionRoot, { recursive: true, mode: 0o700 });
  while (true) {
    try {
      await mkdir(lockPath, { mode: 0o700 });
      break;
    } catch (error) {
      if (!isNodeError(error) || error.code !== "EEXIST") throw error;
      if (Date.now() >= deadline) throw new Error("Timed out acquiring the Anvil measurement projection writer lock");
      await sleep(LOCK_RETRY_MS);
    }
  }
  try {
    return await operation();
  } finally {
    await rm(lockPath, { recursive: true, force: true });
  }
}

async function directories(path: string): Promise<string[]> {
  try {
    const entries = await readdir(path, { withFileTypes: true });
    return entries.filter((entry) => entry.isDirectory()).map((entry) => entry.name).sort();
  } catch (error) {
    if (isNodeError(error) && error.code === "ENOENT") return [];
    throw error;
  }
}

async function discoverJournals(stateRoot: string): Promise<JournalDescriptor[]> {
  const descriptors: JournalDescriptor[] = [];
  for (const [family, rootName, fileName] of [
    ["brain", "brain-usage", "usage.jsonl"],
    ["skill", "skill-invocations", "invocations.jsonl"],
  ] as const) {
    const workspaceRoot = join(stateRoot, rootName, "workspaces");
    for (const workspaceId of await directories(workspaceRoot)) {
      const path = join(workspaceRoot, workspaceId, fileName);
      try {
        await readFile(path);
        descriptors.push({ family, workspaceId, path: resolve(path) });
      } catch (error) {
        if (!isNodeError(error) || error.code !== "ENOENT") throw error;
      }
    }
  }
  return descriptors.sort((left, right) => left.path.localeCompare(right.path));
}

function bindingMapKey(workspaceId: string, sessionId: string): string {
  return `${workspaceId}\u0000${sessionId}`;
}

async function readTrustedBindings(stateRoot: string): Promise<TrustedBindings> {
  const bindingsRoot = join(stateRoot, "work-context", "bindings");
  let files: string[];
  try {
    files = (await readdir(bindingsRoot, { withFileTypes: true }))
      .filter((entry) => entry.isFile() && entry.name.endsWith(".json"))
      .map((entry) => entry.name)
      .sort();
  } catch (error) {
    if (isNodeError(error) && error.code === "ENOENT") return { fingerprint: sha256(""), hostsByWorkspaceSession: new Map() };
    throw error;
  }
  const tuples: string[] = [];
  const hostsByWorkspaceSession = new Map<string, Set<string>>();
  for (const file of files) {
    const path = join(bindingsRoot, file);
    const bindingId = file.slice(0, -".json".length);
    const record = await readStoredWorkContextBinding({ bindingId, stateRoot });
    if (record === undefined || record.collaboration_space.key !== workspaceKeyForRoot(record.collaboration_space.root)) {
      throw new Error(`Stored Work Context binding ${path} is malformed`);
    }
    const workspaceId = record.collaboration_space.key;
    const key = bindingMapKey(workspaceId, record.session_id);
    const hosts = hostsByWorkspaceSession.get(key) ?? new Set<string>();
    hosts.add(record.host);
    hostsByWorkspaceSession.set(key, hosts);
    tuples.push(`${workspaceId}\u0000${record.session_id}\u0000${record.host}`);
  }
  return { fingerprint: sha256(tuples.sort().join("\n")), hostsByWorkspaceSession };
}

function trustedHost(bindings: TrustedBindings, workspaceId: string, sessionId: string | undefined, asserted?: string): string {
  if (sessionId === undefined) return "unknown";
  const hosts = bindings.hostsByWorkspaceSession.get(bindingMapKey(workspaceId, sessionId));
  if (hosts === undefined || hosts.size !== 1) return "unknown";
  const host = hosts.values().next().value as string;
  return asserted === undefined || asserted === host ? host : "unknown";
}

function utcDay(createdAt: string): { start: string; end: string } {
  const timestamp = Date.parse(createdAt);
  const date = new Date(timestamp);
  const start = Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate());
  return { start: new Date(start).toISOString(), end: new Date(start + 86_400_000).toISOString() };
}

function brainContribution(
  record: BrainUsageRecord,
  path: string,
  bindings: TrustedBindings,
): BrainProjectionContributionV1 | undefined {
  if (!(BRAIN_USAGE_RECALL_EVENTS as readonly string[]).includes(record.event)) return undefined;
  const bucket = utcDay(record.created_at);
  return {
    family: "brain",
    source_path: path,
    record_id: record.id,
    bucket_start: bucket.start,
    bucket_end: bucket.end,
    brain_id: record.version === 1 ? `legacy:${record.brain ?? "unknown"}` : record.brain_id ?? "unknown",
    workspace_id: record.workspace.key,
    host: trustedHost(bindings, record.workspace.key, record.session_id),
    runtime: "unknown",
    event: record.event as BrainUsageRecallEvent,
    ...(record.recall_observation === undefined ? {} : {
      observation: {
        timing: { ...record.recall_observation.timing },
        render_outcome: record.recall_observation.render_outcome,
        diagnostics: [...record.recall_observation.diagnostics],
      },
    }),
  };
}

function skillContribution(
  record: SkillInvocationRecord,
  path: string,
  bindings: TrustedBindings,
): SkillProjectionContributionV1 {
  const bucket = utcDay(record.created_at);
  const current = record.version === 2 ? record : undefined;
  return {
    family: "skill",
    source_path: path,
    record_id: record.id,
    bucket_start: bucket.start,
    bucket_end: bucket.end,
    skill: record.skill,
    recorded_outcome: record.outcome,
    workspace_id: record.workspace.key,
    host: current === undefined
      ? "unknown"
      : trustedHost(bindings, record.workspace.key, current.session_id, current.host),
    runtime: "unknown",
    version: record.version,
    has_session_id: current !== undefined,
    has_turn_id: current?.turn_id !== undefined,
    has_message_id: current?.message_id !== undefined,
  };
}

function recordKey(journal: JournalDescriptor, recordId: string): string {
  return `${journal.family}\u0000${journal.path}\u0000${recordId}`;
}

function removeJournalState(state: StoredAnvilMeasurementProjectionStateV1, path: string): void {
  delete state.journals[path];
  for (const [key, contribution] of Object.entries(state.contributions)) {
    if (contribution.source_path === path) delete state.contributions[key];
  }
  const marker = `\u0000${path}\u0000`;
  for (const key of Object.keys(state.record_ids)) {
    if (key.includes(marker)) delete state.record_ids[key];
  }
}

function cutoff(state: StoredAnvilMeasurementProjectionStateV1): { binding_fingerprint: string; journals: JournalCursorV1[] } {
  return {
    binding_fingerprint: state.binding_fingerprint,
    journals: Object.values(state.journals).sort((left, right) => left.canonical_path.localeCompare(right.canonical_path)),
  };
}

function completeEnd(buffer: Buffer): number {
  const lastNewline = buffer.lastIndexOf(0x0a);
  return lastNewline < 0 ? 0 : lastNewline + 1;
}

function parseRecord(journal: JournalDescriptor, line: string, lineNumber: number): BrainUsageRecord | SkillInvocationRecord {
  let parsed: unknown;
  try {
    parsed = JSON.parse(line);
  } catch (error) {
    throw new Error(`Invalid JSON on line ${lineNumber} in ${journal.path}`, { cause: error });
  }
  return journal.family === "brain"
    ? validateBrainUsageRecord(parsed, lineNumber, journal.path)
    : validateSkillInvocationRecord(parsed, lineNumber, journal.path);
}

function storeRecordContribution(
  state: StoredAnvilMeasurementProjectionStateV1,
  journal: JournalDescriptor,
  record: BrainUsageRecord | SkillInvocationRecord,
  bindings: TrustedBindings,
  skipped: ProjectionSkipCounts,
): void {
  const key = recordKey(journal, record.id);
  state.record_ids[key] = true;
  const contribution = journal.family === "brain"
    ? brainContribution(record as BrainUsageRecord, journal.path, bindings)
    : skillContribution(record as SkillInvocationRecord, journal.path, bindings);
  if (contribution === undefined) {
    skipped.non_recall_brain_record += 1;
    return;
  }
  state.contributions[key] = contribution;
}

function canonicalRecordsBefore(
  journal: JournalDescriptor,
  buffer: Buffer,
  end: number,
): Map<string, string> {
  const records = new Map<string, string>();
  const text = buffer.subarray(0, end).toString("utf8");
  for (const [index, line] of text.split("\n").entries()) {
    if (line.trim().length === 0) continue;
    const record = parseRecord(journal, line, index + 1);
    const canonical = JSON.stringify(record);
    const previous = records.get(record.id);
    if (previous !== undefined && previous !== canonical) {
      throw new Error(`conflicting duplicate record id ${record.id} in ${journal.path}`);
    }
    records.set(record.id, canonical);
  }
  return records;
}

async function processJournal(
  state: StoredAnvilMeasurementProjectionStateV1,
  journal: JournalDescriptor,
  bindings: TrustedBindings,
  skipped: ProjectionSkipCounts,
): Promise<{ processed: number; replayed: boolean }> {
  const buffer = await readFile(journal.path);
  let cursor: JournalCursorV1 | undefined = state.journals[journal.path];
  let replayed = false;
  if (cursor !== undefined) {
    const invalidPrefix = cursor.byte_offset > buffer.length
      || sha256(buffer.subarray(0, cursor.byte_offset)) !== cursor.prefix_hash;
    if (invalidPrefix) {
      removeJournalState(state, journal.path);
      cursor = undefined;
      replayed = true;
    }
  }
  const start = cursor?.byte_offset ?? 0;
  const end = completeEnd(buffer);
  if (end < buffer.length) skipped.trailing_partial_line += 1;
  if (end < start) throw new Error(`Journal cursor for ${journal.path} is beyond its complete prefix`);
  const text = buffer.subarray(start, end).toString("utf8");
  const lines = text.split("\n");
  let processed = 0;
  let lastRecordId = cursor?.last_record_id ?? null;
  let priorCanonical: Map<string, string> | undefined;
  const batchCanonical = new Map<string, string>();
  const firstLine = start === 0 ? 1 : buffer.subarray(0, start).toString("utf8").split("\n").length;
  for (const [index, line] of lines.entries()) {
    if (line.trim().length === 0) continue;
    const record = parseRecord(journal, line, firstLine + index);
    const key = recordKey(journal, record.id);
    const canonical = JSON.stringify(record);
    const sameBatch = batchCanonical.get(key);
    if (sameBatch !== undefined && sameBatch !== canonical) {
      throw new Error(`conflicting duplicate record id ${record.id} in ${journal.path}`);
    }
    if (sameBatch === undefined && state.record_ids[key] === true) {
      priorCanonical ??= canonicalRecordsBefore(journal, buffer, start);
      const previous = priorCanonical.get(record.id);
      if (previous === undefined) throw new Error(`record id ${record.id} is missing before its stored journal cursor`);
      if (previous !== canonical) throw new Error(`conflicting duplicate record id ${record.id} in ${journal.path}`);
    } else if (sameBatch === undefined) {
      storeRecordContribution(state, journal, record, bindings, skipped);
    }
    batchCanonical.set(key, canonical);
    lastRecordId = record.id;
    processed += 1;
  }
  state.journals[journal.path] = {
    workspace_id: journal.workspaceId,
    canonical_path: journal.path,
    prefix_hash: sha256(buffer.subarray(0, end)),
    byte_offset: end,
    last_record_id: lastRecordId,
  };
  return { processed, replayed };
}

export async function advanceAnvilMeasurementProjections(
  options: AnvilMeasurementProjectionOptions = {},
): Promise<AdvanceAnvilMeasurementProjectionOutput> {
  const paths = roots(options);
  return withWriterLock(paths.projectionRoot, async () => {
    const bindings = await readTrustedBindings(paths.stateRoot);
    const state = await readState(paths.statePath, bindings.fingerprint);
    const journals = await discoverJournals(paths.stateRoot);
    const discoveredPaths = new Set(journals.map((journal) => journal.path));
    for (const path of Object.keys(state.journals)) {
      if (!discoveredPaths.has(path)) {
        throw new Error(`Canonical journal ${path} disappeared after the recorded projection cutoff`);
      }
    }
    let journalsReplayed = 0;
    if (state.binding_fingerprint !== bindings.fingerprint) {
      journalsReplayed = Object.keys(state.journals).length;
      state.journals = {};
      state.record_ids = {};
      state.contributions = {};
    }
    state.binding_fingerprint = bindings.fingerprint;
    let rowsProcessed = 0;
    const skipped: ProjectionSkipCounts = { trailing_partial_line: 0, non_recall_brain_record: 0 };
    for (const journal of journals) {
      const result = await processJournal(state, journal, bindings, skipped);
      rowsProcessed += result.processed;
      if (result.replayed) journalsReplayed += 1;
    }
    await writeStateAtomic(paths.statePath, state);
    return { rows_processed: rowsProcessed, journals_replayed: journalsReplayed, source_cutoff: cutoff(state), skipped };
  });
}

export async function rebuildAnvilMeasurementProjections(
  options: AnvilMeasurementProjectionOptions = {},
): Promise<AdvanceAnvilMeasurementProjectionOutput> {
  const paths = roots(options);
  return withWriterLock(paths.projectionRoot, async () => {
    const bindings = await readTrustedBindings(paths.stateRoot);
    const state = emptyState(bindings.fingerprint);
    const skipped: ProjectionSkipCounts = { trailing_partial_line: 0, non_recall_brain_record: 0 };
    let rowsProcessed = 0;
    const journals = await discoverJournals(paths.stateRoot);
    for (const journal of journals) rowsProcessed += (await processJournal(state, journal, bindings, skipped)).processed;
    await writeStateAtomic(paths.statePath, state);
    return {
      rows_processed: rowsProcessed,
      journals_replayed: journals.length,
      source_cutoff: cutoff(state),
      skipped,
    };
  });
}

function rate(numerator: number, denominator: number): ProjectionRate {
  return { numerator, denominator, value: denominator === 0 ? null : numerator / denominator };
}

function distribution(values: number[]): ProjectionDistribution {
  if (values.length === 0) return { count: 0 };
  const sorted = [...values].sort((left, right) => left - right);
  const nearest = (percentile: number): number => sorted[Math.max(0, Math.ceil(percentile * sorted.length) - 1)]!;
  return {
    count: sorted.length,
    min: sorted[0],
    p50: nearest(0.5),
    p95: nearest(0.95),
    p99: nearest(0.99),
    max: sorted.at(-1),
  };
}

function brainRows(
  state: StoredAnvilMeasurementProjectionStateV1,
  generatedAt: string,
): BrainRecallProjectionRowV1[] {
  type Aggregate = {
    contribution: BrainProjectionContributionV1;
    byEvent: Record<BrainUsageRecallEvent, number>;
    totalMs: number[];
    retrievalMs: number[];
    instrumented: number;
    truncationDenominator: number;
    truncated: number;
    diagnostics: Map<string, number>;
  };
  const groups = new Map<string, Aggregate>();
  for (const contribution of Object.values(state.contributions)) {
    if (contribution.family !== "brain") continue;
    const key = [
      contribution.bucket_start,
      contribution.brain_id,
      contribution.workspace_id,
      contribution.host,
      contribution.runtime,
    ].join("\u0000");
    const aggregate: Aggregate = groups.get(key) ?? {
      contribution,
      byEvent: { recalled: 0, no_match: 0, degraded: 0, disabled: 0 },
      totalMs: [] as number[],
      retrievalMs: [] as number[],
      instrumented: 0,
      truncationDenominator: 0,
      truncated: 0,
      diagnostics: new Map(),
    };
    aggregate.byEvent[contribution.event] += 1;
    const eligible = contribution.event !== "disabled";
    if (eligible && contribution.observation !== undefined) {
      aggregate.instrumented += 1;
      aggregate.totalMs.push(contribution.observation.timing.total_ms);
      if (contribution.observation.timing.retrieval_ms !== undefined) {
        aggregate.retrievalMs.push(contribution.observation.timing.retrieval_ms);
      }
      aggregate.truncationDenominator += 1;
      if (contribution.observation.render_outcome === "truncated") aggregate.truncated += 1;
      for (const code of new Set(contribution.observation.diagnostics)) {
        aggregate.diagnostics.set(code, (aggregate.diagnostics.get(code) ?? 0) + 1);
      }
    }
    groups.set(key, aggregate);
  }
  const sourceCutoff = cutoff(state);
  return Array.from(groups.entries()).sort(([left], [right]) => left.localeCompare(right)).map(([, aggregate]) => {
    const item = aggregate.contribution;
    const eligible = aggregate.byEvent.recalled + aggregate.byEvent.no_match + aggregate.byEvent.degraded;
    return {
      schema_version: 1,
      projection: "brain_recall_daily_v1",
      generated_at: generatedAt,
      source_cutoff: sourceCutoff,
      bucket: { start: item.bucket_start, end: item.bucket_end },
      cohort: {
        brain_id: item.brain_id,
        workspace_id: item.workspace_id,
        host: item.host,
        runtime: item.runtime,
      },
      counts: { ...aggregate.byEvent, eligible },
      rates: {
        operation_success: rate(aggregate.byEvent.recalled + aggregate.byEvent.no_match, eligible),
        degradation: rate(aggregate.byEvent.degraded, eligible),
        truncation: rate(aggregate.truncated, aggregate.truncationDenominator),
        diagnostics_by_code: Object.fromEntries(
          Array.from(aggregate.diagnostics.entries()).sort(([left], [right]) => left.localeCompare(right))
            .map(([code, count]) => [code, rate(count, eligible)]),
        ),
      },
      coverage: { instrumentation: rate(aggregate.instrumented, eligible) },
      distributions: { total_ms: distribution(aggregate.totalMs), retrieval_ms: distribution(aggregate.retrievalMs) },
      limitations: [
        "ACTIVITY_NOT_OUTCOME",
        "BOUNDED_SOURCE_CUTOFF",
        "BRAIN_USEFULNESS_NOT_MEASURED",
        ...(item.host === "unknown" || item.runtime === "unknown" ? ["COHORT_IDENTITY_UNKNOWN"] : []),
      ].sort(),
    };
  });
}

function skillRows(
  state: StoredAnvilMeasurementProjectionStateV1,
  generatedAt: string,
): SkillInvocationProjectionRowV1[] {
  type Aggregate = { contribution: SkillProjectionContributionV1; recorded: number; legacy: number; v2: number; traceable: number; messaged: number };
  const groups = new Map<string, Aggregate>();
  const composition = new Map<string, number>();
  for (const contribution of Object.values(state.contributions)) {
    if (contribution.family !== "skill") continue;
    const base = [
      contribution.bucket_start,
      contribution.skill,
      contribution.workspace_id,
      contribution.host,
      contribution.runtime,
    ].join("\u0000");
    composition.set(base, (composition.get(base) ?? 0) + 1);
    const key = `${base}\u0000${contribution.recorded_outcome}`;
    const aggregate = groups.get(key) ?? { contribution, recorded: 0, legacy: 0, v2: 0, traceable: 0, messaged: 0 };
    aggregate.recorded += 1;
    if (contribution.version === 1) aggregate.legacy += 1;
    else {
      aggregate.v2 += 1;
      if (contribution.has_session_id && contribution.has_turn_id) aggregate.traceable += 1;
      if (contribution.has_message_id) aggregate.messaged += 1;
    }
    groups.set(key, aggregate);
  }
  const sourceCutoff = cutoff(state);
  return Array.from(groups.entries()).sort(([left], [right]) => left.localeCompare(right)).map(([key, aggregate]) => {
    const item = aggregate.contribution;
    const base = key.slice(0, key.lastIndexOf("\u0000"));
    return {
      schema_version: 1,
      projection: "skill_invocation_daily_v1",
      generated_at: generatedAt,
      source_cutoff: sourceCutoff,
      bucket: { start: item.bucket_start, end: item.bucket_end },
      cohort: {
        skill: item.skill,
        recorded_outcome: item.recorded_outcome,
        workspace_id: item.workspace_id,
        host: item.host,
        runtime: item.runtime,
      },
      counts: { recorded: aggregate.recorded, legacy: aggregate.legacy, v2: aggregate.v2 },
      rates: { recorded_outcome_share: rate(aggregate.recorded, composition.get(base) ?? 0) },
      coverage: {
        traceable_v2: rate(aggregate.traceable, aggregate.v2),
        message_v2: rate(aggregate.messaged, aggregate.v2),
      },
      limitations: [
        "ACTIVITY_NOT_OUTCOME",
        "BOUNDED_SOURCE_CUTOFF",
        "SKILL_ELIGIBLE_POPULATION_UNAVAILABLE",
        "SKILL_OUTCOME_SELF_REPORTED",
        "TRACE_JOIN_COVERAGE_INCOMPLETE",
        ...(item.host === "unknown" || item.runtime === "unknown" ? ["COHORT_IDENTITY_UNKNOWN"] : []),
      ].sort(),
    };
  });
}

export async function readAnvilMeasurementProjectionSnapshot(
  options: AnvilMeasurementProjectionOptions = {},
): Promise<AnvilMeasurementProjectionSnapshotV1> {
  const paths = roots(options);
  const state = await readState(paths.statePath);
  const generatedAt = (options.now ?? nowIso)();
  return {
    schema_version: 1,
    generated_at: generatedAt,
    source_cutoff: cutoff(state),
    brain_recall_daily_v1: brainRows(state, generatedAt),
    skill_invocation_daily_v1: skillRows(state, generatedAt),
  };
}

function sampleRank(seed: string, key: string): string {
  return sha256(`${seed}\u0000${key}`);
}

function normalizeSample(value: number | undefined): number {
  if (value === undefined) return DEFAULT_RECONCILIATION_SAMPLE;
  if (!Number.isInteger(value) || value < 0) throw new Error("maxSample must be a non-negative integer");
  return Math.min(value, MAX_RECONCILIATION_SAMPLE);
}

function reconciliationFamily(
  family: JournalFamily,
  expected: Map<string, ProjectionContributionV1>,
  state: StoredAnvilMeasurementProjectionStateV1,
  seed: string,
  maxSample: number,
): ReconciliationFamily {
  const eligible = Array.from(expected.entries())
    .filter(([, contribution]) => contribution.family === family)
    .sort(([left], [right]) => sampleRank(seed, left).localeCompare(sampleRank(seed, right)) || left.localeCompare(right));
  const sample = eligible.slice(0, maxSample);
  const mismatches: string[] = [];
  let exactMatches = 0;
  for (const [key, contribution] of sample) {
    if (JSON.stringify(state.contributions[key]) === JSON.stringify(contribution)) exactMatches += 1;
    else mismatches.push(sha256(key).slice(0, 24));
  }
  return {
    eligible: eligible.length,
    sample_size: sample.length,
    exact_matches: exactMatches,
    mismatches,
    skipped: { sample_limit: Math.max(0, eligible.length - sample.length) },
  };
}

async function independentlyReplayCutoff(
  state: StoredAnvilMeasurementProjectionStateV1,
  bindings: TrustedBindings,
): Promise<Map<string, ProjectionContributionV1>> {
  const expectedState = emptyState(bindings.fingerprint);
  const skipped: ProjectionSkipCounts = { trailing_partial_line: 0, non_recall_brain_record: 0 };
  for (const cursor of cutoff(state).journals) {
    const family: JournalFamily = cursor.canonical_path.includes("/brain-usage/") ? "brain" : "skill";
    const journal: JournalDescriptor = { family, workspaceId: cursor.workspace_id, path: cursor.canonical_path };
    const buffer = await readFile(cursor.canonical_path);
    if (cursor.byte_offset > buffer.length || sha256(buffer.subarray(0, cursor.byte_offset)) !== cursor.prefix_hash) {
      throw new Error(`Projection cutoff no longer matches canonical journal ${cursor.canonical_path}`);
    }
    const text = buffer.subarray(0, cursor.byte_offset).toString("utf8");
    const seen = new Map<string, string>();
    for (const [index, line] of text.split("\n").entries()) {
      if (line.trim().length === 0) continue;
      const record = parseRecord(journal, line, index + 1);
      const key = recordKey(journal, record.id);
      const canonical = JSON.stringify(record);
      const previous = seen.get(key);
      if (previous !== undefined && previous !== canonical) {
        throw new Error(`conflicting duplicate record id ${record.id} in ${journal.path}`);
      }
      if (previous === undefined) storeRecordContribution(expectedState, journal, record, bindings, skipped);
      seen.set(key, canonical);
    }
  }
  return new Map(Object.entries(expectedState.contributions));
}

export async function reconcileAnvilMeasurementProjections(
  options: ReconcileAnvilMeasurementProjectionOptions = {},
): Promise<AnvilMeasurementProjectionReconciliation> {
  const paths = roots(options);
  const state = await readState(paths.statePath);
  const bindings = await readTrustedBindings(paths.stateRoot);
  if (bindings.fingerprint !== state.binding_fingerprint) {
    throw new Error("Trusted Work Context bindings changed after the projection cutoff; advance before reconciling");
  }
  const seed = options.seed ?? "anvil-measurement-v1";
  if (seed.trim().length === 0) throw new Error("seed must be a non-empty string");
  const maxSample = normalizeSample(options.maxSample);
  const expected = await independentlyReplayCutoff(state, bindings);
  const brain = reconciliationFamily("brain", expected, state, seed, maxSample);
  const skill = reconciliationFamily("skill", expected, state, seed, maxSample);
  const result: AnvilMeasurementProjectionReconciliation = {
    schema_version: 1,
    seed,
    source_cutoff: cutoff(state),
    brain,
    skill,
  };
  if (brain.mismatches.length > 0 || skill.mismatches.length > 0) {
    throw new Error(`Anvil measurement projection reconciliation failed: ${JSON.stringify(result)}`);
  }
  return result;
}

export type {
  AdvanceAnvilMeasurementProjectionOutput,
  AnvilMeasurementProjectionReconciliation,
  AnvilMeasurementProjectionSnapshotV1,
  BrainRecallProjectionRowV1,
  JournalCursorV1,
  SkillInvocationProjectionRowV1,
} from "./model.ts";
