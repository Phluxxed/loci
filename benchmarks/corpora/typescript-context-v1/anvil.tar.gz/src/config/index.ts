import { homedir } from "node:os";
import { isAbsolute, join, resolve } from "node:path";

export type AnvilConfigErrorCode = "VALIDATION_ERROR" | "RUNTIME_AGENT_ID_MISMATCH";

export class AnvilConfigError extends Error {
  code: AnvilConfigErrorCode;

  constructor(code: AnvilConfigErrorCode, message: string) {
    super(`${code}: ${message}`);
    this.name = "AnvilConfigError";
    this.code = code;
  }
}

export type AgentIdStatus = "configured" | "input_matches_runtime" | "missing" | "mismatch";

export type AgentIdentity = {
  status: AgentIdStatus;
  requestedAgentId?: string;
  runtimeAgentId?: string;
  resolvedAgentId?: string;
};

export type ResolveAgentIdentityInput = {
  agentId?: string;
  env?: Record<string, string | undefined>;
};

export type ResolvePathInput = {
  env?: Record<string, string | undefined>;
  homeDir?: string;
};

export type ResolveAnvilHomeInput = ResolvePathInput & {
  anvilHome?: string;
};

export type ResolveBrainRootInput = ResolvePathInput & {
  agentId: string;
  brainRoot?: string;
};

const AGENT_ID_PATTERN = /^[a-z0-9][a-z0-9_-]{0,63}$/;

function configuredEnv(env: Record<string, string | undefined> | undefined): Record<string, string | undefined> {
  return env ?? process.env;
}

function configuredHome(homeDir: string | undefined): string {
  return homeDir ?? homedir();
}

function configuredValue(value: string | undefined): string | undefined {
  return value === undefined ? undefined : value.length > 0 ? value : undefined;
}

export function validateAgentId(value: string): string {
  if (value.length === 0) throw new AnvilConfigError("VALIDATION_ERROR", "agentId must not be empty");
  if (value !== value.trim()) throw new AnvilConfigError("VALIDATION_ERROR", "agentId must not contain leading or trailing whitespace");
  if (!AGENT_ID_PATTERN.test(value)) {
    throw new AnvilConfigError(
      "VALIDATION_ERROR",
      "agentId must use 1-64 lowercase letters, numbers, underscores, or hyphens, and start with a letter or number",
    );
  }
  return value;
}

export function resolveAgentIdentity(input: ResolveAgentIdentityInput = {}): AgentIdentity {
  const runtimeAgentId = configuredValue(configuredEnv(input.env).ANVIL_AGENT_ID);
  const requestedAgentId = configuredValue(input.agentId);

  const validatedRuntimeAgentId = runtimeAgentId === undefined ? undefined : validateAgentId(runtimeAgentId);
  const validatedRequestedAgentId = requestedAgentId === undefined ? undefined : validateAgentId(requestedAgentId);

  if (validatedRuntimeAgentId && validatedRequestedAgentId) {
    if (validatedRuntimeAgentId !== validatedRequestedAgentId) {
      return {
        status: "mismatch",
        runtimeAgentId: validatedRuntimeAgentId,
        requestedAgentId: validatedRequestedAgentId,
      };
    }
    return {
      status: "input_matches_runtime",
      runtimeAgentId: validatedRuntimeAgentId,
      requestedAgentId: validatedRequestedAgentId,
      resolvedAgentId: validatedRuntimeAgentId,
    };
  }

  if (validatedRuntimeAgentId) {
    return {
      status: "configured",
      runtimeAgentId: validatedRuntimeAgentId,
      resolvedAgentId: validatedRuntimeAgentId,
    };
  }

  if (validatedRequestedAgentId) {
    return {
      status: "configured",
      requestedAgentId: validatedRequestedAgentId,
      resolvedAgentId: validatedRequestedAgentId,
    };
  }

  return { status: "missing" };
}

function expandHomePath(path: string, homeDir: string): string {
  if (path === "~") return homeDir;
  if (path.startsWith("~/")) return join(homeDir, path.slice(2));
  if (path.startsWith("~")) throw new AnvilConfigError("VALIDATION_ERROR", "user-qualified ~ paths are not supported");
  return path;
}

function resolveConfiguredPath(value: string, field: string, homeDir: string): string {
  if (value.length === 0) throw new AnvilConfigError("VALIDATION_ERROR", `${field} must not be empty`);
  if (value !== value.trim()) throw new AnvilConfigError("VALIDATION_ERROR", `${field} must not contain leading or trailing whitespace`);
  if (value.includes("\0")) throw new AnvilConfigError("VALIDATION_ERROR", `${field} must not contain null bytes`);
  if (value.split(/[\\/]+/).includes("..")) {
    throw new AnvilConfigError("VALIDATION_ERROR", `${field} must not contain path traversal segments`);
  }
  const expanded = expandHomePath(value, homeDir);
  if (!isAbsolute(expanded)) throw new AnvilConfigError("VALIDATION_ERROR", `${field} must be an absolute or home-relative path`);
  return resolve(expanded);
}

export function resolveAnvilHome(input: ResolveAnvilHomeInput = {}): string {
  const env = configuredEnv(input.env);
  const homeDir = configuredHome(input.homeDir);
  const raw = input.anvilHome ?? env.ANVIL_HOME ?? join(homeDir, ".anvil");
  return resolveConfiguredPath(raw, "anvilHome", homeDir);
}

export function defaultBrainRoot(agentId: string, homeDir = homedir()): string {
  return join(resolve(homeDir), ".anvil-brain", validateAgentId(agentId));
}

export function defaultWikiAlias(agentId: string): string {
  return `anvil-brain-${validateAgentId(agentId)}`;
}

export function resolveBrainRoot(input: ResolveBrainRootInput): string {
  const agentId = validateAgentId(input.agentId);
  const homeDir = configuredHome(input.homeDir);
  const raw = input.brainRoot ?? defaultBrainRoot(agentId, homeDir);
  return resolveConfiguredPath(raw, "brainRoot", homeDir);
}

export function agentConfigPath(anvilHome: string, agentId: string): string {
  return join(resolveConfiguredPath(anvilHome, "anvilHome", homedir()), "agents", validateAgentId(agentId), "config.json");
}
