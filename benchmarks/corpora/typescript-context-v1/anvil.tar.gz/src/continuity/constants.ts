export const INDEX_SCHEMA_VERSION = 1;
export const CURRENT_SCHEMA_VERSION = 2;
export const LEGACY_CURRENT_SCHEMA_VERSION = 1;
export const EVENT_SCHEMA_VERSION = 1;

export const CONTINUITY_DIR_NAME = "continuity";
export const WORKSPACES_DIR_NAME = "workspaces";

export const MAX_ACTIVE_DECISIONS = 8;
export const MAX_OPEN_QUESTIONS = 8;
export const MAX_NEXT_ACTIONS = 8;
export const MAX_CONTINUITY_NOTES = 6;
export const MAX_QUALITY_BAR_ITEMS = 6;
export const MAX_ITEM_CHARS = 240;
export const MAX_EVENT_SUMMARY_CHARS = 500;
export const MAX_EVENT_DETAILS_CHARS = 4_000;
export const MAX_ACTIVE_TASK_TEXT_CHARS = 500;
export const MAX_ACTIVE_TASK_DETAILS_CHARS = 3_400;
export const DEFAULT_EVENT_LIMIT = 20;
export const MAX_EVENT_LIMIT = 50;

export const EVENT_TYPES = ["decision", "hypothesis", "open_question", "next_action", "correction", "phase_change"] as const;
export const EVENT_STATUSES = ["active", "superseded", "resolved", "deferred"] as const;
