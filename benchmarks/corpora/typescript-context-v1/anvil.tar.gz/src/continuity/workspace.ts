import { join, resolve } from "node:path";
import * as z from "zod/v4";

import { CONTINUITY_DIR_NAME, WORKSPACES_DIR_NAME } from "./constants.ts";
import { workspaceRefSchema } from "../work-context/space.ts";
import type { WorkspaceRef } from "../work-context/space.ts";

export {
  directoryWorkspaceRef,
  gitWorkspaceRef,
  normalizeWorkspaceRoot,
  workspaceKeyForRoot,
} from "../work-context/space.ts";
export type { WorkspaceRef } from "../work-context/space.ts";

export const continuityPathsSchema = z
  .object({
    workspace: workspaceRefSchema,
    stateRoot: z.string().min(1),
    continuityRoot: z.string().min(1),
    indexPath: z.string().min(1),
    workspaceDir: z.string().min(1),
    currentPath: z.string().min(1),
    eventsPath: z.string().min(1),
    workspaceMutationKey: z.string().min(1),
  })
  .strict();
export type ContinuityPaths = z.infer<typeof continuityPathsSchema>;

export function deriveContinuityPaths({ stateRoot, workspace }: { stateRoot: string; workspace: WorkspaceRef }): ContinuityPaths {
  if (!stateRoot || typeof stateRoot !== "string") throw new Error("stateRoot must be a non-empty string");
  if (!workspace || typeof workspace !== "object") throw new Error("workspace must be supplied");

  const continuityRoot = join(stateRoot, CONTINUITY_DIR_NAME);
  const workspaceDir = join(continuityRoot, WORKSPACES_DIR_NAME, workspace.key);
  return {
    workspace,
    stateRoot,
    continuityRoot,
    indexPath: join(continuityRoot, "index.json"),
    workspaceDir,
    currentPath: join(workspaceDir, "current.json"),
    eventsPath: join(workspaceDir, "events.jsonl"),
    workspaceMutationKey: join(workspaceDir, ".mutation.lock"),
  };
}
