import { spawnSync } from "node:child_process";
import { stat } from "node:fs/promises";

import { readAllEvents, readCurrent } from "./store.ts";
import { resolveContinuityWorkspace } from "./service.ts";
import type { ContinuityEvent, ContinuityItem, CurrentFrame } from "./schema.ts";
import type { ContinuityWorkspaceOptions } from "./service.ts";
import type { ContinuityPaths } from "./workspace.ts";

export type ContinuityDoctorSeverity = "ok" | "warning" | "error";

export type ContinuityDoctorFinding = {
  severity: ContinuityDoctorSeverity;
  code: string;
  message: string;
  path?: string;
  target?: string;
  event_id?: string;
  count?: number;
  size_bytes?: number;
};

export type ContinuityDoctorOutput = {
  status: ContinuityDoctorSeverity;
  workspace: ContinuityPaths["workspace"];
  findings: ContinuityDoctorFinding[];
};

export type DoctorContinuityInput = ContinuityWorkspaceOptions & {
  checkStaleness?: boolean;
};

type ProjectionLink = {
  target: "active_decisions" | "open_questions" | "next_actions" | "continuity_notes";
  eventId: string;
};

type StalenessCandidate = {
  target: "active_decisions" | "open_questions" | "next_actions";
  item: ContinuityItem;
};

const targetEventTypes = {
  active_decisions: "decision",
  open_questions: "open_question",
  next_actions: "next_action",
} as const;

function isNodeError(error: unknown): error is NodeJS.ErrnoException {
  return typeof error === "object" && error !== null && "code" in error;
}

function worstStatus(findings: ContinuityDoctorFinding[]): ContinuityDoctorSeverity {
  if (findings.some((finding) => finding.severity === "error")) return "error";
  if (findings.some((finding) => finding.severity === "warning")) return "warning";
  return "ok";
}

async function fileSizeFinding(path: string, codePrefix: string, label: string): Promise<ContinuityDoctorFinding> {
  try {
    const file = await stat(path);
    if (!file.isFile()) {
      return {
        severity: "error",
        code: `${codePrefix}_NOT_FILE`,
        message: `${label} exists but is not a regular file`,
        path,
      };
    }
    return {
      severity: "ok",
      code: `${codePrefix}_SIZE`,
      message: `${label} size is ${file.size} bytes`,
      path,
      size_bytes: file.size,
    };
  } catch (error) {
    if (isNodeError(error) && error.code === "ENOENT") {
      return {
        severity: "warning",
        code: `${codePrefix}_MISSING`,
        message: `${label} is missing`,
        path,
      };
    }
    const message = error instanceof Error ? error.message : String(error);
    return {
      severity: "error",
      code: `${codePrefix}_STAT_FAILED`,
      message: `Could not stat ${label}: ${message}`,
      path,
    };
  }
}

function projectionLinks(frame: CurrentFrame): ProjectionLink[] {
  const links: ProjectionLink[] = [];
  for (const target of ["active_decisions", "open_questions", "next_actions"] as const) {
    for (const item of frame[target]) {
      if (item.event_id) links.push({ target, eventId: item.event_id });
    }
  }
  for (const note of frame.continuity_notes) {
    const match = /^\[([^\]]+)\]\s/.exec(note);
    if (match) links.push({ target: "continuity_notes", eventId: match[1] });
  }
  return links;
}

function projectionFindings(frame: CurrentFrame, events: ContinuityEvent[], currentPath: string): ContinuityDoctorFinding[] {
  const byId = new Map(events.map((event) => [event.id, event]));
  const findings: ContinuityDoctorFinding[] = [];

  for (const link of projectionLinks(frame)) {
    const event = byId.get(link.eventId);
    if (!event) {
      findings.push({
        severity: "error",
        code: "PROJECTION_EVENT_MISSING",
        message: `${link.target} references missing event ${link.eventId}`,
        path: currentPath,
        target: link.target,
        event_id: link.eventId,
      });
      continue;
    }

    if (link.target !== "continuity_notes") {
      const expectedType = targetEventTypes[link.target];
      if (event.type !== expectedType) {
        findings.push({
          severity: "error",
          code: "PROJECTION_EVENT_TYPE_MISMATCH",
          message: `${link.target} references ${event.type} event ${event.id}; expected ${expectedType}`,
          path: currentPath,
          target: link.target,
          event_id: event.id,
        });
      }
      if (event.status !== "active") {
        findings.push({
          severity: "error",
          code: "PROJECTION_EVENT_INACTIVE",
          message: `${link.target} references ${event.status} event ${event.id}; expected active`,
          path: currentPath,
          target: link.target,
          event_id: event.id,
        });
      }
    }
  }

  if (findings.length === 0) {
    findings.push({
      severity: "ok",
      code: "PROJECTION_LINKS_VALID",
      message: "Projection event links are valid",
      count: projectionLinks(frame).length,
    });
  }
  return findings;
}

function activeProjectionItems(frame: CurrentFrame): StalenessCandidate[] {
  return (["active_decisions", "open_questions", "next_actions"] as const).flatMap((target) =>
    frame[target].map((item) => ({ target, item })),
  );
}

function gitCommitAfter(root: string, recordedAt: string): { ok: true; commit?: string } | { ok: false; message: string } {
  const result = spawnSync("git", ["-C", root, "log", "--since", recordedAt, "--format=%H", "-n", "1"], {
    encoding: "utf8",
    stdio: ["ignore", "pipe", "pipe"],
  });
  if (result.error) return { ok: false, message: result.error.message };
  if (result.status !== 0) return { ok: false, message: result.stderr.trim() || `git log exited with status ${result.status}` };

  const commit = result.stdout.trim().split("\n").filter(Boolean)[0];
  return commit ? { ok: true, commit } : { ok: true };
}

function stalenessFindings(frame: CurrentFrame, workspaceRoot: string): ContinuityDoctorFinding[] {
  const findings: ContinuityDoctorFinding[] = [];
  let checked = 0;

  for (const { target, item } of activeProjectionItems(frame)) {
    if (!item.event_id) continue;
    if (!item.recorded_at) {
      findings.push({
        severity: "warning",
        code: "STALENESS_RECORDED_AT_MISSING",
        message: `${target} item ${item.event_id} has no recorded_at timestamp; staleness cannot be computed`,
        target,
        event_id: item.event_id,
      });
      continue;
    }

    checked += 1;
    const result = gitCommitAfter(workspaceRoot, item.recorded_at);
    if (!result.ok) {
      findings.push({
        severity: "warning",
        code: "STALENESS_CHECK_FAILED",
        message: `Could not compute staleness for ${target} item ${item.event_id}: ${result.message}`,
        target,
        event_id: item.event_id,
      });
      continue;
    }

    if (result.commit) {
      findings.push({
        severity: "warning",
        code: "PROJECTION_STALE_AFTER_COMMIT",
        message: `${target} item ${item.event_id} was recorded at ${item.recorded_at}; repository has newer commit ${result.commit}`,
        target,
        event_id: item.event_id,
      });
    }
  }

  if (findings.length === 0) {
    findings.push({
      severity: "ok",
      code: "STALENESS_CHECK_OK",
      message: "No active projection items have newer repository commits",
      count: checked,
    });
  }
  return findings;
}

export async function doctorContinuity(input: DoctorContinuityInput = {}): Promise<ContinuityDoctorOutput> {
  const paths = resolveContinuityWorkspace(input);
  const findings: ContinuityDoctorFinding[] = [];

  const [current, events, currentSize, eventsSize, indexSize] = await Promise.all([
    readCurrent(paths),
    readAllEvents(paths),
    fileSizeFinding(paths.currentPath, "CURRENT_FILE", "Current frame file"),
    fileSizeFinding(paths.eventsPath, "EVENT_LOG_FILE", "Event log file"),
    fileSizeFinding(paths.indexPath, "INDEX_FILE", "Workspace index file"),
  ]);

  if (current.kind === "ok") {
    findings.push({
      severity: "ok",
      code: "CURRENT_READABLE",
      message: "Current frame is readable and schema-valid",
      path: paths.currentPath,
    });
  } else if (current.kind === "missing") {
    findings.push({
      severity: "warning",
      code: "CURRENT_MISSING",
      message: current.message,
      path: current.path,
    });
  } else {
    findings.push({
      severity: "error",
      code: "CURRENT_MALFORMED",
      message: current.message,
      path: current.path,
    });
  }

  if (events.kind === "ok") {
    findings.push({
      severity: "ok",
      code: "EVENT_LOG_READABLE",
      message: "Event log is readable and schema-valid",
      path: paths.eventsPath,
      count: events.total,
    });
  } else if (events.kind === "missing") {
    findings.push({
      severity: current.kind === "ok" ? "error" : "warning",
      code: "EVENT_LOG_MISSING",
      message: events.message,
      path: events.path,
    });
  } else {
    findings.push({
      severity: "error",
      code: "EVENT_LOG_MALFORMED",
      message: events.message,
      path: events.path,
    });
  }

  findings.push(currentSize, eventsSize, indexSize);

  if (current.kind === "ok" && events.kind === "ok") {
    findings.push(...projectionFindings(current.value, events.events, paths.currentPath));
    if (input.checkStaleness) findings.push(...stalenessFindings(current.value, paths.workspace.root));
  }

  return {
    status: worstStatus(findings),
    workspace: paths.workspace,
    findings,
  };
}

export function renderContinuityDoctor(result: ContinuityDoctorOutput): string {
  const lines = [
    `Continuity doctor: ${result.status}`,
    `Workspace: ${result.workspace.label ?? result.workspace.key} (${result.workspace.root})`,
  ];
  for (const finding of result.findings) {
    const path = finding.path ? ` [${finding.path}]` : "";
    lines.push(`[${finding.severity}] ${finding.code}: ${finding.message}${path}`);
  }
  return lines.join("\n");
}
