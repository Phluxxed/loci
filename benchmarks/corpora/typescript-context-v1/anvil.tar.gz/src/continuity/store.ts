import { AsyncLocalStorage } from "node:async_hooks";
import { randomUUID } from "node:crypto";
import { constants as fsConstants } from "node:fs";
import { access, appendFile, mkdir, readFile, rename, rm, writeFile } from "node:fs/promises";
import { dirname, join } from "node:path";
import { setTimeout as sleep } from "node:timers/promises";

import { CURRENT_SCHEMA_VERSION, EVENT_SCHEMA_VERSION, INDEX_SCHEMA_VERSION, MAX_EVENT_LIMIT } from "./constants.ts";
import {
  validateContinuityEvent,
  validateCurrentFrame,
  validateCurrentFrameInput,
  validateEventInput,
  validateEventSource,
  validateIndexFile,
} from "./schema.ts";
import type {
  ContinuityEvent,
  CurrentFrame,
  CurrentFrameInput,
  EventInput,
  EventSource,
  IndexFile,
} from "./schema.ts";
import type { ContinuityPaths } from "./workspace.ts";

type ReadOk<T> = { kind: "ok"; value: T };
type ReadMissing = { kind: "missing"; path: string; message: string };
type ReadMalformed = { kind: "malformed"; path: string; message: string };

export type ReadResult<T> = ReadOk<T> | ReadMissing | ReadMalformed;
export type ReadEventsResult =
  | { kind: "ok"; events: ContinuityEvent[]; total: number; truncated: boolean }
  | ReadMissing
  | ReadMalformed;

type Clock = () => string;
type IdGenerator = () => string;
type MutationLockOptions = {
  now?: Clock;
  retryDelayMs?: number;
  timeoutMs?: number;
};

const DEFAULT_MUTATION_LOCK_TIMEOUT_MS = 5_000;
const DEFAULT_MUTATION_LOCK_RETRY_DELAY_MS = 25;
const mutationLockContext = new AsyncLocalStorage<Set<string>>();

function isNodeError(error: unknown): error is NodeJS.ErrnoException {
  return typeof error === "object" && error !== null && "code" in error;
}

async function exists(path: string): Promise<boolean> {
  try {
    await access(path, fsConstants.F_OK);
    return true;
  } catch {
    return false;
  }
}

async function readLockOwner(lockPath: string): Promise<string | undefined> {
  try {
    const text = await readFile(join(lockPath, "owner.json"), "utf8");
    return text.trim().slice(0, 500);
  } catch {
    return undefined;
  }
}

export async function withWorkspaceMutationLock<T>(
  paths: ContinuityPaths,
  mutation: () => Promise<T>,
  options: MutationLockOptions = {},
): Promise<T> {
  const lockPath = paths.workspaceMutationKey;
  const heldLocks = mutationLockContext.getStore();
  if (heldLocks?.has(lockPath)) return mutation();

  const timeoutMs = Math.max(0, Math.floor(options.timeoutMs ?? DEFAULT_MUTATION_LOCK_TIMEOUT_MS));
  const retryDelayMs = Math.max(1, Math.floor(options.retryDelayMs ?? DEFAULT_MUTATION_LOCK_RETRY_DELAY_MS));
  const deadline = Date.now() + timeoutMs;

  await mkdir(dirname(lockPath), { recursive: true });
  while (true) {
    try {
      await mkdir(lockPath);
      break;
    } catch (error) {
      if (!isNodeError(error) || error.code !== "EEXIST") {
        const message = error instanceof Error ? error.message : String(error);
        throw new Error(
          `Failed to acquire continuity mutation lock for workspace ${paths.workspace.key} at ${lockPath}: ${message}`,
        );
      }

      if (Date.now() >= deadline) {
        const owner = await readLockOwner(lockPath);
        const ownerDetail = owner ? ` Existing lock owner: ${owner}` : "";
        throw new Error(
          `Timed out acquiring continuity mutation lock for workspace ${paths.workspace.key} at ${lockPath} after ${timeoutMs}ms.${ownerDetail}`,
        );
      }

      await sleep(retryDelayMs);
    }
  }

  try {
    await writeFile(
      join(lockPath, "owner.json"),
      `${JSON.stringify(
        {
          pid: process.pid,
          workspace_key: paths.workspace.key,
          acquired_at: (options.now ?? nowIso)(),
        },
        null,
        2,
      )}\n`,
      "utf8",
    );

    const nextHeldLocks = new Set(heldLocks ?? []);
    nextHeldLocks.add(lockPath);
    return await mutationLockContext.run(nextHeldLocks, mutation);
  } finally {
    await rm(lockPath, { recursive: true, force: true });
  }
}

async function readJson(path: string): Promise<ReadResult<unknown>> {
  let text;
  try {
    text = await readFile(path, "utf8");
  } catch (error) {
    if (isNodeError(error) && error.code === "ENOENT") {
      return { kind: "missing", path, message: `${path} does not exist` };
    }
    const message = error instanceof Error ? error.message : String(error);
    return { kind: "malformed", path, message };
  }

  try {
    return { kind: "ok", value: JSON.parse(text) };
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    return { kind: "malformed", path, message: `Malformed JSON in ${path}: ${message}` };
  }
}

async function writeJsonAtomic(path: string, value: unknown): Promise<void> {
  await mkdir(dirname(path), { recursive: true });
  const tempPath = `${path}.${process.pid}.${Date.now()}.tmp`;
  await writeFile(tempPath, `${JSON.stringify(value, null, 2)}\n`, "utf8");
  await rename(tempPath, path);
}

async function appendJsonLine(path: string, value: unknown): Promise<void> {
  await mkdir(dirname(path), { recursive: true });
  await appendFile(path, `${JSON.stringify(value)}\n`, "utf8");
}

async function readEventLog(paths: ContinuityPaths): Promise<ReadResult<ContinuityEvent[]>> {
  let text;
  try {
    text = await readFile(paths.eventsPath, "utf8");
  } catch (error) {
    if (isNodeError(error) && error.code === "ENOENT") {
      return { kind: "missing", path: paths.eventsPath, message: `${paths.eventsPath} does not exist` };
    }
    const message = error instanceof Error ? error.message : String(error);
    return { kind: "malformed", path: paths.eventsPath, message };
  }

  const events: ContinuityEvent[] = [];
  const lines = text.split("\n").filter((line) => line.trim().length > 0);
  for (const [index, line] of lines.entries()) {
    let parsed;
    try {
      parsed = JSON.parse(line);
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      return { kind: "malformed", path: paths.eventsPath, message: `Malformed event JSON on line ${index + 1}: ${message}` };
    }

    const validated = validateContinuityEvent(parsed);
    if (!validated.ok) {
      return { kind: "malformed", path: paths.eventsPath, message: `Invalid event on line ${index + 1}: ${validated.message}` };
    }
    events.push(validated.value);
  }

  return { kind: "ok", value: events };
}

function nowIso(): string {
  return new Date().toISOString();
}

function newEventId(): string {
  const stamp = new Date().toISOString().slice(0, 10).replace(/-/g, "");
  return `evt_${stamp}_${randomUUID().replace(/-/g, "").slice(0, 12)}`;
}

function ensureCurrentInput(input: unknown): CurrentFrameInput {
  const validated = validateCurrentFrameInput(input);
  if (!validated.ok) throw new Error(`Invalid current frame input: ${validated.message}`);
  return validated.value;
}

function ensureEventInput(input: unknown): EventInput {
  const validated = validateEventInput(input);
  if (!validated.ok) throw new Error(`Invalid event input: ${validated.message}`);
  return validated.value;
}

function ensureEventSource(source: unknown): EventSource {
  const validated = validateEventSource(source);
  if (!validated.ok) throw new Error(`Invalid event source: ${validated.message}`);
  return validated.value;
}

function bootstrapFrameInput(eventInput: EventInput, eventId: string, recordedAt: string): CurrentFrameInput {
  const item = { event_id: eventId, recorded_at: recordedAt, summary: eventInput.summary };
  const isActive = eventInput.status === "active";
  const continuityNotes = [`Auto-initialized by first ${eventInput.type} continuity event.`];
  if (!isActive || !["decision", "open_question", "next_action"].includes(eventInput.type)) {
    continuityNotes.push(`First event (${eventInput.type}/${eventInput.status}): ${eventInput.summary}`);
  }

  return {
    operating_mode: "continuity bootstrap",
    intent: "Maintain compact workspace continuity for this workspace.",
    quality_bar: [
      "Treat continuity as workspace-local context, not ground truth.",
      "Record explicit events for durable decisions, questions, corrections, and next actions.",
    ],
    permission_envelope: {
      default: "follow active system, developer, user, and repository instructions",
      allowed_without_approval: ["read continuity state", "record explicit continuity events"],
      requires_approval: ["overwrite malformed continuity state", "delete continuity history"],
    },
    active_decisions: isActive && eventInput.type === "decision" ? [item] : [],
    open_questions: isActive && eventInput.type === "open_question" ? [item] : [],
    next_actions: isActive && eventInput.type === "next_action" ? [item] : [],
    continuity_notes: continuityNotes,
  };
}

export async function readIndex(paths: ContinuityPaths): Promise<ReadResult<IndexFile>> {
  const json = await readJson(paths.indexPath);
  if (json.kind !== "ok") return json;
  const validated = validateIndexFile(json.value);
  if (!validated.ok) return { kind: "malformed", path: paths.indexPath, message: validated.message };
  return { kind: "ok", value: validated.value };
}

export async function readCurrent(paths: ContinuityPaths): Promise<ReadResult<CurrentFrame>> {
  const json = await readJson(paths.currentPath);
  if (json.kind !== "ok") return json;
  const validated = validateCurrentFrame(json.value);
  if (!validated.ok) return { kind: "malformed", path: paths.currentPath, message: validated.message };
  return { kind: "ok", value: validated.value };
}

export async function readRecentEvents(paths: ContinuityPaths, requestedLimit = 20): Promise<ReadEventsResult> {
  const result = await readEventLog(paths);
  if (result.kind !== "ok") return result;
  const events = result.value;

  const limit = Math.max(0, Math.min(MAX_EVENT_LIMIT, Math.floor(Number(requestedLimit) || 0)));
  const visible = limit === 0 ? [] : events.slice(-limit);
  return { kind: "ok", events: visible, total: events.length, truncated: events.length > visible.length };
}

export async function readAllEvents(paths: ContinuityPaths): Promise<ReadEventsResult> {
  const result = await readEventLog(paths);
  if (result.kind !== "ok") return result;
  return { kind: "ok", events: result.value, total: result.value.length, truncated: false };
}

export async function initWorkspace(
  paths: ContinuityPaths,
  input: CurrentFrameInput,
  options: { now?: Clock } = {},
): Promise<CurrentFrame> {
  return withWorkspaceMutationLock(paths, () => initWorkspaceUnlocked(paths, input, options), { now: options.now });
}

async function initWorkspaceUnlocked(
  paths: ContinuityPaths,
  input: CurrentFrameInput,
  options: { now?: Clock } = {},
): Promise<CurrentFrame> {
  if (await exists(paths.currentPath)) throw new Error(`Workspace ${paths.workspace.key} is already initialized`);

  const now = (options.now ?? nowIso)();
  const frameInput = ensureCurrentInput(input);
  const current: CurrentFrame = {
    version: CURRENT_SCHEMA_VERSION,
    updated_at: now,
    workspace: paths.workspace,
    ...frameInput,
    active_task: frameInput.active_task ?? null,
  };

  let index: IndexFile;
  const existingIndex = await readIndex(paths);
  if (existingIndex.kind === "ok") {
    index = existingIndex.value;
  } else if (existingIndex.kind === "missing") {
    index = { version: INDEX_SCHEMA_VERSION, updated_at: now, workspaces: [] };
  } else {
    throw new Error(`Cannot initialize with malformed index: ${existingIndex.message}`);
  }

  const existingWorkspace = index.workspaces.find((item) => item.key === paths.workspace.key);
  const workspaceIndexEntry = {
    key: paths.workspace.key,
    kind: paths.workspace.kind,
    root: paths.workspace.root,
    label: paths.workspace.label ?? paths.workspace.key,
    created_at: existingWorkspace?.created_at ?? now,
    updated_at: now,
  };

  index = {
    version: INDEX_SCHEMA_VERSION,
    updated_at: now,
    workspaces: existingWorkspace
      ? index.workspaces.map((item) => (item.key === paths.workspace.key ? workspaceIndexEntry : item))
      : [...index.workspaces, workspaceIndexEntry],
  };

  await mkdir(paths.workspaceDir, { recursive: true });
  await writeJsonAtomic(paths.indexPath, index);
  await writeJsonAtomic(paths.currentPath, current);
  await writeFile(paths.eventsPath, "", { encoding: "utf8", flag: "a" });
  return current;
}

export async function recordEvent(
  paths: ContinuityPaths,
  input: EventInput,
  options: {
    source?: EventSource;
    now?: Clock;
    id?: IdGenerator;
  } = {},
): Promise<ContinuityEvent> {
  return withWorkspaceMutationLock(paths, () => recordEventUnlocked(paths, input, options), { now: options.now });
}

async function recordEventUnlocked(
  paths: ContinuityPaths,
  input: EventInput,
  options: {
    source?: EventSource;
    now?: Clock;
    id?: IdGenerator;
  } = {},
): Promise<ContinuityEvent> {
  const eventInput = ensureEventInput(input);
  const eventId = (options.id ?? newEventId)();
  const now = (options.now ?? nowIso)();
  const source = ensureEventSource(options.source ?? { kind: "manual" });

  const current = await readCurrent(paths);
  let currentFrame: CurrentFrame;
  if (current.kind === "ok") {
    currentFrame = current.value;
  } else if (current.kind === "missing") {
    currentFrame = await initWorkspaceUnlocked(paths, bootstrapFrameInput(eventInput, eventId, now), { now: () => now });
  } else {
    throw new Error(`Cannot record event without valid current frame: ${current.message}`);
  }

  await writeFile(paths.eventsPath, "", { encoding: "utf8", flag: "a" });
  const event: ContinuityEvent = {
    version: EVENT_SCHEMA_VERSION,
    id: eventId,
    created_at: now,
    effective_at: now,
    ...eventInput,
    workspace: currentFrame.workspace,
    source,
  };

  await appendJsonLine(paths.eventsPath, event);
  return event;
}

export async function updateCurrent(
  paths: ContinuityPaths,
  input: CurrentFrameInput,
  options: { now?: Clock } = {},
): Promise<CurrentFrame> {
  return withWorkspaceMutationLock(paths, () => updateCurrentUnlocked(paths, input, options), { now: options.now });
}

async function updateCurrentUnlocked(
  paths: ContinuityPaths,
  input: CurrentFrameInput,
  options: { now?: Clock } = {},
): Promise<CurrentFrame> {
  const current = await readCurrent(paths);
  if (current.kind !== "ok") throw new Error(`Cannot update current frame: ${current.message}`);

  const frameInput = ensureCurrentInput(input);
  const next: CurrentFrame = {
    version: CURRENT_SCHEMA_VERSION,
    updated_at: (options.now ?? nowIso)(),
    workspace: current.value.workspace,
    ...frameInput,
    active_task: frameInput.active_task ?? null,
  };
  await writeJsonAtomic(paths.currentPath, next);
  return next;
}
