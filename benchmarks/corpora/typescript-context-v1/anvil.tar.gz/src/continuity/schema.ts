import {
  CURRENT_SCHEMA_VERSION,
  LEGACY_CURRENT_SCHEMA_VERSION,
  EVENT_SCHEMA_VERSION,
  EVENT_STATUSES,
  EVENT_TYPES,
  INDEX_SCHEMA_VERSION,
  MAX_ACTIVE_DECISIONS,
  MAX_ACTIVE_TASK_TEXT_CHARS,
  MAX_CONTINUITY_NOTES,
  MAX_EVENT_DETAILS_CHARS,
  MAX_EVENT_SUMMARY_CHARS,
  MAX_NEXT_ACTIONS,
  MAX_OPEN_QUESTIONS,
  MAX_QUALITY_BAR_ITEMS,
} from "./constants.ts";
import * as z from "zod/v4";

import { workspaceRefSchema } from "../work-context/index.ts";
import type { WorkspaceRef } from "../work-context/index.ts";

export const eventTypeSchema = z.enum(EVENT_TYPES);
export const eventStatusSchema = z.enum(EVENT_STATUSES);
export type EventType = z.infer<typeof eventTypeSchema>;
export type EventStatus = z.infer<typeof eventStatusSchema>;

export type ValidationResult<T> = { ok: true; value: T } | { ok: false; message: string; path?: string };

export const continuityItemSchema = z
  .object({
    event_id: z.string().min(1).optional(),
    recorded_at: z.iso.datetime().optional(),
    summary: z.string().min(1).max(MAX_EVENT_SUMMARY_CHARS),
  })
  .strict();
export type ContinuityItem = z.infer<typeof continuityItemSchema>;

export const activeTaskStateSchema = z.enum(["active", "waiting"]);
export type ActiveTaskState = z.infer<typeof activeTaskStateSchema>;

export const activeTaskSchema = z
  .object({
    event_id: z.string().min(1),
    recorded_at: z.iso.datetime(),
    summary: z.string().min(1).max(MAX_ACTIVE_TASK_TEXT_CHARS),
    state: activeTaskStateSchema,
    next_step: z.string().min(1).max(MAX_ACTIVE_TASK_TEXT_CHARS),
  })
  .strict();
export type ActiveTask = z.infer<typeof activeTaskSchema>;

export const permissionEnvelopeSchema = z
  .object({
    default: z.string().min(1),
    allowed_without_approval: z.array(z.string().min(1)),
    requires_approval: z.array(z.string().min(1)),
  })
  .strict();
export type PermissionEnvelope = z.infer<typeof permissionEnvelopeSchema>;

export const currentFrameInputSchema = z
  .object({
    operating_mode: z.string().min(1),
    intent: z.string().min(1),
    quality_bar: z.array(z.string().min(1)).max(MAX_QUALITY_BAR_ITEMS),
    permission_envelope: permissionEnvelopeSchema,
    active_task: activeTaskSchema.nullable().optional(),
    active_decisions: z.array(continuityItemSchema).max(MAX_ACTIVE_DECISIONS),
    open_questions: z.array(continuityItemSchema).max(MAX_OPEN_QUESTIONS),
    next_actions: z.array(continuityItemSchema).max(MAX_NEXT_ACTIONS),
    continuity_notes: z.array(z.string().min(1)).max(MAX_CONTINUITY_NOTES),
  })
  .strict();
export type CurrentFrameInput = z.infer<typeof currentFrameInputSchema>;

export const currentFrameSchema = currentFrameInputSchema
  .extend({
    active_task: activeTaskSchema.nullable(),
    version: z.literal(CURRENT_SCHEMA_VERSION),
    updated_at: z.iso.datetime(),
    workspace: workspaceRefSchema,
  })
  .strict();
export type CurrentFrame = z.infer<typeof currentFrameSchema>;

export const eventInputSchema = z
  .object({
    type: eventTypeSchema,
    status: eventStatusSchema,
    summary: z.string().min(1).max(MAX_EVENT_SUMMARY_CHARS),
    details: z.string().max(MAX_EVENT_DETAILS_CHARS).optional(),
    supersedes: z.array(z.string().min(1)),
    resolves: z.array(z.string().min(1)),
    related_events: z.array(z.string().min(1)),
  })
  .strict();
export type EventInput = z.infer<typeof eventInputSchema>;

export const eventSourceSchema = z
  .object({
    kind: z.string().min(1),
    host: z.string().min(1).optional(),
    cwd: z.string().min(1).optional(),
    session_id: z.string().min(1).optional(),
    turn_id: z.string().min(1).optional(),
    entry_id: z.string().min(1).optional(),
    description: z.string().min(1).optional(),
  })
  .strict();
export type EventSource = z.infer<typeof eventSourceSchema>;

export const continuityEventSchema = eventInputSchema
  .extend({
    version: z.literal(EVENT_SCHEMA_VERSION),
    id: z.string().min(1),
    created_at: z.iso.datetime(),
    effective_at: z.iso.datetime().optional(),
    workspace: workspaceRefSchema,
    source: eventSourceSchema,
  })
  .strict();
export type ContinuityEvent = z.infer<typeof continuityEventSchema>;

export const workspaceIndexEntrySchema = z
  .object({
    key: workspaceRefSchema.shape.key,
    kind: workspaceRefSchema.shape.kind,
    root: workspaceRefSchema.shape.root,
    label: z.string().min(1),
    created_at: z.iso.datetime(),
    updated_at: z.iso.datetime(),
  })
  .strict();
export type WorkspaceIndexEntry = z.infer<typeof workspaceIndexEntrySchema>;

export const indexFileSchema = z
  .object({
    version: z.literal(INDEX_SCHEMA_VERSION),
    updated_at: z.iso.datetime(),
    workspaces: z.array(workspaceIndexEntrySchema),
  })
  .strict();
export type IndexFile = z.infer<typeof indexFileSchema>;

function ok<T>(value: T): ValidationResult<T> {
  return { ok: true, value };
}

function fail(message: string, path?: string): ValidationResult<never> {
  return { ok: false, message, ...(path ? { path } : {}) };
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function isNonEmptyString(value: unknown): value is string {
  return typeof value === "string" && value.trim().length > 0;
}

function isIsoTimestamp(value: unknown): value is string {
  return isNonEmptyString(value) && !Number.isNaN(Date.parse(value));
}

function hasLiteral<const T extends readonly string[]>(values: T, value: unknown): value is T[number] {
  return typeof value === "string" && values.includes(value);
}

function validateStringArray(value: unknown, field: string, maxItems?: number): ValidationResult<string[]> {
  if (!Array.isArray(value)) return fail(`${field} must be an array`);
  if (maxItems !== undefined && value.length > maxItems) return fail(`${field} must contain at most ${maxItems} items`);
  const strings = [];
  for (const [index, item] of value.entries()) {
    if (!isNonEmptyString(item)) return fail(`${field}[${index}] must be a non-empty string`);
    strings.push(item);
  }
  return ok(strings);
}

function validateOptionalStringArray(value: unknown, field: string): ValidationResult<string[]> {
  if (value === undefined) return ok([]);
  return validateStringArray(value, field);
}

function validateContinuityItems(value: unknown, field: string, maxItems?: number): ValidationResult<ContinuityItem[]> {
  if (!Array.isArray(value)) return fail(`${field} must be an array`);
  if (maxItems !== undefined && value.length > maxItems) return fail(`${field} must contain at most ${maxItems} items`);
  const items: ContinuityItem[] = [];
  for (const [index, item] of value.entries()) {
    if (!isRecord(item)) return fail(`${field}[${index}] must be an object`);
    if (!isNonEmptyString(item.summary)) return fail(`${field}[${index}].summary must be a non-empty string`);
    if (item.event_id !== undefined && typeof item.event_id !== "string") {
      return fail(`${field}[${index}].event_id must be a string`);
    }
    if (item.recorded_at !== undefined && !isIsoTimestamp(item.recorded_at)) {
      return fail(`${field}[${index}].recorded_at must be an ISO timestamp`);
    }
    items.push({
      ...(item.event_id !== undefined ? { event_id: item.event_id } : {}),
      ...(item.recorded_at !== undefined ? { recorded_at: item.recorded_at } : {}),
      summary: item.summary,
    });
  }
  return ok(items);
}

export function validateWorkspaceRef(value: unknown, field = "workspace"): ValidationResult<WorkspaceRef> {
  if (!isRecord(value)) return fail(`${field} must be an object`);
  if (!isNonEmptyString(value.key)) return fail(`${field}.key must be a non-empty string`);
  if (value.kind !== "git" && value.kind !== "directory") return fail(`${field}.kind must be git or directory`);
  if (!isNonEmptyString(value.root)) return fail(`${field}.root must be a non-empty string`);
  if (value.label !== undefined && typeof value.label !== "string") return fail(`${field}.label must be a string`);
  return ok({
    key: value.key,
    kind: value.kind,
    root: value.root,
    ...(value.label !== undefined ? { label: value.label } : {}),
  });
}

function validatePermissionEnvelope(value: unknown): ValidationResult<PermissionEnvelope> {
  if (!isRecord(value)) return fail("permission_envelope must be an object");
  if (!isNonEmptyString(value.default)) return fail("permission_envelope.default must be a non-empty string");

  const allowed = validateStringArray(value.allowed_without_approval, "permission_envelope.allowed_without_approval");
  if (!allowed.ok) return allowed;
  const requires = validateStringArray(value.requires_approval, "permission_envelope.requires_approval");
  if (!requires.ok) return requires;

  return ok({
    default: value.default,
    allowed_without_approval: allowed.value,
    requires_approval: requires.value,
  });
}

export function validateCurrentFrameInput(value: unknown): ValidationResult<CurrentFrameInput> {
  if (!isRecord(value)) return fail("current frame input must be an object");
  if (!isNonEmptyString(value.operating_mode)) return fail("operating_mode must be a non-empty string");
  if (!isNonEmptyString(value.intent)) return fail("intent must be a non-empty string");

  const qualityBar = validateStringArray(value.quality_bar, "quality_bar", MAX_QUALITY_BAR_ITEMS);
  if (!qualityBar.ok) return qualityBar;
  const permission = validatePermissionEnvelope(value.permission_envelope);
  if (!permission.ok) return permission;
  let activeTask: ActiveTask | null = null;
  if (value.active_task !== undefined && value.active_task !== null) {
    const parsed = activeTaskSchema.safeParse(value.active_task);
    if (!parsed.success) return fail("active_task must be a valid active task checkpoint");
    activeTask = parsed.data;
  }
  const activeDecisions = validateContinuityItems(value.active_decisions, "active_decisions", MAX_ACTIVE_DECISIONS);
  if (!activeDecisions.ok) return activeDecisions;
  const openQuestions = validateContinuityItems(value.open_questions, "open_questions", MAX_OPEN_QUESTIONS);
  if (!openQuestions.ok) return openQuestions;
  const nextActions = validateContinuityItems(value.next_actions, "next_actions", MAX_NEXT_ACTIONS);
  if (!nextActions.ok) return nextActions;
  const continuityNotes = validateStringArray(value.continuity_notes, "continuity_notes", MAX_CONTINUITY_NOTES);
  if (!continuityNotes.ok) return continuityNotes;

  return ok({
    operating_mode: value.operating_mode,
    intent: value.intent,
    quality_bar: qualityBar.value,
    permission_envelope: permission.value,
    active_task: activeTask,
    active_decisions: activeDecisions.value,
    open_questions: openQuestions.value,
    next_actions: nextActions.value,
    continuity_notes: continuityNotes.value,
  });
}

export function validateCurrentFrame(value: unknown): ValidationResult<CurrentFrame> {
  if (!isRecord(value)) return fail("current frame must be an object");
  if (value.version !== CURRENT_SCHEMA_VERSION && value.version !== LEGACY_CURRENT_SCHEMA_VERSION) {
    return fail(`version must be ${LEGACY_CURRENT_SCHEMA_VERSION} or ${CURRENT_SCHEMA_VERSION}`);
  }
  if (!isIsoTimestamp(value.updated_at)) return fail("updated_at must be an ISO timestamp");

  const workspace = validateWorkspaceRef(value.workspace);
  if (!workspace.ok) return workspace;
  const body = validateCurrentFrameInput(value);
  if (!body.ok) return body;

  return ok({
    version: CURRENT_SCHEMA_VERSION,
    updated_at: value.updated_at,
    workspace: workspace.value,
    ...body.value,
    active_task: body.value.active_task ?? null,
  });
}

export function validateEventInput(value: unknown): ValidationResult<EventInput> {
  if (!isRecord(value)) return fail("event input must be an object");
  if (!hasLiteral(EVENT_TYPES, value.type)) return fail(`type must be one of ${EVENT_TYPES.join(", ")}`);
  if (!hasLiteral(EVENT_STATUSES, value.status)) return fail(`status must be one of ${EVENT_STATUSES.join(", ")}`);
  if (!isNonEmptyString(value.summary)) return fail("summary must be a non-empty string");
  if (value.summary.length > MAX_EVENT_SUMMARY_CHARS) {
    return fail(`summary must be at most ${MAX_EVENT_SUMMARY_CHARS} characters`);
  }
  if (value.details !== undefined && typeof value.details !== "string") return fail("details must be a string");
  if (typeof value.details === "string" && value.details.length > MAX_EVENT_DETAILS_CHARS) {
    return fail(`details must be at most ${MAX_EVENT_DETAILS_CHARS} characters`);
  }

  const supersedes = validateOptionalStringArray(value.supersedes, "supersedes");
  if (!supersedes.ok) return supersedes;
  const resolves = validateOptionalStringArray(value.resolves, "resolves");
  if (!resolves.ok) return resolves;
  const relatedEvents = validateOptionalStringArray(value.related_events, "related_events");
  if (!relatedEvents.ok) return relatedEvents;

  return ok({
    type: value.type,
    status: value.status,
    summary: value.summary,
    ...(value.details !== undefined ? { details: value.details } : {}),
    supersedes: supersedes.value,
    resolves: resolves.value,
    related_events: relatedEvents.value,
  });
}

const eventSourceOptionalKeys = ["host", "cwd", "session_id", "turn_id", "entry_id", "description"] as const;

export function validateEventSource(value: unknown): ValidationResult<EventSource> {
  if (!isRecord(value)) return fail("event source must be an object");
  if (!isNonEmptyString(value.kind)) return fail("event source kind must be a non-empty string");
  const source: EventSource = { kind: value.kind };
  for (const key of eventSourceOptionalKeys) {
    if (value[key] !== undefined) {
      if (typeof value[key] !== "string") return fail(`event source ${key} must be a string`);
      source[key] = value[key];
    }
  }
  return ok(source);
}

export function validateContinuityEvent(value: unknown): ValidationResult<ContinuityEvent> {
  if (!isRecord(value)) return fail("event must be an object");
  if (value.version !== EVENT_SCHEMA_VERSION) return fail(`event.version must be ${EVENT_SCHEMA_VERSION}`);
  if (!isNonEmptyString(value.id)) return fail("event.id must be a non-empty string");
  if (!isIsoTimestamp(value.created_at)) return fail("event.created_at must be an ISO timestamp");
  if (value.effective_at !== undefined && !isIsoTimestamp(value.effective_at)) {
    return fail("event.effective_at must be an ISO timestamp");
  }

  const input = validateEventInput(value);
  if (!input.ok) return input;
  const workspace = validateWorkspaceRef(value.workspace, "event.workspace");
  if (!workspace.ok) return workspace;
  const source = validateEventSource(value.source);
  if (!source.ok) return source;

  return ok({
    version: EVENT_SCHEMA_VERSION,
    id: value.id,
    created_at: value.created_at,
    ...(value.effective_at !== undefined ? { effective_at: value.effective_at } : {}),
    ...input.value,
    workspace: workspace.value,
    source: source.value,
  });
}

export function validateIndexFile(value: unknown): ValidationResult<IndexFile> {
  if (!isRecord(value)) return fail("index must be an object");
  if (value.version !== INDEX_SCHEMA_VERSION) return fail(`index.version must be ${INDEX_SCHEMA_VERSION}`);
  if (!isIsoTimestamp(value.updated_at)) return fail("index.updated_at must be an ISO timestamp");
  if (!Array.isArray(value.workspaces)) return fail("index.workspaces must be an array");

  const workspaces: WorkspaceIndexEntry[] = [];
  for (const [index, workspace] of value.workspaces.entries()) {
    if (!isRecord(workspace)) return fail(`index.workspaces[${index}] must be an object`);
    if (!isNonEmptyString(workspace.key)) return fail(`index.workspaces[${index}].key must be a non-empty string`);
    if (workspace.kind !== "git" && workspace.kind !== "directory") {
      return fail(`index.workspaces[${index}].kind must be git or directory`);
    }
    if (!isNonEmptyString(workspace.root)) return fail(`index.workspaces[${index}].root must be a non-empty string`);
    if (!isNonEmptyString(workspace.label)) return fail(`index.workspaces[${index}].label must be a non-empty string`);
    if (!isIsoTimestamp(workspace.created_at)) {
      return fail(`index.workspaces[${index}].created_at must be an ISO timestamp`);
    }
    if (!isIsoTimestamp(workspace.updated_at)) {
      return fail(`index.workspaces[${index}].updated_at must be an ISO timestamp`);
    }
    workspaces.push({
      key: workspace.key,
      kind: workspace.kind,
      root: workspace.root,
      label: workspace.label,
      created_at: workspace.created_at,
      updated_at: workspace.updated_at,
    });
  }

  return ok({ version: INDEX_SCHEMA_VERSION, updated_at: value.updated_at, workspaces });
}
