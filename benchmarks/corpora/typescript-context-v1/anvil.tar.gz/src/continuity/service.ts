import { createHash } from "node:crypto";
import { join, resolve } from "node:path";
import * as z from "zod/v4";

import {
  DEFAULT_EVENT_LIMIT,
  MAX_ACTIVE_DECISIONS,
  MAX_ACTIVE_TASK_DETAILS_CHARS,
  MAX_ACTIVE_TASK_TEXT_CHARS,
  MAX_CONTINUITY_NOTES,
  MAX_NEXT_ACTIONS,
  MAX_OPEN_QUESTIONS,
} from "./constants.ts";
import { renderContinuityFrame } from "./render.ts";
import { readAllEvents, readCurrent, readRecentEvents, recordEvent, updateCurrent, withWorkspaceMutationLock } from "./store.ts";
import {
  assertActiveWorkContextBinding,
  resolveCollaborationSpace,
  resolveWorkContextStateRoot,
  workContextBindingViewSchema,
  workContextBindingView,
  workspaceRefSchema,
} from "../work-context/index.ts";
import type { WorkContextBinding, WorkContextBindingView } from "../work-context/index.ts";
import { continuityPathsSchema, deriveContinuityPaths } from "./workspace.ts";
import { activeTaskSchema, continuityEventSchema, currentFrameSchema } from "./schema.ts";
import type { ActiveTask, ActiveTaskState, ContinuityEvent, ContinuityItem, CurrentFrame, CurrentFrameInput, EventInput, EventSource } from "./schema.ts";
import type { ContinuityPaths } from "./workspace.ts";

type Clock = () => string;
type IdGenerator = () => string;

export type ContinuityServiceErrorCode =
  | "CONTINUITY_NOT_INITIALIZED"
  | "CONTINUITY_MALFORMED"
  | "VALIDATION_ERROR"
  | "EVENT_NOT_FOUND"
  | "PROJECTION_LIMIT_EXCEEDED"
  | "INTERNAL_ERROR";

export class ContinuityServiceError extends Error {
  code: ContinuityServiceErrorCode;

  constructor(code: ContinuityServiceErrorCode, message: string) {
    super(`${code}: ${message}`);
    this.name = "ContinuityServiceError";
    this.code = code;
  }
}

export type ContinuityWorkspaceOptions = {
  cwd?: string;
  stateRoot?: string;
};

export type BoundContinuityMutationOptions = {
  binding: WorkContextBinding;
  stateRoot?: string;
  bindingNow?: Clock;
};

export type ReadContinuityInput = ContinuityWorkspaceOptions & {
  includeEvents?: boolean;
  eventLimit?: number;
};

const missingContinuityReadSchema = z
  .object({
    kind: z.literal("missing"),
    path: z.string().min(1),
    message: z.string().min(1),
  })
  .strict();
const malformedContinuityReadSchema = z
  .object({
    kind: z.literal("malformed"),
    path: z.string().min(1),
    message: z.string().min(1),
  })
  .strict();

export const readContinuityCurrentSchema = z.discriminatedUnion("kind", [
  z.object({ kind: z.literal("ok"), frame: currentFrameSchema, rendered: z.string() }).strict(),
  missingContinuityReadSchema,
  malformedContinuityReadSchema,
]);
export type ReadContinuityCurrent = z.infer<typeof readContinuityCurrentSchema>;

export const readContinuityEventsSchema = z.discriminatedUnion("kind", [
  z
    .object({
      kind: z.literal("ok"),
      items: z.array(continuityEventSchema),
      total: z.number().int().nonnegative(),
      truncated: z.boolean(),
    })
    .strict(),
  missingContinuityReadSchema,
  malformedContinuityReadSchema,
]);
export type ReadContinuityEvents = z.infer<typeof readContinuityEventsSchema>;

export const readContinuityOutputSchema = z
  .object({
    paths: continuityPathsSchema,
    workspace: workspaceRefSchema,
    current: readContinuityCurrentSchema,
    events: readContinuityEventsSchema.optional(),
  })
  .strict();
export type ReadContinuityOutput = z.infer<typeof readContinuityOutputSchema>;

export type RecordContinuityEventInput = BoundContinuityMutationOptions & {
  event: EventInput;
  source?: EventSource;
  now?: Clock;
  id?: IdGenerator;
};

export const recordContinuityEventOutputSchema = z
  .object({
    paths: continuityPathsSchema,
    workspace: workspaceRefSchema,
    event: continuityEventSchema,
    currentFrameInitialized: z.boolean(),
    binding: workContextBindingViewSchema,
  })
  .strict();
export type RecordContinuityEventOutput = z.infer<typeof recordContinuityEventOutputSchema>;

export type CheckpointActiveTaskInput = BoundContinuityMutationOptions & {
  checkpointId: string;
  task:
    | {
        state: ActiveTaskState;
        summary: string;
        nextStep: string;
        details?: string;
      }
    | {
        state: "clear";
        outcome: string;
        details?: string;
      };
  source?: EventSource;
  now?: Clock;
};

export const checkpointActiveTaskOutputSchema = z
  .object({
    paths: continuityPathsSchema,
    workspace: workspaceRefSchema,
    event: continuityEventSchema,
    frame: currentFrameSchema,
    rendered: z.string(),
    changed: z.boolean(),
    binding: workContextBindingViewSchema,
  })
  .strict();
export type CheckpointActiveTaskOutput = z.infer<typeof checkpointActiveTaskOutputSchema>;

export const promoteContinuityTargetSchema = z.enum([
  "active_decisions",
  "open_questions",
  "next_actions",
  "continuity_notes",
]);
export const promoteContinuityModeSchema = z.enum(["append", "replace_matching_event"]);
export type PromoteContinuityTarget = z.infer<typeof promoteContinuityTargetSchema>;
export type PromoteContinuityMode = z.infer<typeof promoteContinuityModeSchema>;

export type PromoteContinuityEventInput = BoundContinuityMutationOptions & {
  eventId: string;
  target: PromoteContinuityTarget;
  mode?: PromoteContinuityMode;
  now?: Clock;
};

export const promoteContinuityEventOutputSchema = z
  .object({
    paths: continuityPathsSchema,
    workspace: workspaceRefSchema,
    event: continuityEventSchema,
    frame: currentFrameSchema,
    changed: z.boolean(),
    binding: workContextBindingViewSchema,
  })
  .strict();
export type PromoteContinuityEventOutput = z.infer<typeof promoteContinuityEventOutputSchema>;

export const retiredContinuityProjectionItemSchema = z
  .object({
    target: promoteContinuityTargetSchema,
    event_id: z.string().min(1).optional(),
    summary: z.string().min(1),
  })
  .strict();
export type RetiredContinuityProjectionItem = z.infer<typeof retiredContinuityProjectionItemSchema>;

export type RetireContinuityProjectionItemInput = BoundContinuityMutationOptions & {
  target: PromoteContinuityTarget;
  eventId?: string;
  summary?: string;
  correctionEventId?: string;
  now?: Clock;
};

export const retireContinuityProjectionItemOutputSchema = z
  .object({
    paths: continuityPathsSchema,
    workspace: workspaceRefSchema,
    frame: currentFrameSchema,
    changed: z.boolean(),
    removedItem: retiredContinuityProjectionItemSchema.optional(),
    correctionEvent: continuityEventSchema.optional(),
    binding: workContextBindingViewSchema,
  })
  .strict();
export type RetireContinuityProjectionItemOutput = z.infer<typeof retireContinuityProjectionItemOutputSchema>;

export function resolveContinuityWorkspace(options: ContinuityWorkspaceOptions = {}): ContinuityPaths {
  const cwd = resolve(options.cwd ?? process.cwd());
  const workspace = resolveCollaborationSpace(cwd);
  const stateRoot = resolve(options.stateRoot ?? process.env.ANVIL_STATE_ROOT ?? join(workspace.root, ".anvil"));
  return deriveContinuityPaths({ stateRoot, workspace });
}

export function resolveBoundContinuityWorkspace(options: BoundContinuityMutationOptions): ContinuityPaths {
  const binding = assertActiveWorkContextBinding(options.binding, options.bindingNow);
  return deriveContinuityPaths({
    stateRoot: resolveWorkContextStateRoot(options.stateRoot),
    workspace: binding.collaboration_space,
  });
}

function boundEventSource(binding: WorkContextBinding, source?: EventSource): EventSource {
  return {
    ...source,
    kind: source?.kind ?? "work_context",
    host: binding.host,
    cwd: binding.collaboration_space.root,
    session_id: binding.session_id,
    entry_id: binding.id,
  };
}

export async function readContinuity(input: ReadContinuityInput = {}): Promise<ReadContinuityOutput> {
  const paths = resolveContinuityWorkspace(input);
  const current = await readCurrent(paths);
  const events = input.includeEvents ? await readRecentEvents(paths, input.eventLimit ?? DEFAULT_EVENT_LIMIT) : undefined;

  return {
    paths,
    workspace: paths.workspace,
    current: current.kind === "ok" ? { kind: "ok", frame: current.value, rendered: renderContinuityFrame(current.value) } : current,
    ...(events
      ? {
          events:
            events.kind === "ok"
              ? { kind: "ok", items: events.events, total: events.total, truncated: events.truncated }
              : events,
        }
      : {}),
  };
}

export async function recordContinuityEvent(input: RecordContinuityEventInput): Promise<RecordContinuityEventOutput> {
  const paths = resolveBoundContinuityWorkspace(input);
  return withWorkspaceMutationLock(paths, async () => {
    const current = await readCurrent(paths);
    if (current.kind === "malformed") throw new ContinuityServiceError("CONTINUITY_MALFORMED", current.message);

    const event = await recordEvent(paths, input.event, {
      source: boundEventSource(input.binding, input.source),
      ...(input.now ? { now: input.now } : {}),
      ...(input.id ? { id: input.id } : {}),
    });

    return {
      paths,
      workspace: paths.workspace,
      event,
      currentFrameInitialized: current.kind === "missing",
      binding: workContextBindingView(input.binding),
    };
  }, { now: input.now });
}

function currentFrameInput(frame: CurrentFrame): CurrentFrameInput {
  return {
    operating_mode: frame.operating_mode,
    intent: frame.intent,
    quality_bar: frame.quality_bar,
    permission_envelope: frame.permission_envelope,
    active_task: frame.active_task,
    active_decisions: frame.active_decisions,
    open_questions: frame.open_questions,
    next_actions: frame.next_actions,
    continuity_notes: frame.continuity_notes,
  };
}

function checkpointEventId(workspaceKey: string, checkpointId: string): string {
  const digest = createHash("sha256").update(`${workspaceKey}\0${checkpointId}`, "utf8").digest("hex").slice(0, 24);
  return `evt_task_${digest}`;
}

function checkpointDetails(input: CheckpointActiveTaskInput["task"]): string {
  const lines =
    input.state === "clear"
      ? [`Task checkpoint: clear`, `Outcome: ${input.outcome}`]
      : [`Task checkpoint: ${input.state}`, `Next step: ${input.nextStep}`];
  if (input.details) lines.push("", input.details);
  return lines.join("\n");
}

function checkpointEventMatches(
  event: ContinuityEvent,
  task: CheckpointActiveTaskInput["task"],
  details: string,
): boolean {
  const expectedType = task.state === "clear" ? "correction" : "next_action";
  const expectedSummary = task.state === "clear" ? task.outcome : task.summary;
  return event.type === expectedType && event.summary === expectedSummary && event.details === details;
}

export async function checkpointActiveTask(
  input: CheckpointActiveTaskInput,
): Promise<CheckpointActiveTaskOutput> {
  const checkpointId = input.checkpointId.trim();
  if (checkpointId.length === 0 || checkpointId.length > 200) {
    throw new ContinuityServiceError("VALIDATION_ERROR", "checkpointId must contain between 1 and 200 characters");
  }
  const summary = input.task.state === "clear" ? input.task.outcome.trim() : input.task.summary.trim();
  if (summary.length === 0 || summary.length > MAX_ACTIVE_TASK_TEXT_CHARS) {
    throw new ContinuityServiceError(
      "VALIDATION_ERROR",
      `task summary must contain between 1 and ${MAX_ACTIVE_TASK_TEXT_CHARS} characters`,
    );
  }
  if (input.task.state !== "clear") {
    const nextStep = input.task.nextStep.trim();
    if (nextStep.length === 0 || nextStep.length > MAX_ACTIVE_TASK_TEXT_CHARS) {
      throw new ContinuityServiceError(
        "VALIDATION_ERROR",
        `task next step must contain between 1 and ${MAX_ACTIVE_TASK_TEXT_CHARS} characters`,
      );
    }
  }
  if ((input.task.details?.length ?? 0) > MAX_ACTIVE_TASK_DETAILS_CHARS) {
    throw new ContinuityServiceError(
      "VALIDATION_ERROR",
      `task details must contain at most ${MAX_ACTIVE_TASK_DETAILS_CHARS} characters`,
    );
  }

  const paths = resolveBoundContinuityWorkspace(input);
  return withWorkspaceMutationLock(paths, async () => {
    const before = await readCurrent(paths);
    if (before.kind === "malformed") throw new ContinuityServiceError("CONTINUITY_MALFORMED", before.message);

    const eventId = checkpointEventId(paths.workspace.key, checkpointId);
    const events = await readAllEvents(paths);
    if (events.kind === "malformed") throw new ContinuityServiceError("CONTINUITY_MALFORMED", events.message);
    const existing = events.kind === "ok" ? events.events.find((event) => event.id === eventId) : undefined;
    const details = checkpointDetails(input.task);
    if (existing && !checkpointEventMatches(existing, input.task, details)) {
      throw new ContinuityServiceError(
        "VALIDATION_ERROR",
        `checkpointId ${checkpointId} was already used for different task content`,
      );
    }
    if (input.task.state === "clear" && before.kind === "missing" && !existing) {
      throw new ContinuityServiceError("CONTINUITY_NOT_INITIALIZED", "Cannot clear an active task before Continuity exists");
    }
    if (input.task.state === "clear" && before.kind === "ok" && before.value.active_task === null && !existing) {
      throw new ContinuityServiceError("VALIDATION_ERROR", "No active task is available to clear");
    }

    const priorTask = before.kind === "ok" ? before.value.active_task : null;
    const eventInput: EventInput = {
      type: input.task.state === "clear" ? "correction" : "next_action",
      status: "active",
      summary: input.task.state === "clear" ? input.task.outcome : input.task.summary,
      details,
      supersedes:
        input.task.state !== "clear" && priorTask && priorTask.event_id !== eventId ? [priorTask.event_id] : [],
      resolves: input.task.state === "clear" && priorTask ? [priorTask.event_id] : [],
      related_events: priorTask ? [priorTask.event_id] : [],
    };
    const event =
      existing ??
      (await recordEvent(paths, eventInput, {
        source: boundEventSource(input.binding, input.source),
        now: input.now,
        id: () => eventId,
      }));

    const afterRecord = await readCurrent(paths);
    if (afterRecord.kind !== "ok") {
      throw new ContinuityServiceError("CONTINUITY_MALFORMED", afterRecord.message);
    }
    const desired: ActiveTask | null =
      input.task.state === "clear"
        ? null
        : activeTaskSchema.parse({
            event_id: event.id,
            recorded_at: event.effective_at ?? event.created_at,
            summary: input.task.summary,
            state: input.task.state,
            next_step: input.task.nextStep,
          });
    const taskChanged = JSON.stringify(afterRecord.value.active_task) !== JSON.stringify(desired);
    const nextInput = currentFrameInput(afterRecord.value);
    nextInput.active_task = desired;
    nextInput.next_actions = nextInput.next_actions.filter((item) => item.event_id !== event.id);
    const changed = taskChanged || nextInput.next_actions.length !== afterRecord.value.next_actions.length;
    const frame = changed
      ? await updateCurrent(paths, nextInput, { now: input.now })
      : afterRecord.value;

    return {
      paths,
      workspace: paths.workspace,
      event,
      frame,
      rendered: renderContinuityFrame(frame),
      changed,
      binding: workContextBindingView(input.binding),
    };
  }, { now: input.now });
}

function assertCompatibleTarget(event: ContinuityEvent, target: PromoteContinuityTarget): void {
  const expectedType =
    target === "active_decisions"
      ? "decision"
      : target === "open_questions"
        ? "open_question"
        : target === "next_actions"
          ? "next_action"
          : undefined;

  if (expectedType && event.type !== expectedType) {
    throw new ContinuityServiceError(
      "VALIDATION_ERROR",
      `Cannot promote ${event.type} event ${event.id} to ${target}; expected ${expectedType}`,
    );
  }
}

function assertPromotableStatus(event: ContinuityEvent, target: PromoteContinuityTarget): void {
  if (target === "continuity_notes" || event.status === "active") return;
  throw new ContinuityServiceError(
    "VALIDATION_ERROR",
    `Cannot promote ${event.status} event ${event.id} to ${target}; event status must be active`,
  );
}

function promoteItem({
  current,
  item,
  maxItems,
  mode,
  target,
}: {
  current: ContinuityItem[];
  item: ContinuityItem;
  maxItems: number;
  mode: PromoteContinuityMode;
  target: PromoteContinuityTarget;
}): { items: ContinuityItem[]; changed: boolean } {
  const existingIndex = current.findIndex((candidate) => candidate.event_id === item.event_id);
  if (existingIndex >= 0) {
    if (mode === "append") return { items: current, changed: false };
    const next = [...current];
    const existing = next[existingIndex];
    next[existingIndex] = item;
    return {
      items: next,
      changed:
        existing.summary !== item.summary ||
        existing.event_id !== item.event_id ||
        existing.recorded_at !== item.recorded_at,
    };
  }

  if (current.length >= maxItems) {
    throw new ContinuityServiceError("PROJECTION_LIMIT_EXCEEDED", `${target} already has ${maxItems} items`);
  }

  return { items: [...current, item], changed: true };
}

function promoteNote({
  current,
  event,
  maxItems,
  mode,
}: {
  current: string[];
  event: ContinuityEvent;
  maxItems: number;
  mode: PromoteContinuityMode;
}): { notes: string[]; changed: boolean } {
  const note = `[${event.id}] ${event.summary}`;
  const existingIndex = current.findIndex((candidate) => candidate.startsWith(`[${event.id}] `));
  if (existingIndex >= 0) {
    if (mode === "append") return { notes: current, changed: false };
    const next = [...current];
    const existing = next[existingIndex];
    next[existingIndex] = note;
    return { notes: next, changed: existing !== note };
  }

  if (current.length >= maxItems) {
    throw new ContinuityServiceError("PROJECTION_LIMIT_EXCEEDED", `continuity_notes already has ${maxItems} items`);
  }

  return { notes: [...current, note], changed: true };
}

type ProjectionSelector = { kind: "event_id"; eventId: string } | { kind: "summary"; summary: string };

function projectionSelector(input: RetireContinuityProjectionItemInput): ProjectionSelector {
  const eventId = input.eventId?.trim();
  const summary = input.summary?.trim();
  if (eventId && summary) {
    throw new ContinuityServiceError("VALIDATION_ERROR", "Provide exactly one of eventId or summary");
  }
  if (!eventId && !summary) {
    throw new ContinuityServiceError("VALIDATION_ERROR", "Provide exactly one of eventId or summary");
  }
  if (summary && input.correctionEventId !== undefined) {
    throw new ContinuityServiceError("VALIDATION_ERROR", "correctionEventId is only valid when retiring by eventId");
  }
  if (eventId && !input.correctionEventId?.trim()) {
    throw new ContinuityServiceError(
      "VALIDATION_ERROR",
      "correctionEventId is required when retiring an event-linked projection item",
    );
  }
  return eventId ? { kind: "event_id", eventId } : { kind: "summary", summary: summary as string };
}

function requireEvent(events: ContinuityEvent[], eventId: string, label: string): ContinuityEvent {
  const event = events.find((candidate) => candidate.id === eventId);
  if (!event) throw new ContinuityServiceError("EVENT_NOT_FOUND", `No ${label} found with id ${eventId}`);
  return event;
}

function correctionEventForRetirement(events: ContinuityEvent[], input: RetireContinuityProjectionItemInput): ContinuityEvent | undefined {
  if (!input.eventId) return undefined;
  const correctionEventId = input.correctionEventId?.trim();
  if (!correctionEventId) {
    throw new ContinuityServiceError(
      "VALIDATION_ERROR",
      "correctionEventId is required when retiring an event-linked projection item",
    );
  }
  const correctionEvent = requireEvent(events, correctionEventId, "correction event");
  if (correctionEvent.type !== "correction") {
    throw new ContinuityServiceError(
      "VALIDATION_ERROR",
      `Retirement lineage event ${correctionEvent.id} must be a correction event`,
    );
  }
  return correctionEvent;
}

function retireItemProjection({
  current,
  selector,
  target,
}: {
  current: ContinuityItem[];
  selector: ProjectionSelector;
  target: PromoteContinuityTarget;
}): { items: ContinuityItem[]; removedItem?: RetiredContinuityProjectionItem; changed: boolean } {
  const index = current.findIndex((candidate) =>
    selector.kind === "event_id"
      ? candidate.event_id === selector.eventId
      : candidate.event_id === undefined && candidate.summary === selector.summary,
  );
  if (index < 0) return { items: current, changed: false };

  const removed = current[index];
  return {
    items: current.filter((_, candidateIndex) => candidateIndex !== index),
    removedItem: {
      target,
      ...(removed.event_id ? { event_id: removed.event_id } : {}),
      summary: removed.summary,
    },
    changed: true,
  };
}

function retireNoteProjection({
  current,
  selector,
}: {
  current: string[];
  selector: ProjectionSelector;
}): { notes: string[]; removedItem?: RetiredContinuityProjectionItem; changed: boolean } {
  const index = current.findIndex((candidate) =>
    selector.kind === "event_id" ? candidate.startsWith(`[${selector.eventId}] `) : candidate === selector.summary,
  );
  if (index < 0) return { notes: current, changed: false };

  const removed = current[index];
  const eventId = selector.kind === "event_id" ? selector.eventId : undefined;
  const prefix = eventId ? `[${eventId}] ` : "";
  return {
    notes: current.filter((_, candidateIndex) => candidateIndex !== index),
    removedItem: {
      target: "continuity_notes",
      ...(eventId ? { event_id: eventId } : {}),
      summary: eventId && removed.startsWith(prefix) ? removed.slice(prefix.length) : removed,
    },
    changed: true,
  };
}

export async function promoteContinuityEvent(input: PromoteContinuityEventInput): Promise<PromoteContinuityEventOutput> {
  const paths = resolveBoundContinuityWorkspace(input);
  return withWorkspaceMutationLock(paths, async () => {
    const current = await readCurrent(paths);
    if (current.kind === "missing") throw new ContinuityServiceError("CONTINUITY_NOT_INITIALIZED", current.message);
    if (current.kind === "malformed") throw new ContinuityServiceError("CONTINUITY_MALFORMED", current.message);

    const events = await readAllEvents(paths);
    if (events.kind === "missing") throw new ContinuityServiceError("EVENT_NOT_FOUND", events.message);
    if (events.kind === "malformed") throw new ContinuityServiceError("CONTINUITY_MALFORMED", events.message);

    const event = events.events.find((candidate) => candidate.id === input.eventId);
    if (!event) throw new ContinuityServiceError("EVENT_NOT_FOUND", `No continuity event found with id ${input.eventId}`);

    assertCompatibleTarget(event, input.target);
    assertPromotableStatus(event, input.target);

    const mode = input.mode ?? "append";
    const nextInput = currentFrameInput(current.value);
    let changed = false;

    if (input.target === "active_decisions") {
      const result = promoteItem({
        current: nextInput.active_decisions,
        item: { event_id: event.id, recorded_at: event.effective_at ?? event.created_at, summary: event.summary },
        maxItems: MAX_ACTIVE_DECISIONS,
        mode,
        target: input.target,
      });
      nextInput.active_decisions = result.items;
      changed = result.changed;
    } else if (input.target === "open_questions") {
      const result = promoteItem({
        current: nextInput.open_questions,
        item: { event_id: event.id, recorded_at: event.effective_at ?? event.created_at, summary: event.summary },
        maxItems: MAX_OPEN_QUESTIONS,
        mode,
        target: input.target,
      });
      nextInput.open_questions = result.items;
      changed = result.changed;
    } else if (input.target === "next_actions") {
      const result = promoteItem({
        current: nextInput.next_actions,
        item: { event_id: event.id, recorded_at: event.effective_at ?? event.created_at, summary: event.summary },
        maxItems: MAX_NEXT_ACTIONS,
        mode,
        target: input.target,
      });
      nextInput.next_actions = result.items;
      changed = result.changed;
    } else {
      const result = promoteNote({
        current: nextInput.continuity_notes,
        event,
        maxItems: MAX_CONTINUITY_NOTES,
        mode,
      });
      nextInput.continuity_notes = result.notes;
      changed = result.changed;
    }

    const frame = changed ? await updateCurrent(paths, nextInput, { ...(input.now ? { now: input.now } : {}) }) : current.value;
    return {
      paths,
      workspace: paths.workspace,
      event,
      frame,
      changed,
      binding: workContextBindingView(input.binding),
    };
  }, { now: input.now });
}

export async function retireContinuityProjectionItem(
  input: RetireContinuityProjectionItemInput,
): Promise<RetireContinuityProjectionItemOutput> {
  const paths = resolveBoundContinuityWorkspace(input);
  return withWorkspaceMutationLock(paths, async () => {
    const current = await readCurrent(paths);
    if (current.kind === "missing") throw new ContinuityServiceError("CONTINUITY_NOT_INITIALIZED", current.message);
    if (current.kind === "malformed") throw new ContinuityServiceError("CONTINUITY_MALFORMED", current.message);

    const selector = projectionSelector(input);
    let correctionEvent: ContinuityEvent | undefined;
    if (selector.kind === "event_id") {
      const events = await readAllEvents(paths);
      if (events.kind === "missing") throw new ContinuityServiceError("EVENT_NOT_FOUND", events.message);
      if (events.kind === "malformed") throw new ContinuityServiceError("CONTINUITY_MALFORMED", events.message);
      requireEvent(events.events, selector.eventId, "continuity event");
      correctionEvent = correctionEventForRetirement(events.events, input);
    }

    const nextInput = currentFrameInput(current.value);
    let changed = false;
    let removedItem: RetiredContinuityProjectionItem | undefined;

    if (input.target === "active_decisions") {
      const result = retireItemProjection({ current: nextInput.active_decisions, selector, target: input.target });
      nextInput.active_decisions = result.items;
      changed = result.changed;
      removedItem = result.removedItem;
    } else if (input.target === "open_questions") {
      const result = retireItemProjection({ current: nextInput.open_questions, selector, target: input.target });
      nextInput.open_questions = result.items;
      changed = result.changed;
      removedItem = result.removedItem;
    } else if (input.target === "next_actions") {
      const result = retireItemProjection({ current: nextInput.next_actions, selector, target: input.target });
      nextInput.next_actions = result.items;
      changed = result.changed;
      removedItem = result.removedItem;
    } else {
      const result = retireNoteProjection({ current: nextInput.continuity_notes, selector });
      nextInput.continuity_notes = result.notes;
      changed = result.changed;
      removedItem = result.removedItem;
    }

    const frame = changed ? await updateCurrent(paths, nextInput, { ...(input.now ? { now: input.now } : {}) }) : current.value;
    return {
      paths,
      workspace: paths.workspace,
      frame,
      changed,
      ...(removedItem ? { removedItem } : {}),
      ...(correctionEvent ? { correctionEvent } : {}),
      binding: workContextBindingView(input.binding),
    };
  }, { now: input.now });
}
