import { isAbsolute } from "node:path";

import { readStoredWorkContextBinding, resolveWorkContextStateRoot } from "../work-context/index.ts";
import { normalizeWorkspaceRoot, resolveCollaborationSpace } from "../work-context/space.ts";
import type { WorkspaceRef } from "../work-context/space.ts";
import { readAllEvents, readCurrent, readIndex } from "./store.ts";
import { deriveContinuityPaths, directoryWorkspaceRef } from "./workspace.ts";
import type { ContinuityEvent, CurrentFrame, WorkspaceIndexEntry } from "./schema.ts";

export type RoutingAuditClassification = "confirmed" | "candidate" | "unknown";

export type RoutingAuditEvent = {
  event_id: string;
  classification: RoutingAuditClassification;
  reason: string;
  observed_workspace_key?: string;
};

export type RoutingAuditPartition = {
  workspace: WorkspaceRef;
  event_count: number;
  date_range: { first: string; last: string } | null;
  source_provenance: Array<{ kind: string; host?: string; count: number }>;
  cross_repository_references: Array<{ event_id: string; source_cwd: string }>;
  compact_frame_churn: {
    current_status: "ok" | "missing" | "malformed";
    current_updated_at?: string;
    projected_items: number;
    unlinked_projected_items: number;
    phase_change_events: number;
    correction_events: number;
  };
  classifications: Record<RoutingAuditClassification, number>;
  events: RoutingAuditEvent[];
};

export type ContinuityRoutingAudit = {
  version: 1;
  generated_at: string;
  state_root: string;
  partition_count: number;
  event_count: number;
  classifications: Record<RoutingAuditClassification, number>;
  partitions: RoutingAuditPartition[];
  findings: Array<{ code: string; message: string }>;
};

function zeroClassifications(): Record<RoutingAuditClassification, number> {
  return { confirmed: 0, candidate: 0, unknown: 0 };
}

function workspaceFromIndex(entry: WorkspaceIndexEntry): WorkspaceRef {
  return { key: entry.key, kind: entry.kind, root: entry.root, label: entry.label };
}

function projectedItemCounts(frame: CurrentFrame | undefined): { projected: number; unlinked: number } {
  if (!frame) return { projected: 0, unlinked: 0 };
  const items = [...frame.active_decisions, ...frame.open_questions, ...frame.next_actions];
  const noteIds = frame.continuity_notes.map((note) => /^\[([^\]]+)\] /.exec(note)?.[1]);
  return {
    projected: items.length + frame.continuity_notes.length,
    unlinked: items.filter((item) => !item.event_id).length + noteIds.filter((id) => id === undefined).length,
  };
}

function observedWorkspaceRoot(sourceCwd: string): string {
  try {
    return resolveCollaborationSpace(sourceCwd).root;
  } catch {
    return normalizeWorkspaceRoot(sourceCwd);
  }
}

async function classifyEvent(
  event: ContinuityEvent,
  partition: WorkspaceRef,
  stateRoot: string,
): Promise<RoutingAuditEvent> {
  if (event.workspace.key !== partition.key) {
    return {
      event_id: event.id,
      classification: "candidate",
      reason: "Stored event workspace key differs from its partition key; human review required.",
      observed_workspace_key: event.workspace.key,
    };
  }
  if (event.source.entry_id?.startsWith("wctx_")) {
    try {
      const binding = await readStoredWorkContextBinding({ bindingId: event.source.entry_id, stateRoot });
      if (binding?.collaboration_space.key === partition.key) {
        return {
          event_id: event.id,
          classification: "confirmed",
          reason: "Event carries a durable Work Context binding for this partition.",
          observed_workspace_key: binding.collaboration_space.key,
        };
      }
      return {
        event_id: event.id,
        classification: "candidate",
        reason: "Event binding is missing or points at a different partition; human review required.",
        ...(binding ? { observed_workspace_key: binding.collaboration_space.key } : {}),
      };
    } catch {
      return {
        event_id: event.id,
        classification: "candidate",
        reason: "Event names a malformed Work Context binding; human review required.",
      };
    }
  }
  if (event.source.cwd && isAbsolute(event.source.cwd)) {
    const observedRoot = observedWorkspaceRoot(event.source.cwd);
    if (observedRoot !== partition.root) {
      return {
        event_id: event.id,
        classification: "candidate",
        reason: "Legacy caller-reported cwd differs from the partition root; it is evidence, not a destination decision.",
      };
    }
  }
  return {
    event_id: event.id,
    classification: "unknown",
    reason: "No trusted historical Work Context binding exists; ownership is intentionally unresolved.",
  };
}

export async function auditContinuityRouting(input: {
  stateRoot?: string;
  now?: () => string;
} = {}): Promise<ContinuityRoutingAudit> {
  const stateRoot = resolveWorkContextStateRoot(input.stateRoot);
  const findings: ContinuityRoutingAudit["findings"] = [];
  const indexPaths = deriveContinuityPaths({ stateRoot, workspace: directoryWorkspaceRef(stateRoot) });
  const index = await readIndex(indexPaths);
  if (index.kind !== "ok") {
    findings.push({
      code: index.kind === "missing" ? "CONTINUITY_INDEX_MISSING" : "CONTINUITY_INDEX_MALFORMED",
      message: index.message,
    });
    return {
      version: 1,
      generated_at: (input.now ?? (() => new Date().toISOString()))(),
      state_root: stateRoot,
      partition_count: 0,
      event_count: 0,
      classifications: zeroClassifications(),
      partitions: [],
      findings,
    };
  }

  const partitions: RoutingAuditPartition[] = [];
  const totals = zeroClassifications();
  for (const entry of index.value.workspaces) {
    const workspace = workspaceFromIndex(entry);
    const paths = deriveContinuityPaths({ stateRoot, workspace });
    const [eventRead, currentRead] = await Promise.all([readAllEvents(paths), readCurrent(paths)]);
    const events = eventRead.kind === "ok" ? eventRead.events : [];
    if (eventRead.kind === "malformed") findings.push({ code: "CONTINUITY_EVENTS_MALFORMED", message: eventRead.message });
    const classifications = zeroClassifications();
    const auditedEvents: RoutingAuditEvent[] = [];
    for (const event of events) {
      const audited = await classifyEvent(event, workspace, stateRoot);
      auditedEvents.push(audited);
      classifications[audited.classification] += 1;
      totals[audited.classification] += 1;
    }

    const sourceCounts = new Map<string, { kind: string; host?: string; count: number }>();
    for (const event of events) {
      const key = `${event.source.kind}\0${event.source.host ?? ""}`;
      const current = sourceCounts.get(key) ?? {
        kind: event.source.kind,
        ...(event.source.host ? { host: event.source.host } : {}),
        count: 0,
      };
      current.count += 1;
      sourceCounts.set(key, current);
    }
    const times = events.map((event) => event.effective_at ?? event.created_at).sort();
    const frame = currentRead.kind === "ok" ? currentRead.value : undefined;
    const projections = projectedItemCounts(frame);
    partitions.push({
      workspace,
      event_count: events.length,
      date_range: times.length > 0 ? { first: times[0], last: times.at(-1)! } : null,
      source_provenance: [...sourceCounts.values()].sort((left, right) =>
        `${left.kind}:${left.host ?? ""}`.localeCompare(`${right.kind}:${right.host ?? ""}`),
      ),
      cross_repository_references: events
        .filter(
          (event) =>
            event.source.cwd !== undefined &&
            isAbsolute(event.source.cwd) &&
            observedWorkspaceRoot(event.source.cwd) !== workspace.root,
        )
        .map((event) => ({ event_id: event.id, source_cwd: event.source.cwd! })),
      compact_frame_churn: {
        current_status: currentRead.kind,
        ...(frame ? { current_updated_at: frame.updated_at } : {}),
        projected_items: projections.projected,
        unlinked_projected_items: projections.unlinked,
        phase_change_events: events.filter((event) => event.type === "phase_change").length,
        correction_events: events.filter((event) => event.type === "correction").length,
      },
      classifications,
      events: auditedEvents,
    });
  }

  return {
    version: 1,
    generated_at: (input.now ?? (() => new Date().toISOString()))(),
    state_root: stateRoot,
    partition_count: partitions.length,
    event_count: partitions.reduce((total, partition) => total + partition.event_count, 0),
    classifications: totals,
    partitions,
    findings,
  };
}
