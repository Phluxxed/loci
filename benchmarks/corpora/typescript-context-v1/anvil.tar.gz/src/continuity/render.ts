import {
  MAX_ACTIVE_DECISIONS,
  MAX_CONTINUITY_NOTES,
  MAX_ITEM_CHARS,
  MAX_NEXT_ACTIONS,
  MAX_OPEN_QUESTIONS,
  MAX_QUALITY_BAR_ITEMS,
} from "./constants.ts";

import type { ActiveTask, CurrentFrame, ContinuityItem } from "./schema.ts";

function truncateText(text: string): string {
  const normalized = String(text).replace(/[\r\n\t]+/g, " ").replace(/ +/g, " ").trim();
  if (normalized.length <= MAX_ITEM_CHARS) return normalized;
  return `${normalized.slice(0, Math.max(0, MAX_ITEM_CHARS - 3)).trimEnd()}...`;
}

function itemText(item: ContinuityItem): string {
  const prefix = item.event_id ? `[${item.event_id}] ` : "";
  const recordedAt = item.recorded_at ? `(recorded ${item.recorded_at.slice(0, 10)}) ` : "";
  return truncateText(`${prefix}${recordedAt}${item.summary}`);
}

function renderStringList(title: string, values: string[], maxItems: number, omittedLabel: string): string[] {
  const lines = [`${title}:`];
  const visible = values.slice(0, maxItems);
  if (visible.length === 0) {
    lines.push("- none");
  } else {
    for (const value of visible) lines.push(`- ${truncateText(value)}`);
  }
  const omitted = values.length - visible.length;
  if (omitted > 0) lines.push(`- Additional ${omittedLabel} omitted: ${omitted}`);
  return lines;
}

function renderItemList(title: string, values: ContinuityItem[], maxItems: number, omittedLabel: string): string[] {
  const lines = [`${title}:`];
  const visible = values.slice(0, maxItems);
  if (visible.length === 0) {
    lines.push("- none");
  } else {
    for (const value of visible) lines.push(`- ${itemText(value)}`);
  }
  const omitted = values.length - visible.length;
  if (omitted > 0) lines.push(`- Additional ${omittedLabel} omitted: ${omitted}`);
  return lines;
}

function renderPermissionEnvelope(frame: CurrentFrame): string[] {
  return [
    "Permission envelope:",
    `- default: ${truncateText(frame.permission_envelope.default)}`,
    `- allowed without approval: ${
      frame.permission_envelope.allowed_without_approval.length > 0
        ? frame.permission_envelope.allowed_without_approval.map(truncateText).join("; ")
        : "none"
    }`,
    `- requires approval: ${
      frame.permission_envelope.requires_approval.length > 0
        ? frame.permission_envelope.requires_approval.map(truncateText).join("; ")
        : "none"
    }`,
  ];
}

export function renderActiveTask(activeTask: ActiveTask | null): string[] {
  if (!activeTask) return ["Active task:", "- none"];
  return [
    "Active task:",
    `- [${activeTask.event_id}] (recorded ${activeTask.recorded_at.slice(0, 10)}) ${truncateText(activeTask.summary)}`,
    `- state: ${activeTask.state}`,
    `- next step: ${truncateText(activeTask.next_step)}`,
  ];
}

export function renderContinuityFrame(frame: CurrentFrame): string {
  return [
    "## Anvil Continuity Frame",
    "",
    "This is workspace continuity, not truth. Current user instruction, current files, command output, tests, and live project evidence override stale continuity.",
    "",
    `Workspace: ${frame.workspace.label ?? frame.workspace.key} (${frame.workspace.root})`,
    `Operating mode: ${truncateText(frame.operating_mode)}`,
    `Intent: ${truncateText(frame.intent)}`,
    ...renderActiveTask(frame.active_task),
    ...renderStringList("Quality bar", frame.quality_bar, MAX_QUALITY_BAR_ITEMS, "quality bar items"),
    ...renderPermissionEnvelope(frame),
    ...renderItemList("Active decisions", frame.active_decisions, MAX_ACTIVE_DECISIONS, "active decisions"),
    ...renderItemList("Open questions", frame.open_questions, MAX_OPEN_QUESTIONS, "open questions"),
    ...renderItemList("Next actions", frame.next_actions, MAX_NEXT_ACTIONS, "next actions"),
    ...renderStringList("Continuity notes", frame.continuity_notes, MAX_CONTINUITY_NOTES, "continuity notes"),
  ].join("\n");
}

export function renderMalformedContinuityDiagnostic(diagnostic: {
  message: string;
  path?: string;
  workspace_key?: string;
}): string {
  const lines = [
    "## Anvil Continuity Diagnostic",
    "",
    "Anvil continuity state exists but is invalid. Do not trust, partially use, or infer from malformed continuity state for this turn.",
    `Problem: ${diagnostic.message}`,
  ];
  if (diagnostic.path) lines.push(`Path: ${diagnostic.path}`);
  if (diagnostic.workspace_key) lines.push(`Workspace key: ${diagnostic.workspace_key}`);
  lines.push("Repair must be explicit/manual; normal host usage may continue without trusted continuity.");
  return lines.join("\n");
}
