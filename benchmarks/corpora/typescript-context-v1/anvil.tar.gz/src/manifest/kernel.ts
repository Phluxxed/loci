import { deriveObjective } from "./derivations.ts";
import type { ObjectiveView } from "./derivations.ts";
import { validateObjective } from "./model.ts";
import type {
  ObjectiveGraph,
  ObjectiveId,
  ImplementationPlan,
  TaskCompletion,
  TaskId,
  ValidationProblem,
  WorkstreamId,
} from "./model.ts";
import { findTaskLocation } from "./tree.ts";

type MutableTextFields = Readonly<{
  title?: string;
  outcome?: string;
  details?: string;
}>;

export type ResolvedGraphChange = Readonly<{
  addWorkstreams?: readonly Readonly<{
    id: WorkstreamId;
    title: string;
    outcome: string;
    details?: string;
    after: WorkstreamId | null;
  }>[];
  addTasks?: readonly Readonly<{
    id: TaskId;
    parent?: WorkstreamId | TaskId;
    workstream?: WorkstreamId;
    title: string;
    outcome: string;
    details?: string;
    decompositionComplete?: boolean;
    completionCriteria: readonly string[];
    after: TaskId | null;
    dependencies?: readonly TaskId[];
  }>[];
  update?: readonly (
    | Readonly<{ id: ObjectiveId; set: MutableTextFields & Readonly<{ phase?: "implementation"; implementation?: ImplementationPlan }> }>
    | Readonly<{ id: WorkstreamId; set: MutableTextFields }>
    | Readonly<{
        id: TaskId;
        set: MutableTextFields & Readonly<{
          completionCriteria?: readonly string[];
          decompositionComplete?: boolean;
          externalBlocker?: string | null;
          completion?: TaskCompletion | null;
          discontinued?: Readonly<{ reason: string }> | null;
        }>;
      }>
  )[];
  place?: readonly Readonly<{
    id: WorkstreamId | TaskId;
    parent?: WorkstreamId | TaskId;
    after: WorkstreamId | TaskId | null;
  }>[];
  setDependencies?: readonly Readonly<{
    task: TaskId;
    prerequisites: readonly TaskId[];
  }>[];
  removeEmptyWorkstreams?: readonly WorkstreamId[];
}>;

export type GraphApplyResult =
  | Readonly<{ applied: true; graph: ObjectiveGraph; view: ObjectiveView }>
  | Readonly<{ applied: false; graph: ObjectiveGraph; problems: readonly ValidationProblem[] }>;

export function applyObjectiveChange(
  graph: ObjectiveGraph,
  change: ResolvedGraphChange,
  session: Readonly<{ currentTaskId?: TaskId }> = {},
): GraphApplyResult {
  const candidate = structuredClone(graph);
  const problems: ValidationProblem[] = [];

  for (const [index, addition] of (change.addWorkstreams ?? []).entries()) {
    const workstream = {
      id: addition.id,
      title: addition.title,
      outcome: addition.outcome,
      details: addition.details ?? "",
      tasks: [],
    };
    insertAfter(
      candidate.workstreams,
      workstream,
      addition.after,
      (item) => item.id,
      `$.change.addWorkstreams[${index}].after`,
      "Workstream",
      problems,
    );
  }

  for (const [index, addition] of (change.addTasks ?? []).entries()) {
    const parentId = addition.parent ?? addition.workstream;
    const parent = parentId === undefined ? null : findTaskParent(candidate, parentId);
    if (parent === null) {
      problems.push({
        path: `$.change.addTasks[${index}].parent`,
        message: `Task parent does not exist: ${parentId ?? "missing"}.`,
      });
      continue;
    }
    insertAfter(
      parent,
      {
        id: addition.id,
        title: addition.title,
        outcome: addition.outcome,
        details: addition.details ?? "",
        ...(addition.decompositionComplete === undefined ? {} : { decompositionComplete: addition.decompositionComplete }),
        completionCriteria: [...addition.completionCriteria],
        dependencies: [...(addition.dependencies ?? [])],
        externalBlocker: null,
        completion: null,
        discontinued: null,
        tasks: [],
      },
      addition.after,
      (item) => item.id,
      `$.change.addTasks[${index}].after`,
      "Task in the target Workstream",
      problems,
    );
  }

  for (const [index, update] of (change.update ?? []).entries()) {
    const target = findGraphEntity(candidate, update.id);
    if (target === null) {
      problems.push({ path: `$.change.update[${index}].id`, message: `Graph identity does not exist: ${update.id}.` });
      continue;
    }
    const allowed = target.kind === "objective"
      ? new Set(["title", "outcome", "details", "phase", "implementation"])
      : target.kind === "workstream"
        ? new Set(["title", "outcome", "details"])
        : new Set([
            "title",
            "outcome",
            "details",
            "decompositionComplete",
            "completionCriteria",
            "externalBlocker",
            "completion",
            "discontinued",
          ]);
    for (const [key, value] of Object.entries(update.set)) {
      if (!allowed.has(key)) {
        problems.push({
          path: `$.change.update[${index}].set.${key}`,
          message: `${target.kind} does not own mutable field: ${key}.`,
        });
        continue;
      }
      if (key === "phase" && value !== "implementation") {
        problems.push({
          path: `$.change.update[${index}].set.phase`,
          message: "Objective phase can only move from Planning to Implementation.",
        });
        continue;
      }
      Object.assign(target.value, { [key]: structuredClone(value) });
    }
  }

  for (const [index, placement] of (change.place ?? []).entries()) {
    if (placement.id.startsWith("ws_")) {
      placeWorkstream(candidate, placement.id as WorkstreamId, placement.after, index, problems);
    } else {
      placeTask(candidate, placement.id as TaskId, placement.parent, placement.after, index, problems);
    }
  }

  for (const [index, replacement] of (change.setDependencies ?? []).entries()) {
    const location = findTaskLocation(candidate, replacement.task);
    if (location === null) {
      problems.push({
        path: `$.change.setDependencies[${index}].task`,
        message: `Task does not exist: ${replacement.task}.`,
      });
      continue;
    }
    location.task.dependencies = [...replacement.prerequisites];
  }

  for (const [index, workstreamId] of (change.removeEmptyWorkstreams ?? []).entries()) {
    const workstreamIndex = candidate.workstreams.findIndex((workstream) => workstream.id === workstreamId);
    if (workstreamIndex === -1) {
      problems.push({
        path: `$.change.removeEmptyWorkstreams[${index}]`,
        message: `Workstream does not exist: ${workstreamId}.`,
      });
    } else if (candidate.workstreams[workstreamIndex]!.tasks.length !== 0) {
      problems.push({
        path: `$.change.removeEmptyWorkstreams[${index}]`,
        message: `Only an empty Workstream can be removed: ${workstreamId}.`,
      });
    } else {
      candidate.workstreams.splice(workstreamIndex, 1);
    }
  }

  const validation = validateObjective(candidate);
  if (!validation.valid) problems.push(...validation.problems);
  if (problems.length > 0) return Object.freeze({ applied: false, graph, problems: Object.freeze(problems) });
  if (!validation.valid) throw new Error("Validated Objective result became invalid.");
  return Object.freeze({
    applied: true,
    graph: validation.graph,
    view: deriveObjective(validation.graph, session),
  });
}

type GraphEntity =
  | { kind: "objective"; value: ObjectiveGraph }
  | { kind: "workstream"; value: ObjectiveGraph["workstreams"][number] }
  | { kind: "task"; value: ObjectiveGraph["workstreams"][number]["tasks"][number] };

function findGraphEntity(graph: ObjectiveGraph, id: string): GraphEntity | null {
  if (graph.id === id) return { kind: "objective", value: graph };
  for (const workstream of graph.workstreams) {
    if (workstream.id === id) return { kind: "workstream", value: workstream };
    const location = findTaskLocation(graph, id);
    if (location !== null) return { kind: "task", value: location.task };
  }
  return null;
}

function insertAfter<T, Id extends string>(
  items: T[],
  item: T,
  after: Id | null,
  idOf: (item: T) => Id,
  path: string,
  label: string,
  problems: ValidationProblem[],
): void {
  if (after === null) {
    items.unshift(item);
    return;
  }
  const index = items.findIndex((candidate) => idOf(candidate) === after);
  if (index === -1) {
    problems.push({ path, message: `${label} placement anchor does not exist: ${after}.` });
    items.push(item);
    return;
  }
  items.splice(index + 1, 0, item);
}

function placeWorkstream(
  graph: ObjectiveGraph,
  id: WorkstreamId,
  after: WorkstreamId | TaskId | null,
  changeIndex: number,
  problems: ValidationProblem[],
): void {
  const sourceIndex = graph.workstreams.findIndex((workstream) => workstream.id === id);
  const path = `$.change.place[${changeIndex}]`;
  if (sourceIndex === -1) {
    problems.push({ path: `${path}.id`, message: `Workstream does not exist: ${id}.` });
    return;
  }
  if (after === id) {
    problems.push({ path: `${path}.after`, message: "Workstream cannot be placed after itself." });
    return;
  }
  if (after !== null && !after.startsWith("ws_")) {
    problems.push({ path: `${path}.after`, message: "A Workstream placement anchor must be a Workstream." });
    return;
  }
  if (after !== null && !graph.workstreams.some((workstream) => workstream.id === after)) {
    problems.push({ path: `${path}.after`, message: `Workstream placement anchor does not exist: ${after}.` });
    return;
  }
  const [workstream] = graph.workstreams.splice(sourceIndex, 1);
  insertAfter(graph.workstreams, workstream!, after as WorkstreamId | null, (item) => item.id, `${path}.after`, "Workstream", problems);
}

function placeTask(
  graph: ObjectiveGraph,
  id: TaskId,
  parentId: WorkstreamId | TaskId | undefined,
  after: WorkstreamId | TaskId | null,
  changeIndex: number,
  problems: ValidationProblem[],
): void {
  const source = findTaskLocation(graph, id);
  const path = `$.change.place[${changeIndex}]`;
  if (source === null) {
    problems.push({ path: `${path}.id`, message: `Task does not exist: ${id}.` });
    return;
  }
  const target = parentId === undefined ? source.siblings : findTaskParent(graph, parentId);
  if (target === null) {
    problems.push({ path: `${path}.parent`, message: `Task parent does not exist: ${parentId}.` });
    return;
  }
  if (after === id) {
    problems.push({ path: `${path}.after`, message: "Task cannot be placed after itself." });
    return;
  }
  if (after !== null && !after.startsWith("task_")) {
    problems.push({ path: `${path}.after`, message: "A Task placement anchor must be a Task." });
    return;
  }
  if (parentId !== undefined && parentId === id) {
    problems.push({ path: `${path}.parent`, message: "A Task cannot be its own parent." });
    return;
  }
  if (parentId?.startsWith("task_") && source.task.tasks.some((task) => containsTask(task, parentId as TaskId))) {
    problems.push({ path: `${path}.parent`, message: "A Task cannot be placed below one of its descendants." });
    return;
  }
  if (after !== null && !target.some((task) => task.id === after)) {
    problems.push({ path: `${path}.after`, message: `Task placement anchor does not exist under the target parent: ${after}.` });
    return;
  }
  source.siblings.splice(source.siblingIndex, 1);
  insertAfter(target, source.task, after as TaskId | null, (task) => task.id, `${path}.after`, "Task", problems);
}

function findTaskParent(graph: ObjectiveGraph, id: WorkstreamId | TaskId): ObjectiveGraph["workstreams"][number]["tasks"] | null {
  if (id.startsWith("ws_")) return graph.workstreams.find((workstream) => workstream.id === id)?.tasks ?? null;
  return findTaskLocation(graph, id)?.task.tasks ?? null;
}

function containsTask(task: ObjectiveGraph["workstreams"][number]["tasks"][number], id: TaskId): boolean {
  return task.id === id || task.tasks.some((child) => containsTask(child, id));
}
