import { lstat, readdir, realpath } from "node:fs/promises";
import { isAbsolute, join, relative, sep } from "node:path";

import { discoverObjectives, ManifestFileError, resolveRepository } from "./files.ts";
import type { DiscoveredObjective } from "./files.ts";

// Discovery searches project directories, not repository internals or generated trees.
const excludedDirectories = new Set([
  ".git", ".manifest", "node_modules", "vendor", ".venv", "venv", "__pycache__",
  ".cache", ".pytest_cache", ".mypy_cache", ".ruff_cache", ".tox", ".nox",
  ".next", ".nuxt", ".turbo", ".parcel-cache", "dist", "build", "coverage", "target",
]);

export type RepositoryDiscovery = Readonly<{
  root: string;
  roots?: readonly string[];
  repositories: readonly Readonly<{
    repository: string;
    objectives: readonly DiscoveredObjective[];
  }>[];
  problems: readonly Readonly<{ path: string; message: string }>[];
}>;

export async function resolveDiscoveryRoot(path: string): Promise<string> {
  if (!isAbsolute(path)) throw new Error("Manifest discovery root must be an absolute directory.");
  try {
    const root = await realpath(path);
    if (!(await lstat(root)).isDirectory()) throw new Error("not a directory");
    return root;
  } catch (cause) {
    throw new Error(`Cannot use Manifest discovery root ${path}: ${errorMessage(cause)}`, { cause });
  }
}

// The server supplies its canonical startup discovery root. Nothing is retained
// between calls: both newly created repositories and changed files are visible.
export async function discoverRepositoryObjectives(
  root: string,
  additionalRoots: readonly string[] = [],
): Promise<RepositoryDiscovery> {
  if (additionalRoots.length === 0) return discoverRoot(root);
  const roots = [...new Set([root, ...additionalRoots])];
  const discoveries = await Promise.all(roots.map(discoverRoot));
  const repositories = new Map<string, RepositoryDiscovery["repositories"][number]>();
  const problems = new Map<string, RepositoryDiscovery["problems"][number]>();
  for (const discovery of discoveries) {
    for (const repository of discovery.repositories) repositories.set(repository.repository, repository);
    for (const problem of discovery.problems) problems.set(JSON.stringify([problem.path, problem.message]), problem);
  }
  return {
    root,
    roots,
    repositories: [...repositories.values()].sort((a, b) => comparePaths(a.repository, b.repository)),
    problems: [...problems.values()].sort((a, b) => comparePaths(a.path, b.path) || comparePaths(a.message, b.message)),
  };
}

async function discoverRoot(root: string): Promise<RepositoryDiscovery> {
  const repositories: RepositoryDiscovery["repositories"][number][] = [];
  const problems: RepositoryDiscovery["problems"][number][] = [];
  const pending = [root];
  const visited = new Set<string>();

  while (pending.length > 0) {
    const path = pending.pop()!;
    try {
      // Do not let replacement of the configured root redirect a running server.
      if (path === root && !(await lstat(root)).isDirectory()) {
        throw new Error("The configured discovery root is no longer a regular directory.");
      }
      const directory = await realpath(path);
      const location = relative(root, directory);
      if (location === ".." || location.startsWith(`..${sep}`) || isAbsolute(location)) continue;
      // An internal alias must not bypass the same exclusions as a direct path.
      if (location.split(sep).some((part) => excludedDirectories.has(part))) continue;
      if (visited.has(directory) || !(await lstat(directory)).isDirectory()) continue;
      visited.add(directory);
      const entries = await readdir(directory, { withFileTypes: true });

      if (entries.some((entry) => entry.name === ".manifest")) {
        try {
          const repository = await resolveRepository(directory);
          const objectives = await discoverObjectives(repository);
          if (objectives.length > 0) repositories.push({ repository, objectives });
        } catch (cause) {
          problems.push({
            path: cause instanceof ManifestFileError ? cause.path : directory,
            message: errorMessage(cause),
          });
        }
      }

      // Continue inside repositories too: nested projects and linked worktrees
      // can own independent Objectives. Directory aliases share the visited set.
      for (const entry of entries) {
        if (!excludedDirectories.has(entry.name) && (entry.isDirectory() || entry.isSymbolicLink())) {
          pending.push(join(directory, entry.name));
        }
      }
    } catch (cause) {
      problems.push({ path, message: `Cannot inspect directory: ${errorMessage(cause)}` });
    }
  }

  repositories.sort((a, b) => comparePaths(a.repository, b.repository));
  problems.sort((a, b) => comparePaths(a.path, b.path));
  return { root, repositories, problems };
}

function comparePaths(a: string, b: string): number {
  return a < b ? -1 : a > b ? 1 : 0;
}

function errorMessage(cause: unknown): string {
  return cause instanceof Error ? cause.message : String(cause);
}
