import { randomBytes } from "node:crypto";

import { deriveObjective } from "./derivations.ts";
import type { ObjectiveView } from "./derivations.ts";
import {
  createObjectiveFile,
  loadObjective,
  writeObjective,
} from "./files.ts";
import { applyObjectiveChange } from "./kernel.ts";
import type { GraphApplyResult, ResolvedGraphChange } from "./kernel.ts";
import {
  objectiveIdSchema,
  taskIdSchema,
  workstreamIdSchema,
} from "./model.ts";
import type {
  ObjectiveGraph,
  ObjectiveId,
  ImplementationPlan,
  TaskCompletion,
  TaskId,
  ValidationProblem,
  WorkstreamId,
} from "./model.ts";
import { inquireObjective } from "./query.ts";
import type { ObjectiveInquiry, ObjectiveInquiryResult } from "./query.ts";

export type WorkstreamRef = WorkstreamId | `@${string}`;
export type TaskRef = TaskId | `@${string}`;

export type SemanticGraphChange = Readonly<{
  addWorkstreams?: readonly Readonly<{
    ref: string;
    title: string;
    outcome: string;
    details?: string;
    after: WorkstreamRef | null;
  }>[];
  addTasks?: readonly Readonly<{
    ref: string;
    workstream: WorkstreamRef | TaskRef;
    title: string;
    outcome: string;
    details?: string;
    decompositionComplete?: boolean;
    completionCriteria: readonly string[];
    after: TaskRef | null;
    dependencies?: readonly TaskRef[];
  }>[];
  update?: readonly Readonly<{
    id: ObjectiveId | WorkstreamId | TaskId;
    set: Readonly<{
      title?: string;
      outcome?: string;
      details?: string;
      phase?: "implementation";
      implementation?: ImplementationPlan;
      decompositionComplete?: boolean;
      completionCriteria?: readonly string[];
      externalBlocker?: string | null;
      completion?: TaskCompletion | null;
      discontinued?: Readonly<{ reason: string }> | null;
    }>;
  }>[];
  place?: readonly Readonly<{
    id: WorkstreamId | TaskId | WorkstreamRef | TaskRef;
    parent?: WorkstreamRef | TaskRef;
    after: WorkstreamRef | TaskRef | null;
  }>[];
  setDependencies?: readonly Readonly<{
    task: TaskRef;
    prerequisites: readonly TaskRef[];
  }>[];
  removeEmptyWorkstreams?: readonly WorkstreamId[];
}>;

export type CreatedGraphIdentity = Readonly<{
  ref: string;
  id: WorkstreamId | TaskId;
}>;

export type CreateObjectiveResult = Readonly<{
  objectiveId: ObjectiveId;
  path: string;
  graph: ObjectiveGraph;
  view: ObjectiveView;
}>;

export type OrientObjectiveResult = Readonly<{
  path: string;
  graph: ObjectiveGraph;
  view: ObjectiveView;
}>;

export type InquireObjectiveResult = Readonly<{
  path: string;
  result: ObjectiveInquiryResult;
}>;

export type ChangeObjectiveResult =
  | Readonly<{
      applied: true;
      path: string;
      graph: ObjectiveGraph;
      created: readonly CreatedGraphIdentity[];
      view: ObjectiveView;
    }>
  | Readonly<{
      applied: false;
      path: string;
      graph: ObjectiveGraph;
      problems: readonly ValidationProblem[];
    }>;

type IdentityKind = "objective" | "workstream" | "task";
type AllocateIdentity = (kind: IdentityKind) => string;

type ManifestServiceDependencies = Readonly<{
  allocateIdentity?: AllocateIdentity;
}>;

export function createManifestService(dependencies: ManifestServiceDependencies = {}) {
  const allocateIdentity = dependencies.allocateIdentity ?? defaultAllocateIdentity;

  return Object.freeze({
    async createObjective(
      repository: string,
      input: Readonly<{ title: string; outcome: string; details?: string }>,
    ): Promise<CreateObjectiveResult> {
      const objectiveId = allocateObjectiveId(allocateIdentity);
      const graph: ObjectiveGraph = {
        id: objectiveId,
        title: input.title,
        outcome: input.outcome,
        details: input.details ?? "",
        phase: "planning",
        workstreams: [],
      };
      const created = await createObjectiveFile(repository, graph);
      return Object.freeze({
        objectiveId,
        path: created.path,
        graph: created.graph,
        view: deriveObjective(created.graph),
      });
    },

    async orientObjective(
      repository: string,
      objectiveId: ObjectiveId,
      currentTaskId?: TaskId,
    ): Promise<OrientObjectiveResult> {
      const loaded = await loadObjective(repository, objectiveId);
      return Object.freeze({
        path: loaded.path,
        graph: loaded.graph,
        view: deriveObjective(loaded.graph, sessionProjection(currentTaskId)),
      });
    },

    async inquireCurrentObjective(
      repository: string,
      objectiveId: ObjectiveId,
      inquiry: ObjectiveInquiry,
      currentTaskId?: TaskId,
    ): Promise<InquireObjectiveResult> {
      const loaded = await loadObjective(repository, objectiveId);
      return Object.freeze({
        path: loaded.path,
        result: inquireObjective(loaded.graph, inquiry, sessionProjection(currentTaskId)),
      });
    },

    async changeObjective(
      repository: string,
      objectiveId: ObjectiveId,
      change: SemanticGraphChange,
      currentTaskId?: TaskId,
    ): Promise<ChangeObjectiveResult> {
      const loaded = await loadObjective(repository, objectiveId);
      const resolution = resolveChange(change, allocateIdentity);
      if (!resolution.resolved) {
        return Object.freeze({
          applied: false,
          path: loaded.path,
          graph: loaded.graph,
          problems: resolution.problems,
        });
      }
      const applied: GraphApplyResult = applyObjectiveChange(
        loaded.graph,
        resolution.change,
        sessionProjection(currentTaskId),
      );
      if (!applied.applied) {
        return Object.freeze({
          applied: false,
          path: loaded.path,
          graph: applied.graph,
          problems: applied.problems,
        });
      }
      const written = await writeObjective(repository, applied.graph);
      return Object.freeze({
        applied: true,
        path: written.path,
        graph: written.graph,
        created: resolution.created,
        view: deriveObjective(written.graph, sessionProjection(currentTaskId)),
      });
    },
  });
}

const defaultService = createManifestService();
export const createObjective = defaultService.createObjective;
export const orientObjective = defaultService.orientObjective;
export const inquireCurrentObjective = defaultService.inquireCurrentObjective;
export const changeObjective = defaultService.changeObjective;

type ResolvedChange =
  | Readonly<{
      resolved: true;
      change: ResolvedGraphChange;
      created: readonly CreatedGraphIdentity[];
    }>
  | Readonly<{ resolved: false; problems: readonly ValidationProblem[] }>;

function resolveChange(change: SemanticGraphChange, allocateIdentity: AllocateIdentity): ResolvedChange {
  const problems: ValidationProblem[] = [];
  const refs = new Map<string, { kind: "workstream" | "task"; id: WorkstreamId | TaskId }>();
  const created: CreatedGraphIdentity[] = [];

  for (const [index, addition] of (change.addWorkstreams ?? []).entries()) {
    const id = allocateWorkstreamId(allocateIdentity);
    registerRef(addition.ref, "workstream", id, `$.change.addWorkstreams[${index}].ref`, refs, created, problems);
  }
  for (const [index, addition] of (change.addTasks ?? []).entries()) {
    const id = allocateTaskId(allocateIdentity);
    registerRef(addition.ref, "task", id, `$.change.addTasks[${index}].ref`, refs, created, problems);
  }

  const resolvedWorkstreams: NonNullable<ResolvedGraphChange["addWorkstreams"]>[number][] = [];
  for (const [index, addition] of (change.addWorkstreams ?? []).entries()) {
    const own = refs.get(`@${addition.ref}`);
    const after = resolveRef(addition.after, "workstream", `$.change.addWorkstreams[${index}].after`, refs, problems);
    if (own?.kind !== "workstream" || after === undefined) continue;
    resolvedWorkstreams.push({
      id: own.id as WorkstreamId,
      title: addition.title,
      outcome: addition.outcome,
      ...(addition.details !== undefined ? { details: addition.details } : {}),
      after,
    });
  }

  const resolvedTasks: NonNullable<ResolvedGraphChange["addTasks"]>[number][] = [];
  for (const [index, addition] of (change.addTasks ?? []).entries()) {
    const own = refs.get(`@${addition.ref}`);
    const parent = resolveAnyGraphRef(addition.workstream, `$.change.addTasks[${index}].workstream`, refs, problems);
    const after = resolveRef(addition.after, "task", `$.change.addTasks[${index}].after`, refs, problems);
    const dependencies = resolveRefs(
      addition.dependencies ?? [],
      "task",
      `$.change.addTasks[${index}].dependencies`,
      refs,
      problems,
    );
    if (own?.kind !== "task" || parent == null || after === undefined || dependencies === undefined) continue;
    resolvedTasks.push({
      id: own.id as TaskId,
      parent,
      title: addition.title,
      outcome: addition.outcome,
      ...(addition.details !== undefined ? { details: addition.details } : {}),
      ...(addition.decompositionComplete !== undefined ? { decompositionComplete: addition.decompositionComplete } : {}),
      completionCriteria: [...addition.completionCriteria],
      after,
      dependencies,
    });
  }

  const placements: NonNullable<ResolvedGraphChange["place"]>[number][] = [];
  for (const [index, placement] of (change.place ?? []).entries()) {
    const id = resolveAnyGraphRef(placement.id, `$.change.place[${index}].id`, refs, problems);
    const parent = placement.parent === undefined
      ? undefined
      : resolveAnyGraphRef(placement.parent, `$.change.place[${index}].parent`, refs, problems);
    const after = resolveAnyGraphRef(placement.after, `$.change.place[${index}].after`, refs, problems);
    if (id == null || (parent == null && placement.parent !== undefined) || after === undefined) continue;
    placements.push({ id, ...(parent != null ? { parent } : {}), after });
  }

  const dependencies: NonNullable<ResolvedGraphChange["setDependencies"]>[number][] = [];
  for (const [index, replacement] of (change.setDependencies ?? []).entries()) {
    const task = resolveRef(replacement.task, "task", `$.change.setDependencies[${index}].task`, refs, problems);
    const prerequisites = resolveRefs(
      replacement.prerequisites,
      "task",
      `$.change.setDependencies[${index}].prerequisites`,
      refs,
      problems,
    );
    if (task == null || prerequisites === undefined) continue;
    dependencies.push({ task, prerequisites });
  }

  if (problems.length > 0) return Object.freeze({ resolved: false, problems: Object.freeze(problems) });
  return Object.freeze({
    resolved: true,
    created: Object.freeze(created),
    change: {
      addWorkstreams: resolvedWorkstreams,
      addTasks: resolvedTasks,
      update: change.update as ResolvedGraphChange["update"],
      place: placements,
      setDependencies: dependencies,
      removeEmptyWorkstreams: change.removeEmptyWorkstreams,
    },
  });
}

function registerRef(
  ref: string,
  kind: "workstream" | "task",
  id: WorkstreamId | TaskId,
  path: string,
  refs: Map<string, { kind: "workstream" | "task"; id: WorkstreamId | TaskId }>,
  created: CreatedGraphIdentity[],
  problems: ValidationProblem[],
): void {
  const key = `@${ref}`;
  if (refs.has(key)) {
    problems.push({ path, message: `Duplicate request reference: ${ref}.` });
    return;
  }
  refs.set(key, { kind, id });
  created.push(Object.freeze({ ref, id }));
}

function resolveRefs<Kind extends "workstream" | "task">(
  values: readonly (WorkstreamRef | TaskRef)[],
  kind: Kind,
  path: string,
  refs: ReadonlyMap<string, { kind: "workstream" | "task"; id: WorkstreamId | TaskId }>,
  problems: ValidationProblem[],
): readonly (Kind extends "workstream" ? WorkstreamId : TaskId)[] | undefined {
  const resolved = values.map((value, index) => resolveRef(value, kind, `${path}[${index}]`, refs, problems));
  return resolved.some((value) => value === undefined)
    ? undefined
    : resolved as readonly (Kind extends "workstream" ? WorkstreamId : TaskId)[];
}

function resolveRef<Kind extends "workstream" | "task">(
  value: WorkstreamRef | TaskRef | null,
  kind: Kind,
  path: string,
  refs: ReadonlyMap<string, { kind: "workstream" | "task"; id: WorkstreamId | TaskId }>,
  problems: ValidationProblem[],
): (Kind extends "workstream" ? WorkstreamId : TaskId) | null | undefined {
  if (value === null) return null;
  if (!value.startsWith("@")) {
    const parsed = (kind === "workstream" ? workstreamIdSchema : taskIdSchema).safeParse(value);
    if (parsed.success) return parsed.data as Kind extends "workstream" ? WorkstreamId : TaskId;
    problems.push({ path, message: `Expected a ${kind} Stable Graph Identity.` });
    return undefined;
  }
  const found = refs.get(value);
  if (found === undefined) {
    problems.push({ path, message: `Unknown request reference: ${value}.` });
    return undefined;
  }
  if (found.kind !== kind) {
    problems.push({ path, message: `Request reference ${value} names a ${found.kind}, not a ${kind}.` });
    return undefined;
  }
  return found.id as Kind extends "workstream" ? WorkstreamId : TaskId;
}

function resolveAnyGraphRef(
  value: WorkstreamRef | TaskRef | null,
  path: string,
  refs: ReadonlyMap<string, { kind: "workstream" | "task"; id: WorkstreamId | TaskId }>,
  problems: ValidationProblem[],
): WorkstreamId | TaskId | null | undefined {
  if (value === null) return null;
  if (value.startsWith("@")) {
    const found = refs.get(value);
    if (found !== undefined) return found.id;
    problems.push({ path, message: `Unknown request reference: ${value}.` });
    return undefined;
  }
  const parsed = workstreamIdSchema.safeParse(value);
  if (parsed.success) return parsed.data;
  const task = taskIdSchema.safeParse(value);
  if (task.success) return task.data;
  problems.push({ path, message: "Expected a Workstream or Task Stable Graph Identity." });
  return undefined;
}

function allocateObjectiveId(allocate: AllocateIdentity): ObjectiveId {
  return objectiveIdSchema.parse(allocate("objective"));
}

function allocateWorkstreamId(allocate: AllocateIdentity): WorkstreamId {
  return workstreamIdSchema.parse(allocate("workstream"));
}

function allocateTaskId(allocate: AllocateIdentity): TaskId {
  return taskIdSchema.parse(allocate("task"));
}

function defaultAllocateIdentity(kind: IdentityKind): string {
  const prefix = kind === "objective" ? "obj" : kind === "workstream" ? "ws" : "task";
  return `${prefix}_${randomBytes(16).toString("hex")}`;
}

function sessionProjection(currentTaskId: TaskId | undefined): Readonly<{ currentTaskId?: TaskId }> {
  return currentTaskId === undefined ? Object.freeze({}) : Object.freeze({ currentTaskId });
}
