import { deriveObjective } from "./derivations.ts";
import type { DerivedTask } from "./derivations.ts";
import type { ObjectiveGraph, TaskCompletion, TaskId } from "./model.ts";
import { taskLocations } from "./tree.ts";
import type { TaskLocation } from "./tree.ts";

export type GraphEntityKind = "objective" | "workstream" | "task";
export type GraphEntitySummary = Readonly<{ kind: GraphEntityKind; id: string; title: string; outcome: string; details: string }>;
export type ConnectedGraphEntity = GraphEntitySummary & Readonly<{
  parent: GraphEntitySummary | null;
  children: readonly GraphEntitySummary[];
  prerequisites: readonly GraphEntitySummary[];
  dependents: readonly GraphEntitySummary[];
  completionCriteria: readonly string[];
  decompositionComplete: boolean | null;
  externalBlocker: string | null;
  completion: TaskCompletion | null;
  discontinued: Readonly<{ reason: string }> | null;
  execution: DerivedTask | null;
}>;
export type ObjectiveInquiry = Readonly<{ id: string }> | Readonly<{ text: string; limit?: number }>;
export type ObjectiveInquiryResult =
  | Readonly<{ outcome: "found"; entity: ConnectedGraphEntity }>
  | Readonly<{ outcome: "not_found"; matches: readonly GraphEntitySummary[] }>
  | Readonly<{ outcome: "multiple"; matches: readonly GraphEntitySummary[]; matchCount: number; limit: number }>;

type LocatedEntity =
  | Readonly<{ kind: "objective"; value: ObjectiveGraph }>
  | Readonly<{ kind: "workstream"; value: ObjectiveGraph["workstreams"][number]; workstreamIndex: number }>
  | Readonly<{ kind: "task"; value: TaskLocation["task"]; location: TaskLocation }>;

export function inquireObjective(
  graph: ObjectiveGraph,
  inquiry: ObjectiveInquiry,
  session: Readonly<{ currentTaskId?: TaskId }> = {},
): ObjectiveInquiryResult {
  if ("id" in inquiry) {
    const entity = findExact(graph, inquiry.id);
    return entity === null
      ? Object.freeze({ outcome: "not_found", matches: Object.freeze([]) })
      : Object.freeze({ outcome: "found", entity: connectEntity(graph, entity, session) });
  }
  const needle = inquiry.text.toLocaleLowerCase();
  const limit = clampLimit(inquiry.limit);
  const matches = graphOrder(graph).filter((entity) => searchableText(entity).includes(needle));
  if (matches.length === 0) return Object.freeze({ outcome: "not_found", matches: Object.freeze([]) });
  if (matches.length === 1) return Object.freeze({ outcome: "found", entity: connectEntity(graph, matches[0]!, session) });
  return Object.freeze({
    outcome: "multiple",
    matches: Object.freeze(matches.slice(0, limit).map(summarize)),
    matchCount: matches.length,
    limit,
  });
}

function findExact(graph: ObjectiveGraph, id: string): LocatedEntity | null {
  if (graph.id === id) return { kind: "objective", value: graph };
  const workstreamIndex = graph.workstreams.findIndex((workstream) => workstream.id === id);
  if (workstreamIndex !== -1) return { kind: "workstream", value: graph.workstreams[workstreamIndex]!, workstreamIndex };
  const location = taskLocations(graph).find(({ task }) => task.id === id);
  return location === undefined ? null : { kind: "task", value: location.task, location };
}

function graphOrder(graph: ObjectiveGraph): LocatedEntity[] {
  const entities: LocatedEntity[] = [{ kind: "objective", value: graph }];
  for (const [workstreamIndex, workstream] of graph.workstreams.entries()) {
    entities.push({ kind: "workstream", value: workstream, workstreamIndex });
    for (const location of taskLocations(graph).filter((candidate) => candidate.workstreamIndex === workstreamIndex)) {
      entities.push({ kind: "task", value: location.task, location });
    }
  }
  return entities;
}

function searchableText(entity: LocatedEntity): string {
  const fields = [entity.value.title, entity.value.outcome, entity.value.details];
  if (entity.kind === "task") fields.push(...entity.value.completionCriteria);
  return fields.join("\n").toLocaleLowerCase();
}

function connectEntity(
  graph: ObjectiveGraph,
  entity: LocatedEntity,
  session: Readonly<{ currentTaskId?: TaskId }>,
): ConnectedGraphEntity {
  const view = deriveObjective(graph, session);
  const summary = summarize(entity);
  if (entity.kind === "objective") return Object.freeze({
    ...summary,
    parent: null,
    children: Object.freeze(graph.workstreams.map((value, workstreamIndex) => summarize({ kind: "workstream", value, workstreamIndex }))),
    prerequisites: Object.freeze([]), dependents: Object.freeze([]), completionCriteria: Object.freeze([]),
    decompositionComplete: null,
    externalBlocker: null, completion: null, discontinued: null, execution: null,
  });
  if (entity.kind === "workstream") return Object.freeze({
    ...summary,
    parent: summarize({ kind: "objective", value: graph }),
    children: Object.freeze(entity.value.tasks.map((task) => summarizeTask(task, graph))),
    prerequisites: Object.freeze([]), dependents: Object.freeze([]), completionCriteria: Object.freeze([]),
    decompositionComplete: null,
    externalBlocker: null, completion: null, discontinued: null, execution: null,
  });

  const all = taskLocations(graph);
  const prerequisiteIds = new Set(entity.value.dependencies);
  const parent = entity.location.parentTask === null
    ? summarize({ kind: "workstream", value: entity.location.workstream, workstreamIndex: entity.location.workstreamIndex })
    : summarizeTask(entity.location.parentTask, graph);
  return Object.freeze({
    ...summary,
    parent,
    children: Object.freeze(entity.value.tasks.map((task) => summarizeTask(task, graph))),
    prerequisites: Object.freeze(all.filter(({ task }) => prerequisiteIds.has(task.id)).map(({ task }) => summarizeTask(task, graph))),
    dependents: Object.freeze(all.filter(({ task }) => task.dependencies.includes(entity.value.id)).map(({ task }) => summarizeTask(task, graph))),
    completionCriteria: Object.freeze([...entity.value.completionCriteria]),
    decompositionComplete: entity.value.tasks.length === 0 ? entity.value.decompositionComplete === true : null,
    externalBlocker: entity.value.externalBlocker,
    completion: entity.value.completion,
    discontinued: entity.value.discontinued,
    execution: view.tasks.find((task) => task.id === entity.value.id) ?? null,
  });
}

function summarizeTask(task: TaskLocation["task"], graph: ObjectiveGraph): GraphEntitySummary {
  const location = taskLocations(graph).find((candidate) => candidate.task.id === task.id)!;
  return summarize({ kind: "task", value: task, location });
}

function summarize(entity: LocatedEntity): GraphEntitySummary {
  return Object.freeze({ kind: entity.kind, id: entity.value.id, title: entity.value.title, outcome: entity.value.outcome, details: entity.value.details });
}

function clampLimit(limit: number | undefined): number {
  if (limit === undefined || !Number.isFinite(limit)) return 20;
  return Math.max(1, Math.min(50, Math.trunc(limit)));
}
