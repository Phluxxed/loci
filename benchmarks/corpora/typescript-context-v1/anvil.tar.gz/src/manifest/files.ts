import { randomUUID } from "node:crypto";
import { execFile } from "node:child_process";
import { constants } from "node:fs";
import {
  access,
  lstat,
  mkdir,
  open,
  readdir,
  realpath,
  rename,
  unlink,
} from "node:fs/promises";
import { isAbsolute, join } from "node:path";
import { promisify } from "node:util";

import { objectiveIdSchema, validateObjective } from "./model.ts";
import type {
  ObjectiveGraph,
  ObjectiveId,
  Task,
  TaskId,
  ValidationProblem,
} from "./model.ts";
import { taskLocations } from "./tree.ts";
import { deriveObjective } from "./derivations.ts";

const execFileAsync = promisify(execFile);

export type ManifestFileErrorCode =
  | "REPOSITORY_INVALID"
  | "OBJECTIVE_NOT_FOUND"
  | "OBJECTIVE_EXISTS"
  | "OBJECTIVE_JSON_INVALID"
  | "OBJECTIVE_GRAPH_INVALID"
  | "OBJECTIVE_ID_MISMATCH"
  | "OBJECTIVE_PATH_INVALID"
  | "FILESYSTEM_ERROR";

export class ManifestFileError extends Error {
  readonly code: ManifestFileErrorCode;
  readonly path: string;
  readonly problems: readonly ValidationProblem[];

  constructor(
    code: ManifestFileErrorCode,
    message: string,
    path: string,
    problems: readonly ValidationProblem[] = [],
    options?: ErrorOptions,
  ) {
    super(message, options);
    this.name = "ManifestFileError";
    this.code = code;
    this.path = path;
    this.problems = problems;
  }
}

export type LoadedObjective = Readonly<{
  repository: string;
  path: string;
  graph: ObjectiveGraph;
}>;

export type DiscoveredObjective =
  | Readonly<{
      valid: true;
      path: string;
      objective: Readonly<{
        id: ObjectiveId;
        title: string;
        outcome: string;
        phase: ObjectiveGraph["phase"];
        complete: boolean;
      }>;
    }>
  | Readonly<{
      valid: false;
      path: string;
      problems: readonly ValidationProblem[];
    }>;

export async function loadObjective(repository: string, objectiveId: ObjectiveId): Promise<LoadedObjective> {
  const root = await resolveRepository(repository);
  return loadObjectiveAtRoot(root, objectiveId);
}

async function loadObjectiveAtRoot(root: string, objectiveId: ObjectiveId): Promise<LoadedObjective> {
  const path = objectivePath(root, objectiveId);
  let bytes: string;
  try {
    await objectiveDirectory(root);
    if (!(await lstat(path)).isFile()) throw invalidObjectivePath(path);
    const file = await open(path, constants.O_RDONLY | constants.O_NOFOLLOW | constants.O_NONBLOCK);
    try {
      if (!(await file.stat()).isFile()) throw invalidObjectivePath(path);
      bytes = await file.readFile("utf8");
    } finally {
      await file.close();
    }
  } catch (cause) {
    if (cause instanceof ManifestFileError) throw cause;
    if (errorCode(cause) === "ELOOP") throw invalidObjectivePath(path);
    if (errorCode(cause) === "ENOENT") {
      throw new ManifestFileError("OBJECTIVE_NOT_FOUND", `Objective file does not exist: ${path}.`, path, [], { cause });
    }
    throw filesystemError("read", path, cause);
  }

  let input: unknown;
  try {
    input = JSON.parse(bytes);
  } catch (cause) {
    const problem = Object.freeze({ path: "$", message: `Malformed JSON: ${errorMessage(cause)}` });
    throw new ManifestFileError("OBJECTIVE_JSON_INVALID", `Objective file contains malformed JSON: ${path}.`, path, [problem], { cause });
  }
  const validation = validateObjective(input);
  if (!validation.valid) {
    throw new ManifestFileError(
      "OBJECTIVE_GRAPH_INVALID",
      `Objective graph is invalid: ${path}.`,
      path,
      validation.problems,
    );
  }
  if (validation.graph.id !== objectiveId) {
    const problem = Object.freeze({
      path: "$.id",
      message: `Objective identity ${validation.graph.id} does not match filename ${objectiveId}.`,
    });
    throw new ManifestFileError(
      "OBJECTIVE_ID_MISMATCH",
      `Objective identity does not match its filename: ${path}.`,
      path,
      [problem],
    );
  }
  return Object.freeze({ repository: root, path, graph: validation.graph });
}

export async function createObjectiveFile(repository: string, graph: ObjectiveGraph): Promise<LoadedObjective> {
  const root = await resolveRepository(repository);
  const canonical = validatedCanonicalGraph(graph);
  const path = objectivePath(root, canonical.id);
  await mkdir(join(root, ".manifest", "objectives"), { recursive: true });
  try {
    await access(path);
  } catch (cause) {
    if (errorCode(cause) !== "ENOENT") throw filesystemError("inspect", path, cause);
    await writeAtomic(path, serializeObjective(canonical));
    return Object.freeze({ repository: root, path, graph: canonical });
  }
  throw new ManifestFileError("OBJECTIVE_EXISTS", `Objective file already exists: ${path}.`, path);
}

export async function writeObjective(repository: string, graph: ObjectiveGraph): Promise<LoadedObjective> {
  const root = await resolveRepository(repository);
  const canonical = validatedCanonicalGraph(graph);
  const path = objectivePath(root, canonical.id);
  try {
    await access(path);
  } catch (cause) {
    if (errorCode(cause) === "ENOENT") {
      throw new ManifestFileError("OBJECTIVE_NOT_FOUND", `Objective file does not exist: ${path}.`, path, [], { cause });
    }
    throw filesystemError("inspect", path, cause);
  }
  await writeAtomic(path, serializeObjective(canonical));
  return Object.freeze({ repository: root, path, graph: canonical });
}

export async function discoverObjectives(repository: string): Promise<readonly DiscoveredObjective[]> {
  const root = await resolveRepository(repository);
  const directory = join(root, ".manifest", "objectives");
  let names: string[];
  try {
    await objectiveDirectory(root);
    names = (await readdir(directory)).filter((name) => name.endsWith(".json")).sort();
  } catch (cause) {
    if (errorCode(cause) === "ENOENT") return Object.freeze([]);
    if (cause instanceof ManifestFileError) throw cause;
    throw filesystemError("read", directory, cause);
  }

  const discovered: DiscoveredObjective[] = [];
  for (const name of names) {
    const path = join(directory, name);
    const parsedId = objectiveIdSchema.safeParse(name.slice(0, -".json".length));
    if (!parsedId.success) {
      discovered.push(Object.freeze({
        valid: false,
        path,
        problems: Object.freeze([{ path: "$", message: `Objective filename is invalid: ${name}.` }]),
      }));
      continue;
    }
    try {
      const loaded = await loadObjectiveAtRoot(root, parsedId.data);
      discovered.push(Object.freeze({
        valid: true,
        path,
        objective: Object.freeze({
          id: loaded.graph.id,
          title: loaded.graph.title,
          outcome: loaded.graph.outcome,
          phase: loaded.graph.phase,
          complete: deriveObjective(loaded.graph).progress.complete,
        }),
      }));
    } catch (cause) {
      discovered.push(Object.freeze({
        valid: false,
        path,
        problems: Object.freeze(problemsFromError(cause)),
      }));
    }
  }
  return Object.freeze(discovered);
}

export async function resolveRepository(repository: string): Promise<string> {
  if (!isAbsolute(repository)) {
    throw new ManifestFileError(
      "REPOSITORY_INVALID",
      "Manifest repository must be an absolute Git worktree root.",
      repository,
    );
  }
  let root: string;
  try {
    root = await realpath(repository);
    const gitEntry = await lstat(join(root, ".git"));
    if (!gitEntry.isDirectory() && !gitEntry.isFile()) throw new Error(".git is not a file or directory");
    // Ambient Git targeting must not redirect validation to a different worktree.
    const env = Object.fromEntries(Object.entries(process.env).filter(([key]) => !key.startsWith("GIT_")));
    const { stdout } = await execFileAsync("git", ["--no-optional-locks", "-C", root, "rev-parse", "--show-toplevel"], {
      env, encoding: "utf8", timeout: 5_000, maxBuffer: 64 * 1024,
    });
    const gitRoot = await realpath(stdout.replace(/\n$/, ""));
    if (gitRoot !== root) throw new Error("path is not the Git worktree root");
  } catch (cause) {
    throw new ManifestFileError(
      "REPOSITORY_INVALID",
      `Manifest repository is not a Git worktree root: ${repository}.`,
      repository,
      [],
      { cause },
    );
  }
  return root;
}

async function objectiveDirectory(root: string): Promise<string> {
  const manifest = join(root, ".manifest");
  const directory = join(manifest, "objectives");
  // Repository aliases are resolved above; storage entries themselves stay local
  // regular directories/files, never symlinks into another storage location.
  for (const path of [manifest, directory]) {
    if (!(await lstat(path)).isDirectory()) throw invalidObjectivePath(path);
  }
  return directory;
}

function invalidObjectivePath(path: string): ManifestFileError {
  return new ManifestFileError(
    "OBJECTIVE_PATH_INVALID",
    `Manifest Objective path must use regular directories and files, without symbolic links: ${path}.`,
    path,
  );
}

function objectivePath(repository: string, objectiveId: ObjectiveId): string {
  const parsed = objectiveIdSchema.safeParse(objectiveId);
  if (!parsed.success) {
    throw new ManifestFileError("OBJECTIVE_GRAPH_INVALID", "Objective identity is invalid.", String(objectiveId), [{
      path: "$.id",
      message: parsed.error.issues[0]?.message ?? "Objective identity is invalid.",
    }]);
  }
  return join(repository, ".manifest", "objectives", `${parsed.data}.json`);
}

function validatedCanonicalGraph(input: unknown): ObjectiveGraph {
  const validation = validateObjective(input);
  if (!validation.valid) {
    throw new ManifestFileError(
      "OBJECTIVE_GRAPH_INVALID",
      "Objective graph is invalid and was not written.",
      "$.graph",
      validation.problems,
    );
  }
  const taskOrder = new Map<TaskId, number>();
  let taskIndex = 0;
  for (const { task } of taskLocations(validation.graph)) taskOrder.set(task.id, taskIndex++);
  return {
    id: validation.graph.id,
    title: validation.graph.title,
    outcome: validation.graph.outcome,
    details: validation.graph.details,
    phase: validation.graph.phase,
    ...(validation.graph.implementation === undefined
      ? {}
      : { implementation: structuredClone(validation.graph.implementation) }),
    workstreams: validation.graph.workstreams.map((workstream) => ({
      id: workstream.id,
      title: workstream.title,
      outcome: workstream.outcome,
      details: workstream.details,
      tasks: workstream.tasks.map((task) => canonicalTask(task, taskOrder)),
    })),
  };
}

function canonicalTask(task: Task, taskOrder: ReadonlyMap<TaskId, number>): Task {
  return {
    id: task.id,
    title: task.title,
    outcome: task.outcome,
    details: task.details,
    ...(task.decompositionComplete === undefined ? {} : { decompositionComplete: task.decompositionComplete }),
    completionCriteria: [...task.completionCriteria],
    dependencies: [...task.dependencies].sort((left, right) => taskOrder.get(left)! - taskOrder.get(right)!),
    externalBlocker: task.externalBlocker,
    completion: task.completion === null
      ? null
      : { evidence: task.completion.evidence.map((entry) => ({
          criterion: entry.criterion,
          summary: entry.summary,
          references: [...entry.references],
        })) },
    discontinued: task.discontinued === null ? null : { reason: task.discontinued.reason },
    tasks: task.tasks.map((child) => canonicalTask(child, taskOrder)),
  };
}

function serializeObjective(graph: ObjectiveGraph): string {
  return `${JSON.stringify(graph, null, 2)}\n`;
}

async function writeAtomic(path: string, bytes: string): Promise<void> {
  const temporaryPath = `${path}.tmp-${process.pid}-${randomUUID()}`;
  let handle: Awaited<ReturnType<typeof open>> | undefined;
  let renamed = false;
  try {
    handle = await open(temporaryPath, "wx", 0o600);
    await handle.writeFile(bytes, "utf8");
    await handle.sync();
    await handle.close();
    handle = undefined;
    await rename(temporaryPath, path);
    renamed = true;
  } catch (cause) {
    if (handle !== undefined) await handle.close().catch(() => undefined);
    throw filesystemError("write", path, cause);
  } finally {
    if (!renamed) await unlink(temporaryPath).catch(() => undefined);
  }
}

function problemsFromError(cause: unknown): ValidationProblem[] {
  if (cause instanceof ManifestFileError && cause.problems.length > 0) return [...cause.problems];
  return [{ path: "$", message: errorMessage(cause) }];
}

function filesystemError(operation: string, path: string, cause: unknown): ManifestFileError {
  return new ManifestFileError(
    "FILESYSTEM_ERROR",
    `Could not ${operation} Manifest path ${path}: ${errorMessage(cause)}`,
    path,
    [],
    { cause },
  );
}

function errorCode(cause: unknown): string | undefined {
  return typeof cause === "object" && cause !== null && "code" in cause && typeof cause.code === "string"
    ? cause.code
    : undefined;
}

function errorMessage(cause: unknown): string {
  return cause instanceof Error ? cause.message : String(cause);
}
