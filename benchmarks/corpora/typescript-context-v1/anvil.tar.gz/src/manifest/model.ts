import * as z from "zod/v4";

export const objectiveIdSchema = z.string().regex(/^obj_[a-f0-9]{32}$/).brand<"ObjectiveId">();
export const workstreamIdSchema = z.string().regex(/^ws_[a-f0-9]{32}$/).brand<"WorkstreamId">();
export const taskIdSchema = z.string().regex(/^task_[a-f0-9]{32}$/).brand<"TaskId">();

const requiredTextSchema = z.string().trim().min(1);
const detailsSchema = z.string().trim();

const completionEvidenceSchema = z.object({
  criterion: requiredTextSchema,
  summary: requiredTextSchema,
  references: z.array(requiredTextSchema).min(1),
}).strict();

const taskCompletionSchema = z.object({
  evidence: z.array(completionEvidenceSchema).min(1),
}).strict();

const discontinuedTaskSchema = z.object({
  reason: requiredTextSchema,
}).strict();

const implementationIdSchema = z.string().regex(/^[A-Z][A-Z0-9]*(?:\.\d+)?$/);
const conceptIdSchema = z.string().regex(/^M(?:\.\d+)*$/);

const implementationCoverageSchema = z.object({
  concepts: z.array(conceptIdSchema).default([]),
  nodes: z.array(z.union([objectiveIdSchema, workstreamIdSchema, taskIdSchema])).default([]),
}).strict();

const implementationSliceSchema = z.object({
  id: implementationIdSchema,
  label: requiredTextSchema,
  coverage: requiredTextSchema,
  acceptance: requiredTextSchema,
  mapsTo: implementationCoverageSchema,
}).strict();

const implementationStageSchema = z.object({
  id: implementationIdSchema,
  label: requiredTextSchema,
  detail: requiredTextSchema,
  coverage: requiredTextSchema,
  exit: requiredTextSchema,
  primary: implementationCoverageSchema,
  supporting: implementationCoverageSchema,
  slices: z.array(implementationSliceSchema).min(1),
}).strict();

export const implementationPlanSchema = z.object({
  sequence: z.array(z.array(implementationIdSchema).min(1)).min(1),
  stages: z.array(implementationStageSchema).min(1),
  scenario: z.array(requiredTextSchema).min(1),
}).strict();

export type TaskCompletion = z.infer<typeof taskCompletionSchema>;

export type Task = {
  id: TaskId;
  title: string;
  outcome: string;
  details: string;
  decompositionComplete?: boolean;
  completionCriteria: string[];
  dependencies: TaskId[];
  externalBlocker: string | null;
  completion: TaskCompletion | null;
  discontinued: { reason: string } | null;
  tasks: Task[];
};

const taskSchema: z.ZodType<Task> = z.object({
  id: taskIdSchema,
  title: requiredTextSchema,
  outcome: requiredTextSchema,
  details: detailsSchema,
  decompositionComplete: z.boolean().optional(),
  completionCriteria: z.array(requiredTextSchema),
  dependencies: z.array(taskIdSchema),
  externalBlocker: requiredTextSchema.nullable(),
  completion: taskCompletionSchema.nullable(),
  discontinued: discontinuedTaskSchema.nullable(),
  tasks: z.lazy(() => z.array(taskSchema)).default([]),
}).strict();

const workstreamSchema = z.object({
  id: workstreamIdSchema,
  title: requiredTextSchema,
  outcome: requiredTextSchema,
  details: detailsSchema,
  tasks: z.array(taskSchema),
}).strict();

export const objectiveGraphSchema = z.object({
  id: objectiveIdSchema,
  title: requiredTextSchema,
  outcome: requiredTextSchema,
  details: detailsSchema,
  phase: z.enum(["planning", "implementation"]),
  implementation: implementationPlanSchema.optional(),
  workstreams: z.array(workstreamSchema),
}).strict();

export type ObjectiveId = z.infer<typeof objectiveIdSchema>;
export type WorkstreamId = z.infer<typeof workstreamIdSchema>;
export type TaskId = z.infer<typeof taskIdSchema>;
export type Workstream = z.infer<typeof workstreamSchema>;
export type ObjectiveGraph = z.infer<typeof objectiveGraphSchema>;
export type ImplementationPlan = z.infer<typeof implementationPlanSchema>;

export type ValidationProblem = Readonly<{
  path: string;
  message: string;
}>;

export type ObjectiveValidationResult =
  | Readonly<{ valid: true; graph: ObjectiveGraph }>
  | Readonly<{ valid: false; problems: readonly ValidationProblem[] }>;

export function validateObjective(input: unknown): ObjectiveValidationResult {
  const parsed = objectiveGraphSchema.safeParse(input);
  if (!parsed.success) {
    return {
      valid: false,
      problems: parsed.error.issues.map((issue) => ({
        path: formatPath(issue.path),
        message: issue.message,
      })),
    };
  }
  const problems = validateGraph(parsed.data);
  return problems.length === 0
    ? { valid: true, graph: parsed.data }
    : { valid: false, problems };
}

function validateGraph(graph: ObjectiveGraph): ValidationProblem[] {
  const problems: ValidationProblem[] = [];
  const identities = new Set<string>([graph.id]);
  const taskIds = new Set<string>();
  const taskWorkstreams = new Map<string, number>();
  const tasks: { task: Task; path: string; workstreamIndex: number }[] = [];
  for (const [workstreamIndex, workstream] of graph.workstreams.entries()) {
    registerIdentity(workstream.id, `$.workstreams[${workstreamIndex}].id`, identities, problems);
    visitTasks(workstream.tasks, `$.workstreams[${workstreamIndex}].tasks`, (task, path) => {
      registerIdentity(task.id, `${path}.id`, identities, problems);
      taskIds.add(task.id);
      taskWorkstreams.set(task.id, workstreamIndex);
      tasks.push({ task, path, workstreamIndex });
    });
  }
  validateImplementation(graph, identities, graphConceptIds(graph), problems);
  for (const { task, path: taskPath, workstreamIndex } of tasks) {
      if (task.tasks.length > 0 && task.decompositionComplete === true) {
        problems.push({
          path: `${taskPath}.decompositionComplete`,
          message: "Only a leaf Task stores decomposition completion; parent state is derived from its children.",
        });
      }
      const seenDependencies = new Set<string>();
      for (const [dependencyIndex, dependencyId] of task.dependencies.entries()) {
        const path = `${taskPath}.dependencies[${dependencyIndex}]`;
        if (dependencyId === task.id) {
          problems.push({ path, message: "A Task cannot depend on itself." });
        }
        if (!taskIds.has(dependencyId)) {
          problems.push({
            path,
            message: `Dependency endpoint does not exist in this Objective: ${dependencyId}.`,
          });
        } else if (taskWorkstreams.get(dependencyId) !== workstreamIndex) {
          problems.push({
            path,
            message: `Work Dependency cannot cross Workstreams: ${dependencyId}.`,
          });
        }
        if (seenDependencies.has(dependencyId)) {
          problems.push({ path, message: `Duplicate Work Dependency: ${dependencyId}.` });
        }
        seenDependencies.add(dependencyId);
      }
      validateCompletion(task, taskPath, problems);
  }
  const cycle = findDependencyCycle(graph);
  if (cycle !== null) {
    const first = findTask(graph, cycle[0]);
    problems.push({
      path: first === null
        ? "$.workstreams"
        : `${first.path}.dependencies`,
      message: `Work Dependencies contain a cycle: ${cycle.join(" -> ")}.`,
    });
  }
  return problems;
}

function validateImplementation(
  graph: ObjectiveGraph,
  identities: ReadonlySet<string>,
  concepts: ReadonlySet<string>,
  problems: ValidationProblem[],
): void {
  const implementation = graph.implementation;
  if (implementation === undefined) return;
  if (graph.phase !== "implementation") {
    problems.push({
      path: "$.implementation",
      message: "Implementation plan metadata requires the Objective to be in Implementation phase.",
    });
  }
  const stageIds = new Set<string>();
  const sliceIds = new Set<string>();
  for (const [stageIndex, stage] of implementation.stages.entries()) {
    const stagePath = `$.implementation.stages[${stageIndex}]`;
    if (stageIds.has(stage.id)) problems.push({ path: `${stagePath}.id`, message: `Duplicate implementation stage: ${stage.id}.` });
    stageIds.add(stage.id);
    validateImplementationCoverage(stage.primary, `${stagePath}.primary`, identities, concepts, false, problems);
    validateImplementationCoverage(stage.supporting, `${stagePath}.supporting`, identities, concepts, false, problems);
    for (const [sliceIndex, slice] of stage.slices.entries()) {
      const slicePath = `${stagePath}.slices[${sliceIndex}]`;
      if (sliceIds.has(slice.id)) problems.push({ path: `${slicePath}.id`, message: `Duplicate implementation slice: ${slice.id}.` });
      if (!slice.id.startsWith(`${stage.id}.`)) {
        problems.push({ path: `${slicePath}.id`, message: `Implementation slice ${slice.id} must belong to stage ${stage.id}.` });
      }
      sliceIds.add(slice.id);
      validateImplementationCoverage(slice.mapsTo, `${slicePath}.mapsTo`, identities, concepts, true, problems);
    }
  }
  const sequenced = implementation.sequence.flat();
  const sequenceIds = new Set<string>();
  for (const [index, stageId] of sequenced.entries()) {
    if (!stageIds.has(stageId)) {
      problems.push({ path: `$.implementation.sequence[${index}]`, message: `Implementation sequence names an unknown stage: ${stageId}.` });
    }
    if (sequenceIds.has(stageId)) {
      problems.push({ path: `$.implementation.sequence[${index}]`, message: `Implementation sequence repeats stage: ${stageId}.` });
    }
    sequenceIds.add(stageId);
  }
  for (const stageId of stageIds) {
    if (!sequenceIds.has(stageId)) problems.push({ path: "$.implementation.sequence", message: `Implementation sequence omits stage: ${stageId}.` });
  }
}

function validateImplementationCoverage(
  coverage: z.infer<typeof implementationCoverageSchema>,
  path: string,
  identities: ReadonlySet<string>,
  concepts: ReadonlySet<string>,
  required: boolean,
  problems: ValidationProblem[],
): void {
  let matched = false;
  for (const [index, id] of coverage.nodes.entries()) {
    if (!identities.has(id)) {
      problems.push({ path: `${path}.nodes[${index}]`, message: `Implementation coverage names an unknown graph identity: ${id}.` });
    } else {
      matched = true;
    }
  }
  for (const [index, concept] of coverage.concepts.entries()) {
    const exists = [...concepts].some((candidate) =>
      candidate === concept || candidate.startsWith(`${concept}.`)
    );
    if (!exists) {
      problems.push({ path: `${path}.concepts[${index}]`, message: `Implementation coverage names an unknown graph concept: ${concept}.` });
    } else {
      matched = true;
    }
  }
  if (required && !matched) {
    problems.push({ path, message: "Implementation slice coverage does not match a graph surface." });
  }
}

function graphConceptIds(graph: ObjectiveGraph): ReadonlySet<string> {
  const concepts = new Set<string>(["M"]);
  const collect = (details: string): void => {
    const concept = details.match(/^ID:\s*(M(?:\.\d+)*)\b/m)?.[1];
    if (concept !== undefined) concepts.add(concept);
  };
  collect(graph.details);
  for (const workstream of graph.workstreams) {
    collect(workstream.details);
    visitTasks(workstream.tasks, "", (task) => collect(task.details));
  }
  return concepts;
}

function validateCompletion(
  task: Task,
  taskPath: string,
  problems: ValidationProblem[],
): void {
  if (task.completion !== null) {
    const currentCriteria = new Set(task.completionCriteria);
    const evidenceCounts = new Map<string, number>();
    for (const [evidenceIndex, evidence] of task.completion.evidence.entries()) {
      evidenceCounts.set(evidence.criterion, (evidenceCounts.get(evidence.criterion) ?? 0) + 1);
      if (!currentCriteria.has(evidence.criterion)) {
        problems.push({
          path: `${taskPath}.completion.evidence[${evidenceIndex}].criterion`,
          message: `Completion evidence names a criterion that is not current: ${evidence.criterion}`,
        });
      }
    }
    for (const criterion of task.completionCriteria) {
      const count = evidenceCounts.get(criterion) ?? 0;
      if (count === 0) {
        problems.push({
          path: `${taskPath}.completion.evidence`,
          message: `Completion evidence is missing for criterion: ${criterion}`,
        });
      } else if (count > 1) {
        problems.push({
          path: `${taskPath}.completion.evidence`,
          message: `Completion evidence is duplicated for criterion: ${criterion}`,
        });
      }
    }
  }
  if (task.completion !== null && task.discontinued !== null) {
    problems.push({
      path: `${taskPath}.discontinued`,
      message: "A completed Task cannot also be discontinued.",
    });
  }
}

function findDependencyCycle(graph: ObjectiveGraph): string[] | null {
  const tasks = new Map<string, Task>();
  for (const workstream of graph.workstreams) {
    visitTasks(workstream.tasks, "", (task) => tasks.set(task.id, task));
  }
  const state = new Map<string, "visiting" | "visited">();
  const stack: string[] = [];

  function visit(taskId: string): string[] | null {
    const currentState = state.get(taskId);
    if (currentState === "visited") return null;
    if (currentState === "visiting") {
      const start = stack.indexOf(taskId);
      return [...stack.slice(start), taskId];
    }
    state.set(taskId, "visiting");
    stack.push(taskId);
    for (const dependencyId of tasks.get(taskId)?.dependencies ?? []) {
      if (dependencyId === taskId || !tasks.has(dependencyId)) continue;
      const cycle = visit(dependencyId);
      if (cycle !== null) return cycle;
    }
    stack.pop();
    state.set(taskId, "visited");
    return null;
  }

  for (const taskId of tasks.keys()) {
    const cycle = visit(taskId);
    if (cycle !== null) return cycle;
  }
  return null;
}

function findTask(graph: ObjectiveGraph, taskId: string): { path: string } | null {
  for (const [workstreamIndex, workstream] of graph.workstreams.entries()) {
    let found: { path: string } | null = null;
    visitTasks(workstream.tasks, `$.workstreams[${workstreamIndex}].tasks`, (task, path) => {
      if (found === null && task.id === taskId) found = { path };
    });
    if (found !== null) return found;
  }
  return null;
}

function visitTasks(tasks: readonly Task[], basePath: string, visit: (task: Task, path: string) => void): void {
  for (const [index, task] of tasks.entries()) {
    const path = `${basePath}[${index}]`;
    visit(task, path);
    visitTasks(task.tasks, `${path}.tasks`, visit);
  }
}

function registerIdentity(
  id: string,
  path: string,
  identities: Set<string>,
  problems: ValidationProblem[],
): void {
  if (identities.has(id)) {
    problems.push({ path, message: `Duplicate Stable Graph Identity: ${id}.` });
    return;
  }
  identities.add(id);
}

function formatPath(path: PropertyKey[]): string {
  return path.reduce<string>((result, part) =>
    typeof part === "number" ? `${result}[${part}]` : `${result}.${String(part)}`, "$"
  );
}
