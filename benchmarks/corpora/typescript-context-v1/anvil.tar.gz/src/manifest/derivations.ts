import type { ImplementationPlan, ObjectiveGraph, Task, TaskId, WorkstreamId } from "./model.ts";
import { taskLocations, tasksInWorkstream, type TaskLocation } from "./tree.ts";

export type DerivedTask = Readonly<{
  id: TaskId;
  title: string;
  workstreamId: WorkstreamId;
  position: Readonly<{ workstreamIndex: number; siblingIndex: number }>;
  complete: boolean;
  discontinued: boolean;
  current: boolean;
  available: boolean;
  phase: ObjectiveGraph["phase"];
  prerequisites: readonly Readonly<{ taskId: TaskId; complete: boolean }>[];
  externalBlocker: string | null;
  reasons: readonly string[];
}>;

export type WorkstreamProgress = Readonly<{
  id: WorkstreamId;
  total: number;
  required: number;
  completed: number;
  discontinued: number;
  complete: boolean;
}>;

export type ObjectiveView = Readonly<{
  objectiveId: ObjectiveGraph["id"];
  phase: ObjectiveGraph["phase"];
  tasks: readonly DerivedTask[];
  current: DerivedTask | null;
  available: readonly DerivedTask[];
  next: Readonly<{ task: DerivedTask; reason: string; candidateCount: number }> | null;
  choices: readonly DerivedTask[];
  blockers: readonly Readonly<{ taskId: TaskId; reason: string }>[];
  progress: Readonly<{ complete: boolean; workstreams: readonly WorkstreamProgress[] }>;
}>;

export type ImplementationSliceStatus = "complete" | "partial" | "active" | "upcoming" | "discontinued";
export type ImplementationStageStatus = "complete" | "partial" | "current" | "upcoming";
export type DerivedImplementationPlan = Readonly<{
  currentStage: string | null;
  currentSlice: string | null;
  sequence: ImplementationPlan["sequence"];
  stages: readonly (Omit<ImplementationPlan["stages"][number], "slices"> & Readonly<{
      status: ImplementationStageStatus;
      mappedNodeIds: readonly string[];
      visibleDependencyEdgeIds: readonly string[];
      slices: readonly (ImplementationPlan["stages"][number]["slices"][number] & Readonly<{
        status: ImplementationSliceStatus;
        mappedNodeIds: readonly string[];
        visibleDependencyEdgeIds: readonly string[];
      }>)[];
  }>)[];
  scenario: ImplementationPlan["scenario"];
}>;

export function deriveObjective(
  graph: ObjectiveGraph,
  session: Readonly<{ currentTaskId?: TaskId }> = {},
): ObjectiveView {
  const locations = taskLocations(graph);
  const taskById = new Map(locations.map(({ task }) => [task.id, task]));
  const derivedById = new Map<TaskId, DerivedTask>();

  for (const location of locations) {
    const { task } = location;
    const complete = taskComplete(task);
    const discontinued = task.discontinued !== null || location.ancestors.some((ancestor) => ancestor.discontinued !== null);
    const current = task.id === session.currentTaskId;
    const prerequisites = task.dependencies.map((taskId) => Object.freeze({
      taskId,
      complete: taskComplete(taskById.get(taskId)!),
    }));
    const reasons: string[] = [];
    if (graph.phase !== "implementation") reasons.push("Objective is in Planning.");
    if (task.tasks.length > 0) reasons.push("Task is decomposed; execution occurs in its leaf Tasks.");
    if (complete) reasons.push("Task is complete.");
    if (discontinued) reasons.push("Task is discontinued.");
    const incomplete = prerequisites.filter((item) => !item.complete);
    if (incomplete.length > 0) reasons.push(`Incomplete prerequisites: ${incomplete.map((item) => item.taskId).join(", ")}.`);
    if (task.externalBlocker !== null) reasons.push(`External Blocker: ${task.externalBlocker}`);
    if (current) reasons.push("Task is Current and excluded from Available choices.");
    const derived = Object.freeze({
      id: task.id,
      title: task.title,
      workstreamId: location.workstream.id,
      position: Object.freeze({ workstreamIndex: location.workstreamIndex, siblingIndex: location.siblingIndex }),
      complete,
      discontinued,
      current,
      available: reasons.length === 0,
      phase: graph.phase,
      prerequisites: Object.freeze(prerequisites),
      externalBlocker: task.externalBlocker,
      reasons: Object.freeze(reasons),
    });
    derivedById.set(task.id, derived);
  }

  const tasks = locations.map(({ task }) => derivedById.get(task.id)!);
  const current = tasks.find((task) => task.current) ?? null;
  const available = tasks.filter((task) => task.available);
  const next = deriveNext(graph, derivedById, available, current);
  const workstreams = graph.workstreams.map((workstream): WorkstreamProgress => {
    const leaves = tasksInWorkstream(graph, workstream.id).filter(({ task }) => task.tasks.length === 0);
    const isDiscontinued = (location: (typeof leaves)[number]) =>
      location.task.discontinued !== null || location.ancestors.some((ancestor) => ancestor.discontinued !== null);
    const completed = leaves.filter((location) => !isDiscontinued(location) && taskComplete(location.task)).length;
    const discontinued = leaves.filter(isDiscontinued).length;
    return Object.freeze({
      id: workstream.id,
      total: leaves.length,
      required: leaves.length - discontinued,
      completed,
      discontinued,
      complete: leaves.length > 0 && completed + discontinued === leaves.length,
    });
  });
  const blockers = locations
    .filter(({ task, ancestors }) => task.tasks.length === 0 && !taskComplete(task) && task.discontinued === null
      && !ancestors.some((ancestor) => ancestor.discontinued !== null) && task.externalBlocker !== null)
    .map(({ task }) => Object.freeze({ taskId: task.id, reason: task.externalBlocker! }));

  return Object.freeze({
    objectiveId: graph.id,
    phase: graph.phase,
    tasks: Object.freeze(tasks),
    current,
    available: Object.freeze(available),
    next,
    choices: Object.freeze(next === null ? available : []),
    blockers: Object.freeze(blockers),
    progress: Object.freeze({
      complete: workstreams.length > 0 && workstreams.every((workstream) => workstream.complete),
      workstreams: Object.freeze(workstreams),
    }),
  });
}

export function deriveImplementationPlan(
  graph: ObjectiveGraph,
  view: ObjectiveView,
): DerivedImplementationPlan | null {
  const locations = taskLocations(graph);
  const plan = graph.implementation ?? graphImplementationPanel(graph, locations);
  const derivedById = new Map(view.tasks.map((task) => [task.id, task]));
  const targets = implementationTargets(graph, locations);
  const currentLocation = view.current === null
    ? null
    : locations.find(({ task }) => task.id === view.current!.id) ?? null;

  const slices = plan.stages.flatMap((stage) => stage.slices.map((slice) => ({ stage, slice })));
  const active = currentLocation === null
    ? null
    : slices
      .map((candidate, index) => ({
        ...candidate,
        index,
        score: implementationCoverageScore(candidate.slice.mapsTo, currentLocation),
      }))
      .filter((candidate) => candidate.score >= 0)
      .sort((left, right) => right.score - left.score || left.index - right.index)[0] ?? null;

  const stages = plan.stages.map((stage) => {
    const derivedSlices = stage.slices.map((slice) => {
      const visualTargets = implementationVisualTargets(slice.mapsTo, targets);
      const mappedNodeIds = Object.freeze(unique(visualTargets.flatMap((target) =>
        targetNodeIds(target, graph, locations)
      )));
      const visibleDependencyEdgeIds = dependencyEdgesWithin(mappedNodeIds, locations);
      const presentation = { mappedNodeIds, visibleDependencyEdgeIds };
      if (graph.implementation === undefined && derivedById.get(slice.id as TaskId)?.discontinued) {
        return Object.freeze({ ...slice, ...presentation, status: "discontinued" as const });
      }
      if (slice.id === active?.slice.id) {
        return Object.freeze({ ...slice, ...presentation, status: "active" as const });
      }
      if (stage.id === "G") {
        return Object.freeze({
          ...slice,
          ...presentation,
          status: graph.phase === "implementation" ? "complete" as const : "upcoming" as const,
        });
      }
      const mapped = implementationCoverageTargets(slice.mapsTo, targets);
      const progress = mapped.flatMap((target) => targetLeafProgress(target, locations, derivedById));
      const satisfied = progress.filter((item) => item).length;
      const status: ImplementationSliceStatus = progress.length > 0 && satisfied === progress.length
        ? "complete"
        : satisfied > 0
          ? "partial"
          : "upcoming";
      return Object.freeze({ ...slice, ...presentation, status });
    });
    const status: ImplementationStageStatus = derivedSlices.some((slice) => slice.status === "active")
      ? "current"
      : derivedSlices.length > 0 && derivedSlices.every((slice) => slice.status === "complete" || slice.status === "discontinued")
        ? "complete"
        : derivedSlices.some((slice) => slice.status === "complete" || slice.status === "partial")
          ? "partial"
          : "upcoming";
    const mappedNodeIds = Object.freeze(graph.implementation === undefined
      ? targetNodeIds(targets.find((target) => target.id === stage.id)!, graph, locations)
      : unique(derivedSlices.flatMap((slice) => slice.mappedNodeIds)));
    return Object.freeze({
      ...stage,
      status,
      mappedNodeIds,
      visibleDependencyEdgeIds: dependencyEdgesWithin(mappedNodeIds, locations),
      slices: Object.freeze(derivedSlices),
    });
  });

  return Object.freeze({
    currentStage: active?.stage.id ?? null,
    currentSlice: active?.slice.id ?? null,
    sequence: plan.sequence,
    stages: Object.freeze(stages),
    scenario: plan.scenario,
  });
}

// View-only defaults reuse canonical identities. Nothing is added to the graph
// or serialized as a second plan, and the existing derivation owns all status.
function graphImplementationPanel(graph: ObjectiveGraph, locations: readonly TaskLocation[]): ImplementationPlan {
  return {
    // Workstreams are independent; their order is not a dependency chain.
    sequence: graph.workstreams.length > 0 ? [graph.workstreams.map((workstream) => workstream.id)] : [],
    stages: graph.workstreams.map((workstream) => {
      const work = locations.filter((location) => location.workstream.id === workstream.id);
      return {
        id: workstream.id,
        label: workstream.title,
        detail: workstream.details || workstream.outcome,
        coverage: workstream.outcome,
        exit: workstream.outcome,
        primary: { concepts: [], nodes: [workstream.id, ...work.map(({ task }) => task.id)] },
        supporting: { concepts: [], nodes: [] },
        slices: work.map(({ task, ancestors }) => ({
          id: task.id,
          label: task.title,
          coverage: [...ancestors.map((ancestor) => ancestor.title), task.outcome].join(" → "),
          acceptance: task.completionCriteria.join("\n") || "No completion criteria recorded.",
          mapsTo: { concepts: [], nodes: [task.id] },
        })),
      };
    }),
    scenario: [],
  };
}

function dependencyEdgesWithin(
  mappedNodeIds: readonly string[],
  locations: readonly TaskLocation[],
): readonly string[] {
  const mappedNodeIdSet = new Set(mappedNodeIds);
  return Object.freeze(locations.flatMap(({ task }) =>
    mappedNodeIdSet.has(task.id)
      ? task.dependencies
        .filter((prerequisiteId) => mappedNodeIdSet.has(prerequisiteId))
        .map((prerequisiteId) => `dependency:${prerequisiteId}:${task.id}`)
      : []
  ));
}

type ImplementationTarget = Readonly<{
  id: string;
  concept: string | null;
  kind: "objective" | "workstream" | "task";
}>;

function implementationTargets(graph: ObjectiveGraph, locations: readonly TaskLocation[]): ImplementationTarget[] {
  return [
    { id: graph.id, concept: graphConcept(graph.details) ?? "M", kind: "objective" },
    ...graph.workstreams.map((workstream) => ({
      id: workstream.id,
      concept: graphConcept(workstream.details),
      kind: "workstream" as const,
    })),
    ...locations.map(({ task }) => ({ id: task.id, concept: graphConcept(task.details), kind: "task" as const })),
  ];
}

function implementationCoverageTargets(
  coverage: ImplementationPlan["stages"][number]["slices"][number]["mapsTo"],
  targets: readonly ImplementationTarget[],
): ImplementationTarget[] {
  if (coverage.nodes.length > 0) {
    const ids = new Set<string>(coverage.nodes);
    return targets.filter((target) => ids.has(target.id));
  }
  const concepts = new Set<string>(coverage.concepts);
  return targets.filter((target) => target.concept !== null && concepts.has(target.concept));
}

function implementationVisualTargets(
  coverage: ImplementationPlan["stages"][number]["slices"][number]["mapsTo"],
  targets: readonly ImplementationTarget[],
): ImplementationTarget[] {
  const ids = new Set<string>(coverage.nodes);
  const concepts = new Set<string>(coverage.concepts);
  return targets.filter((target) =>
    ids.has(target.id) || (target.concept !== null && concepts.has(target.concept))
  );
}

function targetNodeIds(
  target: ImplementationTarget,
  graph: ObjectiveGraph,
  locations: readonly TaskLocation[],
): string[] {
  if (target.kind === "objective") {
    return [graph.id, ...graph.workstreams.map((workstream) => workstream.id), ...locations.map(({ task }) => task.id)];
  }
  if (target.kind === "workstream") {
    return [target.id, ...locations
      .filter((location) => location.workstream.id === target.id)
      .map(({ task }) => task.id)];
  }
  return [target.id, ...locations
    .filter((location) => location.ancestors.some((ancestor) => ancestor.id === target.id))
    .map(({ task }) => task.id)];
}

function unique(values: readonly string[]): string[] {
  return [...new Set(values)];
}

function targetLeafProgress(
  target: ImplementationTarget,
  locations: readonly TaskLocation[],
  derivedById: ReadonlyMap<TaskId, DerivedTask>,
): boolean[] {
  const leaves = locations.filter((location) => {
    if (location.task.tasks.length > 0) return false;
    if (target.kind === "objective") return true;
    if (target.kind === "workstream") return location.workstream.id === target.id;
    return location.task.id === target.id || location.ancestors.some((ancestor) => ancestor.id === target.id);
  });
  return leaves.map(({ task }) => {
    const derived = derivedById.get(task.id)!;
    return derived.complete || derived.discontinued;
  });
}

function implementationCoverageScore(
  coverage: ImplementationPlan["stages"][number]["slices"][number]["mapsTo"],
  current: TaskLocation,
): number {
  if (coverage.nodes.includes(current.task.id)) return 10_000;
  const identities = new Set<string>([
    current.workstream.id,
    ...current.ancestors.map((ancestor) => ancestor.id),
    current.task.id,
  ]);
  if (coverage.nodes.some((id) => identities.has(id))) return 9_000;
  const currentConcept = graphConcept(current.task.details);
  if (currentConcept === null) return -1;
  return coverage.concepts.reduce((best, concept) =>
    currentConcept === concept || currentConcept.startsWith(`${concept}.`)
      ? Math.max(best, concept.length)
      : best, -1);
}

function graphConcept(details: string): string | null {
  return details.match(/^ID:\s*(M(?:\.\d+)*)\b/m)?.[1] ?? null;
}

function deriveNext(
  graph: ObjectiveGraph,
  byId: ReadonlyMap<TaskId, DerivedTask>,
  available: readonly DerivedTask[],
  current: DerivedTask | null,
): ObjectiveView["next"] {
  if (current?.complete) {
    const locations = taskLocations(graph);
    const dependents = available.filter((candidate) => {
      const source = locations.find(({ task }) => task.id === candidate.id)?.task;
      return source?.dependencies.includes(current.id) ?? false;
    });
    if (dependents.length === 1) {
      return Object.freeze({ task: dependents[0]!, reason: "The only Available direct dependent of Current.", candidateCount: 1 });
    }
  }
  if (current !== null) {
    const location = taskLocations(graph).find(({ task }) => task.id === current.id);
    const nextSibling = location?.siblings.slice(location.siblingIndex + 1)
      .map((task) => byId.get(task.id))
      .find((task) => task?.available);
    if (nextSibling !== undefined) {
      return Object.freeze({ task: nextSibling, reason: "The next Available sibling after Current.", candidateCount: 1 });
    }
  }
  if (available.length === 1) {
    return Object.freeze({ task: available[0]!, reason: "The only globally Available Task.", candidateCount: 1 });
  }
  return null;
}

function taskComplete(task: Task): boolean {
  if (task.completion !== null) return true;
  if (task.discontinued !== null || task.tasks.length === 0) return false;
  return task.tasks.every((child) => child.discontinued !== null || taskComplete(child));
}
