/**
 * The all-objectives entry page deliberately owns no Manifest state. It renders
 * the current response from the discovery endpoint and leaves every objective
 * graph in its repository-owned file.
 */
export function renderManifestLanding(): string {
  return `<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Objectives · Manifest</title>
  <style>
    :root {
      color-scheme: dark;
      --bg: #0e1116;
      --surface: #151a21;
      --surface2: #1b222c;
      --border: #2b3542;
      --text: #b6c0cc;
      --text-strong: #e6ebf1;
      --text-dim: #6b7683;
      --blue: #7aa2f7;
      --teal: #34e2c9;
      --red: #ff5c57;
      --sans: Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
      --mono: "SFMono-Regular", Consolas, "Liberation Mono", monospace;
    }
    * { box-sizing: border-box; }
    body { margin: 0; min-width: 0; background: var(--bg); color: var(--text); font-family: var(--sans); }
    a { color: inherit; }
    .topbar { min-height: 56px; display: flex; align-items: center; gap: 12px; padding: 0 24px; border-bottom: 1px solid var(--border); background: var(--surface); }
    .brand { color: var(--blue); font: 600 15px var(--mono); text-decoration: none; }
    .crumb { color: var(--text-dim); font-size: 13px; }
    main { width: min(1120px, calc(100% - 40px)); margin: 0 auto; padding: 42px 0 56px; }
    .eyebrow { margin: 0 0 8px; color: var(--teal); font: 600 10px var(--mono); letter-spacing: .15em; text-transform: uppercase; }
    h1 { margin: 0; color: var(--text-strong); font: 600 clamp(26px, 4vw, 38px)/1.15 var(--mono); letter-spacing: -.035em; }
    .intro { max-width: 650px; margin: 12px 0 0; color: var(--text-dim); font-size: 15px; line-height: 1.55; }
    .controls { display: flex; gap: 10px; align-items: center; margin: 30px 0 12px; }
    .filter { flex: 1 1 300px; min-width: 0; height: 38px; padding: 0 12px; border: 1px solid var(--border); border-radius: 7px; background: var(--surface); color: var(--text-strong); font: 13px var(--sans); }
    .filter::placeholder { color: var(--text-dim); }
    button { height: 38px; padding: 0 13px; border: 1px solid var(--border); border-radius: 7px; background: transparent; color: var(--text); font: 13px var(--sans); cursor: pointer; }
    button:hover { border-color: var(--teal); color: var(--text-strong); background: var(--surface2); }
    .filter:focus-visible, button:focus-visible, a:focus-visible { outline: 2px solid var(--blue); outline-offset: 3px; }
    .status { min-height: 21px; margin: 0 0 22px; color: var(--text-dim); font-size: 12px; }
    .status[data-stale="true"] { color: var(--teal); }
    .errors { display: grid; gap: 10px; margin-bottom: 18px; }
    .error { border-left: 3px solid var(--red); padding: 11px 13px; background: color-mix(in srgb, var(--red) 8%, var(--surface)); color: var(--text); font-size: 13px; line-height: 1.5; }
    .error strong { color: var(--red); }
    .error code, .repository-path, .objective-path { font-family: var(--mono); overflow-wrap: anywhere; }
    .objective-section { margin-top: 26px; }
    .section-heading { margin: 0 0 12px; color: var(--text-strong); font: 600 14px var(--mono); }
    .repositories { display: grid; gap: 18px; }
    .completed-objectives { margin-top: 28px; border: 1px solid var(--border); border-radius: 9px; background: var(--surface); }
    .completed-summary { display: flex; align-items: center; justify-content: space-between; gap: 12px; padding: 12px 15px; color: var(--text); cursor: pointer; font: 600 13px var(--mono); }
    .completed-summary:hover { color: var(--text-strong); background: var(--surface2); }
    .completed-summary:focus-visible { outline: 2px solid var(--blue); outline-offset: -3px; }
    .completed-count { color: var(--text-dim); font-size: 11px; }
    .completed-repositories { padding: 0 12px 12px; gap: 12px; }
    .completed-repositories .repository { border-radius: 8px; }
    .completed-repositories .repository-head { padding: 11px 14px; }
    .completed-repositories .objective-link, .completed-repositories .invalid { padding: 13px 14px; }
    .repository { border: 1px solid var(--border); border-radius: 11px; overflow: hidden; background: var(--surface); }
    .repository-head { padding: 15px 18px; border-bottom: 1px solid var(--border); background: var(--surface2); }
    .repository-label { margin: 0 0 4px; color: var(--teal); font: 600 10px var(--mono); letter-spacing: .14em; text-transform: uppercase; }
    .repository-path { margin: 0; color: var(--text); font-size: 12px; line-height: 1.45; }
    .objective-list { margin: 0; padding: 0; list-style: none; }
    .objective { border-top: 1px solid color-mix(in srgb, var(--border) 72%, transparent); }
    .objective:first-child { border-top: 0; }
    .objective-link { display: block; padding: 17px 18px; text-decoration: none; }
    .objective-link:hover { background: color-mix(in srgb, var(--blue) 7%, transparent); }
    .objective-topline { display: flex; align-items: baseline; justify-content: space-between; gap: 12px; }
    .objective-title { color: var(--text-strong); font: 600 15px/1.35 var(--mono); overflow-wrap: anywhere; }
    .phase { flex: 0 0 auto; color: var(--blue); font: 600 10px var(--mono); letter-spacing: .11em; text-transform: uppercase; }
    .outcome { margin: 7px 0 0; color: var(--text); font-size: 13px; line-height: 1.5; }
    .objective-path { display: block; margin-top: 9px; color: var(--text-dim); font-size: 11px; line-height: 1.4; }
    .invalid { padding: 16px 18px; }
    .invalid-title { margin: 0; color: var(--red); font: 600 12px var(--mono); }
    .invalid-path { margin: 7px 0 0; color: var(--text); font: 12px/1.45 var(--mono); overflow-wrap: anywhere; }
    .problems { margin: 10px 0 0; padding-left: 19px; color: var(--text-dim); font-size: 12px; line-height: 1.5; }
    .empty { padding: 32px 18px; border: 1px dashed var(--border); border-radius: 11px; color: var(--text-dim); line-height: 1.5; text-align: center; }
    [hidden] { display: none !important; }
    @media (max-width: 620px) {
      .topbar { padding: 0 18px; }
      main { width: min(100% - 28px, 1120px); padding-top: 30px; }
      .controls { align-items: stretch; flex-direction: column; }
      .filter, button { width: 100%; flex: 0 0 38px; }
      .objective-topline { align-items: flex-start; flex-direction: column; gap: 6px; }
      .repository-head, .objective-link, .invalid { padding-left: 14px; padding-right: 14px; }
      .completed-repositories { padding-left: 8px; padding-right: 8px; }
    }
  </style>
</head>
<body>
  <nav class="topbar" aria-label="Manifest navigation"><a class="brand" href="/objectives">Manifest</a><span class="crumb" aria-current="page">Objectives</span></nav>
  <main data-testid="manifest-objectives-landing">
    <p class="eyebrow">Manifest</p>
    <h1>Objectives</h1>
    <p class="intro">Find the accepted work in the repositories discovered from this Manifest entrypoint.</p>
    <div class="controls">
      <input class="filter" id="objective-filter" type="search" autocomplete="off" placeholder="Filter by title, repository, or phase" aria-label="Filter objectives">
      <button id="refresh" type="button">Refresh</button>
    </div>
    <p class="status" data-testid="discovery-status" role="status" aria-live="polite">Loading objectives…</p>
    <div class="errors" aria-live="polite"></div>
    <section class="objective-section" aria-labelledby="in-progress-heading">
      <h2 class="section-heading" id="in-progress-heading">In progress</h2>
      <div class="repositories in-progress-repositories" aria-live="polite"></div>
    </section>
    <details class="completed-objectives" data-testid="completed-objectives" hidden>
      <summary class="completed-summary"><span>Completed</span><span class="completed-count"></span></summary>
      <div class="repositories completed-repositories" aria-live="polite"></div>
    </details>
    <p class="empty" data-testid="discovery-empty" hidden></p>
  </main>
  <script>
    "use strict";
    (function () {
      var POLL_MS = 5000;
      var state = { data: null, request: null, timer: null, stale: false, filter: "", lastUpdated: null };
      var status = document.querySelector("[data-testid=discovery-status]");
      var errors = document.querySelector(".errors");
      var inProgress = document.querySelector(".in-progress-repositories");
      var completed = document.querySelector("[data-testid=completed-objectives]");
      var completedRepositories = document.querySelector(".completed-repositories");
      var completedCount = document.querySelector(".completed-count");
      var empty = document.querySelector("[data-testid=discovery-empty]");
      var filterInput = document.getElementById("objective-filter");
      var refreshButton = document.getElementById("refresh");

      function text(value) { return typeof value === "string" ? value : ""; }
      function array(value) { return Array.isArray(value) ? value : []; }
      function discoveryProblem(value) { return value && typeof value === "object" ? value : {}; }
      function objectiveEntry(value) { return value && typeof value === "object" ? value : {}; }
      function setText(node, value) { if (node.textContent !== value) node.textContent = value; }
      function setStatus(value, stale) { setText(status, value); status.dataset.stale = stale ? "true" : "false"; }
      function make(tag, className) { var node = document.createElement(tag); if (className) node.className = className; return node; }
      function setChildren(parent, nodes) { parent.replaceChildren.apply(parent, nodes); }
      function sameArray(left, right) { return left.length === right.length && left.every(function (value, index) { return value === right[index]; }); }
      function displayPhase(phase) { return phase ? phase.slice(0, 1).toUpperCase() + phase.slice(1) : "Unknown"; }
      function isComplete(entry) { return entry.valid === true && objectiveEntry(entry.objective).complete === true; }
      function displayStatus(entry) { return isComplete(entry) ? "Complete" : displayPhase(text(objectiveEntry(entry.objective).phase)); }
      function matches(repository, entry) {
        var query = state.filter.trim().toLowerCase();
        if (!query) return true;
        var objective = entry.objective || {};
        return [repository, entry.path, objective.title, objective.phase, objective.outcome].some(function (value) { return text(value).toLowerCase().includes(query); });
      }
      function errorKey(problem) { return text(problem.path) + "\\n" + text(problem.message); }
      function renderErrors(problems, requestError) {
        var wanted = [];
        if (requestError) wanted.push({ path: "Discovery", message: requestError });
        array(problems).forEach(function (problem) { wanted.push(discoveryProblem(problem)); });
        var existing = new Map(Array.from(errors.children).map(function (node) { return [node.dataset.errorKey, node]; }));
        var nodes = wanted.map(function (problem) {
          var key = errorKey(problem);
          var node = existing.get(key);
          if (!node) {
            node = make("div", "error");
            node.dataset.testid = "discovery-error";
            node.dataset.errorKey = key;
            var title = make("strong");
            var detail = document.createTextNode("");
            node.append(title, document.createTextNode(" "), detail);
            node._title = title;
            node._detail = detail;
          }
          setText(node._title, text(problem.path) || "Discovery");
          node._detail.data = text(problem.message) || "Could not read discovery results.";
          return node;
        });
        var current = Array.from(errors.children);
        if (!sameArray(current, nodes)) setChildren(errors, nodes);
      }
      function objectiveKey(entry) { return (entry.valid ? "valid:" : "invalid:") + text(entry.path); }
      function renderValidObjective(node, repository, entry) {
        var objective = objectiveEntry(entry.objective);
        var href = "/objectives/" + encodeURIComponent(text(objective.id)) + "?repository=" + encodeURIComponent(repository);
        if (objective.phase === "implementation" && objective.complete !== true) href += "&stream=current&manifest-surface=implementation";
        node.dataset.objectiveId = text(objective.id);
        if (node.href !== new URL(href, location.origin).href) node.href = href;
        setText(node._title, text(objective.title) || "Untitled Objective");
        setText(node._phase, displayStatus(entry));
        setText(node._outcome, text(objective.outcome));
        node._outcome.hidden = !text(objective.outcome);
        setText(node._path, text(entry.path));
      }
      function renderInvalidObjective(node, entry) {
        setText(node._path, text(entry.path));
        var wanted = array(entry.problems).map(discoveryProblem);
        var existing = new Map(Array.from(node._problems.children).map(function (item) { return [item.dataset.problemKey, item]; }));
        var nodes = wanted.map(function (problem) {
          var key = errorKey(problem);
          var item = existing.get(key);
          if (!item) { item = document.createElement("li"); item.dataset.problemKey = key; }
          setText(item, (text(problem.path) ? text(problem.path) + ": " : "") + text(problem.message));
          return item;
        });
        if (!sameArray(Array.from(node._problems.children), nodes)) setChildren(node._problems, nodes);
      }
      function createObjective(repository, entry) {
        if (entry.valid) {
          var link = make("a", "objective-link");
          var top = make("div", "objective-topline");
          var title = make("span", "objective-title");
          var phase = make("span", "phase");
          var outcome = make("p", "outcome");
          var path = make("code", "objective-path");
          top.append(title, phase); link.append(top, outcome, path);
          link._title = title; link._phase = phase; link._outcome = outcome; link._path = path;
          renderValidObjective(link, repository, entry);
          return link;
        }
        var invalid = make("div", "invalid");
        invalid.dataset.testid = "discovery-error";
        var heading = make("p", "invalid-title"); heading.textContent = "Invalid Objective file";
        var invalidPath = make("p", "invalid-path");
        var problems = make("ul", "problems");
        invalid.append(heading, invalidPath, problems);
        invalid._path = invalidPath; invalid._problems = problems;
        renderInvalidObjective(invalid, entry);
        return invalid;
      }
      function renderRepository(parent, repository, entries) {
        var sections = new Map(Array.from(parent.children).map(function (node) { return [node.dataset.repository, node]; }));
        var section = sections.get(repository);
        if (!section) {
          section = make("section", "repository"); section.dataset.repository = repository;
          var head = make("header", "repository-head");
          var label = make("p", "repository-label"); label.textContent = "Repository";
          var path = make("code", "repository-path"); head.append(label, path);
          var list = make("ul", "objective-list"); section.append(head, list); section._path = path; section._list = list;
        }
        setText(section._path, repository);
        var oldEntries = new Map(Array.from(section._list.children).map(function (item) { return [item.dataset.entryKey, item]; }));
        var visible = entries.filter(function (entry) { return matches(repository, entry); });
        var nodes = visible.map(function (entry) {
          var key = objectiveKey(entry);
          var item = oldEntries.get(key);
          if (!item) { item = document.createElement("li"); item.dataset.entryKey = key; item.append(createObjective(repository, entry)); }
          else if (entry.valid) renderValidObjective(item.firstElementChild, repository, entry);
          else renderInvalidObjective(item.firstElementChild, entry);
          return item;
        });
        if (!sameArray(Array.from(section._list.children), nodes)) setChildren(section._list, nodes);
        section.hidden = nodes.length === 0;
        return section;
      }
      function render() {
        var data = state.data;
        if (!data) { inProgress.replaceChildren(); completedRepositories.replaceChildren(); completed.hidden = true; empty.hidden = true; return; }
        var wanted = array(data.repositories).map(function (entry) { return entry && typeof entry === "object" ? entry : {}; })
          .filter(function (entry) { return text(entry.repository); })
          .sort(function (left, right) { return text(left.repository).localeCompare(text(right.repository)); });
        var inProgressNodes = wanted.map(function (repository) {
          return renderRepository(inProgress, text(repository.repository), array(repository.objectives).filter(function (entry) { return !isComplete(entry); }));
        })
          .filter(function (section) { return !section.hidden; });
        if (!sameArray(Array.from(inProgress.children), inProgressNodes)) setChildren(inProgress, inProgressNodes);
        var completedNodes = wanted.map(function (repository) {
          return renderRepository(completedRepositories, text(repository.repository), array(repository.objectives).filter(isComplete));
        }).filter(function (section) { return !section.hidden; });
        if (!sameArray(Array.from(completedRepositories.children), completedNodes)) setChildren(completedRepositories, completedNodes);
        var completedObjectives = completedNodes.reduce(function (total, section) { return total + section.querySelectorAll("[data-objective-id]").length; }, 0);
        completed.hidden = completedObjectives === 0;
        setText(completedCount, completedObjectives === 1 ? "1 Objective" : completedObjectives + " Objectives");
        if (state.filter.trim() && completedObjectives) completed.open = true;
        var hasObjectives = inProgressNodes.some(function (section) { return section.querySelector("[data-objective-id], .invalid"); }) || completedObjectives > 0;
        empty.hidden = Boolean(hasObjectives);
        if (!hasObjectives) setText(empty, state.filter.trim() ? "No Objectives match this filter." : "No Objectives were found in the discovered repositories.");
      }
      function schedule() {
        if (state.timer !== null) { clearTimeout(state.timer); state.timer = null; }
        if (!document.hidden) state.timer = window.setTimeout(function () { state.timer = null; refresh(); }, POLL_MS);
      }
      async function refresh() {
        if (state.request || document.hidden) return;
        var initial = state.data === null;
        if (initial) setStatus("Loading objectives…", false);
        refreshButton.disabled = true;
        var request = fetch("/api/discovery", { headers: { "Accept": "application/json" } });
        state.request = request;
        try {
          var response = await request;
          if (!response.ok) throw new Error("Discovery returned " + response.status + ".");
          var body = await response.json();
          if (!body || typeof body !== "object" || !Array.isArray(body.repositories)) throw new Error("Discovery returned an invalid response.");
          state.data = body; state.stale = false; state.lastUpdated = new Date();
          renderErrors(body.problems, ""); render();
          var count = array(body.repositories).reduce(function (total, repository) { return total + array(repository && repository.objectives).length; }, 0);
          setStatus(count === 1 ? "1 Objective discovered." : count + " Objectives discovered.", false);
        } catch (error) {
          var message = error instanceof Error ? error.message : String(error);
          state.stale = state.data !== null;
          renderErrors(state.data ? array(state.data.problems) : [], message);
          if (state.data) setStatus("Showing the previous discovery results. Refresh failed.", true);
          else { setStatus("Could not load objectives.", false); render(); }
        } finally {
          if (state.request === request) state.request = null;
          refreshButton.disabled = false;
          schedule();
        }
      }
      filterInput.addEventListener("input", function () {
        var wasFiltering = Boolean(state.filter.trim());
        state.filter = filterInput.value;
        if (!wasFiltering && state.filter.trim()) state.completedOpenBeforeFilter = completed.open;
        if (wasFiltering && !state.filter.trim() && state.completedOpenBeforeFilter !== undefined) {
          completed.open = state.completedOpenBeforeFilter;
          delete state.completedOpenBeforeFilter;
        }
        render();
      });
      refreshButton.addEventListener("click", function () { refresh(); });
      document.addEventListener("visibilitychange", function () {
        if (document.hidden) { if (state.timer !== null) { clearTimeout(state.timer); state.timer = null; } return; }
        refresh();
      });
      refresh();
    }());
  </script>
</body>
</html>`;
}
