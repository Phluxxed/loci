import { execFile } from "node:child_process";
import { promisify } from "node:util";

import { validateObjective } from "./model.ts";
import type { ObjectiveGraph, Task } from "./model.ts";

type TaskCreation = "planning" | "implementation" | "unknown";
type ObjectivePhase = ObjectiveGraph["phase"];

type HistorySnapshot = Readonly<{
  phase: ObjectivePhase;
  taskIds: ReadonlySet<string>;
}>;

type HistoryAnalysis = Readonly<{
  byTaskId: ReadonlyMap<string, TaskCreation>;
  hasUsableSnapshot: boolean;
  reliable: boolean;
  latestSnapshot: HistorySnapshot | null;
}>;

type GitExecResult = Readonly<{
  stdout: string;
  stderr: string;
}>;

const execFileAsync = promisify(execFile);
const MAX_GIT_OUTPUT_BYTES = 16 * 1024 * 1024;
const MAX_HISTORY_CACHE_ENTRIES = 8;
const historyCache = new Map<string, HistoryAnalysis>();

/**
 * Derive the first phase in which each current Task identity was established.
 *
 * Git history is advisory view metadata only. A missing repository, an
 * unavailable history, or an unusable historical graph leaves unproved Tasks
 * explicitly marked as unknown rather than preventing the current graph from
 * being rendered.
 */
export async function deriveTaskCreation(
  repository: string,
  graph: ObjectiveGraph,
): Promise<Record<string, TaskCreation>> {
  const currentTaskIds = collectTaskIds(graph);
  if (currentTaskIds.length === 0) return {};

  // Read explicit notes from the current graph on every call. They are
  // presentation evidence, not part of the Git history cache, so a detail
  // correction is visible without a new commit or HEAD change.
  const explicitCreation = collectExplicitCreation(graph);
  const history = await committedHistory(repository, graph.id);
  const result: Record<string, TaskCreation> = {};
  for (const taskId of currentTaskIds) {
    const noted = explicitCreation.get(taskId);
    if (noted !== undefined) {
      result[taskId] = noted;
      continue;
    }

    const established = history.byTaskId.get(taskId);
    if (established !== undefined) {
      result[taskId] = established;
      continue;
    }

    let creation: TaskCreation = "unknown";
    if (history.reliable && history.hasUsableSnapshot) {
      if (graph.phase === "planning") {
        creation = "planning";
      } else if (history.latestSnapshot?.phase === "implementation") {
        creation = "implementation";
      }
    }
    result[taskId] = creation;
  }
  return result;
}

async function committedHistory(repository: string, objectiveId: string): Promise<HistoryAnalysis> {
  const root = await gitOutput(repository, ["rev-parse", "--show-toplevel"]);
  const head = await gitOutput(repository, ["rev-parse", "--verify", "HEAD"]);
  if (root === null || head === null) return emptyHistory();

  const cacheKey = `${root}\u0000${objectiveId}\u0000${head}`;
  const cached = historyCache.get(cacheKey);
  if (cached !== undefined) {
    // Keep frequently refreshed views warm without allowing a process-local
    // cache to grow with every repository or Objective encountered.
    historyCache.delete(cacheKey);
    historyCache.set(cacheKey, cached);
    return cached;
  }

  const analysis = await scanHistory(root, objectiveId);
  historyCache.set(cacheKey, analysis);
  while (historyCache.size > MAX_HISTORY_CACHE_ENTRIES) {
    const oldest = historyCache.keys().next().value;
    if (oldest === undefined) break;
    historyCache.delete(oldest);
  }
  return analysis;
}

async function scanHistory(repository: string, objectiveId: string): Promise<HistoryAnalysis> {
  const relativePath = objectivePath(objectiveId);
  if (relativePath === null) return emptyHistory();

  const log = await gitOutput(repository, ["log", "--format=%H", "--reverse", "--no-renames", "--", relativePath]);
  if (log === null) return emptyHistory();

  const commits = log.split(/\r?\n/).map((line) => line.trim()).filter((line) => line.length > 0);
  if (commits.length === 0) return emptyHistory();

  const byTaskId = new Map<string, TaskCreation>();
  let reliable = true;
  let hasUsableSnapshot = false;
  let latestSnapshot: HistorySnapshot | null = null;

  for (const commit of commits) {
    const snapshot = await historicalSnapshot(repository, commit, relativePath, objectiveId);
    if (snapshot === null) {
      // Once any path revision is unusable, a later first appearance cannot
      // prove that the ID was absent from that malformed/deleted revision.
      reliable = false;
      latestSnapshot = null;
      continue;
    }

    hasUsableSnapshot = true;
    for (const taskId of snapshot.taskIds) {
      if (byTaskId.has(taskId)) continue;
      if (snapshot.phase === "planning") {
        byTaskId.set(taskId, reliable ? "planning" : "unknown");
      } else {
        // The first Implementation snapshot is the accepted baseline. It is
        // intentionally ambiguous: Git cannot prove that its Tasks were late
        // additions. Only a later Implementation snapshot after a fully
        // usable Implementation snapshot proves an Implementation addition.
        const precedingImplementation = latestSnapshot?.phase === "implementation";
        byTaskId.set(taskId, reliable && precedingImplementation ? "implementation" : "unknown");
      }
    }
    latestSnapshot = snapshot;
  }

  return Object.freeze({
    byTaskId,
    hasUsableSnapshot,
    reliable,
    latestSnapshot,
  });
}

async function historicalSnapshot(
  repository: string,
  commit: string,
  relativePath: string,
  objectiveId: string,
): Promise<HistorySnapshot | null> {
  const bytes = await gitOutput(repository, ["show", `${commit}:${relativePath}`]);
  if (bytes === null) return null;

  let input: unknown;
  try {
    input = JSON.parse(bytes);
  } catch {
    return null;
  }

  let validation: ReturnType<typeof validateObjective>;
  try {
    validation = validateObjective(input);
  } catch {
    return null;
  }
  if (!validation.valid || validation.graph.id !== objectiveId) return null;

  const taskIds = new Set<string>();
  for (const workstream of validation.graph.workstreams) collectTasks(workstream.tasks, taskIds);
  return Object.freeze({
    phase: validation.graph.phase,
    taskIds,
  });
}

async function gitOutput(repository: string, args: readonly string[]): Promise<string | null> {
  try {
    const result = await execFileAsync("git", [...args], {
      cwd: repository,
      encoding: "utf8",
      maxBuffer: MAX_GIT_OUTPUT_BYTES,
      shell: false,
    }) as GitExecResult;
    return result.stdout.trim();
  } catch {
    return null;
  }
}

function objectivePath(objectiveId: string): string | null {
  return /^obj_[a-f0-9]{32}$/.test(objectiveId)
    ? `.manifest/objectives/${objectiveId}.json`
    : null;
}

function collectTaskIds(graph: ObjectiveGraph): string[] {
  const ids: string[] = [];
  const seen = new Set<string>();
  if (!Array.isArray(graph.workstreams)) return ids;
  for (const workstream of graph.workstreams) {
    if (!Array.isArray(workstream?.tasks)) continue;
    collectTasks(workstream.tasks, seen, ids);
  }
  return ids;
}

function collectTasks(tasks: readonly Task[], ids: Set<string>, ordered?: string[]): void {
  for (const task of tasks) {
    if (typeof task?.id === "string") {
      if (!ids.has(task.id)) {
        ids.add(task.id);
        ordered?.push(task.id);
      }
    }
    if (Array.isArray(task?.tasks)) collectTasks(task.tasks, ids, ordered);
  }
}

function collectExplicitCreation(graph: ObjectiveGraph): Map<string, TaskCreation> {
  const notes = new Map<string, TaskCreation>();
  if (!Array.isArray(graph.workstreams)) return notes;
  for (const workstream of graph.workstreams) {
    if (Array.isArray(workstream?.tasks)) collectExplicitCreationFromTasks(workstream.tasks, notes);
  }
  return notes;
}

function collectExplicitCreationFromTasks(tasks: readonly Task[], notes: Map<string, TaskCreation>): void {
  for (const task of tasks) {
    if (typeof task?.id === "string") {
      const creation = explicitCreationNote(task.details);
      if (creation !== null) notes.set(task.id, creation);
    }
    if (Array.isArray(task?.tasks)) collectExplicitCreationFromTasks(task.tasks, notes);
  }
}

function explicitCreationNote(details: unknown): TaskCreation | null {
  if (typeof details !== "string") return null;

  const phases = new Set<"planning" | "implementation">();
  let fenceMarker: "`" | "~" | null = null;
  let fenceLength = 0;
  for (const rawLine of details.split(/\r\n?|\n/)) {
    const line = rawLine.trim();
    const fenceRun = /^(`{3,}|~{3,})/.exec(line)?.[1];

    if (fenceMarker !== null) {
      if (fenceRun !== undefined && fenceRun[0] === fenceMarker && fenceRun.length >= fenceLength) {
        fenceMarker = null;
        fenceLength = 0;
      }
      continue;
    }
    if (fenceRun !== undefined) {
      fenceMarker = fenceRun[0] as "`" | "~";
      fenceLength = fenceRun.length;
      continue;
    }

    if (line === "Creation phase: Planning.") phases.add("planning");
    if (line === "Creation phase: Implementation.") phases.add("implementation");
  }

  if (phases.size > 1) return "unknown";
  return phases.values().next().value ?? null;
}

function emptyHistory(): HistoryAnalysis {
  return Object.freeze({
    byTaskId: new Map<string, TaskCreation>(),
    hasUsableSnapshot: false,
    reliable: false,
    latestSnapshot: null,
  });
}
