export { applyObjectiveChange } from "./kernel.ts";
export type { GraphApplyResult, ResolvedGraphChange } from "./kernel.ts";

export {
  createObjectiveFile,
  discoverObjectives,
  loadObjective,
  ManifestFileError,
  resolveRepository,
  writeObjective,
} from "./files.ts";
export type {
  DiscoveredObjective,
  LoadedObjective,
  ManifestFileErrorCode,
} from "./files.ts";

export { inquireObjective } from "./query.ts";
export type {
  ConnectedGraphEntity,
  GraphEntityKind,
  GraphEntitySummary,
  ObjectiveInquiry,
  ObjectiveInquiryResult,
} from "./query.ts";

export {
  changeObjective,
  createManifestService,
  createObjective,
  inquireCurrentObjective,
  orientObjective,
} from "./service.ts";
export type {
  ChangeObjectiveResult,
  CreatedGraphIdentity,
  CreateObjectiveResult,
  InquireObjectiveResult,
  OrientObjectiveResult,
  SemanticGraphChange,
  TaskRef,
  WorkstreamRef,
} from "./service.ts";

export { deriveObjective } from "./derivations.ts";
export type { DerivedTask, ObjectiveView, WorkstreamProgress } from "./derivations.ts";

export {
  buildManifestHumanView,
  DEFAULT_MANIFEST_VIEW_PORT,
  startManifestViewServer,
} from "./view-server.ts";
export type {
  HumanEdge,
  HumanNode,
  HumanNodeState,
  ManifestHumanView,
  StartedManifestViewServer,
} from "./view-server.ts";

export {
  implementationPlanSchema,
  objectiveGraphSchema,
  objectiveIdSchema,
  taskIdSchema,
  validateObjective,
  workstreamIdSchema,
} from "./model.ts";
export type {
  ImplementationPlan,
  ObjectiveGraph,
  ObjectiveId,
  ObjectiveValidationResult,
  Task,
  TaskCompletion,
  TaskId,
  ValidationProblem,
  Workstream,
  WorkstreamId,
} from "./model.ts";
