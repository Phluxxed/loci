import type { ObjectiveGraph, Task, TaskId, Workstream, WorkstreamId } from "./model.ts";

export type TaskLocation = Readonly<{
  task: Task;
  workstream: Workstream;
  workstreamIndex: number;
  parentTask: Task | null;
  ancestors: readonly Task[];
  siblings: Task[];
  siblingIndex: number;
  path: readonly number[];
}>;

export function taskLocations(graph: ObjectiveGraph): TaskLocation[] {
  const locations: TaskLocation[] = [];
  for (const [workstreamIndex, workstream] of graph.workstreams.entries()) {
    walk(workstream.tasks, workstream, workstreamIndex, null, [], [], locations);
  }
  return locations;
}

export function findTaskLocation(graph: ObjectiveGraph, id: TaskId | string): TaskLocation | null {
  return taskLocations(graph).find((location) => location.task.id === id) ?? null;
}

export function tasksInWorkstream(graph: ObjectiveGraph, workstreamId: WorkstreamId): TaskLocation[] {
  return taskLocations(graph).filter((location) => location.workstream.id === workstreamId);
}

export function leafTaskLocations(graph: ObjectiveGraph): TaskLocation[] {
  return taskLocations(graph).filter((location) => location.task.tasks.length === 0);
}

function walk(
  tasks: Task[],
  workstream: Workstream,
  workstreamIndex: number,
  parentTask: Task | null,
  parentPath: readonly number[],
  ancestors: readonly Task[],
  output: TaskLocation[],
): void {
  for (const [siblingIndex, task] of tasks.entries()) {
    const path = [...parentPath, siblingIndex];
    output.push({ task, workstream, workstreamIndex, parentTask, ancestors, siblings: tasks, siblingIndex, path });
    walk(task.tasks, workstream, workstreamIndex, task, path, [...ancestors, task], output);
  }
}
