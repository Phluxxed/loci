import { readFile } from "node:fs/promises";
import { createServer, type Server } from "node:http";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

import { deriveImplementationPlan, deriveObjective } from "./derivations.ts";
import { discoverRepositoryObjectives, resolveDiscoveryRoot } from "./discovery.ts";
import { renderManifestLanding } from "./landing.ts";
import type { DerivedImplementationPlan, DerivedTask, ObjectiveView } from "./derivations.ts";
import { discoverObjectives, loadObjective, resolveRepository } from "./files.ts";
import type { ObjectiveGraph, ObjectiveId, Task, TaskId } from "./model.ts";
import { tasksInWorkstream } from "./tree.ts";
import { objectiveIdSchema, taskIdSchema } from "./model.ts";
import { deriveTaskCreation } from "./task-creation.ts";

export type HumanNodeState =
  | "planning"
  | "current"
  | "next"
  | "available"
  | "blocked"
  | "complete"
  | "discontinued";

export type HumanNode = Readonly<{
  id: string;
  label: string;
  /** Current graph position, for display only; never a stable identity. */
  reference?: string;
  /** Read-only creation evidence from Task details or Git, never an execution fact. */
  creationPhase?: "planning" | "implementation" | "unknown";
  kind: "objective" | "workstream" | "task";
  state: HumanNodeState;
  decomposed: boolean;
  planningSublabel: string;
  sublabel: string;
  body: string;
  data: Readonly<Record<string, unknown>>;
}>;

export type HumanEdge = Readonly<{
  id: string;
  source: string;
  target: string;
  kind: "structure" | "dependency";
  label?: string;
}>;

export type ManifestHumanView = Readonly<{
  objective: Readonly<{
    id: ObjectiveId;
    title: string;
    outcome: string;
    phase: ObjectiveGraph["phase"];
  }>;
  graph: Readonly<{
    nodes: readonly HumanNode[];
    edges: readonly HumanEdge[];
  }>;
  progress: ObjectiveView["progress"];
  current: ObjectiveView["current"];
  next: ObjectiveView["next"];
  choices: ObjectiveView["choices"];
  available: ObjectiveView["available"];
  blockers: ObjectiveView["blockers"];
  implementation: DerivedImplementationPlan | null;
}>;

export type StartedManifestViewServer = Readonly<{
  url: string;
  close: () => Promise<void>;
}>;

type ManifestTarget = Readonly<{ repository: string; objectiveId: ObjectiveId }>;

export const DEFAULT_MANIFEST_VIEW_PORT = 27247;

export function buildManifestHumanView(
  graph: ObjectiveGraph,
  currentTaskId?: TaskId,
  taskCreation: Readonly<Record<string, "planning" | "implementation" | "unknown">> = {},
): ManifestHumanView {
  const view = deriveObjective(graph, currentTaskId === undefined ? {} : { currentTaskId });
  const byTaskId = new Map(view.tasks.map((task) => [task.id, task]));
  const decomposedById = new Map<string, boolean>();
  const deriveTaskDecomposition = (task: Task): boolean => {
    const childStates = task.tasks.map(deriveTaskDecomposition);
    const decomposed = graph.phase === "implementation"
      || (task.tasks.length > 0
        ? childStates.every(Boolean)
        : task.decompositionComplete === true);
    decomposedById.set(task.id, decomposed);
    return decomposed;
  };
  const workstreamDecomposition = new Map(graph.workstreams.map((workstream) => {
    const taskStates = workstream.tasks.map(deriveTaskDecomposition);
    const decomposed = graph.phase === "implementation"
      || (taskStates.length > 0 && taskStates.every(Boolean));
    return [workstream.id, decomposed] as const;
  }));
  const objectiveDecomposition = graph.phase === "implementation"
    || (graph.workstreams.length > 0 && graph.workstreams.every((workstream) => workstreamDecomposition.get(workstream.id) === true));
  const nodes: HumanNode[] = [{
    id: graph.id,
    label: graph.title,
    kind: "objective",
    state: objectiveState(graph, view),
    decomposed: objectiveDecomposition,
    planningSublabel: objectiveDecomposition ? "Decomposition complete" : "Decomposition in progress",
    sublabel: `Objective · ${view.progress.complete ? "Complete" : capitalize(graph.phase)} · ${progressSummary(view)}`,
    body: joinDetails(graph.outcome, graph.details),
    data: {
      Phase: capitalize(graph.phase),
      Outcome: graph.outcome,
      Progress: progressSummary(view),
    },
  }];
  const edges: HumanEdge[] = [];

  for (const [workstreamIndex, workstream] of graph.workstreams.entries()) {
    const workstreamReference = `W${workstreamIndex + 1}`;
    const progress = view.progress.workstreams.find((candidate) => candidate.id === workstream.id)!;
    const taskViews = tasksInWorkstream(graph, workstream.id).map(({ task }) => byTaskId.get(task.id)!);
    const decomposed = workstreamDecomposition.get(workstream.id) === true;
    nodes.push({
      id: workstream.id,
      label: workstream.title,
      reference: workstreamReference,
      kind: "workstream",
      state: workstreamState(progress.complete, taskViews),
      decomposed,
      planningSublabel: decomposed
        ? "Recursively fully decomposed"
        : `${taskViews.length} Tasks currently shaped`,
      sublabel: `Workstream · ${progress.completed}/${progress.required} required Tasks complete`,
      body: joinDetails(workstream.outcome, workstream.details),
      data: {
        Reference: workstreamReference,
        Outcome: workstream.outcome,
        Progress: `${progress.completed}/${progress.required}`,
        Discontinued: progress.discontinued,
      },
    });
    edges.push({
      id: `structure:${graph.id}:${workstream.id}`,
      source: graph.id,
      target: workstream.id,
      kind: "structure",
    });

    function appendTasks(tasks: readonly Task[], parentId: string, parentReference: string): void {
      for (const [taskIndex, task] of tasks.entries()) {
      const reference = `${parentReference}.${taskIndex + 1}`;
      const derived = byTaskId.get(task.id)!;
      const state = taskState(derived, view.next?.task.id);
      const decomposed = decomposedById.get(task.id) === true;
      const creationMarker = taskCreation[task.id] === "implementation"
        ? " · Added during Implementation"
        : "";
      nodes.push({
        id: task.id,
        label: task.title,
        reference,
        kind: "task",
        creationPhase: taskCreation[task.id] ?? "unknown",
        state,
        decomposed,
        planningSublabel: decomposed
          ? `Recursively fully decomposed${creationMarker}`
          : task.tasks.length > 0
            ? `${task.tasks.length} child Tasks${creationMarker}`
            : `Decomposition unfinished${creationMarker}`,
        sublabel: `${capitalize(state)}${creationMarker}`,
        body: joinDetails(task.outcome, task.details),
        data: {
          Reference: reference,
          "Creation phase": taskCreation[task.id] === "implementation"
            ? "Added during Implementation (recorded Task details or Git history)"
            : taskCreation[task.id] === "planning"
              ? "Planning (recorded Task details or Git history)"
              : "Unknown — recorded history does not establish the creation phase; no marker does not mean Planning.",
          Outcome: task.outcome,
          "Decomposition complete": task.tasks.length === 0 ? task.decompositionComplete === true : decomposed,
          "Completion criteria": task.completionCriteria,
          Prerequisites: task.dependencies,
          "External blocker": task.externalBlocker,
          Completion: task.completion,
          Discontinued: task.discontinued,
          Explanation: derived.reasons,
        },
      });
      edges.push({
        id: `structure:${parentId}:${task.id}`,
        source: parentId,
        target: task.id,
        kind: "structure",
      });
      for (const prerequisite of task.dependencies) {
        edges.push({
          id: `dependency:${prerequisite}:${task.id}`,
          source: prerequisite,
          target: task.id,
          kind: "dependency",
          label: "requires",
        });
      }
      appendTasks(task.tasks, task.id, reference);
      }
    }
    appendTasks(workstream.tasks, workstream.id, workstreamReference);
  }

  return Object.freeze({
    objective: Object.freeze({ id: graph.id, title: graph.title, outcome: graph.outcome, phase: graph.phase }),
    graph: Object.freeze({ nodes: Object.freeze(nodes), edges: Object.freeze(edges) }),
    progress: view.progress,
    current: view.current,
    next: view.next,
    choices: view.choices,
    available: view.available,
    blockers: view.blockers,
    implementation: deriveImplementationPlan(graph, view),
  });
}

export async function startManifestViewServer(options: Readonly<{
  repository: string;
  discoveryRoot?: string;
  additionalDiscoveryRoots?: readonly string[];
  objectiveId?: ObjectiveId;
  host?: string;
  port?: number;
}>): Promise<StartedManifestViewServer> {
  const host = options.host ?? "127.0.0.1";
  const port = options.port ?? DEFAULT_MANIFEST_VIEW_PORT;
  const repository = await resolveRepository(options.repository);
  const discoveryRoot = await resolveDiscoveryRoot(options.discoveryRoot ?? repository);
  const additionalDiscoveryRoots = await Promise.all(
    (options.additionalDiscoveryRoots ?? []).map(resolveDiscoveryRoot),
  );
  const templatePath = resolve(dirname(fileURLToPath(import.meta.url)), "../../docs/manifest-objective.html");
  const template = await readFile(templatePath, "utf8");
  const server = createServer(async (request, response) => {
    try {
      const requestUrl = new URL(request.url ?? "/", `http://${host}`);
      if (requestUrl.pathname === "/api/discovery") {
        return json(response, 200, await discoverRepositoryObjectives(discoveryRoot, additionalDiscoveryRoots));
      }
      if (requestUrl.pathname === "/api/objectives") {
        const selectedRepository = requestUrl.searchParams.get("repository");
        if (selectedRepository !== null) {
          const root = await resolveRepository(selectedRepository);
          return json(response, 200, {
            repository: root,
            objectives: await discoverObjectives(root),
          });
        }
        return json(response, 200, await discoverObjectives(repository));
      }
      const apiId = routeObjectiveId(requestUrl.pathname, "/api/objectives/");
      if (apiId !== null) {
        const root = await requestRepository(requestUrl, repository);
        const human = await loadHumanView(root, apiId, requestUrl.searchParams.get("current-task-id"));
        return json(response, 200, requestUrl.searchParams.has("repository")
          ? { ...human, target: { repository: root, objectiveId: apiId } }
          : human);
      }
      const pageId = routeObjectiveId(requestUrl.pathname, "/objectives/");
      if (pageId !== null) {
        const root = await requestRepository(requestUrl, repository);
        const target = { repository: root, objectiveId: pageId };
        const human = await loadHumanView(root, pageId, requestUrl.searchParams.get("current-task-id"));
        const href = objectiveHref(target, requestUrl.searchParams);
        if (requestUrl.pathname + requestUrl.search !== href) return redirect(response, href);
        return html(response, 200, renderObjectiveHtml(template, human, target));
      }
      if (requestUrl.pathname === "/objectives") return html(response, 200, renderManifestLanding());
      if (requestUrl.pathname !== "/") return html(response, 404, "<!doctype html><h1>Not found</h1>");
      if (options.objectiveId !== undefined) {
        return redirect(response, objectiveHref({ repository, objectiveId: options.objectiveId }, requestUrl.searchParams));
      }
      return redirect(response, "/objectives");
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      return json(response, 400, { error: { message } });
    }
  });
  await listen(server, port, host);
  const address = server.address();
  if (address === null || typeof address === "string") throw new Error("Manifest view server did not bind a TCP address.");
  const url = `http://${formatHost(host)}:${address.port}`;
  return Object.freeze({ url, close: () => closeServer(server) });
}

async function requestRepository(url: URL, startupRepository: string): Promise<string> {
  const requested = url.searchParams.get("repository");
  return requested === null ? startupRepository : resolveRepository(requested);
}

function objectiveHref(target: ManifestTarget, parameters?: URLSearchParams): string {
  const search = new URLSearchParams(parameters);
  search.set("repository", target.repository);
  return `/objectives/${encodeURIComponent(target.objectiveId)}?${search}`;
}

function redirect(response: import("node:http").ServerResponse, href: string): void {
  response.writeHead(302, { location: href, "cache-control": "no-store" });
  response.end();
}

async function loadHumanView(repository: string, objectiveId: ObjectiveId, currentTask: string | null) {
  const currentTaskId = currentTask === null ? undefined : taskIdSchema.parse(currentTask);
  const loaded = await loadObjective(repository, objectiveId);
  const creation = await deriveTaskCreation(repository, loaded.graph);
  return buildManifestHumanView(loaded.graph, currentTaskId, creation);
}

function routeObjectiveId(pathname: string, prefix: string): ObjectiveId | null {
  if (!pathname.startsWith(prefix)) return null;
  return objectiveIdSchema.parse(decodeURIComponent(pathname.slice(prefix.length)));
}

function renderObjectiveHtml(template: string, human: ManifestHumanView, target: ManifestTarget): string {
  const humanJson = safeJson(human);
  // The shared card row reserves both phase labels even when one is hidden.
  // Feed its longer real text to native sizing; keep Human JSON phase-specific.
  const lensNodes = human.graph.nodes.map((node) => ({
    ...node,
    sublabel: node.planningSublabel.length > node.sublabel.length
      ? node.planningSublabel
      : node.sublabel,
  }));
  const lensJson = safeJson({
    meta: {
      direction: "RIGHT",
      root: human.objective.id,
      collapsed: false,
      title: `${human.objective.title} · ${human.progress.complete ? "Complete" : capitalize(human.objective.phase)}`,
    },
    nodes: lensNodes,
    edges: human.graph.edges,
  });
  const data = `<script id="manifest-human-view" type="application/json">${humanJson}</script>\n` +
    `<script id="manifest-target" type="application/json">${safeJson(target)}</script>\n` +
    `<script id="lens-data" type="application/json">${lensJson}</script>`;
  return adaptBundledRenderer(template, target)
    .replace('</style>', '.lg-ctl{min-width:0;max-width:100%;flex-shrink:1}.lg-ctl a.ctl{text-decoration:none;display:inline-flex;align-items:center}</style>')
    .replace(/<title>[\s\S]*?<\/title>/, `<title>${escapeHtml(human.objective.title)} · Manifest</title>`)
    .replace(/<script id="lens-data" type="application\/json">[\s\S]*?<\/script>/, data)
    .replace(/<script id="manifest-implementation-view">[\s\S]*?<\/script>/, humanInterfaceScript());
}

function adaptBundledRenderer(template: string, target: ManifestTarget): string {
  return template
    .replace(
      'manifestLiveStateKey="manifest-map-live-state"',
      `manifestLiveStateKey=${safeJson("manifest-map-live-state-v3::" + JSON.stringify([target.repository, target.objectiveId]))}`,
    )
    .replace(
      'let ne=bn=>{g(Jn=>{let Sn=new Set(Jn);',
      '(0,Ft.useEffect)(()=>{const save=()=>{try{sessionStorage.setItem(manifestLiveStateKey,JSON.stringify({expanded:[...a],selected:S,mode:k,viewport:f.getViewport()}))}catch{}};window.addEventListener("pagehide",save);window.addEventListener("beforeunload",save);return()=>{window.removeEventListener("pagehide",save);window.removeEventListener("beforeunload",save)}},[a,S,k,f]);let ne=bn=>{g(Jn=>{let Sn=new Set(Jn);',
    )
    .replace(
      'for(let y of a)g[y.source]&&g[y.target]&&(g[y.source].children.push(y.target),b[y.target]=(b[y.target]??0)+1);',
      'for(let y of a)y.kind!=="dependency"&&g[y.source]&&g[y.target]&&(g[y.source].children.push(y.target),b[y.target]=(b[y.target]??0)+1);',
    )
    .replace(
      'Vkn=(f,a)=>dkn(hm,f,a);',
      'Vkn=(f,a)=>{let g=dkn(hm,f,a),b=new Set(g.nodes.map(y=>y.id));return{nodes:g.nodes,edges:[...g.edges,...tk.edges.filter(y=>y.kind==="dependency"&&b.has(y.source)&&b.has(y.target))]}};',
    )
    .replace(
      'for(let F of S)O.get(F.source)?.push(F.target),k[F.target]=(k[F.source]??0)+1;',
      'for(let F of S)F.kind!=="dependency"&&(O.get(F.source)?.push(F.target),k[F.target]=(k[F.source]??0)+1);',
    )
    .replace(
      'for(let H of b)B.get(H.source)?.push(H.target);',
      'for(let H of b)H.kind!=="dependency"&&B.get(H.source)?.push(H.target);',
    )
    .replace(
      'bst={primary:"var(--teal-dim)",muted:"var(--amber-dim)",inactive:"var(--border)"}',
      'bst={primary:"var(--teal-dim)",muted:"var(--amber-dim)",inactive:"var(--border)",planning:"var(--blue)",current:"var(--teal)",next:"var(--blue)",available:"var(--teal-dim)",blocked:"var(--red)",complete:"var(--text-dim)",discontinued:"var(--border)"}',
    )
    .replace(
      'markerEnd:C,style:{stroke:y,strokeWidth:1.5,strokeDasharray:!HE||b==="primary"?void 0:"4 4"}',
      'markerEnd:S?.kind==="dependency"?{type:Z6.ArrowClosed,color:y}:C,style:{stroke:y,strokeWidth:1.5}',
    )
    .replace(
      'nodesConnectable:!1,minZoom:.05,maxZoom:2',
      'nodesConnectable:!1,minZoom:.05,maxZoom:2,zoomOnDoubleClick:!1',
    )
    .replace(
      'let Te=()=>C(Ve=>Ve.includes(Sn.id)?Ve.filter(nn=>nn!==Sn.id):[...Ve,Sn.id]);',
      'let Te=()=>{};',
    )
    .replace(
      'let me=(0,Ft.useCallback)((bn,Jn)=>{',
      '(0,Ft.useEffect)(()=>{const selectManifestWork=event=>{const {id,ancestors,toggleDetail}=event.detail;C(id&&hm[id]?toggleDetail&&k==="node"&&S.length===1&&S[0]===id?[]:[id]:[]);g(previous=>new Set([...previous,...ancestors.filter(parent=>hm[parent])]));};window.addEventListener("manifest-work-selection",selectManifestWork);return()=>window.removeEventListener("manifest-work-selection",selectManifestWork);},[S,k]);let me=(0,Ft.useCallback)((bn,Jn)=>{',
    )
    .replace(
      'onClick:()=>C(bn=>bn.filter(Jn=>Jn!==Ae.id))',
      'onClick:()=>C([])',
    )
    .replace(
      'className:"detail"}',
      'className:"detail","data-manifest-node-id":Ae.id}',
    );
}

function humanInterfaceScript(): string {
  return String.raw`<script id="manifest-implementation-view">
(() => {
  const humanElement = document.getElementById('manifest-human-view');
  const targetElement = document.getElementById('manifest-target');
  if (!humanElement || !targetElement) return;
  let human, target;
  try {
    human = JSON.parse(humanElement.textContent);
    target = JSON.parse(targetElement.textContent);
  } catch { return; }
  const targetKey = JSON.stringify([target.repository, target.objectiveId]);
  const plan = human.implementation;
  const objectiveComplete = human.progress?.complete === true;
  const implementationLabel = objectiveComplete ? 'Complete' : 'Implementation';
  const requested = new URLSearchParams(location.search);
  const create = (tag, className, text) => {
    const element = document.createElement(tag);
    if (className) element.className = className;
    if (text !== undefined) element.textContent = text;
    return element;
  };
  const surfaceKey = 'manifest-human-surface-v2::' + targetKey;
  const implementationAvailable = human.objective.phase === 'implementation';
  let savedSurface = null;
  try { savedSurface = sessionStorage.getItem(surfaceKey); } catch {}
  let surface = objectiveComplete && implementationAvailable ? 'implementation'
    : savedSurface === 'planning' || savedSurface === 'implementation' ? savedSurface
    : human.objective.phase;
  if (requested.get('manifest-surface') === 'planning' || requested.get('manifest-surface') === 'implementation') {
    surface = requested.get('manifest-surface');
  }
  if (!implementationAvailable) surface = 'planning';

  let applySurface = () => {};
  let surfaceNavigation = null;
  const chooseSurface = nextSurface => {
    if (nextSurface === 'implementation' && !implementationAvailable) return;
    surface = nextSurface;
    try { sessionStorage.setItem(surfaceKey, nextSurface); } catch {}
    applySurface();
  };
  const ensureSurfaceSwitch = () => {
    const controls = document.querySelector('.lg-ctl');
    if (!controls) return;
    if (!controls.querySelector('[data-manifest-objectives-link]')) {
      const link = create('a', 'ctl', 'All Objectives');
      link.href = '/objectives';
      link.dataset.manifestObjectivesLink = '';
      controls.prepend(link);
    }
    if (!surfaceNavigation) {
      surfaceNavigation = create('nav', 'manifest-surface-switch');
      surfaceNavigation.setAttribute('aria-label', 'Manifest phase presentation');
      for (const nextSurface of implementationAvailable ? ['planning', 'implementation'] : ['planning']) {
        const button = create('button', 'manifest-surface-switch__button', nextSurface === 'planning' ? 'Planning' : implementationLabel);
        button.type = 'button';
        button.dataset.manifestSurfaceChoice = nextSurface;
        button.title = 'Preview the ' + nextSurface + ' presentation without changing the Objective phase';
        button.addEventListener('click', () => chooseSurface(nextSurface));
        surfaceNavigation.append(button);
      }
    }
    if (surfaceNavigation.parentElement !== controls) controls.prepend(surfaceNavigation);
    surfaceNavigation.querySelectorAll('[data-manifest-surface-choice]').forEach(button =>
      button.setAttribute('aria-pressed', String(surface === button.dataset.manifestSurfaceChoice)));
    ensureProgressPanel();
  };

  const positionDetailPanel = () => {
    const app = document.querySelector('.lg-app');
    const flow = document.querySelector('.lg-flow');
    const detail = document.querySelector('.detail');
    if (!app || !flow || !detail) return;
    const appRect = app.getBoundingClientRect();
    const flowRect = flow.getBoundingClientRect();
    detail.style.top = Math.max(0, flowRect.top - appRect.top) + 'px';
    detail.style.height = Math.max(0, flowRect.height) + 'px';
  };
  window.addEventListener('resize', positionDetailPanel);

  const semanticColors = {
    objective: '#7aa2f7',
    workstream: '#34e2c9',
    task: '#ff5c57'
  };
  const semanticNodes = new Map(human.graph.nodes.map(node => [node.id, node]));
  const detailPrefix = '__lens_detail__:';
  const planningColor = node => node?.decomposed ? '#ffffff' : semanticColors[node?.kind] || semanticColors.task;
  const normalizeReferenceLabel = (kindLabel, node) => {
    const kindText = node.kind.toUpperCase();
    if (node.reference) {
      let reference = kindLabel.querySelector('.manifest-card__reference');
      if (!reference) {
        kindLabel.textContent = kindText + ' · ';
        reference = create('span', 'manifest-card__reference', node.reference);
        reference.dataset.manifestSlot = 'reference';
        reference.title = 'Position in the current Objective; changes when Work is reordered';
        kindLabel.append(reference);
      } else if (reference.textContent !== node.reference) {
        reference.textContent = node.reference;
      }
    } else if (kindLabel.textContent !== kindText) {
      kindLabel.textContent = kindText;
    }
  };
  const normalizeSharedCard = rendered => {
    const renderedId = rendered.getAttribute('data-id') || '';
    const id = renderedId.startsWith(detailPrefix) ? renderedId.slice(detailPrefix.length) : renderedId;
    const node = semanticNodes.get(id);
    const card = rendered.querySelector('.node');
    if (!node || !card) return;
    const detail = renderedId.startsWith(detailPrefix);
    const alreadyNormalized = card.dataset.manifestCardNormalized === 'true'
      && card.classList.contains('manifest-card')
      && (detail || card.classList.contains('node--' + node.kind))
      && card.dataset.manifestKind === node.kind
      && rendered.dataset.manifestKind === node.kind
      && card.querySelector('.manifest-card__kind')
      && (!node.reference || card.querySelector('.manifest-card__reference')?.textContent === node.reference)
      && card.querySelector('.manifest-card__title')
      && (detail || (card.querySelector('.manifest-card__support--planning')
        && card.querySelector('.manifest-card__support--implementation')));
    if (alreadyNormalized) return;
    if (detail) card.classList.add('manifest-card');
    else card.classList.add('manifest-card', 'node--' + node.kind);
    card.dataset.manifestCardNormalized = 'true';
    card.dataset.manifestKind = node.kind;
    rendered.dataset.manifestKind = node.kind;
    rendered.dataset.decomposed = String(node.decomposed === true);
    card.style.setProperty('--planning-color', planningColor(node));

    let kindLabel = detail
      ? card.querySelector('.node--detail__head .manifest-card__kind')
      : card.querySelector(':scope > .manifest-card__kind');
    if (!kindLabel) {
      kindLabel = detail
        ? card.querySelector('.node--detail__head .node__eyebrow')
        : card.querySelector(':scope > .node__eyebrow');
      if (!kindLabel) {
        kindLabel = create('div', 'node__eyebrow');
        const firstContent = card.querySelector(':scope > .node__row, :scope > .node__title, :scope > .node--detail__head');
        card.insertBefore(kindLabel, firstContent || card.firstChild);
      }
      kindLabel.classList.add('manifest-card__kind');
    }
    kindLabel.dataset.manifestSlot = 'kind';
    normalizeReferenceLabel(kindLabel, node);

    const title = detail
      ? card.querySelector('.node--detail__title')
      : card.querySelector(':scope > .node__title, :scope > .node__row > .node__name');
    if (title) {
      title.classList.add('manifest-card__title');
      title.dataset.manifestSlot = 'title';
    }
    const titleRow = card.querySelector(':scope > .node__row');
    if (titleRow) titleRow.classList.add('manifest-card__title-row');
    if (detail) return;

    const implementationSupport = card.querySelector(':scope > .node__sub:not(.manifest-card__support--planning)');
    if (implementationSupport) {
      implementationSupport.classList.add('manifest-card__support', 'manifest-card__support--implementation');
      implementationSupport.dataset.manifestSlot = 'supporting-implementation';
      if (implementationSupport.textContent !== node.sublabel) implementationSupport.textContent = node.sublabel;
      let planningSupport = card.querySelector(':scope > .manifest-card__support--planning');
      if (!planningSupport) {
        planningSupport = create('div', 'node__sub manifest-card__support manifest-card__support--planning', node.planningSublabel);
        implementationSupport.after(planningSupport);
      } else if (planningSupport.textContent !== node.planningSublabel) {
        planningSupport.textContent = node.planningSublabel;
      }
      planningSupport.dataset.manifestSlot = 'supporting-planning';
    }
    const legacyBadge = card.querySelector(':scope > .node__badge');
    if (legacyBadge) legacyBadge.classList.add('manifest-card__legacy-badge');
    const children = card.querySelector(':scope > .node__count');
    if (children) {
      children.classList.add('manifest-card__children');
      children.dataset.manifestSlot = 'children';
    }
  };
  const normalizeSharedCards = () => {
    document.querySelectorAll('.react-flow__node[data-id]').forEach(normalizeSharedCard);
    const panel = document.querySelector('.detail[data-manifest-node-id]');
    const node = semanticNodes.get(panel?.dataset.manifestNodeId);
    const kindLabel = panel?.querySelector('.detail__eyebrow');
    if (node && kindLabel) normalizeReferenceLabel(kindLabel, node);
  };
  const sharedCardClassObserver = new MutationObserver(records => {
    const rendered = new Set(records.flatMap(record => {
      const node = record.target.closest?.('.react-flow__node[data-id]');
      return node ? [node] : [];
    }));
    rendered.forEach(normalizeSharedCard);
  });
  sharedCardClassObserver.observe(document.getElementById('root'), {
    attributes: true,
    attributeFilter: ['class'],
    subtree: true
  });

  let applyPlanningOverlay = () => {};
  const startPlanningSurface = () => {
    const root = document.getElementById('root');
    if (!root) return;
    const decorateEdge = edge => {
      const rendered = [...root.querySelectorAll('.react-flow__edge')].find(candidate =>
        candidate.getAttribute('aria-label') === 'Edge from ' + edge.source + ' to ' + edge.target
        && (edge.kind !== 'dependency' || candidate.textContent.trim() === 'requires'));
      const target = semanticNodes.get(edge.target);
      const path = rendered?.querySelector('.react-flow__edge-path');
      if (!rendered || !target || !path) return;
      const color = planningColor(target);
      rendered.classList.remove('impl-edge-muted', 'impl-edge-related', 'impl-edge-governed', 'impl-edge-hidden');
      path.style.stroke = color;
      path.style.strokeDasharray = edge.kind === 'dependency' ? '6 5' : 'none';
      const label = rendered.querySelector('.react-flow__edge-text');
      if (label) label.style.fill = color;
      const markerReference = path.getAttribute('marker-end')?.match(/#([^')]+)/)?.[1];
      const marker = markerReference ? document.getElementById(markerReference) : null;
      const arrow = marker?.querySelector('polyline');
      if (arrow) {
        arrow.style.stroke = color;
        arrow.style.fill = color;
      }
    };
    const decorate = () => {
      ensureSurfaceSwitch();
      positionDetailPanel();
      const title = root.querySelector('.lg-title');
      if (title && title.textContent !== human.objective.title + ' · Planning') {
        title.textContent = human.objective.title + ' · Planning';
      }
      human.graph.edges.forEach(decorateEdge);
    };
    applyPlanningOverlay = decorate;
  };

  const colors = {
    G: 'var(--impl-gate)', W1: 'var(--impl-w1)', W2: 'var(--impl-w2)',
    W3: 'var(--impl-w3)', W4: 'var(--impl-w4)', W5: 'var(--impl-w5)', W6: 'var(--impl-w6)'
  };
  const stageColor = id => colors[displayCode(id)] || 'var(--blue)';
  // Panel metadata is optional; both surfaces still project the canonical graph.
  const planStages = plan?.stages || [];
  const stages = new Map(planStages.map(stage => [stage.id, stage]));
  const slices = new Map(planStages.flatMap(stage => stage.slices.map(slice => [slice.id, { ...slice, stageId: stage.id }])));
  // Compact labels are presentation only; selection and coverage keep graph IDs.
  const displayCode = id => semanticNodes.get(id)?.reference || id;
  const nodes = new Map(human.graph.nodes.map(node => {
    const text = String(node.sublabel || '') + '\n' + String(node.body || '');
    const concept = text.match(/\bM(?:\.\d+)*\b/)?.[0] || (node.id === human.objective.id ? 'M' : null);
    return [node.id, { ...node, concept }];
  }));
  const fallbackStage = planStages.find(stage => stage.status !== 'complete') || planStages[0];
  const fallbackSlice = fallbackStage?.slices.find(slice => slice.status !== 'complete' && slice.status !== 'discontinued');
  const nextTask = human.graph.nodes.find(node => node.kind === 'task' && node.state === 'next');
  const nextSlice = nextTask ? [...slices.values()]
    .filter(slice => slice.mappedNodeIds?.includes(nextTask.id))
    .sort((left, right) => left.mappedNodeIds.length - right.mappedNodeIds.length)[0] : null;
  const initialStage = objectiveComplete ? 'all' : plan?.currentStage || nextSlice?.stageId || fallbackStage?.id || 'all';
  const initialSlice = objectiveComplete ? null : plan?.currentSlice || nextSlice?.id || fallbackSlice?.id || null;
  const projectionKey = plan?.currentSlice || 'no-current-work';
  const stateKey = 'manifest-map-implementation-view-v6::' + targetKey;
  const stageIds = new Set(stages.keys());
  const sliceIds = new Set(slices.keys());
  let filter = initialStage;
  let selectedItem = initialSlice;
  let selectedId = null;
  let panelCollapsed = false;
  let panelToggle = null;
  let shellReady = false;
  let decorating = false;

  try {
    const saved = JSON.parse(sessionStorage.getItem(stateKey) || 'null');
    panelCollapsed = saved?.panelCollapsed === true;
    if (!objectiveComplete && saved?.plan === projectionKey && (saved.filter === 'all' || stageIds.has(saved.filter))) filter = saved.filter;
    if (!objectiveComplete && saved?.plan === projectionKey && (saved.item === null || sliceIds.has(saved.item))) selectedItem = saved.item;
  } catch {}
  const requestedStream = requested.get('stream');
  const requestedItem = requested.get('item');
  if (requestedStream === 'current') {
    filter = initialStage;
    selectedItem = initialSlice;
  } else if (requestedStream === 'all') {
    filter = 'all';
    selectedItem = null;
  } else if (stageIds.has(requestedStream)) {
    filter = requestedStream;
    selectedItem = sliceIds.has(requestedItem) && slices.get(requestedItem)?.stageId === filter ? requestedItem : null;
  } else if (sliceIds.has(requestedItem)) {
    selectedItem = requestedItem;
    filter = slices.get(requestedItem).stageId;
  }
  if (filter === 'all') selectedItem = null;
  if (selectedItem !== null && slices.get(selectedItem)?.stageId !== filter) selectedItem = null;

  const appendDefinition = (list, term, description) => {
    list.append(create('dt', '', term), create('dd', '', description));
  };
  const save = () => {
    try { sessionStorage.setItem(stateKey, JSON.stringify({ filter, item: selectedItem, plan: projectionKey, panelCollapsed })); } catch {}
  };
  const ensureProgressPanel = () => {
    const flow = document.querySelector('.lg-flow');
    if (!plan || !flow) return;
    if (!panelToggle) {
      panelToggle = create('button', 'ctl manifest-panel-toggle');
      panelToggle.type = 'button';
      panelToggle.dataset.manifestPanelToggle = '';
      panelToggle.setAttribute('aria-controls', 'manifest-progress-panel');
      panelToggle.addEventListener('click', () => {
        panelCollapsed = !panelCollapsed;
        save();
        ensureProgressPanel();
      });
    }
    if (panelToggle.parentElement !== flow) flow.append(panelToggle);
    const visible = surface === 'implementation';
    panelToggle.hidden = !visible;
    panelToggle.setAttribute('aria-expanded', String(visible && !panelCollapsed));
    const label = panelCollapsed ? 'Show progress' : 'Hide progress';
    if (panelToggle.textContent !== label) panelToggle.textContent = label;
    const shell = document.querySelector('.manifest-view-shell');
    if (shell) shell.hidden = !visible || panelCollapsed;
  };
  const replaceQuery = changes => {
    const next = new URL(location.href);
    Object.entries(changes).forEach(([key, value]) => value == null ? next.searchParams.delete(key) : next.searchParams.set(key, value));
    history.replaceState(null, '', next);
  };
  const graphHref = (stageId = initialStage, sliceId = initialSlice) => {
    const href = targetHref();
    href.searchParams.set('stream', stageId);
    if (sliceId !== null) href.searchParams.set('item', sliceId);
    href.searchParams.set('variant', 'adaptive');
    return href.href;
  };
  const planHref = () => {
    const href = targetHref();
    href.searchParams.set('surface', 'plan');
    return href.href;
  };
  const targetHref = () => {
    const href = new URL('/objectives/' + encodeURIComponent(target.objectiveId), location.href);
    href.searchParams.set('repository', target.repository);
    const currentTask = requested.get('current-task-id');
    if (currentTask) href.searchParams.set('current-task-id', currentTask);
    return href;
  };
  const statusLabel = status => status === 'discontinued' ? '× Discontinued' : status === 'complete' ? '✓ Complete' : status === 'partial' ? '◐ Partial' : status === 'active' ? '● Active' : status === 'current' ? '● Current' : '○ Upcoming';
  const statusElement = (className, status) => {
    const element = create('span', className);
    const [marker, label] = statusLabel(status).split(' ');
    element.append(create('span', className + '-marker', marker + ' '), create('span', className + '-label', label));
    return element;
  };
  const markerFor = status => status === 'complete' ? '✓' : status === 'partial' ? '◐' : status === 'active' || status === 'current' ? '●' : '○';
  const matchCoverage = (coverage, node) => {
    if (coverage.nodes.includes(node.id)) return true;
    return node.concept !== null && coverage.concepts.some(concept => node.concept === concept || node.concept.startsWith(concept + '.'));
  };
  const coverageScore = (coverage, node) => {
    if (coverage.nodes.includes(node.id)) return 10000;
    if (node.concept === null) return -1;
    return coverage.concepts.reduce((best, concept) =>
      node.concept === concept || node.concept.startsWith(concept + '.') ? Math.max(best, concept.length) : best, -1);
  };
  const ownershipFor = node => {
    const candidates = planStages
      .map(stage => ({ stage, score: coverageScore(stage.primary, node) }))
      .filter(candidate => candidate.score >= 0)
      .sort((left, right) => right.score - left.score);
    const primary = candidates[0]?.stage.id || (planStages.length ? initialStage : null);
    const supporting = planStages
      .filter(stage => stage.id !== primary && matchCoverage(stage.supporting, node))
      .map(stage => stage.id);
    return { primary, supporting };
  };
  const ownership = new Map([...nodes].map(([id, node]) => [id, ownershipFor(node)]));
  const selectedSlice = () => slices.get(selectedItem);
  const selectedStage = () => filter === 'all' ? null : stages.get(filter);
  const structureParents = new Map(human.graph.edges.filter(edge => edge.kind === 'structure').map(edge => [edge.target, edge.source]));
  const workAncestors = id => {
    const ancestors = [];
    let parent = structureParents.get(id);
    while (parent && nodes.has(parent)) {
      ancestors.push(parent);
      parent = structureParents.get(parent);
    }
    return ancestors;
  };
  const taskAncestors = id => workAncestors(id).filter(parent => nodes.get(parent)?.kind === 'task');
  const highlightedNodeIds = () => {
    const mapped = selectedSlice()?.mappedNodeIds
      || (selectedId && nodes.has(selectedId)
        ? [...nodes.keys()].filter(id => id === selectedId || workAncestors(id).includes(selectedId))
        : selectedStage()?.mappedNodeIds || []);
    // Ancestors provide navigation context, not additional completion coverage.
    return new Set([...mapped, ...mapped.flatMap(workAncestors)]);
  };
  const matchFor = node => {
    if (filter === 'all') return 'primary';
    const own = ownership.get(node.id);
    if (highlightedNodeIds().has(node.id)) return 'primary';
    if (own.primary === filter || own.supporting.includes(filter)) return 'support';
    return 'none';
  };
  const colorEdgeForTarget = (rendered, edge, target) => {
    const edgeStage = filter !== 'all' && matchFor(target) === 'primary' ? filter : ownership.get(target.id).primary;
    const color = plan ? stageColor(edgeStage) : semanticColors[target.kind];
    const path = rendered.querySelector('.react-flow__edge-path');
    if (!path) return;
    path.style.stroke = color;
    path.style.strokeDasharray = edge.kind === 'dependency' ? '6 5' : 'none';
    if (edge.kind !== 'dependency') return;
    const svg = rendered.closest('svg');
    if (!svg) return;
    let definitions = svg.querySelector('defs');
    if (!definitions) {
      definitions = document.createElementNS('http://www.w3.org/2000/svg', 'defs');
      svg.prepend(definitions);
    }
    const markerId = 'manifest-requires-' + (edgeStage || target.kind).replace(/[^a-zA-Z0-9_-]/g, '-');
    let marker = [...definitions.children].find(element => element.id === markerId);
    if (!marker) {
      marker = document.createElementNS('http://www.w3.org/2000/svg', 'marker');
      marker.id = markerId;
      marker.classList.add('react-flow__arrowhead');
      marker.setAttribute('markerWidth', '12.5');
      marker.setAttribute('markerHeight', '12.5');
      marker.setAttribute('viewBox', '-10 -10 20 20');
      marker.setAttribute('markerUnits', 'strokeWidth');
      marker.setAttribute('orient', 'auto-start-reverse');
      marker.setAttribute('refX', '0');
      marker.setAttribute('refY', '0');
      const arrow = document.createElementNS('http://www.w3.org/2000/svg', 'polyline');
      arrow.classList.add('arrowclosed');
      arrow.setAttribute('stroke-linecap', 'round');
      arrow.setAttribute('stroke-linejoin', 'round');
      arrow.setAttribute('points', '-5,-4 0,0 -5,4 -5,-4');
      arrow.style.strokeWidth = '1';
      arrow.style.stroke = color;
      arrow.style.fill = color;
      marker.append(arrow);
      definitions.append(marker);
    }
    path.setAttribute('marker-end', "url('#" + markerId + "')");
  };

  const decorateDetail = (container, id) => {
    if (!plan) return;
    const node = nodes.get(id);
    const own = ownership.get(id);
    if (!container || !node || !own?.primary) return;
    let detail = container.querySelector(':scope > .implementation-detail');
    if (!detail) {
      detail = create('div', 'implementation-detail');
      container.prepend(detail);
    }
    const selected = selectedSlice();
    const selectedMatch = filter !== 'all' && selected?.stageId === filter && selected.mappedNodeIds.includes(id);
    const stageMatch = filter !== 'all' && !selected && selectedStage()?.mappedNodeIds.includes(id);
    const displayStage = selectedMatch || stageMatch ? stages.get(filter) : stages.get(own.primary);
    const slice = selectedMatch ? selected : stageMatch ? null : displayStage.slices.find(item => item.mappedNodeIds.includes(id));
    const renderKey = JSON.stringify([displayStage.id, own.primary, own.supporting, slice?.id || null, selectedMatch, stageMatch]);
    if (detail.dataset.renderKey === renderKey) return;
    detail.dataset.renderKey = renderKey;
    detail.replaceChildren();
    detail.style.setProperty('--implementation-color', stageColor(displayStage.id));
    const ownerLine = create('strong', '', selectedMatch
      ? (node.concept || node.label) + ' · mapped to ' + displayCode(slice.id) + ' ' + slice.label
      : stageMatch
        ? (node.concept || node.label) + ' · mapped to ' + displayCode(displayStage.id) + ' ' + displayStage.label
      : (node.concept || node.label) + ' · primary ' + displayCode(own.primary) + ' ' + displayStage.label);
    detail.append(ownerLine, document.createElement('br'));
    if (slice) detail.append(document.createTextNode('Delivery slice: ' + displayCode(slice.id) + ' · ' + slice.label), document.createElement('br'));
    if (stageMatch) detail.append(document.createTextNode('Delivery stage: ' + displayCode(displayStage.id) + ' · aggregate slice coverage'), document.createElement('br'));
    if (!selectedMatch && !stageMatch) {
      detail.append(document.createTextNode('Supporting: ' + (own.supporting.length ? own.supporting.join(' · ') : 'none')), document.createElement('br'));
    }
    detail.append(document.createTextNode(displayStage.detail));
  };

  const decorate = () => {
    if (decorating) return;
    decorating = true;
    try {
      positionDetailPanel();
      const title = document.querySelector('.lg-title');
      if (title && title.textContent !== human.objective.title + ' · ' + implementationLabel) {
        title.textContent = human.objective.title + ' · ' + implementationLabel;
      }
      document.querySelectorAll('.react-flow__node[data-id]').forEach(element => {
        const renderedId = element.getAttribute('data-id');
        const prefix = '__lens_detail__:';
        const id = renderedId.startsWith(prefix) ? renderedId.slice(prefix.length) : renderedId;
        const node = nodes.get(id);
        const own = ownership.get(id);
        if (!node || !own) return;
        const match = matchFor(node);
        const accent = plan && own.primary
          ? match === 'primary' && filter !== 'all' ? stageColor(filter) : stageColor(own.primary)
          : semanticColors[node.kind];
        element.classList.remove('impl-match-primary', 'impl-match-support', 'impl-match-none');
        element.classList.add('impl-match-' + match);
        element.style.setProperty('--implementation-color', accent);
        const card = element.querySelector('.node');
        if (!card) return;
        card.style.setProperty('--implementation-color', accent);
        if (renderedId.startsWith(prefix)) {
          decorateDetail(card.querySelector('.node--detail__scroll'), id);
          return;
        }
        if (!own.primary && node.state !== 'complete' && node.state !== 'discontinued') return;
        let badge = card.querySelector(':scope > .implementation-owner');
        if (!badge) {
          badge = create('div', 'implementation-owner');
          card.append(badge);
        }
        const selected = selectedSlice();
        const selectedMatch = filter !== 'all' && match === 'primary'
          && selected?.stageId === filter && selected.mappedNodeIds.includes(id);
        const stageMatch = filter !== 'all' && match === 'primary'
          && !selected && selectedStage()?.mappedNodeIds.includes(id);
        const badgeStage = selectedMatch || stageMatch ? filter : own.primary;
        const badgeLabel = selectedMatch ? selected.id : stageMatch ? filter : own.primary;
        const supporting = selectedMatch || stageMatch ? [] : own.supporting;
        badge.style.setProperty('--implementation-color', stageColor(badgeStage));
        const presentationComplete = selectedMatch
          ? selected.status === 'complete'
          : stageMatch
            ? selectedStage()?.status === 'complete'
            : stages.get(own.primary)?.status === 'complete';
        const graphComplete = node.state === 'complete';
        const graphDiscontinued = node.state === 'discontinued';
        const complete = graphComplete || presentationComplete;
        const renderKey = JSON.stringify([badgeStage, badgeLabel, supporting, complete, graphDiscontinued]);
        if (badge.dataset.renderKey !== renderKey) {
          badge.dataset.renderKey = renderKey;
          badge.replaceChildren();
          if (graphDiscontinued) {
            const dead = create('span', 'implementation-owner__discontinued', '×');
            dead.setAttribute('role', 'img');
            dead.setAttribute('aria-label', 'Discontinued');
            badge.append(dead);
          } else if (complete) {
            const tick = create('span', 'implementation-owner__complete', '✓');
            tick.setAttribute('role', 'img');
            tick.setAttribute('aria-label', 'Complete');
            badge.append(tick);
          }
          if (badgeLabel) badge.append(create('span', '', displayCode(badgeLabel)));
          for (const stageId of supporting) {
            const dot = create('i', 'implementation-support-dot');
            dot.style.setProperty('--support-color', stageColor(stageId));
            dot.setAttribute('aria-hidden', 'true');
            badge.append(dot);
          }
        }
        badge.dataset.completionStatus = graphDiscontinued ? 'discontinued' : complete ? 'complete' : 'incomplete';
        const mappingTitle = selectedMatch
          ? 'Mapped to selected delivery slice ' + selected.id + ' (' + selected.status + ')'
          : stageMatch
            ? 'Mapped to selected delivery stage ' + filter + ' (' + selectedStage().status + ')'
          : own.primary
            ? 'Primary ' + own.primary + ' (' + stages.get(own.primary).status + '); supporting ' + (own.supporting.join(', ') || 'none')
            : node.sublabel;
        badge.title = graphDiscontinued ? 'Discontinued Task; ' + mappingTitle : mappingTitle;
      });
      const visibleDependencyEdgeIds = new Set(selectedSlice()?.visibleDependencyEdgeIds || selectedStage()?.visibleDependencyEdgeIds || []);
      const renderedEdges = new Map([...document.querySelectorAll('.react-flow__edge')].flatMap(rendered => {
        const label = rendered.getAttribute('aria-label') || '';
        const endpoints = label.match(/^Edge from (.+) to (.+)$/);
        if (!endpoints) return [];
        const kind = rendered.textContent.trim() === 'requires' ? 'dependency' : 'structure';
        return [[kind + ':' + endpoints[1] + ':' + endpoints[2], rendered]];
      }));
      human.graph.edges.forEach(edge => {
        const rendered = renderedEdges.get(edge.id);
        if (!rendered) return;
        const target = nodes.get(edge.target);
        if (!target) return;
        colorEdgeForTarget(rendered, edge, target);
        rendered.classList.remove('impl-edge-muted', 'impl-edge-related', 'impl-edge-governed', 'impl-edge-hidden');
        if (filter === 'all') return;
        if (edge.kind === 'dependency') {
          rendered.classList.add(visibleDependencyEdgeIds.has(edge.id) ? 'impl-edge-related' : 'impl-edge-hidden');
          return;
        }
        const source = nodes.get(edge.source);
        const related = source && target && matchFor(source) === 'primary' && matchFor(target) === 'primary';
        rendered.classList.add(related ? 'impl-edge-related' : 'impl-edge-muted');
      });
      if (selectedId) decorateDetail(document.querySelector('.detail__scroll'), selectedId);
    } finally { decorating = false; }
  };

  const updateStageLane = () => {
    const lane = document.querySelector('.implementation-gate-lane');
    if (!lane) return;
    lane.replaceChildren();
    const visible = filter === 'all' ? plan.stages : [stages.get(filter)];
    for (const stage of visible) {
      if (!stage) continue;
      const section = create('section', 'implementation-stage-section');
      section.style.setProperty('--impl-gate', stageColor(stage.id));
      section.dataset.stageStatus = stage.status;
      const heading = create('div', 'implementation-gate-lane__heading');
      const headingTitle = create('strong', '', displayCode(stage.id) + ' · ' + stage.label + ' · ');
      headingTitle.append(create('span', 'implementation-gate-lane__stage-status', stage.status));
      heading.append(headingTitle, create('span', '', stage.detail));
      const cards = create('div', 'implementation-gate-lane__cards');
      for (const slice of stage.slices) {
        const button = create('button', 'implementation-gate');
        button.type = 'button';
        button.dataset.implementationItem = slice.id;
        button.style.setProperty('--task-depth', String(taskAncestors(slice.id).length));
        button.dataset.ancestorContext = String(workAncestors(selectedItem).includes(slice.id));
        button.dataset.gateStatus = slice.status === 'complete' ? 'accepted' : slice.status;
        button.setAttribute('aria-pressed', String(slice.id === selectedItem));
        button.append(
          create('span', 'implementation-gate__id', displayCode(slice.id)),
          create('span', 'implementation-gate__label', slice.label),
          statusElement('implementation-gate__status', slice.status)
        );
        button.addEventListener('click', () => selectWork(slice.id));
        cards.append(button);
      }
      section.append(heading, cards);
      const selected = slices.get(selectedItem);
      if (selected?.stageId === stage.id) {
        const detail = create('div', 'implementation-gate-lane__detail');
        detail.append(create('strong', '', displayCode(selected.id) + ' · ' + selected.label + ' · ' + statusLabel(selected.status)));
        const definitions = create('dl');
        appendDefinition(definitions, 'Coverage', selected.coverage);
        appendDefinition(definitions, stage.id === 'G' ? 'Decision' : 'Acceptance', selected.acceptance);
        appendDefinition(definitions, 'Stage exit', stage.exit);
        detail.append(definitions);
        section.append(detail);
      } else if (filter === stage.id) {
        const detail = create('div', 'implementation-gate-lane__detail');
        detail.append(create('strong', '', displayCode(stage.id) + ' · ' + stage.label + ' · ' + statusLabel(stage.status)));
        const definitions = create('dl');
        appendDefinition(definitions, 'Coverage', stage.coverage);
        appendDefinition(definitions, 'Stage exit', stage.exit);
        detail.append(definitions);
        section.append(detail);
      }
      lane.append(section);
    }
    if (!visible.length) lane.append(create('p', '', 'No Workstreams or Tasks have been added to this Objective yet.'));
  };

  const updateLive = () => {
    const live = document.querySelector('.implementation-live');
    if (!live) return;
    live.replaceChildren();
    const text = create('span');
    text.append(create('span', 'implementation-live__eyebrow', 'Viewing'), document.createTextNode(' '));
    const selected = slices.get(selectedItem);
    const viewing = filter === 'all'
      ? 'all ' + slices.size + ' implementation slices'
      : selected
        ? displayCode(selected.id) + ' · ' + selected.label
        : displayCode(filter) + ' · ' + stages.get(filter).label;
    text.append(create('strong', '', viewing));
    text.append(document.createTextNode(plan.currentStage && plan.currentSlice
      ? ' · progress remains ' + displayCode(plan.currentStage) + ' / ' + displayCode(plan.currentSlice) + '.'
      : ' · no Current Work is projected for this session.'));
    const link = create('a', 'implementation-live__plan', 'Plan overview ↗');
    link.href = planHref();
    link.target = '_blank';
    link.rel = 'noreferrer';
    live.append(text, link);
  };

  const updateControls = () => {
    if (!plan) {
      decorateActiveSurface();
      return;
    }
    document.documentElement.dataset.manifestFilter = filter;
    document.documentElement.dataset.manifestLayout = 'side';
    document.documentElement.style.setProperty('--impl-current', stageColor(plan.currentStage || filter));
    document.querySelectorAll('[data-implementation-stream]').forEach(button =>
      button.setAttribute('aria-pressed', String(button.dataset.implementationStream === filter)));
    updateStageLane();
    updateLive();
    ensureSurfaceSwitch();
    decorateActiveSurface();
    save();
  };
  const setItem = id => {
    const slice = slices.get(id);
    if (!slice) return;
    selectedItem = id;
    selectedId = nodes.has(id) ? id : null;
    filter = slice.stageId;
    replaceQuery({ stream: filter, item: id, surface: null });
    updateControls();
  };
  const setFilter = id => {
    if (id !== 'all' && !stages.has(id)) return;
    filter = id;
    selectedItem = null;
    selectedId = nodes.has(id) ? id : null;
    replaceQuery({ stream: id, item: null, surface: null });
    updateControls();
  };
  const selectWork = (id, toggleDetail = false) => {
    if (slices.has(id)) setItem(id);
    else if (stages.has(id) || id === 'all') setFilter(id);
    else if (nodes.has(id)) {
      selectedId = id;
      selectedItem = null;
      filter = nodes.get(id).kind === 'objective' ? 'all' : ownership.get(id)?.primary || 'all';
      replaceQuery({ stream: filter, item: null, surface: null });
      updateControls();
    } else return;
    // Project one activation into the renderer's existing detail/expansion state.
    window.dispatchEvent(new CustomEvent('manifest-work-selection', {
      detail: {
        id: id === 'all' ? null : id,
        ancestors: workAncestors(id),
        ...(toggleDetail ? { toggleDetail: true } : {})
      }
    }));
  };
  const makeStep = stage => {
    const button = create('button', 'implementation-step');
    button.type = 'button';
    button.dataset.implementationStream = stage.id;
    button.dataset.progressStatus = stage.status;
    button.style.setProperty('--implementation-color', stageColor(stage.id));
    button.append(
      create('span', 'implementation-step__marker', markerFor(stage.status)),
      create('span', '', displayCode(stage.id)),
      create('span', 'implementation-step__progress', stage.status)
    );
    button.setAttribute('aria-label', displayCode(stage.id) + ' ' + stage.label + ', ' + stage.status);
    button.title = stage.label + ' · ' + stage.status;
    button.addEventListener('click', () => selectWork(stage.id));
    return button;
  };

  const buildShell = () => {
    if (!plan) return true;
    if (shellReady && document.querySelector('.manifest-view-shell')) return true;
    const flow = document.querySelector('.lg-flow');
    if (!flow) return false;
    const shell = create('div', 'manifest-view-shell');
    shell.id = 'manifest-progress-panel';
    shell.dataset.testid = 'manifest-progress-rail';
    const lane = create('section', 'implementation-gate-lane');
    lane.setAttribute('aria-label', 'Implementation work detail');
    lane.setAttribute('aria-live', 'polite');
    const bar = create('div', 'implementation-bar');
    const heading = create('div', 'implementation-progress-heading');
    heading.append(
      create('span', '', 'Implementation progress'),
      create('strong', '', plan.currentStage && plan.currentSlice
        ? displayCode(plan.currentStage) + ' · ' + displayCode(plan.currentSlice) + ' active'
        : 'No Current Work')
    );
    const sequence = create('div', 'implementation-sequence');
    const all = create('button', 'implementation-step');
    all.type = 'button';
    all.dataset.implementationStream = 'all';
    all.style.setProperty('--implementation-color', 'var(--text)');
    all.append(create('span', 'implementation-step__marker', '◇'), create('span', '', 'All'), create('span', 'implementation-step__progress', 'inspect'));
    all.setAttribute('aria-label', 'Inspect all implementation coverage');
    all.addEventListener('click', () => selectWork('all'));
    sequence.append(all);
    plan.sequence.forEach((group, index) => {
      sequence.append(create('span', 'implementation-sequence__arrow', '→'));
      if (group.length === 1) {
        sequence.append(makeStep(stages.get(group[0])));
      } else {
        const parallel = create('span', 'implementation-sequence__parallel');
        group.forEach((id, groupIndex) => {
          if (groupIndex > 0) parallel.append(create('span', 'implementation-sequence__arrow', '+'));
          parallel.append(makeStep(stages.get(id)));
        });
        sequence.append(parallel);
      }
    });
    const live = create('div', 'implementation-live');
    live.setAttribute('aria-live', 'polite');
    bar.append(heading, sequence, live);
    shell.append(bar, lane);
    flow.append(shell);
    shellReady = true;
    ensureSurfaceSwitch();
    updateControls();
    return true;
  };

  const buildPlanOverview = () => {
    document.documentElement.dataset.manifestSurface = 'plan';
    document.title = human.objective.title + ' — implementation plan overview';
    const overview = create('main', 'plan-overview');
    overview.dataset.testid = 'manifest-plan-overview';
    const header = create('header', 'plan-overview__header');
    const intro = create('div');
    intro.append(
      create('div', 'plan-overview__eyebrow', human.objective.title + ' · implementation plan'),
      create('h1', '', 'From accepted Objective to working product'),
      create('p', 'plan-overview__lede', human.objective.outcome)
    );
    const actions = create('nav', 'plan-overview__actions');
    actions.setAttribute('aria-label', 'Plan actions');
    const graphLink = create('a', '', 'Open current graph ↗');
    graphLink.href = graphHref();
    const objectivesLink = create('a', 'ctl', 'All Objectives');
    objectivesLink.href = '/objectives';
    objectivesLink.dataset.manifestObjectivesLink = '';
    actions.append(objectivesLink, graphLink);
    header.append(intro, actions);
    const flow = create('section', 'plan-overview__flow');
    flow.setAttribute('aria-label', 'Implementation sequence');
    plan.sequence.forEach((group, index) => {
      if (index > 0) flow.append(create('span', 'plan-overview__flow-arrow', '→'));
      const container = group.length > 1 ? create('div', 'plan-overview__flow-parallel') : flow;
      for (const id of group) {
        const stage = stages.get(id);
        const step = create('div', 'plan-overview__flow-step');
        step.style.setProperty('--stage-color', stageColor(id));
        step.dataset.stageStatus = stage.status;
        step.append(create('strong', '', displayCode(id) + ' · ' + stage.label), create('span', '', stage.status));
        container.append(step);
      }
      if (container !== flow) flow.append(container);
    });
    const grid = create('section', 'plan-overview__grid');
    for (const stage of plan.stages) {
      const details = create('details', 'plan-stage');
      details.style.setProperty('--stage-color', stageColor(stage.id));
      details.dataset.stageStatus = stage.status;
      details.open = stage.status === 'current';
      const summary = create('summary');
      summary.append(
        create('span', 'plan-stage__id', displayCode(stage.id)),
        create('span', 'plan-stage__name', stage.label),
        create('span', 'plan-stage__status', stage.status)
      );
      const body = create('div', 'plan-stage__body');
      const coverage = create('p', 'plan-stage__meta');
      coverage.append(create('strong', '', 'Coverage: '), document.createTextNode(stage.coverage));
      const items = create('div', 'plan-stage__items');
      for (const slice of stage.slices) {
        const link = create('a', 'plan-item');
        link.href = graphHref(stage.id, slice.id);
        link.dataset.itemStatus = slice.status;
        link.append(
          create('span', 'plan-item__id', displayCode(slice.id)),
          create('span', '', slice.label),
          statusElement('plan-item__status', slice.status),
          create('span', 'plan-item__coverage', slice.coverage)
        );
        items.append(link);
      }
      const exit = create('p', 'plan-stage__exit');
      exit.append(create('strong', '', 'Stage exit: '), document.createTextNode(stage.exit));
      body.append(coverage, items, exit);
      details.append(summary, body);
      grid.append(details);
    }
    const scenario = create('section', 'plan-overview__scenario');
    scenario.append(create('h2', '', 'End-to-end proof'));
    const steps = create('ol');
    for (const item of plan.scenario) steps.append(create('li', '', item));
    scenario.append(plan.scenario.length ? steps : create('p', '', 'No end-to-end proof has been recorded for this Objective.'));
    overview.append(header, flow, grid, scenario);
    document.body.append(overview);
  };

  if (implementationAvailable && plan && requested.get('surface') === 'plan') {
    buildPlanOverview();
    return;
  }

  startPlanningSurface();
  const decorateActiveSurface = () => {
    if (surface === 'planning') applyPlanningOverlay();
    else decorate();
    document.documentElement.dataset.manifestSelection = String(selectedId !== null);
    const highlighted = highlightedNodeIds();
    document.querySelectorAll('.react-flow__node[data-id]').forEach(element => {
      const id = element.getAttribute('data-id').replace(/^__lens_detail__:/, '');
      element.dataset.manifestLineage = String(highlighted.has(id));
    });
  };
  document.addEventListener('click', event => {
    const rendered = event.target.closest?.('.react-flow__node[data-id]');
    const id = rendered?.getAttribute('data-id');
    if (id && nodes.has(id)) {
      if (!event.target.closest?.('[data-lens-expand]')) selectWork(id, true);
    }
  }, true);
  applySurface = () => {
    document.documentElement.dataset.manifestSurface = surface;
    document.documentElement.dataset.manifestView = surface;
    if (surface === 'implementation') {
      const title = document.querySelector('.lg-title');
      if (title) title.textContent = human.objective.title + ' · ' + implementationLabel;
      updateControls();
    } else {
      decorateActiveSurface();
    }
    ensureSurfaceSwitch();
    positionDetailPanel();
  };
  const observer = new MutationObserver(() => {
    if (!buildShell()) return;
    normalizeSharedCards();
    decorateActiveSurface();
    ensureSurfaceSwitch();
  });
  observer.observe(document.getElementById('root'), { childList: true, subtree: true });
  normalizeSharedCards();
  buildShell();
  applySurface();
})();
</script>`;
}

function taskState(task: DerivedTask, nextTaskId: TaskId | undefined): HumanNodeState {
  if (task.current) return "current";
  if (task.complete) return "complete";
  if (task.discontinued) return "discontinued";
  if (task.id === nextTaskId) return "next";
  if (task.available) return "available";
  if (task.externalBlocker !== null || task.prerequisites.some((item) => !item.complete)) return "blocked";
  return "planning";
}

function workstreamState(complete: boolean, tasks: readonly DerivedTask[]): HumanNodeState {
  if (complete) return "complete";
  if (tasks.some((task) => task.current)) return "current";
  if (tasks.some((task) => task.available)) return "available";
  return "planning";
}

function objectiveState(graph: ObjectiveGraph, view: ObjectiveView): HumanNodeState {
  if (view.progress.complete) return "complete";
  if (view.current !== null) return "current";
  return graph.phase === "planning" ? "planning" : "available";
}

function progressSummary(view: ObjectiveView): string {
  const completed = view.progress.workstreams.reduce((sum, item) => sum + item.completed, 0);
  const required = view.progress.workstreams.reduce((sum, item) => sum + item.required, 0);
  return `${completed}/${required} required Tasks complete`;
}

function joinDetails(outcome: string, details: string): string {
  return details.length === 0 ? outcome : `${outcome}\n\n${details}`;
}

function capitalize(value: string): string {
  return value.charAt(0).toUpperCase() + value.slice(1);
}

function safeJson(value: unknown): string {
  return JSON.stringify(value).replaceAll("<", "\\u003c").replaceAll("\u2028", "\\u2028").replaceAll("\u2029", "\\u2029");
}

function escapeHtml(value: string): string {
  return value.replace(/[&<>"']/g, (character) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;",
  })[character]!);
}

function json(response: import("node:http").ServerResponse, status: number, value: unknown): void {
  const body = `${JSON.stringify(value)}\n`;
  response.writeHead(status, { "content-type": "application/json; charset=utf-8", "content-length": Buffer.byteLength(body), "cache-control": "no-store" });
  response.end(body);
}

function html(response: import("node:http").ServerResponse, status: number, body: string): void {
  response.writeHead(status, { "content-type": "text/html; charset=utf-8", "content-length": Buffer.byteLength(body), "cache-control": "no-store" });
  response.end(body);
}

function listen(server: Server, port: number, host: string): Promise<void> {
  return new Promise((resolvePromise, reject) => {
    server.once("error", reject);
    server.listen(port, host, () => {
      server.off("error", reject);
      resolvePromise();
    });
  });
}

function closeServer(server: Server): Promise<void> {
  return new Promise((resolvePromise, reject) => server.close((error) => error === undefined ? resolvePromise() : reject(error)));
}

function formatHost(host: string): string {
  return host.includes(":") ? `[${host}]` : host;
}
