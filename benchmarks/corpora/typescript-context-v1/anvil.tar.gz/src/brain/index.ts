import { createHash } from "node:crypto";
import { constants as fsConstants } from "node:fs";
import { access, appendFile, lstat, mkdir, readdir, readFile, rename, rm, writeFile } from "node:fs/promises";
import { homedir } from "node:os";
import { dirname, join, parse, relative, resolve, sep } from "node:path";
import { setTimeout as sleep } from "node:timers/promises";
import { z } from "zod";

import {
  agentConfigPath,
  defaultWikiAlias,
  resolveAgentIdentity,
  resolveAnvilHome,
  resolveBrainRoot,
} from "../config/index.ts";

export type BrainSetupMode = "dry_run" | "apply";
export type BrainSetupStatus = "planned" | "created" | "already_configured" | "repaired_missing_files" | "refused";
export type BrainSetupErrorCode =
  | "VALIDATION_ERROR"
  | "RUNTIME_AGENT_ID_MISSING"
  | "RUNTIME_AGENT_ID_MISMATCH"
  | "UNSAFE_TARGET_PATH"
  | "OWNERSHIP_MARKER_MISMATCH"
  | "SETUP_LOCKED"
  | "SETUP_PLAN_CONFLICT"
  | "SETUP_PARTIAL"
  | "SETUP_DRIFT_REFUSED"
  | "INTERNAL_ERROR";

export class BrainSetupError extends Error {
  code: BrainSetupErrorCode;

  constructor(code: BrainSetupErrorCode, message: string) {
    super(`${code}: ${message}`);
    this.name = "BrainSetupError";
    this.code = code;
  }
}

export type BrainSetupInput = {
  agentId?: string;
  anvilHome?: string;
  brainRoot?: string;
  wikiAlias?: string;
  mode?: BrainSetupMode;
  planHash?: string;
  acknowledgement?: string;
  env?: Record<string, string | undefined>;
  homeDir?: string;
  now?: () => string;
};

export type PlannedWrite = {
  kind: "directory" | "json_file" | "jsonl_file";
  path: string;
  owner: "anvil";
};

export type SetupNotice = {
  code: string;
  severity: "info" | "warning" | "error";
  message: string;
};

export type BrainSetupBrief = {
  purpose: string;
  audience: string;
  authority: string;
  primary_sections: string[];
  raw_sources_policy: string;
  privacy_policy: string;
  agent_runtime?: string;
  wiki_alias?: string;
  target_path?: string;
};

export type LlmWikiSetupAction = {
  kind: "wikime_setup";
  target_path?: string;
  instructions: string[];
};

const brainSetupErrorCodeSchema = z.enum([
  "VALIDATION_ERROR",
  "RUNTIME_AGENT_ID_MISSING",
  "RUNTIME_AGENT_ID_MISMATCH",
  "UNSAFE_TARGET_PATH",
  "OWNERSHIP_MARKER_MISMATCH",
  "SETUP_LOCKED",
  "SETUP_PLAN_CONFLICT",
  "SETUP_PARTIAL",
  "SETUP_DRIFT_REFUSED",
  "INTERNAL_ERROR",
]);

export const setupSuggestedCallSchema = z
  .object({
    tool: z.literal("wiki_register"),
    arguments: z.union([
      z.object({}).strict(),
      z
        .object({
          alias: z.string(),
          path: z.string(),
          created_by: z.literal("anvil"),
        })
        .strict(),
    ]),
    reason: z.string(),
    precondition: z.string().optional(),
  })
  .strict();

export type SetupSuggestedCall = z.infer<typeof setupSuggestedCallSchema>;
type StrictSetupSuggestedCall = SetupSuggestedCall;

export type BrainSetupOutput = {
  status: BrainSetupStatus;
  resolved_agent_id?: string;
  runtime_agent_id?: string;
  target_config_path?: string;
  target_brain_root?: string;
  wiki_alias?: string;
  planned_writes: PlannedWrite[];
  refusals_or_warnings: SetupNotice[];
  brain_setup_brief: BrainSetupBrief;
  llm_wiki_setup_action: LlmWikiSetupAction;
  llm_wiki_registration_call: SetupSuggestedCall;
  plan_hash: string;
  acknowledgement_token: string;
  error?: {
    code: BrainSetupErrorCode;
    message: string;
  };
};

export const plannedWriteSchema = z
  .object({
    kind: z.enum(["directory", "json_file", "jsonl_file"]),
    path: z.string(),
    owner: z.literal("anvil"),
  })
  .strict();

export const setupNoticeSchema = z
  .object({
    code: z.string(),
    severity: z.enum(["info", "warning", "error"]),
    message: z.string(),
  })
  .strict();

export const brainSetupBriefSchema = z
  .object({
    purpose: z.string(),
    audience: z.string(),
    authority: z.string(),
    primary_sections: z.array(z.string()),
    raw_sources_policy: z.string(),
    privacy_policy: z.string(),
    agent_runtime: z.string().optional(),
    wiki_alias: z.string().optional(),
    target_path: z.string().optional(),
  })
  .strict();

export const llmWikiSetupActionSchema = z
  .object({
    kind: z.literal("wikime_setup"),
    target_path: z.string().optional(),
    instructions: z.array(z.string()),
  })
  .strict();

export const brainSetupOutputSchema = z
  .object({
    status: z.enum(["planned", "created", "already_configured", "repaired_missing_files", "refused"]),
    resolved_agent_id: z.string().optional(),
    runtime_agent_id: z.string().optional(),
    target_config_path: z.string().optional(),
    target_brain_root: z.string().optional(),
    wiki_alias: z.string().optional(),
    planned_writes: z.array(plannedWriteSchema),
    refusals_or_warnings: z.array(setupNoticeSchema),
    brain_setup_brief: brainSetupBriefSchema,
    llm_wiki_setup_action: llmWikiSetupActionSchema,
    llm_wiki_registration_call: setupSuggestedCallSchema,
    plan_hash: z.string(),
    acknowledgement_token: z.string(),
    error: z
      .object({
        code: brainSetupErrorCodeSchema,
        message: z.string(),
      })
      .strict()
      .optional(),
    // These planning fields are present in successful dry-run/apply values even
    // though callers only rely on the public BrainSetupOutput projection.
    agent_dir: z.string().optional(),
    setup_state_path: z.string().optional(),
    setup_log_path: z.string().optional(),
    anvil_home: z.string().optional(),
  })
  .strict();

type Assert<T extends true> = T;
type BrainSetupSchemaProducesOutput = Assert<z.infer<typeof brainSetupOutputSchema> extends BrainSetupOutput ? true : false>;

type BrainSetupPlan = BrainSetupOutput & {
  agent_dir: string;
  setup_state_path: string;
  setup_log_path: string;
  anvil_home: string;
};

type ExistingConfig = {
  agent_id: string;
  brain_root: string;
  wiki_alias: string;
};

const WIKI_ALIAS_PATTERN = /^[a-z0-9][a-z0-9_-]{0,95}$/;
const LOCK_TIMEOUT_MS = 5_000;
const LOCK_RETRY_MS = 25;

function isNodeError(error: unknown): error is NodeJS.ErrnoException {
  return typeof error === "object" && error !== null && "code" in error;
}

function validateWikiAlias(value: string): string {
  if (!WIKI_ALIAS_PATTERN.test(value)) {
    throw new BrainSetupError(
      "VALIDATION_ERROR",
      "wikiAlias must use 1-96 lowercase letters, numbers, underscores, or hyphens, and start with a letter or number",
    );
  }
  return value;
}

function nowIso(input: BrainSetupInput): string {
  return input.now?.() ?? new Date().toISOString();
}

function setupBrief(agentId: string | undefined, wikiAlias: string | undefined, brainRoot: string | undefined): BrainSetupBrief {
  return {
    purpose: "Agent-owned Brain wiki for durable synthesized memory.",
    audience: "One agent runtime plus Vik inspecting and correcting it.",
    authority:
      "Memory/context only; current instructions, repo files, command output, tests, live tool results, and repo docs outrank Brain memory.",
    primary_sections: ["projects", "work-history", "self-model", "patterns", "entities", "sources", "review-feed", "hygiene-log"],
    raw_sources_policy: "Link or summarize; do not copy raw runtime session stores.",
    privacy_policy: "No secrets, credentials, raw private transcripts, or sensitive details unless explicitly justified and safely summarized.",
    ...(agentId ? { agent_runtime: agentId } : {}),
    ...(wikiAlias ? { wiki_alias: wikiAlias } : {}),
    ...(brainRoot ? { target_path: brainRoot } : {}),
  };
}

function llmWikiSetupAction(brainRoot: string | undefined): LlmWikiSetupAction {
  return {
    kind: "wikime_setup",
    ...(brainRoot ? { target_path: brainRoot } : {}),
    instructions: [
      "Enter the target Brain root directory.",
      "Run the existing /wikime setup workflow.",
      "Answer setup questions from the Brain setup brief; inspect llm-wiki context if unclear.",
      "Let llm-wiki own scaffold files, wiki-agent.md conventions, lint, render, and doctor behavior.",
    ],
  };
}

function registrationCall(wikiAlias: string | undefined, brainRoot: string | undefined): StrictSetupSuggestedCall {
  return {
    tool: "wiki_register",
    arguments: wikiAlias && brainRoot ? { alias: wikiAlias, path: brainRoot, created_by: "anvil" } : {},
    reason: "Register the Brain wiki with the current agent runtime after /wikime creates the scaffold.",
    precondition: "Only run after the Brain root contains a valid llm-wiki scaffold.",
  };
}

function refused(code: BrainSetupErrorCode, message: string): BrainSetupOutput {
  return {
    status: "refused",
    planned_writes: [],
    refusals_or_warnings: [{ code, severity: "error", message }],
    brain_setup_brief: setupBrief(undefined, undefined, undefined),
    llm_wiki_setup_action: llmWikiSetupAction(undefined),
    llm_wiki_registration_call: registrationCall(undefined, undefined),
    plan_hash: "",
    acknowledgement_token: "",
    error: { code, message },
  };
}

function hashPlan(material: object): string {
  return createHash("sha256").update(JSON.stringify(material)).digest("hex");
}

function acknowledgementFor(planHash: string): string {
  return `ack-anvil-brain-${planHash.slice(0, 16)}`;
}

function buildPlan(input: BrainSetupInput): BrainSetupPlan | BrainSetupOutput {
  const identity = resolveAgentIdentity({ agentId: input.agentId, env: input.env });
  if (identity.status === "missing") {
    return refused("RUNTIME_AGENT_ID_MISSING", "ANVIL_AGENT_ID or agentId is required to plan Brain setup.");
  }
  if (identity.status === "mismatch") {
    return refused("RUNTIME_AGENT_ID_MISMATCH", "Caller-supplied agentId does not match ANVIL_AGENT_ID.");
  }
  if (!identity.resolvedAgentId) {
    return refused("RUNTIME_AGENT_ID_MISSING", "Could not resolve an agent id for Brain setup.");
  }

  const homeDir = input.homeDir ?? input.env?.HOME ?? process.env.HOME ?? homedir();
  const anvilHome = resolveAnvilHome({ anvilHome: input.anvilHome, env: input.env, homeDir });
  const brainRoot = resolveBrainRoot({ agentId: identity.resolvedAgentId, brainRoot: input.brainRoot, homeDir });
  const wikiAlias = validateWikiAlias(input.wikiAlias ?? defaultWikiAlias(identity.resolvedAgentId));
  const targetConfigPath = agentConfigPath(anvilHome, identity.resolvedAgentId);
  const agentDir = dirname(targetConfigPath);
  const setupStatePath = join(agentDir, "setup-state.json");
  const setupLogPath = join(agentDir, "setup-log.jsonl");
  const plannedWrites: PlannedWrite[] = [
    { kind: "directory", path: anvilHome, owner: "anvil" },
    { kind: "directory", path: agentDir, owner: "anvil" },
    { kind: "directory", path: brainRoot, owner: "anvil" },
    { kind: "json_file", path: targetConfigPath, owner: "anvil" },
    { kind: "json_file", path: setupStatePath, owner: "anvil" },
    { kind: "jsonl_file", path: setupLogPath, owner: "anvil" },
  ];

  const material = {
    schema_version: 1,
    agent_id: identity.resolvedAgentId,
    anvil_home: anvilHome,
    brain_root: brainRoot,
    wiki_alias: wikiAlias,
    planned_writes: plannedWrites,
  };
  const planHash = hashPlan(material);

  return {
    status: "planned",
    resolved_agent_id: identity.resolvedAgentId,
    ...(identity.runtimeAgentId ? { runtime_agent_id: identity.runtimeAgentId } : {}),
    target_config_path: targetConfigPath,
    target_brain_root: brainRoot,
    wiki_alias: wikiAlias,
    planned_writes: plannedWrites,
    refusals_or_warnings: [],
    brain_setup_brief: setupBrief(identity.resolvedAgentId, wikiAlias, brainRoot),
    llm_wiki_setup_action: llmWikiSetupAction(brainRoot),
    llm_wiki_registration_call: registrationCall(wikiAlias, brainRoot),
    plan_hash: planHash,
    acknowledgement_token: acknowledgementFor(planHash),
    agent_dir: agentDir,
    setup_state_path: setupStatePath,
    setup_log_path: setupLogPath,
    anvil_home: anvilHome,
  };
}

async function readExistingConfig(path: string): Promise<ExistingConfig | undefined> {
  let text;
  try {
    text = await readFile(path, "utf8");
  } catch (error) {
    if (isNodeError(error) && error.code === "ENOENT") return undefined;
    const message = error instanceof Error ? error.message : String(error);
    throw new BrainSetupError("SETUP_PARTIAL", `Could not read existing Brain config: ${message}`);
  }

  try {
    const parsed = JSON.parse(text) as Record<string, unknown>;
    if (typeof parsed.agent_id !== "string" || typeof parsed.brain_root !== "string" || typeof parsed.wiki_alias !== "string") {
      throw new Error("config is missing required fields");
    }
    return {
      agent_id: parsed.agent_id,
      brain_root: resolve(parsed.brain_root),
      wiki_alias: parsed.wiki_alias,
    };
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    throw new BrainSetupError("SETUP_PARTIAL", `Existing Brain config is malformed: ${message}`);
  }
}

async function pathExists(path: string): Promise<boolean> {
  try {
    await access(path, fsConstants.F_OK);
    return true;
  } catch {
    return false;
  }
}

function isInside(parent: string, child: string): boolean {
  const rel = relative(resolve(parent), resolve(child));
  return rel === "" || (rel.length > 0 && !rel.startsWith("..") && !rel.includes(`..${sep}`));
}

async function assertNoSymlinkAncestors(target: string): Promise<void> {
  const parsed = parse(target);
  const rel = relative(parsed.root, target);
  let current = parsed.root;
  for (const part of rel.split(sep).filter(Boolean)) {
    current = join(current, part);
    try {
      const item = await lstat(current);
      if (item.isSymbolicLink()) throw new BrainSetupError("UNSAFE_TARGET_PATH", `Refusing symlink target or ancestor: ${current}`);
      if (!item.isDirectory() && current !== target) {
        throw new BrainSetupError("UNSAFE_TARGET_PATH", `Refusing target under non-directory path: ${current}`);
      }
    } catch (error) {
      if (error instanceof BrainSetupError) throw error;
      if (isNodeError(error) && error.code === "ENOENT") return;
      const message = error instanceof Error ? error.message : String(error);
      throw new BrainSetupError("UNSAFE_TARGET_PATH", `Could not inspect target path ${current}: ${message}`);
    }
  }
}

async function assertSafeBrainRoot(plan: BrainSetupPlan, existingConfig: ExistingConfig | undefined): Promise<void> {
  if (!plan.target_brain_root) throw new BrainSetupError("VALIDATION_ERROR", "target Brain root is missing from setup plan");
  const brainRoot = resolve(plan.target_brain_root);
  if (brainRoot === parse(brainRoot).root) throw new BrainSetupError("UNSAFE_TARGET_PATH", "Refusing to use filesystem root as Brain root");
  if (isInside(plan.anvil_home, brainRoot)) {
    throw new BrainSetupError("UNSAFE_TARGET_PATH", "Brain root must not be inside Anvil's private config directory");
  }

  await assertNoSymlinkAncestors(brainRoot);

  try {
    const item = await lstat(brainRoot);
    if (item.isSymbolicLink()) throw new BrainSetupError("UNSAFE_TARGET_PATH", `Refusing symlink Brain root: ${brainRoot}`);
    if (!item.isDirectory()) throw new BrainSetupError("UNSAFE_TARGET_PATH", `Brain root exists but is not a directory: ${brainRoot}`);

    const entries = await readdir(brainRoot);
    if (entries.length > 0 && !(await pathExists(join(brainRoot, "wiki-agent.md"))) && !existingConfig) {
      throw new BrainSetupError("UNSAFE_TARGET_PATH", "Refusing non-empty Brain root without an existing wiki-agent.md or Anvil config");
    }
  } catch (error) {
    if (error instanceof BrainSetupError) throw error;
    if (isNodeError(error) && error.code === "ENOENT") return;
    const message = error instanceof Error ? error.message : String(error);
    throw new BrainSetupError("UNSAFE_TARGET_PATH", `Could not inspect Brain root: ${message}`);
  }
}

async function writeJsonAtomic(path: string, value: unknown): Promise<void> {
  await mkdir(dirname(path), { recursive: true });
  const tempPath = `${path}.${process.pid}.${Date.now()}.tmp`;
  await writeFile(tempPath, `${JSON.stringify(value, null, 2)}\n`, "utf8");
  await rename(tempPath, path);
}

async function appendJsonLine(path: string, value: unknown): Promise<void> {
  await mkdir(dirname(path), { recursive: true });
  await appendFile(path, `${JSON.stringify(value)}\n`, "utf8");
}

async function withSetupLock<T>(plan: BrainSetupPlan, mutation: () => Promise<T>): Promise<T> {
  if (!plan.resolved_agent_id) throw new BrainSetupError("RUNTIME_AGENT_ID_MISSING", "Cannot acquire setup lock without agent id");
  const lockPath = join(plan.anvil_home, "locks", `${plan.resolved_agent_id}.brain-setup.lock`);
  const deadline = Date.now() + LOCK_TIMEOUT_MS;
  await mkdir(dirname(lockPath), { recursive: true });

  while (true) {
    try {
      await mkdir(lockPath);
      break;
    } catch (error) {
      if (!isNodeError(error) || error.code !== "EEXIST") {
        const message = error instanceof Error ? error.message : String(error);
        throw new BrainSetupError("SETUP_LOCKED", `Could not acquire setup lock: ${message}`);
      }
      if (Date.now() >= deadline) throw new BrainSetupError("SETUP_LOCKED", `Timed out acquiring setup lock at ${lockPath}`);
      await sleep(LOCK_RETRY_MS);
    }
  }

  try {
    await writeJsonAtomic(join(lockPath, "owner.json"), {
      pid: process.pid,
      agent_id: plan.resolved_agent_id,
      acquired_at: new Date().toISOString(),
    });
    return await mutation();
  } finally {
    await rm(lockPath, { recursive: true, force: true });
  }
}

function assertMatchingExistingConfig(plan: BrainSetupPlan, existingConfig: ExistingConfig): void {
  if (
    existingConfig.agent_id !== plan.resolved_agent_id ||
    resolve(existingConfig.brain_root) !== resolve(plan.target_brain_root ?? "") ||
    existingConfig.wiki_alias !== plan.wiki_alias
  ) {
    throw new BrainSetupError("SETUP_PLAN_CONFLICT", "Existing Brain config does not match the requested setup plan");
  }
}

async function applyPlan(plan: BrainSetupPlan, input: BrainSetupInput): Promise<BrainSetupOutput> {
  if (!plan.runtime_agent_id) {
    throw new BrainSetupError("RUNTIME_AGENT_ID_MISSING", "Setup apply requires ANVIL_AGENT_ID for this agent runtime.");
  }
  if (input.planHash !== plan.plan_hash) {
    throw new BrainSetupError("SETUP_PLAN_CONFLICT", "Setup apply requires the current dry-run plan hash.");
  }
  if (input.acknowledgement !== plan.acknowledgement_token) {
    throw new BrainSetupError("SETUP_PLAN_CONFLICT", "Setup apply requires the acknowledgement token from the current dry run.");
  }

  return withSetupLock(plan, async () => {
    const refreshed = buildPlan(input);
    if (refreshed.status === "refused") {
      throw new BrainSetupError(refreshed.error?.code ?? "SETUP_DRIFT_REFUSED", refreshed.error?.message ?? "Setup plan drifted");
    }
    const refreshedPlan = refreshed as BrainSetupPlan;
    if (refreshedPlan.plan_hash !== plan.plan_hash || refreshedPlan.acknowledgement_token !== plan.acknowledgement_token) {
      throw new BrainSetupError("SETUP_DRIFT_REFUSED", "Setup inputs changed after dry run.");
    }

    const existingConfig = await readExistingConfig(refreshedPlan.target_config_path ?? "");
    await assertSafeBrainRoot(refreshedPlan, existingConfig);

    if (existingConfig) {
      assertMatchingExistingConfig(refreshedPlan, existingConfig);
      if (refreshedPlan.target_brain_root) await mkdir(refreshedPlan.target_brain_root, { recursive: true });
      return { ...refreshedPlan, status: "already_configured" };
    }

    await mkdir(refreshedPlan.agent_dir, { recursive: true });
    if (refreshedPlan.target_brain_root) await mkdir(refreshedPlan.target_brain_root, { recursive: true });

    const timestamp = nowIso(input);
    await writeJsonAtomic(refreshedPlan.target_config_path ?? "", {
      schema_version: 1,
      agent_id: refreshedPlan.resolved_agent_id,
      brain_root: refreshedPlan.target_brain_root,
      wiki_alias: refreshedPlan.wiki_alias,
      created_at: timestamp,
      updated_at: timestamp,
    });
    await writeJsonAtomic(refreshedPlan.setup_state_path, {
      schema_version: 1,
      agent_id: refreshedPlan.resolved_agent_id,
      state: "complete",
      plan_hash: refreshedPlan.plan_hash,
      history: ["planning", "writing_config", "prepared_wiki_setup", "verifying", "complete"],
      updated_at: timestamp,
    });
    await appendJsonLine(refreshedPlan.setup_log_path, {
      timestamp,
      status: "created",
      agent_id: refreshedPlan.resolved_agent_id,
      plan_hash: refreshedPlan.plan_hash,
    });

    return { ...refreshedPlan, status: "created" };
  });
}

export async function setupBrain(input: BrainSetupInput = {}): Promise<BrainSetupOutput> {
  const mode = input.mode ?? "dry_run";
  const plan = buildPlan(input);
  if (plan.status === "refused") {
    if (mode === "apply") {
      throw new BrainSetupError(plan.error?.code ?? "VALIDATION_ERROR", plan.error?.message ?? "Brain setup refused");
    }
    return plan;
  }
  if (mode === "dry_run") return plan;
  return applyPlan(plan as BrainSetupPlan, input);
}
