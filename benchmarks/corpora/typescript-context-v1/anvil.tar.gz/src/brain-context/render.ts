import type { BrainContextDiagnostic } from "./index.ts";
import type { BrainCompiledEvidence, BrainRetrievalResult } from "./retrieve.ts";

export const PROMPT_EVIDENCE_DELIVERY_FORMAT = "anvil_prompt_evidence_v1";

const RETRIEVAL_LIMIT_MESSAGES = {
  unavailable: "Some sources or retrieval providers could not supply evidence; retrieval may be incomplete.",
  problem: "The compiler reported retrieval problems; evidence may be incomplete.",
  budget: "Additional candidate evidence was omitted or shortened to fit the context limit.",
  diagnostics: "Some diagnostic details were not returned; their categories are unavailable here.",
  omissions: "Some omission details were not returned; their reasons are unavailable here.",
} as const;

const EVIDENCE_ROLE_DISCLAIMER =
  "Evidence roles describe retrieval function, not whether this context is sufficient to answer.";

// Local framing, deliberately outside the compiler's closed delivery profile.
// Measure this maximum with the same renderer before assigning its allowance.
export const MAX_RETRIEVAL_LIMIT_SUMMARY = [
  RETRIEVAL_LIMIT_MESSAGES.unavailable,
  RETRIEVAL_LIMIT_MESSAGES.budget,
  RETRIEVAL_LIMIT_MESSAGES.diagnostics,
  RETRIEVAL_LIMIT_MESSAGES.omissions,
].join(" ");

export function compilerHasUnavailableEvidence(diagnostics: BrainRetrievalResult["diagnostics"]): boolean {
  return diagnostics.some(({ code }) =>
    ["SOURCE_PATH_INVALID", "SOURCE_NOT_FOUND", "SOURCE_NOT_TEXT", "PROVIDER_FAILED"].includes(code) ||
    (code.startsWith("LOCI_") &&
      /(?:FAILED|TIMEOUT|UNAVAILABLE|CONFIG_MISSING|NOT_INDEXED|RESULT_INVALID|RESULT_OUT_OF_SCOPE)$/.test(code)),
  );
}

export function compilerRetrievalLimits(retrieval: BrainRetrievalResult): string | undefined {
  const unavailable = compilerHasUnavailableEvidence(retrieval.diagnostics);
  const budgetLimited = retrieval.omissions.some(({ reason }) =>
    ["byte_limit", "content_byte_limit", "delivery_byte_limit", "item_limit"].includes(reason),
  ) || [
    "byte_budget_exhausted", "content_budget_exhausted", "delivery_budget_exhausted", "item_budget_exhausted",
  ].includes(retrieval.stop.reason) || retrieval.evidence.some(({ selectionReasons }) =>
    selectionReasons.some((reason) =>
      ["hard_limit_excerpt", "content_limit_excerpt", "delivered_limit_excerpt"].includes(reason)),
  );
  const messages = [
    ...(unavailable ? [RETRIEVAL_LIMIT_MESSAGES.unavailable]
      : retrieval.stop.reason === "provider_degraded" ? [RETRIEVAL_LIMIT_MESSAGES.problem] : []),
    ...(budgetLimited ? [RETRIEVAL_LIMIT_MESSAGES.budget] : []),
    ...(retrieval.reporting.diagnostics.total > retrieval.reporting.diagnostics.returned
      ? [RETRIEVAL_LIMIT_MESSAGES.diagnostics] : []),
    ...(retrieval.reporting.omissions.total > retrieval.reporting.omissions.returned
      ? [RETRIEVAL_LIMIT_MESSAGES.omissions] : []),
  ];
  return messages.length > 0 ? messages.join(" ") : undefined;
}

/** The compiler's closed delivery-cost profile uses this same projection. */
export function compilerContextDiagnostics(retrieval: BrainRetrievalResult): BrainContextDiagnostic[] {
  const codes = new Set(["PROJECT_IDENTITY_AMBIGUOUS", "PROJECT_IDENTITY_INVALID", "PROJECT_ALIAS_SHADOWED"]);
  const recovery = "Repair the canonical Brain project identity or workspace mapping before relying on project routing.";
  const diagnostics = retrieval.diagnostics
    .filter((diagnostic) => codes.has(diagnostic.code))
    .map((diagnostic) => ({
      code: diagnostic.code as BrainContextDiagnostic["code"],
      message: diagnostic.message,
      recovery,
    }));
  if (retrieval.query.projectResolution?.status === "ambiguous" &&
      !diagnostics.some((diagnostic) => diagnostic.code === "PROJECT_IDENTITY_AMBIGUOUS")) {
    diagnostics.push({
      code: "PROJECT_IDENTITY_AMBIGUOUS",
      message: "llm-wiki reported multiple projects for the observed workspace identity.",
      recovery,
    });
  }
  const temporal = {
    TEMPORAL_HISTORY_INVALID: {
      code: "BRAIN_TEMPORAL_HISTORY_INVALID",
      recovery: "Repair the affected authored history through the wiki Steward; do not use its prose as a settled temporal answer.",
    },
    TEMPORAL_CONFLICT: {
      code: "BRAIN_TEMPORAL_UNCERTAIN",
      recovery: "Use the existing conflict view and inspect the competing claims; do not choose a settled winner from this recall.",
    },
    TEMPORAL_STATE_UNCERTAIN: {
      code: "BRAIN_TEMPORAL_UNCERTAIN",
      recovery: "Use explicit temporal or source follow-up before claiming current or dated applicability; do not invent missing times.",
    },
  } as const;
  for (const diagnostic of retrieval.diagnostics) {
    const mapped = temporal[diagnostic.code as keyof typeof temporal];
    if (mapped) diagnostics.push({ ...mapped, message: diagnostic.message });
  }
  return diagnostics;
}

export function renderCompilerPromptEvidenceContext(retrieval: BrainRetrievalResult): PromptBrainContextRender {
  const resolution = retrieval.contractVersion === "3" ? retrieval.query.projectResolution : undefined;
  return renderPromptEvidenceContext({
    matchedProject: resolution?.status === "matched" ? resolution.page : undefined,
    includeRoute: true,
    diagnostics: retrieval.contractVersion === "3" ? compilerContextDiagnostics(retrieval) : [],
    temporal: retrieval.query.temporal,
    evidence: retrieval.evidence,
    hardBytes: Number.MAX_SAFE_INTEGER,
  });
}

export type PromptEvidenceContextRenderInput = {
  matchedProject?: string;
  includeRoute?: boolean;
  diagnostics?: BrainContextDiagnostic[];
  retrievalLimits?: string;
  includeRoleDisclaimer?: boolean;
  temporal?: BrainRetrievalResult["query"]["temporal"];
  evidence: BrainCompiledEvidence[];
  hardBytes: number;
};

export type BrainContextRender = {
  markdown: string;
  renderedBytes: number;
  truncated: boolean;
};

export type PromptBrainContextRender = BrainContextRender & {
  attemptedBytes: number;
  guidanceBytes: number;
  retrievedContextBytes: number;
  framingBytes: number;
};

export type SessionStartContextRenderInput = {
  continuity: string;
  compactContinuity?: string;
  brain: string;
  hardBytes: number;
};

function evidenceBlock(evidence: BrainCompiledEvidence): string {
  const origin = evidence.page ?? evidence.source ?? evidence.id;
  return [
    `#### \`${origin}\``,
    "",
    evidence.content.trim(),
    "",
    `- evidence_id: \`${evidence.id}\``,
    `- roles: ${evidence.roles.length > 0 ? evidence.roles.map((role) => `\`${role}\``).join(", ") : "none"}`,
  ].join("\n");
}

function section(title: string, body: string): string {
  return [`### ${title}`, "", body].join("\n");
}

function byteLength(value: string): number {
  return Buffer.byteLength(value, "utf8");
}

function truncateUtf8(value: string, maxBytes: number): string {
  if (maxBytes <= 0) return "";
  let bytes = 0;
  let output = "";
  for (const character of value) {
    const characterBytes = byteLength(character);
    if (bytes + characterBytes > maxBytes) break;
    output += character;
    bytes += characterBytes;
  }
  const paragraphBoundary = output.lastIndexOf("\n\n");
  if (paragraphBoundary >= Math.floor(output.length * 0.75)) output = output.slice(0, paragraphBoundary);
  return output.trimEnd();
}

export function renderSessionStartContext(input: SessionStartContextRenderInput): BrainContextRender {
  const continuity = input.continuity.trimEnd();
  const brain = input.brain.trimStart();
  const full = brain.length > 0 ? `${continuity}\n\n${brain}` : continuity;
  if (byteLength(full) <= input.hardBytes) {
    return { markdown: full, renderedBytes: byteLength(full), truncated: false };
  }

  const diagnostic = [
    "## Brain Bootstrap Diagnostic",
    "",
    "- status: degraded",
    "- code: BRAIN_CONTEXT_TRUNCATED",
    "- message: Combined Continuity and Brain context exceeded the reviewed hard byte limit.",
    "- recovery: Reduce the Continuity frame or selected Brain context before raising the reviewed limit.",
  ].join("\n");
  const suffix = `\n\n${diagnostic}`;
  const available = input.hardBytes - byteLength(suffix);
  const fallback = input.compactContinuity?.trimEnd() ?? continuity;
  const markdown =
    available > 0 ? `${truncateUtf8(fallback, available)}${suffix}` : truncateUtf8(diagnostic, input.hardBytes);
  return { markdown, renderedBytes: byteLength(markdown), truncated: true };
}

export function renderPromptEvidenceContext(input: PromptEvidenceContextRenderInput): PromptBrainContextRender {
  const routeRequested =
    input.includeRoute === true ||
    input.evidence.length > 0;
  const diagnosticSections = input.diagnostics ?? [];
  if (input.evidence.length === 0 && !routeRequested && diagnosticSections.length === 0 &&
      !input.retrievalLimits && !input.includeRoleDisclaimer) {
    return {
      markdown: "",
      renderedBytes: 0,
      truncated: false,
      attemptedBytes: 0,
      guidanceBytes: 0,
      retrievedContextBytes: 0,
      framingBytes: 0,
    };
  }

  const relevant =
    input.evidence.length > 0
      ? section("Prompt Evidence", input.evidence.map(evidenceBlock).join("\n\n"))
      : undefined;
  const pages = [...new Set(input.evidence.flatMap((evidence) => (evidence.page ? [evidence.page] : [])))];
  const routes = routeRequested
    ? section(
        "Recall Route",
        [
          `- current_project: ${input.matchedProject ? `\`${input.matchedProject}\`` : "unknown_project"}`,
          "- kernel_pages: none",
          `- evidence_pages: ${pages.length > 0 ? pages.map((page) => `\`${page}\``).join(", ") : "none"}`,
          ...(input.temporal ? [`- temporal_query: ${JSON.stringify({
            view: input.temporal.view,
            request_time: input.temporal.request_time,
            ...(input.temporal.world_at !== undefined ? { world_at: input.temporal.world_at } : {}),
            ...(input.temporal.known_at !== undefined ? { known_at: input.temporal.known_at } : {}),
            ...(input.temporal.transition ? { transition: {
              from: input.temporal.transition.from, to: input.temporal.transition.to,
            } } : {}),
          })}`] : []),
        ].join("\n"),
      )
    : undefined;
  const diagnostics = diagnosticSections.length > 0
    ? section(
        "Diagnostics",
        diagnosticSections
          .map((diagnostic) => [
            `- code: ${diagnostic.code}`,
            `- message: ${diagnostic.message.replace(/\s+/g, " ").trim()}`,
            `- recovery: ${diagnostic.recovery.replace(/\s+/g, " ").trim()}`,
          ].join("\n"))
          .join("\n"),
      )
    : undefined;
  const prefix = [
    "## Brain Context",
    ...(input.retrievalLimits ? ["", section("Retrieval limits", input.retrievalLimits)] : []),
    ...(input.includeRoleDisclaimer ? ["", EVIDENCE_ROLE_DISCLAIMER] : []),
    ...(relevant ? ["", relevant] : []),
    ...(diagnostics ? ["", diagnostics] : []),
  ].join("\n");
  const full = `${prefix}${routes ? `\n\n${routes}` : ""}\n`;
  const attemptedBytes = byteLength(full);
  const guidanceBytes = 0;
  const retrievedContextBytes = relevant === undefined ? 0 : byteLength(relevant);
  const framingBytes = attemptedBytes - guidanceBytes - retrievedContextBytes;
  if (attemptedBytes <= input.hardBytes) {
    return {
      markdown: full,
      renderedBytes: attemptedBytes,
      truncated: false,
      attemptedBytes,
      guidanceBytes,
      retrievedContextBytes,
      framingBytes,
    };
  }

  const diagnostic = section(
    "Diagnostics",
    "- code: BRAIN_CONTEXT_TRUNCATED\n- recovery: Repair the compiler-to-envelope byte allowance before retrying.",
  );
  const suffix = `${routes ? `\n\n${routes}` : ""}\n\n[truncated]\n\n${diagnostic}\n`;
  const available = input.hardBytes - byteLength(suffix);
  const markdown =
    available > 0
      ? `${truncateUtf8(prefix, available)}${suffix}`
      : truncateUtf8("## Brain Context\n\n### Diagnostics\n\n- code: BRAIN_CONTEXT_TRUNCATED\n", input.hardBytes);
  return {
    markdown,
    renderedBytes: byteLength(markdown),
    truncated: true,
    attemptedBytes,
    guidanceBytes,
    retrievedContextBytes,
    framingBytes,
  };
}

function oneLine(value: string): string {
  return value.replace(/\s+/g, " ").trim();
}

export function renderDegradedBrainContext(
  diagnostic: BrainContextDiagnostic,
  brainRoot?: string,
  hardBytes = 24_576,
  mode: "bootstrap" | "recall" = "bootstrap",
): BrainContextRender {
  const lines = [
    `## Brain ${mode === "bootstrap" ? "Bootstrap" : "Recall"} Diagnostic`,
    "",
    "- status: degraded",
    `- code: ${diagnostic.code}`,
    ...(brainRoot ? [`- brain_root: ${oneLine(brainRoot)}`] : []),
    `- message: ${oneLine(diagnostic.message)}`,
    `- recovery: ${oneLine(diagnostic.recovery)}`,
    "",
  ];
  const full = lines.join("\n");
  const markdown = hardBytes <= 0 ? "" : byteLength(full) <= hardBytes ? full : `${truncateUtf8(full, hardBytes - 1)}\n`;
  return { markdown, renderedBytes: byteLength(markdown), truncated: markdown !== full };
}
