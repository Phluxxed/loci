import { BrainContextError } from "./manifest.ts";

export const TEMPORAL_VIEWS = ["current", "historical", "transition", "lineage", "conflict"] as const;

export type TemporalView = (typeof TEMPORAL_VIEWS)[number];

export type TemporalTransition = Readonly<{
  from: string;
  to: string;
}>;

/** Canonical temporal query shape shared by Anvil and llm-wiki contract 3. */
export type TemporalQuery = Readonly<{
  view: TemporalView;
  request_time: string;
  world_at?: string;
  known_at: string;
  transition?: TemporalTransition;
}>;

/** Raw structured input accepted at the Context Harness and retrieval seams. */
export type TemporalQueryInput = Readonly<{
  view: unknown;
  request_time: unknown;
  world_at?: unknown;
  known_at?: unknown;
  transition?: unknown;
}>;

const RFC3339_INSTANT = /^(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2})(?:\.(\d+))?(Z|[+-]\d{2}:\d{2})$/;
const ISO_DATE = /^\d{4}-\d{2}-\d{2}$/;

function invalidTemporal(field: string, message: string): never {
  throw new BrainContextError(
    "BRAIN_RETRIEVAL_INVALID",
    `Temporal query ${field} is invalid: ${message}.`,
    "Pass the strict llm-wiki temporal query contract with RFC 3339 request and known instants.",
  );
}

/** The existing llm-wiki persistence reader compares instants at whole seconds. */
export function currentTemporalRequestTime(now = new Date()): string {
  const wholeSecond = new Date(now.getTime());
  wholeSecond.setUTCMilliseconds(0);
  return wholeSecond.toISOString();
}

function recordValue(value: unknown, field: string): Record<string, unknown> {
  if (typeof value !== "object" || value === null || Array.isArray(value)) {
    invalidTemporal(field, "must be an object");
  }
  return value as Record<string, unknown>;
}

function assertAllowedFields(record: Record<string, unknown>, allowed: readonly string[], field: string): void {
  const allowedSet = new Set(allowed);
  const unknown = Object.keys(record).find((key) => !allowedSet.has(key));
  if (unknown !== undefined) invalidTemporal(`${field}.${unknown}`, "unknown field");
}

function utcDateFromParts(year: number, month: number, day: number, field: string): Date {
  if (year < 1 || year > 9_999) invalidTemporal(field, "must be a valid calendar date");
  const date = new Date(0);
  date.setUTCFullYear(year, month - 1, day);
  date.setUTCHours(0, 0, 0, 0);
  if (
    date.getUTCFullYear() !== year ||
    date.getUTCMonth() !== month - 1 ||
    date.getUTCDate() !== day
  ) {
    invalidTemporal(field, "must be a valid calendar date");
  }
  return date;
}

function parseDate(value: unknown, field: string): string {
  if (typeof value !== "string" || value.trim().length === 0) {
    invalidTemporal(field, "must be a known date or RFC 3339 instant");
  }
  const candidate = value.trim();
  if (!ISO_DATE.test(candidate)) return parseInstant(candidate, field);
  const [year, month, day] = candidate.split("-").map(Number);
  utcDateFromParts(year!, month!, day!, field);
  return candidate;
}

function parseInstant(value: unknown, field: string): string {
  if (typeof value !== "string" || value.trim().length === 0) {
    invalidTemporal(field, "must be an RFC 3339 instant");
  }
  const candidate = value.trim();
  const match = RFC3339_INSTANT.exec(candidate);
  if (match === null) invalidTemporal(field, "must be an RFC 3339 instant");

  const dateTime = match![1]!;
  const rawFraction = match![2] ?? "";
  if (/[1-9]/.test(rawFraction)) {
    invalidTemporal(field, "must use whole-second precision supported by the existing temporal reader");
  }
  const fraction = "000000";
  const timezone = match![3]!;
  const [datePart, timePart] = dateTime.split("T");
  const [year, month, day] = datePart!.split("-").map(Number);
  const [hour, minute, second] = timePart!.split(":").map(Number);
  utcDateFromParts(year!, month!, day!, field);
  if (hour! > 23 || minute! > 59 || second! > 59) {
    invalidTemporal(field, "must be an RFC 3339 instant");
  }
  const offsetSign = timezone === "Z" ? 1 : timezone.startsWith("+") ? 1 : -1;
  const offsetHour = timezone === "Z" ? 0 : Number(timezone.slice(1, 3));
  const offsetMinute = timezone === "Z" ? 0 : Number(timezone.slice(4, 6));
  if (offsetHour > 23 || offsetMinute > 59) {
    invalidTemporal(field, "must include a valid timezone offset");
  }

  const milliseconds = Number(fraction.slice(0, 3));
  const microsRemainder = fraction.slice(3);
  const instant = new Date(0);
  instant.setUTCFullYear(year!, month! - 1, day!);
  instant.setUTCHours(hour!, minute!, second!, milliseconds);
  instant.setTime(
    instant.getTime() - offsetSign * (offsetHour * 60 + offsetMinute) * 60_000,
  );
  if (
    Number.isNaN(instant.getTime()) ||
    instant.getUTCFullYear() < 1 ||
    instant.getUTCFullYear() > 9_999
  ) invalidTemporal(field, "must be an RFC 3339 instant");

  const iso = instant.toISOString();
  const [isoDate, isoTime] = iso.split("T");
  const [isoClock] = isoTime!.split(".");
  if (fraction === "000000") return `${isoDate}T${isoClock}Z`;
  return `${isoDate}T${isoClock}.${iso.slice(iso.indexOf(".") + 1, iso.indexOf(".") + 4)}${microsRemainder}Z`;
}

function pointKey(value: string): string {
  const instant = ISO_DATE.test(value) ? `${value}T00:00:00Z` : value;
  const withoutZone = instant.endsWith("Z") ? instant.slice(0, -1) : instant;
  const separator = withoutZone.indexOf(".");
  const wholeSeconds = separator < 0 ? withoutZone : withoutZone.slice(0, separator);
  const fraction = separator < 0 ? "" : withoutZone.slice(separator + 1);
  // llm-wiki preserves microseconds; fixed-width UTC strings compare in
  // chronological order without reducing the range to JavaScript milliseconds.
  return `${wholeSeconds}.${fraction.padEnd(6, "0")}Z`;
}

export function parseTemporalQuery(value: unknown): TemporalQuery {
  const raw = recordValue(value, "temporal");
  assertAllowedFields(raw, ["view", "request_time", "world_at", "known_at", "transition"], "temporal");
  if (typeof raw.view !== "string" || !TEMPORAL_VIEWS.includes(raw.view as TemporalView)) {
    invalidTemporal("temporal.view", "must be one of current, historical, transition, lineage, or conflict");
  }
  const view = raw.view as TemporalView;
  const requestTime = parseInstant(raw.request_time, "temporal.request_time");
  const hasKnownAt = Object.prototype.hasOwnProperty.call(raw, "known_at");
  const hasWorldAt = Object.prototype.hasOwnProperty.call(raw, "world_at");
  const hasTransition = Object.prototype.hasOwnProperty.call(raw, "transition");
  const knownAt = !hasKnownAt
    ? requestTime
    : parseInstant(raw.known_at, "temporal.known_at");
  const worldAt = !hasWorldAt
    ? undefined
    : parseDate(raw.world_at, "temporal.world_at");

  let transition: TemporalTransition | undefined;
  if (hasTransition) {
    const transitionRaw = recordValue(raw.transition, "temporal.transition");
    assertAllowedFields(transitionRaw, ["from", "to"], "temporal.transition");
    if (!("from" in transitionRaw) || !("to" in transitionRaw)) {
      invalidTemporal("temporal.transition", "requires from and to");
    }
    const from = parseDate(transitionRaw.from, "temporal.transition.from");
    const to = parseDate(transitionRaw.to, "temporal.transition.to");
    if (pointKey(from) >= pointKey(to)) {
      invalidTemporal("temporal.transition", "from must precede to");
    }
    transition = { from, to };
  }

  if (view === "historical" && worldAt === undefined) {
    invalidTemporal("temporal.world_at", "historical view requires world_at");
  }
  if (view === "transition") {
    if (worldAt !== undefined) invalidTemporal("temporal.world_at", "transition view forbids world_at");
    if (transition === undefined) invalidTemporal("temporal.transition", "transition view requires a range");
  } else if (transition !== undefined) {
    invalidTemporal("temporal.transition", "transition range is only valid for transition view");
  }

  return {
    view,
    request_time: requestTime,
    ...(worldAt !== undefined
      ? { world_at: worldAt }
      : view === "current"
        ? { world_at: requestTime }
        : {}),
    known_at: knownAt,
    ...(transition !== undefined ? { transition } : {}),
  };
}

export function defaultCurrentTemporalQuery(requestTime = currentTemporalRequestTime()): TemporalQuery {
  return parseTemporalQuery({ view: "current", request_time: requestTime });
}

export function normalizeTemporalQuery(
  value: unknown,
  defaultRequestTime?: string,
): TemporalQuery | undefined {
  if (value === undefined) {
    return defaultRequestTime === undefined ? undefined : defaultCurrentTemporalQuery(defaultRequestTime);
  }
  return parseTemporalQuery(value);
}

export function temporalQueriesEqual(left: TemporalQuery, right: TemporalQuery): boolean {
  return JSON.stringify(left) === JSON.stringify(right);
}

export function temporalCliArgs(query: TemporalQuery): string[] {
  return [
    "--temporal-view",
    query.view,
    "--request-time",
    query.request_time,
    ...(query.world_at === undefined ? [] : ["--world-at", query.world_at]),
    "--known-at",
    query.known_at,
    ...(query.transition === undefined
      ? []
      : ["--transition-from", query.transition.from, "--transition-to", query.transition.to]),
  ];
}
