import { constants as fsConstants } from "node:fs";
import { access, readFile, realpath } from "node:fs/promises";
import { isAbsolute, posix, relative, resolve, sep } from "node:path";

import { normalizeGitRemote } from "./project.ts";

export const BRAIN_CONTEXT_DIAGNOSTIC_CODES = [
  "BRAIN_NOT_CONFIGURED",
  "BRAIN_ROOT_MISSING",
  "BRAIN_MANIFEST_MISSING",
  "BRAIN_MANIFEST_INVALID",
  "BRAIN_CORE_PAGE_MISSING",
  "BRAIN_PROJECT_AMBIGUOUS",
  "PROJECT_IDENTITY_AMBIGUOUS",
  "PROJECT_IDENTITY_INVALID",
  "PROJECT_ALIAS_SHADOWED",
  "BRAIN_PROMPT_INVALID",
  "BRAIN_PROMPT_GUIDANCE_TOO_LARGE",
  "BRAIN_LLM_WIKI_MISSING",
  "BRAIN_RETRIEVAL_TIMEOUT",
  "BRAIN_RETRIEVAL_FAILED",
  "BRAIN_RETRIEVAL_INVALID",
  "BRAIN_TEMPORAL_HISTORY_INVALID",
  "BRAIN_TEMPORAL_UNCERTAIN",
  "BRAIN_SELECTED_PATH_UNSAFE",
  "BRAIN_SNAPSHOT_INVALID",
  "BRAIN_SNAPSHOT_STALE",
  "BRAIN_SNAPSHOT_UNAVAILABLE",
  "BRAIN_CONTEXT_BUDGET_VIOLATION",
  "BRAIN_KERNEL_TARGET_EXCEEDED",
  "BRAIN_CONTEXT_TRUNCATED",
] as const;

export type BrainContextDiagnosticCode = (typeof BRAIN_CONTEXT_DIAGNOSTIC_CODES)[number];

export class BrainContextError extends Error {
  code: BrainContextDiagnosticCode;
  recovery: string;

  constructor(code: BrainContextDiagnosticCode, message: string, recovery: string) {
    super(message);
    this.name = "BrainContextError";
    this.code = code;
    this.recovery = recovery;
  }
}

export type BrainBootstrapBudgets = {
  session_start_target_bytes: number;
  session_start_hard_bytes: number;
  prompt_recall_target_bytes: number;
  prompt_recall_hard_bytes: number;
  prompt_guidance_hard_bytes: number;
};

export type BrainBootstrapProject = {
  page: string;
  aliases: string[];
  remotes: string[];
};

export type CollaborationKernelRole = "identity" | "collaboration" | "authority";

export type CollaborationKernelSource = {
  role: CollaborationKernelRole;
  page: string;
  section: string;
};

export type CollaborationKernelManifest = {
  target_bytes: 3_072;
  hard_bytes: 4_096;
  sources: CollaborationKernelSource[];
};

type BrainBootstrapManifestCommon = {
  core_pages: string[];
  prompt_guidance_pages: string[];
  collaboration_kernel?: CollaborationKernelManifest;
  budgets: BrainBootstrapBudgets;
};

export type BrainBootstrapManifestV1 = BrainBootstrapManifestCommon & {
  version: 1;
  projects: BrainBootstrapProject[];
};

export type BrainBootstrapManifestV2 = BrainBootstrapManifestCommon & {
  version: 2;
};

export type BrainBootstrapManifest = BrainBootstrapManifestV1 | BrainBootstrapManifestV2;

const MANIFEST_RECOVERY = "Repair brain-bootstrap.json using the documented version 1 or version 2 contract.";
const ALIAS_PATTERN = /^[a-z0-9][a-z0-9._-]{0,127}$/i;

function invalidManifest(message: string): never {
  throw new BrainContextError("BRAIN_MANIFEST_INVALID", message, MANIFEST_RECOVERY);
}

function asRecord(value: unknown, field: string): Record<string, unknown> {
  if (typeof value !== "object" || value === null || Array.isArray(value)) {
    invalidManifest(`${field} must be an object.`);
  }
  return value as Record<string, unknown>;
}

export function isSafeBrainRelativePath(value: string): boolean {
  if (value.length === 0 || value.includes("\0") || value.includes("\\") || isAbsolute(value)) return false;
  if (!value.endsWith(".md")) return false;
  if (value.split("/").some((segment) => segment.length === 0 || segment === "." || segment === "..")) return false;
  return posix.normalize(value) === value;
}

function parsePagePath(value: unknown, field: string): string {
  if (typeof value !== "string" || !isSafeBrainRelativePath(value)) {
    invalidManifest(`${field} must be a safe wiki-root-relative Markdown path.`);
  }
  return value;
}

function parseStringArray(value: unknown, field: string, allowEmpty: boolean): string[] {
  if (!Array.isArray(value) || (!allowEmpty && value.length === 0)) {
    invalidManifest(`${field} must be ${allowEmpty ? "an" : "a non-empty"} array.`);
  }
  return value.map((item, index) => {
    if (typeof item !== "string" || item.length === 0 || item !== item.trim()) {
      invalidManifest(`${field}[${index}] must be a non-empty trimmed string.`);
    }
    return item;
  });
}

function parseBudget(value: unknown, field: string): number {
  if (!Number.isSafeInteger(value) || (value as number) <= 0) {
    invalidManifest(`${field} must be a positive integer.`);
  }
  return value as number;
}

function assertUnique(values: string[], field: string, normalize: (value: string) => string): void {
  const seen = new Set<string>();
  for (const value of values) {
    const normalized = normalize(value);
    if (seen.has(normalized)) invalidManifest(`${field} contains a duplicate identifier: ${value}.`);
    seen.add(normalized);
  }
}

export function parseBrainBootstrapManifest(value: unknown): BrainBootstrapManifest {
  const record = asRecord(value, "manifest");
  if (record.version !== 1 && record.version !== 2) invalidManifest("manifest.version must be 1 or 2.");
  const version = record.version;

  if (!Array.isArray(record.core_pages) || record.core_pages.length === 0) {
    invalidManifest("manifest.core_pages must be a non-empty array.");
  }
  const corePages = record.core_pages.map((page, index) => parsePagePath(page, `manifest.core_pages[${index}]`));
  assertUnique(corePages, "manifest.core_pages", (page) => page);

  const rawPromptGuidancePages = record.prompt_guidance_pages ?? [];
  if (!Array.isArray(rawPromptGuidancePages)) {
    invalidManifest("manifest.prompt_guidance_pages must be an array when provided.");
  }
  const promptGuidancePages = rawPromptGuidancePages.map((page, index) =>
    parsePagePath(page, `manifest.prompt_guidance_pages[${index}]`),
  );
  assertUnique(promptGuidancePages, "manifest.prompt_guidance_pages", (page) => page);
  const corePageSet = new Set(corePages);
  for (const page of promptGuidancePages) {
    if (!corePageSet.has(page)) {
      invalidManifest(`Prompt guidance page must also be a core page: ${page}.`);
    }
  }

  let collaborationKernel: CollaborationKernelManifest | undefined;
  if (record.collaboration_kernel !== undefined) {
    const kernel = asRecord(record.collaboration_kernel, "manifest.collaboration_kernel");
    if (kernel.target_bytes !== 3_072 || kernel.hard_bytes !== 4_096) {
      invalidManifest("Collaboration Kernel target_bytes and hard_bytes must remain at the reviewed 3072/4096 limits.");
    }
    if (!Array.isArray(kernel.sources) || kernel.sources.length !== 3) {
      invalidManifest("manifest.collaboration_kernel.sources must contain exactly three role locators.");
    }
    const roles = ["identity", "collaboration", "authority"] as const;
    const sources = kernel.sources.map((source, index): CollaborationKernelSource => {
      const item = asRecord(source, `manifest.collaboration_kernel.sources[${index}]`);
      if (!roles.includes(item.role as CollaborationKernelRole)) {
        invalidManifest(`manifest.collaboration_kernel.sources[${index}].role is invalid.`);
      }
      const page = parsePagePath(item.page, `manifest.collaboration_kernel.sources[${index}].page`);
      if (!corePageSet.has(page)) {
        invalidManifest(`Collaboration Kernel source must also be a core page: ${page}.`);
      }
      if (
        typeof item.section !== "string" || item.section.length === 0 ||
        item.section !== item.section.trim() || item.section.includes("\n") || item.section.startsWith("#")
      ) {
        invalidManifest(`manifest.collaboration_kernel.sources[${index}].section must be a plain trimmed heading.`);
      }
      return { role: item.role as CollaborationKernelRole, page, section: item.section };
    });
    assertUnique(sources.map((source) => source.role), "manifest.collaboration_kernel roles", (role) => role);
    for (const role of roles) {
      if (!sources.some((source) => source.role === role)) {
        invalidManifest(`manifest.collaboration_kernel.sources is missing the ${role} role.`);
      }
    }
    assertUnique(
      sources.map((source) => `${source.page}#${source.section}`),
      "manifest.collaboration_kernel locators",
      (locator) => locator,
    );
    collaborationKernel = { target_bytes: 3_072, hard_bytes: 4_096, sources };
  }

  if (version === 2) {
    if (Object.prototype.hasOwnProperty.call(record, "projects")) {
      invalidManifest("Version 2 manifests must not declare a projects catalogue.");
    }
  }

  let projects: BrainBootstrapProject[] | undefined;
  if (version === 1) {
    if (!Array.isArray(record.projects)) invalidManifest("manifest.projects must be an array.");
    projects = record.projects.map((project, index): BrainBootstrapProject => {
      const item = asRecord(project, `manifest.projects[${index}]`);
      const page = parsePagePath(item.page, `manifest.projects[${index}].page`);
      const aliases = parseStringArray(item.aliases, `manifest.projects[${index}].aliases`, false);
      const remotes = parseStringArray(item.remotes, `manifest.projects[${index}].remotes`, true);
      for (const alias of aliases) {
        if (!ALIAS_PATTERN.test(alias)) invalidManifest(`Project alias is invalid: ${alias}.`);
      }
      for (const remote of remotes) {
        try {
          normalizeGitRemote(remote);
        } catch {
          invalidManifest(`Project remote is invalid: ${remote}.`);
        }
      }
      return { page, aliases, remotes };
    });

    assertUnique(
      projects.map((project) => project.page),
      "manifest.projects pages",
      (page) => page,
    );
    assertUnique(
      projects.flatMap((project) => project.aliases),
      "manifest.projects aliases",
      (alias) => alias.toLowerCase(),
    );
    assertUnique(
      projects.flatMap((project) => project.remotes),
      "manifest.projects remotes",
      normalizeGitRemote,
    );
  }

  const budgetRecord = asRecord(record.budgets, "manifest.budgets");
  let promptGuidanceHardBytes = 0;
  if (promptGuidancePages.length > 0) {
    promptGuidanceHardBytes = parseBudget(
      budgetRecord.prompt_guidance_hard_bytes,
      "manifest.budgets.prompt_guidance_hard_bytes",
    );
  } else if (budgetRecord.prompt_guidance_hard_bytes !== undefined && budgetRecord.prompt_guidance_hard_bytes !== 0) {
    invalidManifest("Prompt guidance hard bytes must be omitted or zero when no prompt guidance pages are declared.");
  }

  const budgets: BrainBootstrapBudgets = {
    session_start_target_bytes: parseBudget(
      budgetRecord.session_start_target_bytes,
      "manifest.budgets.session_start_target_bytes",
    ),
    session_start_hard_bytes: parseBudget(
      budgetRecord.session_start_hard_bytes,
      "manifest.budgets.session_start_hard_bytes",
    ),
    prompt_recall_target_bytes: parseBudget(
      budgetRecord.prompt_recall_target_bytes,
      "manifest.budgets.prompt_recall_target_bytes",
    ),
    prompt_recall_hard_bytes: parseBudget(
      budgetRecord.prompt_recall_hard_bytes,
      "manifest.budgets.prompt_recall_hard_bytes",
    ),
    prompt_guidance_hard_bytes: promptGuidanceHardBytes,
  };
  if (budgets.session_start_target_bytes > budgets.session_start_hard_bytes) {
    invalidManifest("SessionStart target bytes must not exceed its hard byte limit.");
  }
  if (budgets.prompt_recall_target_bytes > budgets.prompt_recall_hard_bytes) {
    invalidManifest("Prompt recall target bytes must not exceed its hard byte limit.");
  }
  if (budgets.prompt_guidance_hard_bytes > budgets.prompt_recall_hard_bytes) {
    invalidManifest("Prompt guidance hard bytes must not exceed the prompt recall hard byte limit.");
  }

  if (version === 1) {
    return {
      version: 1,
      core_pages: corePages,
      prompt_guidance_pages: promptGuidancePages,
      projects: projects!,
      ...(collaborationKernel ? { collaboration_kernel: collaborationKernel } : {}),
      budgets,
    };
  }
  return {
    version: 2,
    core_pages: corePages,
    prompt_guidance_pages: promptGuidancePages,
    ...(collaborationKernel ? { collaboration_kernel: collaborationKernel } : {}),
    budgets,
  };
}

function isInside(root: string, candidate: string): boolean {
  const path = relative(root, candidate);
  return path === "" || (!path.startsWith(`..${sep}`) && path !== ".." && !isAbsolute(path));
}

async function checkedPagePath(
  brainRoot: string,
  page: string,
  missingCode: BrainContextDiagnosticCode,
): Promise<string> {
  if (!isSafeBrainRelativePath(page)) {
    throw new BrainContextError(
      "BRAIN_SELECTED_PATH_UNSAFE",
      `Selected Brain path is unsafe: ${page}.`,
      "Repair the manifest or retrieval result so every selected page stays inside the Brain root.",
    );
  }

  const root = await realpath(brainRoot);
  const candidate = resolve(root, page);
  if (!isInside(root, candidate)) {
    throw new BrainContextError(
      "BRAIN_SELECTED_PATH_UNSAFE",
      `Selected Brain path escapes the Brain root: ${page}.`,
      "Remove the unsafe selected path.",
    );
  }

  let resolvedPage: string;
  try {
    resolvedPage = await realpath(candidate);
    await access(resolvedPage, fsConstants.R_OK);
  } catch (error) {
    const code = (error as NodeJS.ErrnoException).code;
    if (code === "ENOENT" || code === "ENOTDIR") {
      throw new BrainContextError(
        missingCode,
        `Brain page is missing: ${page}.`,
        "Restore the referenced Brain page or update brain-bootstrap.json.",
      );
    }
    throw error;
  }

  if (!isInside(root, resolvedPage)) {
    throw new BrainContextError(
      "BRAIN_SELECTED_PATH_UNSAFE",
      `Selected Brain path resolves outside the Brain root: ${page}.`,
      "Replace the escaping symlink or remove the selected path.",
    );
  }
  return resolvedPage;
}

export async function readBrainPage(
  brainRoot: string,
  page: string,
  missingCode: BrainContextDiagnosticCode = "BRAIN_RETRIEVAL_INVALID",
): Promise<string> {
  const path = await checkedPagePath(brainRoot, page, missingCode);
  try {
    return await readFile(path, "utf8");
  } catch {
    throw new BrainContextError(
      missingCode,
      `Brain page could not be read: ${page}.`,
      "Repair the referenced Brain page and retry.",
    );
  }
}

export async function loadBrainBootstrapManifest(brainRoot: string): Promise<BrainBootstrapManifest> {
  const path = resolve(brainRoot, "brain-bootstrap.json");
  let text: string;
  try {
    text = await readFile(path, "utf8");
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code === "ENOENT") {
      throw new BrainContextError(
        "BRAIN_MANIFEST_MISSING",
        "Brain bootstrap manifest is missing.",
        "Add brain-bootstrap.json at the configured Brain root.",
      );
    }
    throw error;
  }

  let raw: unknown;
  try {
    raw = JSON.parse(text);
  } catch {
    invalidManifest("brain-bootstrap.json is not valid JSON.");
  }
  const manifest = parseBrainBootstrapManifest(raw);

  for (const page of manifest.core_pages) {
    await readBrainPage(brainRoot, page, "BRAIN_CORE_PAGE_MISSING");
  }
  if (manifest.version === 1) {
    for (const project of manifest.projects) {
      await readBrainPage(brainRoot, project.page, "BRAIN_MANIFEST_INVALID");
    }
  }
  return manifest;
}
