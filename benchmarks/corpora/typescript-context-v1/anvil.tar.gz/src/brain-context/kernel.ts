import { execFile } from "node:child_process";

import {
  BrainContextError,
  type CollaborationKernelManifest,
  type CollaborationKernelSource,
} from "./manifest.ts";
import { resolveLlmWikiCommand, type BrainCompiledEvidence, type BrainCompilerCoverage, type BrainCompilerDiagnostic, type BrainCompilerOmission, type BrainCompilerReporting, type BrainCompilerStop } from "./retrieve.ts";
import type { BrainSnapshot } from "./snapshot.ts";

export type CollaborationKernelBudget = Readonly<{
  limits: { targetBytes: 3_072; maxBytes: 4_096 };
  contentBytes: number;
  targetExceeded: boolean;
  accounting: "utf-8";
}>;

export type CollaborationKernelProjection = Readonly<{
  sources: CollaborationKernelSource[];
  evidence: BrainCompiledEvidence[];
  omissions: BrainCompilerOmission[];
  coverage: BrainCompilerCoverage;
  budget: CollaborationKernelBudget;
  stop: BrainCompilerStop;
  continuation: null;
  diagnostics: BrainCompilerDiagnostic[];
  reporting: BrainCompilerReporting;
}>;

type CompileKernelInput = Readonly<{
  brainRoot: string;
  wikiAlias: string;
  snapshot: BrainSnapshot;
  manifest: CollaborationKernelManifest;
  env?: Record<string, string | undefined>;
  timeoutMs?: number;
}>;

function invalid(message: string): never {
  throw new BrainContextError(
    "BRAIN_RETRIEVAL_INVALID",
    message,
    "Repair the installed llm-wiki Collaboration Kernel contract before retrying.",
  );
}

function record(value: unknown, label: string): Record<string, unknown> {
  if (typeof value !== "object" || value === null || Array.isArray(value)) invalid(`${label} must be an object.`);
  return value as Record<string, unknown>;
}

function strings(value: unknown, label: string): string[] {
  if (!Array.isArray(value) || value.some((item) => typeof item !== "string")) invalid(`${label} must be a string array.`);
  return value as string[];
}

function sameJson(left: unknown, right: unknown): boolean {
  return JSON.stringify(left) === JSON.stringify(right);
}

export function parseKernelProjection(
  value: unknown,
  input: Pick<CompileKernelInput, "wikiAlias" | "snapshot" | "manifest">,
): CollaborationKernelProjection {
  const root = record(value, "Kernel projection");
  const wiki = record(root.wiki, "Kernel projection wiki");
  const projection = record(root.projection, "Kernel projection selection");
  if (
    root.kind !== "collaboration_kernel_projection" || root.contract_version !== "1" ||
    wiki.alias !== input.wikiAlias || wiki.digest !== input.snapshot.digest ||
    // Anvil calls a valid retained revision last-known-good when publication
    // fails; the compiler may still resolve that same digest via current.json.
    // Digest/source identity must agree, not the two callers' recovery route.
    (wiki.snapshot_status !== "current" && wiki.snapshot_status !== "last_known_good") ||
    projection.selection !== "explicit_ordered_sources" || projection.mandatory_sections !== true ||
    !sameJson(projection.sources, input.manifest.sources)
  ) invalid("llm-wiki returned a kernel projection for a different snapshot or source contract.");

  if (!Array.isArray(root.evidence) || root.evidence.length !== input.manifest.sources.length) {
    invalid("Kernel projection must return exactly one evidence record per mandatory source.");
  }
  const evidence = root.evidence.map((raw, index): BrainCompiledEvidence => {
    const item = record(raw, `Kernel evidence ${index}`);
    const source = input.manifest.sources[index]!;
    const locator = record(item.locator, `Kernel evidence ${index} locator`);
    const roles = strings(item.roles, `Kernel evidence ${index} roles`);
    const content = item.content;
    const byteCost = item.byte_cost;
    if (
      typeof item.id !== "string" || item.provider !== "snapshot_section" ||
      item.route !== "explicit_ordered_source" || item.page !== source.page ||
      typeof item.source !== "string" || item.source.startsWith("/") ||
      locator.role !== source.role || locator.source_index !== index || locator.section !== source.section ||
      !sameJson(roles, [source.role]) || typeof content !== "string" ||
      byteCost !== Buffer.byteLength(content, "utf8") || item.truncated !== false || item.atomic !== true
    ) invalid(`Kernel evidence ${index} does not exactly match its mandatory source.`);
    return {
      id: item.id,
      provider: item.provider,
      route: item.route,
      page: item.page,
      source: item.source,
      locator,
      content,
      roles,
      authoredState: typeof item.authored_state === "string" ? item.authored_state : invalid(`Kernel evidence ${index} authored_state is invalid.`),
      derivedFlags: strings(item.derived_flags, `Kernel evidence ${index} derived_flags`),
      authoritySignals: strings(item.authority_signals, `Kernel evidence ${index} authority_signals`),
      selectionReasons: strings(item.selection_reasons, `Kernel evidence ${index} selection_reasons`),
      byteCost,
      truncated: false,
      atomic: true,
    };
  });

  const omissions = root.omissions;
  const coverage = record(root.coverage, "Kernel coverage");
  const budget = record(root.budget, "Kernel budget");
  const limits = record(budget.limits, "Kernel budget limits");
  const stop = record(root.stop, "Kernel stop");
  const diagnostics = root.diagnostics;
  const reporting = record(root.reporting, "Kernel reporting");
  const reportingOmissions = record(reporting.omissions, "Kernel omission reporting");
  const reportingDiagnostics = record(reporting.diagnostics, "Kernel diagnostic reporting");
  const roles = input.manifest.sources.map((source) => source.role);
  const contentBytes = evidence.reduce((total, item) => total + Buffer.byteLength(item.content, "utf8"), 0);
  if (
    !Array.isArray(omissions) || omissions.length !== 0 || root.continuation !== null ||
    !sameJson(coverage.required_roles, roles) || !sameJson(coverage.covered_roles, roles) ||
    !sameJson(coverage.uncovered_roles, []) || limits.target_content_bytes !== 3_072 ||
    limits.max_content_bytes !== 4_096 || budget.content_bytes !== contentBytes ||
    budget.target_exceeded !== (contentBytes > 3_072) || budget.accounting !== "utf-8" ||
    contentBytes > 4_096 || stop.reason !== "all_sources_projected" || stop.sufficient !== true ||
    typeof stop.detail !== "string" || !Array.isArray(diagnostics) ||
    reportingOmissions.total !== 0 || reportingOmissions.returned !== 0 ||
    reportingDiagnostics.total !== diagnostics.length || reportingDiagnostics.returned !== diagnostics.length
  ) invalid("llm-wiki returned internally inconsistent kernel coverage, budget, or completion evidence.");
  const parsedDiagnostics = diagnostics.map((raw, index): BrainCompilerDiagnostic => {
    const item = record(raw, `Kernel diagnostic ${index}`);
    if (typeof item.code !== "string" || typeof item.message !== "string" ||
        (item.provider !== null && typeof item.provider !== "string")) invalid(`Kernel diagnostic ${index} is invalid.`);
    return { code: item.code, message: item.message, provider: item.provider as string | null, details: record(item.details, `Kernel diagnostic ${index} details`) };
  });
  const expectedCodes = contentBytes > 3_072 ? ["KERNEL_TARGET_EXCEEDED"] : [];
  if (!sameJson(parsedDiagnostics.map((item) => item.code), expectedCodes)) invalid("Kernel diagnostics do not match its measured content budget.");
  return {
    sources: input.manifest.sources,
    evidence,
    omissions: [],
    coverage: { requiredRoles: roles, coveredRoles: roles, uncoveredRoles: [] },
    budget: { limits: { targetBytes: 3_072, maxBytes: 4_096 }, contentBytes, targetExceeded: contentBytes > 3_072, accounting: "utf-8" },
    stop: { reason: stop.reason, sufficient: true, detail: stop.detail },
    continuation: null,
    diagnostics: parsedDiagnostics,
    reporting: { omissions: { total: 0, returned: 0 }, diagnostics: { total: parsedDiagnostics.length, returned: parsedDiagnostics.length } },
  };
}

function run(command: string, args: string[], input: CompileKernelInput): Promise<string> {
  return new Promise((resolve, reject) => execFile(command, args, {
    cwd: input.brainRoot,
    encoding: "utf8",
    env: { ...process.env, ...input.env },
    maxBuffer: 1024 * 1024,
    timeout: input.timeoutMs ?? 10_000,
  }, (error, stdout, stderr) => error ? reject(Object.assign(error, { stderr })) : resolve(stdout)));
}

export async function compileCollaborationKernel(input: CompileKernelInput): Promise<CollaborationKernelProjection> {
  const command = await resolveLlmWikiCommand(input);
  try {
    const stdout = await run(command, [
      "compile-kernel", "--alias", input.wikiAlias, "--output-root", input.snapshot.outputRoot,
      ...input.manifest.sources.flatMap((source) => ["--source", JSON.stringify(source)]),
    ], input);
    return parseKernelProjection(JSON.parse(stdout), input);
  } catch (error) {
    if (error instanceof BrainContextError) throw error;
    const stderr = typeof error === "object" && error !== null && "stderr" in error ? String(error.stderr) : "";
    if (stderr.includes("KERNEL_CONTENT_CEILING_EXCEEDED")) {
      throw new BrainContextError(
        "BRAIN_CONTEXT_BUDGET_VIOLATION",
        "The mandatory Collaboration Kernel exceeds its 4096-byte content ceiling.",
        "Compact the declared source sections; Anvil will not truncate mandatory doctrine.",
      );
    }
    throw new BrainContextError(
      "BRAIN_RETRIEVAL_FAILED",
      "llm-wiki could not compile the Collaboration Kernel from the validated snapshot.",
      "Repair the installed llm-wiki producer or declared kernel source sections.",
    );
  }
}
