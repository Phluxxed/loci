import { createHash } from "node:crypto";
import { isAbsolute } from "node:path";

import {
  buildBrainContext,
  isValidBrainPrompt,
  type BrainContextDiagnostic,
  type BrainContextOptions,
  type BrainRecallObservation,
} from "./index.ts";
import { compilerRetrievalLimits, renderDegradedBrainContext } from "./render.ts";
import {
  collaborationKernelRequired,
  recordCollaborationKernelDelivery,
} from "./kernel-receipt.ts";
import type {
  BrainCompilerBudget,
  BrainCompilerCoverage,
  BrainCompilerDiagnostic,
  BrainCompilerOmission,
  BrainCompilerReporting,
  BrainCompilerStop,
  BrainCompiledEvidence,
  BrainProjectResolution,
} from "./retrieve.ts";
import type { CollaborationKernelBudget } from "./kernel.ts";
import type { TemporalQuery } from "./temporal.ts";

export type ContextLifecycle = "session_start" | "resume" | "clear" | "compact" | "prompt";

export type ContextRequest = Readonly<{
  lifecycle: ContextLifecycle;
  cwd: string;
  prompt?: string;
  /** Optional structured temporal query; omitted prompt recalls default to current time in contract 3. */
  temporal?: unknown;
  host: string;
  sessionId?: string;
  reservedBytes: number;
}>;

export type DeliveredEvidenceReceipt = Readonly<{
  id: string;
  provider: string;
  route: string;
  page: string | null;
  source: string | null;
  locator: Record<string, unknown>;
  roles: string[];
  authoredState: string;
  derivedFlags: string[];
  authoritySignals: string[];
  selectionReasons: string[];
  byteCost: number;
  truncated: boolean;
  atomic: boolean;
}>;

export type RecallReceipt = Readonly<{
  snapshotDigest: string | null;
  lifecycle: ContextLifecycle;
  project?: string;
  projectResolution?: BrainProjectResolution;
  temporal?: TemporalQuery;
  selectedEvidence: DeliveredEvidenceReceipt[];
  omissions: BrainCompilerOmission[];
  coverage: BrainCompilerCoverage | null;
  compilerBudget: BrainCompilerBudget | null;
  kernelBudget: CollaborationKernelBudget | null;
  stop: BrainCompilerStop;
  continuation: Record<string, unknown> | null;
  compilerDiagnostics: BrainCompilerDiagnostic[];
  reporting: BrainCompilerReporting | null;
  recallObservation: BrainRecallObservation | null;
  kernel: {
    action: "emitted" | "suppressed";
    reason: string;
    digest: string | null;
    lifecycleGeneration: number | null;
  };
  budget: {
    reservedBytes: number;
    hardBytes: number;
    renderedBytes: number;
  };
}>;

export type ContextEnvelope = Readonly<{
  contractVersion: "anvil-context-envelope/1";
  status: "ready" | "partial" | "empty" | "degraded";
  markdown: string;
  diagnostics: BrainContextDiagnostic[];
  receipt: RecallReceipt;
}>;

export type ContextHarness = Readonly<{
  planContext(request: ContextRequest): Promise<ContextEnvelope>;
}>;

function evidenceReceipt(evidence: BrainCompiledEvidence): DeliveredEvidenceReceipt {
  return {
    id: evidence.id,
    provider: evidence.provider,
    route: evidence.route,
    page: evidence.page,
    source: evidence.source !== null && isAbsolute(evidence.source) ? null : evidence.source,
    locator: { ...evidence.locator },
    roles: [...evidence.roles],
    authoredState: evidence.authoredState,
    derivedFlags: [...evidence.derivedFlags],
    authoritySignals: [...evidence.authoritySignals],
    selectionReasons: [...evidence.selectionReasons],
    byteCost: evidence.byteCost,
    truncated: evidence.truncated,
    atomic: evidence.atomic,
  };
}

const NO_COMPILER_STOP: BrainCompilerStop = {
  reason: "not_run",
  sufficient: true,
  detail: "Prompt compilation was not required for this lifecycle.",
};

type KernelReceiptResult = RecallReceipt["kernel"];

function digestMarkdown(markdown: string): string {
  return createHash("sha256").update(markdown, "utf8").digest("hex");
}

function joinKernelAndPrompt(kernelMarkdown: string, promptMarkdown: string): string {
  return [kernelMarkdown, promptMarkdown].filter(Boolean).join("\n\n");
}

function boundedPromptDiagnostic(
  result: Awaited<ReturnType<typeof buildBrainContext>>,
  request: ContextRequest,
  diagnostic: BrainContextDiagnostic = result.diagnostics[0] ?? {
    code: "BRAIN_CONTEXT_BUDGET_VIOLATION",
    message: "The combined Collaboration Kernel and Prompt Evidence exceed the reviewed delivery allowance.",
    recovery: "Reduce reserved or kernel context before changing the reviewed envelope ceiling.",
  },
): Awaited<ReturnType<typeof buildBrainContext>> {
  const promptHardBytes = result.promptHardBytes ?? result.hardBytes;
  const availableBytes = Math.max(0, promptHardBytes - request.reservedBytes);
  const rendered = renderDegradedBrainContext(diagnostic, undefined, availableBytes, "recall");
  return {
    ...result,
    markdown: rendered.markdown,
    renderedBytes: rendered.renderedBytes,
    hardBytes: promptHardBytes,
    diagnostics: result.diagnostics.length > 0 ? result.diagnostics : [diagnostic],
    deliveredEvidence: [],
  };
}

function fitsPromptEnvelope(
  result: Awaited<ReturnType<typeof buildBrainContext>>,
  request: ContextRequest,
  markdown: string,
): boolean {
  const availableBytes = Math.max(0, result.hardBytes - request.reservedBytes);
  return Buffer.byteLength(markdown, "utf8") <= availableBytes;
}

function envelopeFromResult(
  result: Awaited<ReturnType<typeof buildBrainContext>>,
  request: ContextRequest,
  kernel: KernelReceiptResult,
): ContextEnvelope {
  const compiled = result.compiledContext;
  const kernelProjection = result.kernelProjection;
  const selectedEvidence = (result.deliveredEvidence ?? []).map(evidenceReceipt);
  const status: ContextEnvelope["status"] =
    result.status === "degraded"
      ? "degraded"
      : request.lifecycle === "prompt" && selectedEvidence.length === 0 &&
          result.markdown.length === 0 && compiled?.stop.reason === "no_evidence"
        ? "empty"
        : result.diagnostics.length > 0 ||
            (compiled !== undefined && (!compiled.stop.sufficient || compiled.diagnostics.length > 0 ||
              compilerRetrievalLimits(compiled) !== undefined)) ||
            (kernelProjection !== undefined && kernelProjection.diagnostics.length > 0)
          ? "partial"
          : "ready";
  return {
    contractVersion: "anvil-context-envelope/1",
    status,
    markdown: result.markdown,
    diagnostics: result.diagnostics,
    receipt: {
      snapshotDigest: result.snapshotDigest ?? null,
      lifecycle: request.lifecycle,
      ...(result.matchedProject ? { project: result.matchedProject } : {}),
      ...(result.projectResolution ? { projectResolution: result.projectResolution } : {}),
      ...(compiled?.query.temporal ? { temporal: compiled.query.temporal } : {}),
      selectedEvidence,
      omissions: compiled?.omissions ?? kernelProjection?.omissions ?? [],
      coverage: compiled?.coverage ?? kernelProjection?.coverage ?? null,
      compilerBudget: compiled?.budget ?? null,
      kernelBudget: kernelProjection?.budget ?? null,
      stop: compiled?.stop ?? kernelProjection?.stop ?? NO_COMPILER_STOP,
      continuation: compiled?.continuation ?? kernelProjection?.continuation ?? null,
      compilerDiagnostics: compiled?.diagnostics ?? kernelProjection?.diagnostics ?? [],
      reporting: compiled?.reporting ?? kernelProjection?.reporting ?? null,
      recallObservation: result.recallObservation ?? null,
      kernel,
      budget: {
        reservedBytes: request.reservedBytes,
        hardBytes: result.hardBytes,
        renderedBytes: result.renderedBytes,
      },
    },
  };
}

async function recordKernel(
  request: ContextRequest,
  snapshotDigest: string,
  markdown: string,
  reason: string,
  stateRoot?: string,
): Promise<KernelReceiptResult> {
  const digest = digestMarkdown(markdown);
  if (!request.sessionId || request.host.length === 0) {
    return { action: "emitted", reason, digest, lifecycleGeneration: null };
  }
  const receipt = await recordCollaborationKernelDelivery({
    host: request.host,
    sessionId: request.sessionId,
    snapshotDigest,
    kernelDigest: digest,
    stateRoot,
  });
  return {
    action: "emitted",
    reason,
    digest,
    lifecycleGeneration: receipt.lifecycleGeneration,
  };
}

export function createContextHarness(options: BrainContextOptions = {}): ContextHarness {
  return {
    async planContext(request): Promise<ContextEnvelope> {
      const build = (event: Parameters<typeof buildBrainContext>[0], reservedBytes: number) =>
        buildBrainContext(event, {
          ...options,
          reservedOutputBytes: reservedBytes,
        });

      if (request.lifecycle !== "prompt") {
        const result = await build({ type: "session_start", cwd: request.cwd }, request.reservedBytes);
        const snapshotDigest = result.snapshotDigest;
        const kernel = snapshotDigest && result.status === "ready"
          ? await recordKernel(request, snapshotDigest, result.markdown, request.lifecycle, options.stateRoot)
          : { action: "emitted" as const, reason: request.lifecycle, digest: null, lifecycleGeneration: null };
        return envelopeFromResult(result, request, kernel);
      }

      const promptEvent = {
        type: "user_prompt_submit" as const,
        cwd: request.cwd,
        prompt: request.prompt,
        ...(request.temporal !== undefined ? { temporal: request.temporal } : {}),
      };
      if (!isValidBrainPrompt(request.prompt)) {
        const invalidPrompt = await build(promptEvent, request.reservedBytes);
        return envelopeFromResult(invalidPrompt, request, {
          action: "suppressed", reason: "snapshot_unavailable", digest: null, lifecycleGeneration: null,
        });
      }
      const kernelResult = await build({ type: "session_start", cwd: request.cwd }, 0);
      if (!kernelResult.snapshotDigest) {
        return envelopeFromResult(boundedPromptDiagnostic(kernelResult, request), request, {
          action: "suppressed", reason: "snapshot_unavailable", digest: null, lifecycleGeneration: null,
        });
      }
      if (kernelResult.status === "degraded") {
        return envelopeFromResult(boundedPromptDiagnostic(kernelResult, request), request, {
          action: "suppressed", reason: "kernel_unavailable", digest: null, lifecycleGeneration: null,
        });
      }
      const kernelRequired = await collaborationKernelRequired({
        lifecycle: "prompt",
        host: request.host,
        sessionId: request.sessionId,
        snapshotDigest: kernelResult.snapshotDigest,
        stateRoot: options.stateRoot,
      });
      if (!kernelRequired) {
        const promptResult = await build(promptEvent, request.reservedBytes);
        const normalizedPromptResult = promptResult.status === "degraded" && promptResult.markdown.trim().length === 0
          ? boundedPromptDiagnostic(promptResult, request)
          : promptResult;
        if (normalizedPromptResult.snapshotDigest !== kernelResult.snapshotDigest) {
          const mismatch: BrainContextDiagnostic = {
            code: "BRAIN_SNAPSHOT_INVALID",
            message: "The Brain Snapshot changed while assembling one Context Envelope.",
            recovery: "Retry against one stable validated snapshot.",
          };
          const degraded = { ...normalizedPromptResult, status: "degraded" as const, markdown: "", diagnostics: [mismatch], renderedBytes: 0 };
          return envelopeFromResult(degraded, request, {
            action: "suppressed", reason: "snapshot_changed", digest: null, lifecycleGeneration: null,
          });
        }
        const envelope = envelopeFromResult(normalizedPromptResult, request, {
          action: "suppressed", reason: "retention_receipt_match", digest: null, lifecycleGeneration: null,
        });
        return normalizedPromptResult.status === "degraded" &&
          !normalizedPromptResult.diagnostics.some((item) => item.code === "BRAIN_CONTEXT_BUDGET_VIOLATION")
          ? { ...envelope, status: "partial" }
          : envelope;
      }

      const separatorBytes = kernelResult.markdown.length > 0 ? 2 : 0;
      const promptResult = await build(
        promptEvent,
        request.reservedBytes + Buffer.byteLength(kernelResult.markdown, "utf8") + separatorBytes,
      );
      if (promptResult.snapshotDigest !== kernelResult.snapshotDigest) {
        const mismatch: BrainContextDiagnostic = {
          code: "BRAIN_SNAPSHOT_INVALID",
          message: "The Brain Snapshot changed while assembling one Context Envelope.",
          recovery: "Retry against one stable validated snapshot.",
        };
        const degraded = { ...promptResult, status: "degraded" as const, markdown: "", diagnostics: [mismatch], renderedBytes: 0 };
        return envelopeFromResult(degraded, request, {
          action: "suppressed", reason: "snapshot_changed", digest: null, lifecycleGeneration: null,
        });
      }
      const normalizedPromptResult = promptResult.status === "degraded" && promptResult.markdown.trim().length === 0
        ? boundedPromptDiagnostic(promptResult, request)
        : promptResult;
      const markdown = joinKernelAndPrompt(kernelResult.markdown, normalizedPromptResult.markdown);
      if (!fitsPromptEnvelope(normalizedPromptResult, request, markdown)) {
        const availableBytes = Math.max(0, normalizedPromptResult.hardBytes - request.reservedBytes);
        const kernelBytes = Buffer.byteLength(kernelResult.markdown, "utf8");
        if (normalizedPromptResult.status === "degraded" && kernelBytes <= availableBytes) {
          const kernel = await recordKernel(
            request,
            kernelResult.snapshotDigest,
            kernelResult.markdown,
            "prompt_retrieval_degraded",
            options.stateRoot,
          );
          const combined = {
            ...normalizedPromptResult,
            status: "ready" as const,
            markdown: kernelResult.markdown,
            diagnostics: [...kernelResult.diagnostics, ...normalizedPromptResult.diagnostics],
            renderedBytes: kernelBytes,
            deliveredEvidence: kernelResult.deliveredEvidence ?? [],
            kernelProjection: kernelResult.kernelProjection,
          };
          return { ...envelopeFromResult(combined, request, kernel), status: "partial" };
        }
        const bounded = boundedPromptDiagnostic(
          { ...normalizedPromptResult, status: "degraded" as const },
          request,
        );
        return envelopeFromResult(bounded, request, {
          action: "suppressed", reason: "budget_contract_violation", digest: null, lifecycleGeneration: null,
        });
      }
      const kernel = await recordKernel(
        request,
        kernelResult.snapshotDigest,
        kernelResult.markdown,
        normalizedPromptResult.status === "degraded" ? "prompt_retrieval_degraded" : "retention_unproven",
        options.stateRoot,
      );
      const combined = {
        ...normalizedPromptResult,
        status: normalizedPromptResult.status === "degraded" ? "ready" as const : normalizedPromptResult.status,
        markdown,
        diagnostics: [...kernelResult.diagnostics, ...normalizedPromptResult.diagnostics],
        renderedBytes: Buffer.byteLength(markdown, "utf8"),
        deliveredEvidence: [
          ...(kernelResult.deliveredEvidence ?? []),
          ...(promptResult.deliveredEvidence ?? []),
        ],
        kernelProjection: kernelResult.kernelProjection,
      };
      const envelope = envelopeFromResult(combined, request, kernel);
      return normalizedPromptResult.status === "degraded" && kernelResult.status === "ready"
        ? { ...envelope, status: "partial" }
        : envelope;
    },
  };
}

const defaultHarness = createContextHarness();

export async function planContext(request: ContextRequest): Promise<ContextEnvelope> {
  return defaultHarness.planContext(request);
}
