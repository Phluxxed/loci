import { execFile } from "node:child_process";
import { constants as fsConstants } from "node:fs";
import { access } from "node:fs/promises";
import { isAbsolute, join } from "node:path";

import { BrainContextError, isSafeBrainRelativePath } from "./manifest.ts";
import { isPortableWorkspaceIdentityInput, type WorkspaceIdentityInput } from "./project.ts";
import { PROMPT_EVIDENCE_DELIVERY_FORMAT, renderCompilerPromptEvidenceContext } from "./render.ts";
import {
  normalizeTemporalQuery,
  parseTemporalQuery,
  temporalCliArgs,
  temporalQueriesEqual,
  type TemporalQuery,
  type TemporalQueryInput,
} from "./temporal.ts";

export type BrainRetrievalInput = {
  brainRoot: string;
  wikiAlias: string;
  seeds: readonly string[];
  question: string;
  targetBytes: number;
  hardBytes: number;
  maxContentBytes?: number;
  maxDeliveryBytes?: number;
  env?: Record<string, string | undefined>;
  timeoutMs?: number;
  onRetrievalDuration?: (durationMs: number) => void;
  compilerContractVersion?: "1" | "3";
  workspaceIdentity?: WorkspaceIdentityInput;
  temporal?: TemporalQueryInput | TemporalQuery;
};

export type BrainProjectResolution =
  | { status: "not_requested" }
  | { status: "unknown" }
  | {
      status: "matched";
      projectId: string;
      page: string;
      matchedBy: "remote" | "alias";
    }
  | {
      status: "ambiguous";
      matchedBy: "remote" | "alias";
      candidates: Array<{ projectId: string; page: string }>;
      candidateCount: number;
    };

export type BrainCompiledEvidence = {
  id: string;
  provider: string;
  route: string;
  page: string | null;
  source: string | null;
  locator: Record<string, unknown>;
  content: string;
  roles: string[];
  authoredState: string;
  derivedFlags: string[];
  authoritySignals: string[];
  selectionReasons: string[];
  byteCost: number;
  truncated: boolean;
  atomic: boolean;
};

export type BrainCompilerOmission = {
  candidateId: string;
  reason: string;
  estimatedBytes: number | null;
};

export type BrainCompilerCoverage = {
  requiredRoles: string[];
  coveredRoles: string[];
  uncoveredRoles: string[];
};

export type BrainCompilerBudget = {
  limits: {
    targetBytes: number;
    maxBytes: number;
    targetItems: number;
    maxItems: number;
      maxEstimatedTokens: number | null;
      maxContentBytes: number | null;
      maxDeliveryBytes: number | null;
      deliveryFormat: string | null;
  };
  targetExceededForCoverage: boolean;
  evidenceBytes: number;
  envelopeBytes: number;
  items: number;
  estimatedTokens: number;
  contentBytes: number | null;
  deliveryBytes: number | null;
};

export type BrainCompilerStop = {
  reason: string;
  sufficient: boolean;
  detail: string;
};

export type BrainCompilerDiagnostic = {
  code: string;
  message: string;
  provider: string | null;
  details: Record<string, unknown>;
};

export type BrainCompilerReporting = {
  omissions: { total: number; returned: number };
  diagnostics: { total: number; returned: number };
};

export type BrainRetrievalResult = {
  contractVersion: "1" | "3";
  wiki: {
    alias: string;
    schemaVersion: string;
    runtimeContract: string;
  };
  query: {
    question: string;
    shapes: string[];
    stateView: string;
    resolvedSeeds: string[];
    projectResolution?: BrainProjectResolution;
    temporal?: TemporalQuery;
  };
  evidence: BrainCompiledEvidence[];
  omissions: BrainCompilerOmission[];
  coverage: BrainCompilerCoverage;
  budget: BrainCompilerBudget;
  stop: BrainCompilerStop;
  continuation: Record<string, unknown> | null;
  diagnostics: BrainCompilerDiagnostic[];
  reporting: BrainCompilerReporting;
  selectedPages: string[];
  evidenceCount: number;
  candidateCount: number;
};

type ExecFileError = Error & {
  code?: string | number;
  killed?: boolean;
  signal?: NodeJS.Signals;
};

const RETRIEVAL_TARGET_ITEMS = 8;
const RETRIEVAL_MAX_ITEMS = 12;

async function isExecutable(path: string): Promise<boolean> {
  try {
    await access(path, fsConstants.X_OK);
    return true;
  } catch {
    return false;
  }
}

export async function resolveLlmWikiCommand(
  input: Pick<BrainRetrievalInput, "brainRoot" | "env">,
): Promise<string> {
  const override = input.env?.ANVIL_LLM_WIKI_BIN ?? process.env.ANVIL_LLM_WIKI_BIN;
  if (override !== undefined) {
    if (override.length > 0 && !override.includes("/")) return override;
    if (override.length > 0 && (await isExecutable(override))) return override;
    throw new BrainContextError(
      "BRAIN_LLM_WIKI_MISSING",
      "ANVIL_LLM_WIKI_BIN does not point to an executable file.",
      "Set ANVIL_LLM_WIKI_BIN to an executable llm-wiki path.",
    );
  }

  const brainLocal = join(input.brainRoot, ".venv", "bin", "llm-wiki");
  if (await isExecutable(brainLocal)) return brainLocal;
  return "llm-wiki";
}

function runCompiler(command: string, args: string[], input: BrainRetrievalInput): Promise<string> {
  return new Promise((resolve, reject) => {
    execFile(
      command,
      args,
      {
        cwd: input.brainRoot,
        encoding: "utf8",
        env: { ...process.env, ...input.env },
        maxBuffer: 16 * 1024 * 1024,
        timeout: input.timeoutMs ?? 10_000,
      },
      (error, stdout) => {
        if (error) {
          const failure = error as ExecFileError;
          if (failure.code === "ENOENT") {
            reject(
              new BrainContextError(
                "BRAIN_LLM_WIKI_MISSING",
                "llm-wiki is not available from the Brain environment or PATH.",
                "Install llm-wiki in the Brain virtual environment or set ANVIL_LLM_WIKI_BIN.",
              ),
            );
            return;
          }
          if (failure.killed || failure.signal === "SIGTERM") {
            reject(
              new BrainContextError(
                "BRAIN_RETRIEVAL_TIMEOUT",
                "Brain retrieval exceeded its local timeout.",
                "Check llm-wiki health or increase the bounded retrieval timeout.",
              ),
            );
            return;
          }
          reject(
            new BrainContextError(
              "BRAIN_RETRIEVAL_FAILED",
              "llm-wiki compile-context exited unsuccessfully.",
              "Run the Brain doctor and a local compile-context probe.",
            ),
          );
          return;
        }
        resolve(stdout);
      },
    );
  });
}

type JsonRecord = Record<string, unknown>;

function invalidCompilerOutput(message: string): never {
  throw new BrainContextError(
    "BRAIN_RETRIEVAL_INVALID",
    message,
    "Verify the supported llm-wiki compiled-context contract.",
  );
}

function isAbsoluteTransportPath(value: string): boolean {
  return (
    isAbsolute(value) ||
    value.startsWith("\\") ||
    /^\/?[a-zA-Z]:[\\/]/.test(value) ||
    /^file:/i.test(value)
  );
}

function containsAbsoluteTransportPath(value: unknown, seen = new Set<object>()): boolean {
  if (typeof value === "string") return isAbsoluteTransportPath(value);
  if (typeof value !== "object" || value === null || seen.has(value)) return false;
  seen.add(value);
  if (Array.isArray(value)) return value.some((item) => containsAbsoluteTransportPath(item, seen));
  return Object.entries(value).some(
    ([key, item]) => isAbsoluteTransportPath(key) || containsAbsoluteTransportPath(item, seen),
  );
}

function assertPathFreeMetadata(value: unknown, label: string): void {
  if (!containsAbsoluteTransportPath(value)) return;
  throw new BrainContextError(
    "BRAIN_SELECTED_PATH_UNSAFE",
    `llm-wiki returned an absolute path in ${label} metadata.`,
    "Repair the compiler response so contract version 3 metadata remains path-free.",
  );
}

function portableProjectId(value: unknown, label: string): string {
  if (
    typeof value !== "string" ||
    value.length === 0 ||
    value.length > 64 ||
    !/^[a-z0-9]+(?:_[a-z0-9]+)*$/.test(value)
  ) invalidCompilerOutput(`llm-wiki ${label} is invalid.`);
  return value;
}

function parseProjectResolution(value: unknown): BrainProjectResolution {
  const resolution = recordValue(value, "query.project_resolution");
  const status = resolution.status;
  if (status === "not_requested") return { status: "not_requested" };
  if (status === "unknown") return { status: "unknown" };

  if (status === "matched") {
    const projectId = portableProjectId(resolution.project_id, "query.project_resolution.project_id");
    const page = stringValue(resolution, "page", "query.project_resolution");
    if (isAbsoluteTransportPath(page) || !isSafeBrainRelativePath(page)) {
      throw new BrainContextError(
        "BRAIN_SELECTED_PATH_UNSAFE",
        "llm-wiki selected an unsafe project page.",
        "Reject or repair the project resolution so every selected page stays inside the Brain root.",
      );
    }
    const matchedBy = resolution.matched_by;
    if (matchedBy !== "remote" && matchedBy !== "alias") {
      invalidCompilerOutput("llm-wiki query.project_resolution.matched_by is invalid.");
    }
    return { status: "matched", projectId, page, matchedBy };
  }

  if (status === "ambiguous") {
    const matchedBy = resolution.matched_by;
    if (matchedBy !== "remote" && matchedBy !== "alias") {
      invalidCompilerOutput("llm-wiki query.project_resolution.matched_by is invalid.");
    }
    const candidates = arrayValue(resolution, "candidates", "query.project_resolution").map((value, index) => {
      const label = `query.project_resolution.candidates[${index}]`;
      const candidate = recordValue(value, label);
      const projectId = portableProjectId(candidate.project_id, `${label}.project_id`);
      const page = stringValue(candidate, "page", label);
      if (isAbsoluteTransportPath(page) || !isSafeBrainRelativePath(page)) {
        throw new BrainContextError(
          "BRAIN_SELECTED_PATH_UNSAFE",
          "llm-wiki selected an unsafe project page.",
          "Reject or repair the project resolution so every selected page stays inside the Brain root.",
        );
      }
      return { projectId, page };
    });
    if (candidates.length > 8) invalidCompilerOutput("llm-wiki returned too many project resolution candidates.");
    const candidateCount = integerValue(resolution, "candidate_count", "query.project_resolution");
    if (candidateCount < candidates.length) {
      invalidCompilerOutput("llm-wiki query.project_resolution.candidate_count is smaller than candidates.");
    }
    return { status: "ambiguous", matchedBy, candidates, candidateCount };
  }

  invalidCompilerOutput("llm-wiki query.project_resolution.status is invalid.");
}

function recordValue(value: unknown, label: string): JsonRecord {
  if (typeof value !== "object" || value === null || Array.isArray(value)) {
    invalidCompilerOutput(`llm-wiki ${label} is invalid.`);
  }
  return value as JsonRecord;
}

function stringValue(record: JsonRecord, key: string, label: string): string {
  const value = record[key];
  if (typeof value !== "string") invalidCompilerOutput(`llm-wiki ${label}.${key} is invalid.`);
  return value;
}

function nullableStringValue(record: JsonRecord, key: string, label: string): string | null {
  const value = record[key];
  if (value !== null && typeof value !== "string") {
    invalidCompilerOutput(`llm-wiki ${label}.${key} is invalid.`);
  }
  return value as string | null;
}

function booleanValue(record: JsonRecord, key: string, label: string): boolean {
  const value = record[key];
  if (typeof value !== "boolean") invalidCompilerOutput(`llm-wiki ${label}.${key} is invalid.`);
  return value;
}

function integerValue(record: JsonRecord, key: string, label: string): number {
  const value = record[key];
  if (!Number.isSafeInteger(value) || (value as number) < 0) {
    invalidCompilerOutput(`llm-wiki ${label}.${key} is invalid.`);
  }
  return value as number;
}

function nullableIntegerValue(record: JsonRecord, key: string, label: string): number | null {
  const value = record[key];
  if (value !== null && (!Number.isSafeInteger(value) || (value as number) < 0)) {
    invalidCompilerOutput(`llm-wiki ${label}.${key} is invalid.`);
  }
  return value as number | null;
}

function optionalIntegerValue(record: JsonRecord, key: string, label: string): number | null {
  return record[key] === undefined ? null : integerValue(record, key, label);
}

function stringArrayValue(record: JsonRecord, key: string, label: string): string[] {
  const value = record[key];
  if (!Array.isArray(value) || value.some((item) => typeof item !== "string")) {
    invalidCompilerOutput(`llm-wiki ${label}.${key} is invalid.`);
  }
  return [...value] as string[];
}

function arrayValue(record: JsonRecord, key: string, label: string): unknown[] {
  const value = record[key];
  if (!Array.isArray(value)) invalidCompilerOutput(`llm-wiki ${label}.${key} is invalid.`);
  return value as unknown[];
}

function parseEvidence(value: unknown, index: number, enforcePathFreeMetadata: boolean): BrainCompiledEvidence {
  const label = `evidence[${index}]`;
  const evidence = recordValue(value, label);
  const page = nullableStringValue(evidence, "page", label);
  if (page !== null && !isSafeBrainRelativePath(page)) {
    throw new BrainContextError(
      "BRAIN_SELECTED_PATH_UNSAFE",
      enforcePathFreeMetadata
        ? "llm-wiki selected an unsafe Brain path."
        : `llm-wiki selected an unsafe Brain path: ${page}.`,
      "Reject or repair the unsafe retrieval result.",
    );
  }
  const source = nullableStringValue(evidence, "source", label);
  if (enforcePathFreeMetadata && source !== null && isAbsoluteTransportPath(source)) {
    throw new BrainContextError(
      "BRAIN_SELECTED_PATH_UNSAFE",
      "llm-wiki returned an absolute evidence source.",
      "Repair the compiler response so evidence provenance remains path-free.",
    );
  }
  const locator = recordValue(evidence.locator, `${label}.locator`);
  if (enforcePathFreeMetadata) assertPathFreeMetadata(locator, label);
  return {
    id: stringValue(evidence, "id", label),
    provider: stringValue(evidence, "provider", label),
    route: stringValue(evidence, "route", label),
    page,
    source,
    locator: { ...locator },
    content: stringValue(evidence, "content", label),
    roles: stringArrayValue(evidence, "roles", label),
    authoredState: stringValue(evidence, "authored_state", label),
    derivedFlags: stringArrayValue(evidence, "derived_flags", label),
    authoritySignals: stringArrayValue(evidence, "authority_signals", label),
    selectionReasons: stringArrayValue(evidence, "selection_reasons", label),
    byteCost: integerValue(evidence, "byte_cost", label),
    truncated: booleanValue(evidence, "truncated", label),
    atomic: booleanValue(evidence, "atomic", label),
  };
}

export function parseCompilerOutput(stdout: string): BrainRetrievalResult {
  let value: unknown;
  try {
    value = JSON.parse(stdout);
  } catch {
    throw new BrainContextError(
      "BRAIN_RETRIEVAL_INVALID",
      "llm-wiki compile-context returned malformed JSON.",
      "Run a local compile-context probe and repair the llm-wiki runtime.",
    );
  }

  const record = recordValue(value, "compile-context envelope");
  if (
    record.kind !== "compiled_context" ||
    (record.contract_version !== "1" && record.contract_version !== "3") ||
    !Array.isArray(record.evidence)
  ) {
    throw new BrainContextError(
      "BRAIN_RETRIEVAL_INVALID",
      "llm-wiki compile-context returned an unsupported contract.",
      "Use compiled-context contract version 1 for legacy manifests or version 3 for project-aware manifests.",
    );
  }
  const contractVersion = record.contract_version as "1" | "3";
  if (record.evidence.length > RETRIEVAL_MAX_ITEMS) {
    throw new BrainContextError(
      "BRAIN_RETRIEVAL_INVALID",
      "llm-wiki compile-context returned too many evidence items.",
      "Keep compiled-context evidence within the bounded item limit.",
    );
  }

  const wiki = recordValue(record.wiki, "wiki");
  const query = recordValue(record.query, "query");
  if (contractVersion === "1" && query.temporal !== undefined) {
    invalidCompilerOutput("llm-wiki contract version 1 returned unsupported temporal query metadata.");
  }
  const parsedQuery = {
    question: stringValue(query, "question", "query"),
    shapes: stringArrayValue(query, "shapes", "query"),
    stateView: stringValue(query, "state_view", "query"),
    resolvedSeeds: stringArrayValue(query, "resolved_seeds", "query"),
    ...(contractVersion === "3"
      ? { projectResolution: parseProjectResolution(query.project_resolution) }
      : {}),
    ...(query.temporal === undefined ? {} : { temporal: parseTemporalQuery(query.temporal) }),
  };

  const evidence = record.evidence.map((item, index) => parseEvidence(item, index, contractVersion === "3"));
  const omissions = arrayValue(record, "omissions", "envelope").map((value, index) => {
    const label = `omissions[${index}]`;
    const omission = recordValue(value, label);
    return {
      candidateId: stringValue(omission, "candidate_id", label),
      reason: stringValue(omission, "reason", label),
      estimatedBytes: nullableIntegerValue(omission, "estimated_bytes", label),
    };
  });
  const coverageRecord = recordValue(record.coverage, "coverage");
  const coverage = {
    requiredRoles: stringArrayValue(coverageRecord, "required_roles", "coverage"),
    coveredRoles: stringArrayValue(coverageRecord, "covered_roles", "coverage"),
    uncoveredRoles: stringArrayValue(coverageRecord, "uncovered_roles", "coverage"),
  };
  const budgetRecord = recordValue(record.budget, "budget");
  const limitsRecord = recordValue(budgetRecord.limits, "budget.limits");
  const budget = {
    limits: {
      targetBytes: integerValue(limitsRecord, "target_bytes", "budget.limits"),
      maxBytes: integerValue(limitsRecord, "max_bytes", "budget.limits"),
      targetItems: integerValue(limitsRecord, "target_items", "budget.limits"),
      maxItems: integerValue(limitsRecord, "max_items", "budget.limits"),
      maxEstimatedTokens: nullableIntegerValue(limitsRecord, "max_estimated_tokens", "budget.limits"),
      maxContentBytes: optionalIntegerValue(limitsRecord, "max_content_bytes", "budget.limits"),
      maxDeliveryBytes: optionalIntegerValue(limitsRecord, "max_delivery_bytes", "budget.limits"),
      deliveryFormat: limitsRecord.delivery_format === undefined ? null : stringValue(limitsRecord, "delivery_format", "budget.limits"),
    },
    targetExceededForCoverage: booleanValue(
      budgetRecord,
      "target_exceeded_for_coverage",
      "budget",
    ),
    evidenceBytes: integerValue(budgetRecord, "evidence_bytes", "budget"),
    envelopeBytes: integerValue(budgetRecord, "envelope_bytes", "budget"),
    items: integerValue(budgetRecord, "items", "budget"),
    estimatedTokens: integerValue(budgetRecord, "estimated_tokens", "budget"),
    contentBytes: optionalIntegerValue(budgetRecord, "content_bytes", "budget"),
    deliveryBytes: optionalIntegerValue(budgetRecord, "delivery_bytes", "budget"),
  };
  if (budget.items !== evidence.length || budget.evidenceBytes !== evidence.reduce((sum, item) => sum + item.byteCost, 0)) {
    invalidCompilerOutput("llm-wiki budget accounting does not match its evidence records.");
  }
  const actualContentBytes = evidence.reduce((sum, item) => sum + Buffer.byteLength(item.content, "utf8"), 0);
  if (budget.contentBytes !== null && budget.contentBytes !== actualContentBytes) {
    invalidCompilerOutput("llm-wiki content budget accounting does not match its evidence records.");
  }
  const stopRecord = recordValue(record.stop, "stop");
  const stop = {
    reason: stringValue(stopRecord, "reason", "stop"),
    sufficient: booleanValue(stopRecord, "sufficient", "stop"),
    detail: stringValue(stopRecord, "detail", "stop"),
  };
  const continuationRecord = record.continuation === null ? null : recordValue(record.continuation, "continuation");
  if (contractVersion === "3" && continuationRecord !== null) {
    assertPathFreeMetadata(continuationRecord, "continuation");
  }
  const continuation = continuationRecord === null ? null : { ...continuationRecord };
  const diagnostics = arrayValue(record, "diagnostics", "envelope").map((value, index) => {
    const label = `diagnostics[${index}]`;
    const diagnostic = recordValue(value, label);
    const details = recordValue(diagnostic.details, `${label}.details`);
    if (contractVersion === "3") assertPathFreeMetadata(details, label);
    return {
      code: stringValue(diagnostic, "code", label),
      message: stringValue(diagnostic, "message", label),
      provider: nullableStringValue(diagnostic, "provider", label),
      details: { ...details },
    };
  });
  const reportingRecord = recordValue(record.reporting, "reporting");
  const parseReportingCount = (key: "omissions" | "diagnostics") => {
    const value = recordValue(reportingRecord[key], `reporting.${key}`);
    const count = {
      total: integerValue(value, "total", `reporting.${key}`),
      returned: integerValue(value, "returned", `reporting.${key}`),
    };
    if (count.total < count.returned) {
      invalidCompilerOutput(`llm-wiki reporting.${key}.total is smaller than returned.`);
    }
    return count;
  };
  const reporting = {
    omissions: parseReportingCount("omissions"),
    diagnostics: parseReportingCount("diagnostics"),
  };
  if (reporting.omissions.returned !== omissions.length || reporting.diagnostics.returned !== diagnostics.length) {
    invalidCompilerOutput("llm-wiki reporting counts do not match returned records.");
  }

  const selectedPages: string[] = [];
  const seen = new Set<string>();
  for (const item of evidence) {
    const page = item.page;
    if (page === null) continue;
    if (!seen.has(page)) {
      selectedPages.push(page);
      seen.add(page);
    }
  }
  return {
    contractVersion,
    wiki: {
      alias: stringValue(wiki, "alias", "wiki"),
      schemaVersion: stringValue(wiki, "schema_version", "wiki"),
      runtimeContract: stringValue(wiki, "runtime_contract", "wiki"),
    },
    query: parsedQuery,
    evidence,
    omissions,
    coverage,
    budget,
    stop,
    continuation,
    diagnostics,
    reporting,
    selectedPages,
    evidenceCount: evidence.length,
    candidateCount: selectedPages.length,
  };
}

export async function retrieveBrainContext(input: BrainRetrievalInput): Promise<BrainRetrievalResult> {
  const compilerContractVersion = input.compilerContractVersion ?? (input.workspaceIdentity || input.temporal ? "3" : "1");
  const temporal = normalizeTemporalQuery(input.temporal);
  if (temporal !== undefined && compilerContractVersion !== "3") {
    throw new BrainContextError(
      "BRAIN_RETRIEVAL_INVALID",
      "Temporal queries are only supported by compile-context contract version 3.",
      "Use compiler contract version 3 when supplying a temporal query.",
    );
  }
  if (compilerContractVersion === "1" && input.workspaceIdentity !== undefined) {
    throw new BrainContextError(
      "BRAIN_RETRIEVAL_INVALID",
      "Workspace Identity is only supported by compile-context contract version 3.",
      "Use compiler contract version 3 when supplying Workspace Identity.",
    );
  }
  if (
    compilerContractVersion === "3" &&
    input.workspaceIdentity !== undefined &&
    !isPortableWorkspaceIdentityInput(input.workspaceIdentity)
  ) {
    throw new BrainContextError(
      "BRAIN_RETRIEVAL_INVALID",
      "Workspace Identity contains an unsafe or non-normalized value.",
      "Pass only a path-free directory alias and normalized host/path remotes to compiler contract version 3.",
    );
  }
  const command = await resolveLlmWikiCommand(input);
  const args = [
    "compile-context",
    "--wiki",
    input.brainRoot,
    "--alias",
    input.wikiAlias,
    "--question",
    input.question,
    ...input.seeds.flatMap((seed) => ["--seed", seed]),
    "--target-bytes",
    String(input.targetBytes),
    "--max-bytes",
    String(input.hardBytes),
    ...(input.maxContentBytes === undefined
      ? []
      : ["--max-content-bytes", String(input.maxContentBytes)]),
    ...(input.maxDeliveryBytes === undefined
      ? []
      : ["--max-delivery-bytes", String(input.maxDeliveryBytes), "--delivery-format", PROMPT_EVIDENCE_DELIVERY_FORMAT]),
    ...(temporal === undefined ? [] : temporalCliArgs(temporal)),
    "--target-items",
    String(RETRIEVAL_TARGET_ITEMS),
    "--max-items",
    String(RETRIEVAL_MAX_ITEMS),
    ...(compilerContractVersion === "3" && input.workspaceIdentity !== undefined
      ? [
          "--workspace-directory-alias",
          input.workspaceIdentity.directory_alias,
          ...input.workspaceIdentity.remotes.flatMap((remote) => ["--workspace-remote", remote]),
        ]
      : []),
    "--contract-version",
    compilerContractVersion,
  ];
  const startedAt = performance.now();
  try {
    const result = parseCompilerOutput(await runCompiler(command, args, input));
    if (result.contractVersion !== compilerContractVersion) {
      throw new BrainContextError(
        "BRAIN_RETRIEVAL_INVALID",
        "llm-wiki compile-context returned a different contract than requested.",
        "Repair the compiler version negotiation before retrying.",
      );
    }
    if (result.wiki.alias !== input.wikiAlias || result.query.question !== input.question) {
      throw new BrainContextError(
        "BRAIN_RETRIEVAL_INVALID",
        "llm-wiki compile-context returned evidence for a different wiki or question.",
        "Repair the compiler request/response identity contract before retrying.",
      );
    }
    if (temporal !== undefined && (
      result.query.temporal === undefined ||
      !temporalQueriesEqual(result.query.temporal, temporal)
    )) {
      throw new BrainContextError(
        "BRAIN_RETRIEVAL_INVALID",
        "llm-wiki compile-context did not echo the requested temporal query.",
        "Repair the compiler temporal request/response identity contract before retrying.",
      );
    }
    if (input.maxContentBytes !== undefined) {
      if (
        result.budget.limits.maxContentBytes !== input.maxContentBytes ||
        result.budget.contentBytes === null
      ) {
        throw new BrainContextError(
          "BRAIN_CONTEXT_BUDGET_VIOLATION",
          "llm-wiki did not honor the requested evidence-content byte allowance.",
          "Repair the compiler content-budget contract before retrying.",
        );
      }
    }
    if (input.maxDeliveryBytes !== undefined && (
      result.budget.limits.maxDeliveryBytes !== input.maxDeliveryBytes ||
      result.budget.limits.deliveryFormat !== PROMPT_EVIDENCE_DELIVERY_FORMAT ||
      result.budget.deliveryBytes === null ||
      result.budget.deliveryBytes > input.maxDeliveryBytes ||
      result.budget.deliveryBytes !== renderCompilerPromptEvidenceContext(result).renderedBytes
    )) {
      throw new BrainContextError(
        "BRAIN_CONTEXT_BUDGET_VIOLATION",
        "llm-wiki did not honor the requested Prompt Evidence delivery-byte allowance.",
        "Repair the compiler delivery-budget contract; do not truncate the returned evidence in Anvil.",
      );
    }
    return result;
  } finally {
    try {
      input.onRetrievalDuration?.(Math.max(0, Math.round(performance.now() - startedAt)));
    } catch {
      // Observability callbacks must not change recall behavior.
    }
  }
}
