import { spawnSync } from "node:child_process";
import { basename, resolve } from "node:path";

import type {
  BrainBootstrapManifest,
  BrainBootstrapManifestV1,
  BrainBootstrapProject,
} from "./manifest.ts";
import { normalizeGitRemote } from "../repository/identity.ts";

export { normalizeGitRemote } from "../repository/identity.ts";

export type WorkspaceProjectIdentity = {
  gitRoot?: string;
  directoryAlias: string;
  remotes: string[];
  /** Number of live Git remotes discarded before the identity reached callers. */
  discardedRemoteCount?: number;
};

/** Portable workspace facts accepted by the project-aware compiler. */
export type WorkspaceIdentityInput = Readonly<{
  directory_alias: string;
  remotes: string[];
}>;

export type WorkspaceIdentityDiagnostic = Readonly<{
  code: "PROJECT_IDENTITY_INVALID";
  message: string;
  recovery: string;
}>;

export type WorkspaceIdentityInputConversion = Readonly<{
  input: WorkspaceIdentityInput;
  diagnostics: WorkspaceIdentityDiagnostic[];
}>;

export type BrainProjectSelection =
  | { kind: "matched"; project: BrainBootstrapProject; matchedBy: "remote" | "alias" }
  | { kind: "unknown" }
  | { kind: "ambiguous"; pages: string[] };

function runGit(cwd: string, args: string[]): string | undefined {
  const result = spawnSync("git", ["-C", cwd, ...args], {
    encoding: "utf8",
    stdio: ["ignore", "pipe", "ignore"],
  });
  if (result.status !== 0 || typeof result.stdout !== "string") return undefined;
  const output = result.stdout.trim();
  return output.length > 0 ? output : undefined;
}

export function inspectWorkspaceProject(cwd: string): WorkspaceProjectIdentity {
  const resolvedCwd = resolve(cwd);
  const gitRoot = runGit(resolvedCwd, ["rev-parse", "--show-toplevel"]);
  const workspaceRoot = gitRoot ?? resolvedCwd;
  const remoteOutput = gitRoot ? runGit(gitRoot, ["remote", "-v"]) : undefined;
  const remotes = new Set<string>();
  let discardedRemoteCount = 0;

  for (const line of remoteOutput?.split("\n") ?? []) {
    const fields = line.trim().split(/\s+/);
    if (line.trim().length === 0) continue;
    if (fields.length < 2) {
      discardedRemoteCount += 1;
      continue;
    }
    const normalized = portableRemote(fields[1]);
    if (normalized === undefined) discardedRemoteCount += 1;
    else remotes.add(normalized);
  }

  return {
    ...(gitRoot ? { gitRoot } : {}),
    directoryAlias: basename(workspaceRoot).toLowerCase(),
    remotes: [...remotes],
    ...(discardedRemoteCount > 0 ? { discardedRemoteCount } : {}),
  };
}

const WORKSPACE_IDENTITY_MAX_REMOTES = 8;
const WORKSPACE_IDENTITY_MAX_ALIAS_CHARS = 255;
const WORKSPACE_IDENTITY_MAX_REMOTE_CHARS = 1_024;
const CONTROL_CHARACTER = /[\u0000-\u001f\u007f]/;
const NORMALIZED_REMOTE = /^[a-z0-9._-]+(?:\/[a-z0-9._-]+)+$/;

function isPortableAlias(value: string): boolean {
  return (
    value.length > 0 &&
    value.length <= WORKSPACE_IDENTITY_MAX_ALIAS_CHARS &&
    value !== "." &&
    value !== ".." &&
    !value.includes("/") &&
    !value.includes("\\") &&
    !CONTROL_CHARACTER.test(value)
  );
}

function portableRemote(value: string): string | undefined {
  try {
    const raw = value.trim();
    if (raw.includes("?") || raw.includes("#")) return undefined;
    const normalized = normalizeGitRemote(value);
    if (
      normalized.length === 0 ||
      normalized.length > WORKSPACE_IDENTITY_MAX_REMOTE_CHARS ||
      CONTROL_CHARACTER.test(normalized) ||
      !NORMALIZED_REMOTE.test(normalized) ||
      normalized.split("/").some((segment) => segment === "." || segment === "..")
    ) return undefined;
    const [host, ...pathSegments] = normalized.split("/");
    if (
      host.split(".").some((label) =>
        label.length === 0 ||
        label.startsWith("-") ||
        label.endsWith("-") ||
        !/^[a-z0-9-]+$/.test(label),
      ) ||
      pathSegments.length === 0 ||
      pathSegments.some((segment) => segment === "." || segment === "..")
    ) return undefined;
    return normalized;
  } catch {
    return undefined;
  }
}

/**
 * Convert internal workspace inspection into the path-free compiler wire
 * value. The Git root is deliberately not copied across this seam.
 */
export function toWorkspaceIdentityInput(identity: WorkspaceProjectIdentity): WorkspaceIdentityInput {
  const directoryAlias = identity.directoryAlias.trim().toLowerCase();
  if (!isPortableAlias(directoryAlias)) {
    throw new Error("Workspace directory alias is not a portable basename.");
  }

  const remotes: string[] = [];
  const seen = new Set<string>();
  for (const remote of identity.remotes) {
    const normalized = portableRemote(remote);
    if (normalized === undefined || seen.has(normalized)) continue;
    seen.add(normalized);
    remotes.push(normalized);
    if (remotes.length === WORKSPACE_IDENTITY_MAX_REMOTES) break;
  }
  return { directory_alias: directoryAlias, remotes };
}

/**
 * Convert workspace observations while retaining only one bounded diagnostic
 * for any discarded remote observations. Diagnostic text never includes the
 * discarded value, Git root, or another host path.
 */
export function toWorkspaceIdentityInputWithDiagnostics(
  identity: WorkspaceProjectIdentity,
): WorkspaceIdentityInputConversion {
  let discardedRemoteCount = identity.discardedRemoteCount ?? 0;
  const seen = new Set<string>();
  for (const remote of identity.remotes) {
    const normalized = portableRemote(remote);
    if (normalized === undefined) {
      discardedRemoteCount += 1;
    } else if (!seen.has(normalized)) {
      seen.add(normalized);
      if (seen.size > WORKSPACE_IDENTITY_MAX_REMOTES) discardedRemoteCount += 1;
    }
  }
  const input = toWorkspaceIdentityInput(identity);
  return {
    input,
    diagnostics: discardedRemoteCount > 0
      ? [{
          code: "PROJECT_IDENTITY_INVALID",
          message: "One or more workspace remote observations were discarded before compiler transport.",
          recovery: "Repair the repository remote or continue with directory-alias routing.",
        }]
      : [],
  };
}

/**
 * Validate an already-normalized wire value at the retrieval boundary. This
 * keeps direct callers from bypassing the host-observation conversion and
 * accidentally placing a path-bearing value on compiler argv.
 */
export function isPortableWorkspaceIdentityInput(value: unknown): value is WorkspaceIdentityInput {
  if (typeof value !== "object" || value === null || Array.isArray(value)) return false;
  const candidate = value as Record<string, unknown>;
  if (
    typeof candidate.directory_alias !== "string" ||
    candidate.directory_alias !== candidate.directory_alias.trim() ||
    !isPortableAlias(candidate.directory_alias) ||
    !Array.isArray(candidate.remotes) ||
    candidate.remotes.length > WORKSPACE_IDENTITY_MAX_REMOTES
  ) return false;

  const seen = new Set<string>();
  return candidate.remotes.every((remote) => {
    if (typeof remote !== "string" || portableRemote(remote) !== remote || seen.has(remote)) return false;
    seen.add(remote);
    return true;
  });
}

/** Alias kept descriptive at call sites that construct the transport value. */
export const workspaceIdentityInput = toWorkspaceIdentityInput;

function selectionForMatches(
  matches: BrainBootstrapProject[],
  matchedBy: "remote" | "alias",
): BrainProjectSelection {
  if (matches.length === 0) return { kind: "unknown" };
  if (matches.length === 1) return { kind: "matched", project: matches[0], matchedBy };
  return { kind: "ambiguous", pages: matches.map((project) => project.page).sort() };
}

export function selectBrainProject(
  manifest: BrainBootstrapManifest,
  identity: WorkspaceProjectIdentity,
): BrainProjectSelection {
  if (manifest.version !== 1) return { kind: "unknown" };
  return selectLegacyBrainProject(manifest, identity);
}

function selectLegacyBrainProject(
  manifest: BrainBootstrapManifestV1,
  identity: WorkspaceProjectIdentity,
): BrainProjectSelection {
  const workspaceRemotes = new Set(identity.remotes.map(normalizeGitRemote));
  const remoteMatches = manifest.projects.filter((project) =>
    project.remotes.some((remote) => workspaceRemotes.has(normalizeGitRemote(remote))),
  );
  if (remoteMatches.length > 0) return selectionForMatches(remoteMatches, "remote");

  const alias = identity.directoryAlias.toLowerCase();
  const aliasMatches = manifest.projects.filter((project) =>
    project.aliases.some((candidate) => candidate.toLowerCase() === alias),
  );
  return selectionForMatches(aliasMatches, "alias");
}
