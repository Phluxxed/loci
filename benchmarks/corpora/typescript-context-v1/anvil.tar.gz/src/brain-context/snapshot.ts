import { execFile } from "node:child_process";
import { realpathSync } from "node:fs";
import { isAbsolute, join, relative, resolve, sep } from "node:path";

import { resolveWorkContextStateRoot } from "../work-context/index.ts";
import { BrainContextError } from "./manifest.ts";
import { resolveLlmWikiCommand } from "./retrieve.ts";

export type BrainSnapshot = Readonly<{
  digest: string;
  wikiRoot: string;
  outputRoot: string;
  status: "current" | "last_known_good";
}>;

type SnapshotOptions = Readonly<{
  brainRoot: string;
  wikiAlias: string;
  stateRoot?: string;
  env?: Record<string, string | undefined>;
  timeoutMs?: number;
}>;

function run(command: string, args: string[], options: SnapshotOptions): Promise<string> {
  return new Promise((resolveOutput, reject) => {
    execFile(command, args, {
      cwd: options.brainRoot,
      encoding: "utf8",
      env: { ...process.env, ...options.env },
      maxBuffer: 1024 * 1024,
      timeout: options.timeoutMs ?? 10_000,
    }, (error, stdout) => error ? reject(error) : resolveOutput(stdout));
  });
}

function inside(root: string, candidate: string): boolean {
  const path = relative(resolve(root), resolve(candidate));
  return path === "" || (!path.startsWith(`..${sep}`) && path !== ".." && !isAbsolute(path));
}

function parseSnapshot(stdout: string, alias: string, outputRoot: string): BrainSnapshot {
  let value: unknown;
  try {
    value = JSON.parse(stdout);
  } catch {
    throw new BrainContextError(
      "BRAIN_SNAPSHOT_INVALID",
      "llm-wiki returned malformed Brain Snapshot metadata.",
      "Repair the installed llm-wiki snapshot contract before retrying.",
    );
  }
  if (typeof value !== "object" || value === null || Array.isArray(value)) {
    throw new BrainContextError("BRAIN_SNAPSHOT_INVALID", "llm-wiki returned invalid Brain Snapshot metadata.", "Repair the installed llm-wiki snapshot contract before retrying.");
  }
  const record = value as Record<string, unknown>;
  const digest = record.digest;
  const wikiRoot = record.snapshot_wiki_root;
  const status = record.status;
  if (
    record.contract_version !== "1" || record.alias !== alias ||
    typeof digest !== "string" || !/^[a-f0-9]{64}$/.test(digest) ||
    typeof wikiRoot !== "string" || !isAbsolute(wikiRoot) ||
    !["published", "already_current", "current", "last_known_good"].includes(String(status))
  ) {
    throw new BrainContextError("BRAIN_SNAPSHOT_INVALID", "llm-wiki returned unsupported Brain Snapshot metadata.", "Repair the installed llm-wiki snapshot contract before retrying.");
  }
  const canonicalOutputRoot = realpathSync(outputRoot);
  const canonicalWikiRoot = realpathSync(wikiRoot);
  const expectedRoot = join(canonicalOutputRoot, alias, "snapshots", digest, "wiki");
  if (canonicalWikiRoot !== expectedRoot || !inside(canonicalOutputRoot, canonicalWikiRoot)) {
    throw new BrainContextError("BRAIN_SNAPSHOT_INVALID", "llm-wiki returned a Brain Snapshot outside the trusted snapshot store.", "Repair the snapshot receipt or storage permissions before retrying.");
  }
  return {
    digest,
    wikiRoot: canonicalWikiRoot,
    outputRoot: canonicalOutputRoot,
    status: status === "last_known_good" ? "last_known_good" : "current",
  };
}

export async function resolveBrainSnapshot(options: SnapshotOptions): Promise<BrainSnapshot> {
  const outputRoot = join(resolveWorkContextStateRoot(options.stateRoot), "brain-snapshots");
  const command = await resolveLlmWikiCommand(options);
  try {
    const stdout = await run(command, [
      "publish-snapshot", "--wiki", options.brainRoot, "--alias", options.wikiAlias,
      "--output-root", outputRoot,
    ], options);
    return parseSnapshot(stdout, options.wikiAlias, outputRoot);
  } catch (publicationError) {
    try {
      const stdout = await run(command, [
        "resolve-snapshot", "--alias", options.wikiAlias, "--output-root", outputRoot,
      ], options);
      const snapshot = parseSnapshot(stdout, options.wikiAlias, outputRoot);
      return { ...snapshot, status: "last_known_good" };
    } catch {
      if (publicationError instanceof BrainContextError) throw publicationError;
      throw new BrainContextError(
        "BRAIN_SNAPSHOT_UNAVAILABLE",
        "No validated current or last-known-good Brain Snapshot is available.",
        "Publish a valid Brain Snapshot with the installed llm-wiki runtime.",
      );
    }
  }
}
