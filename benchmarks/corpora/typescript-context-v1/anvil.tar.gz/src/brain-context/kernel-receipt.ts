import { createHash, randomUUID } from "node:crypto";
import { chmod, mkdir, readFile, rename, rm, stat, writeFile } from "node:fs/promises";
import { dirname, join } from "node:path";
import { setTimeout as sleep } from "node:timers/promises";

import { resolveWorkContextStateRoot } from "../work-context/index.ts";

const RECEIPT_MAX_BYTES = 4_096;
const IDENTITY_MAX_CHARS = 512;
const DIGEST_PATTERN = /^[a-f0-9]{64}$/;

export type CollaborationKernelLifecycle =
  | "session_start"
  | "resume"
  | "clear"
  | "compact"
  | "prompt";

export type CollaborationKernelDecision = Readonly<{
  lifecycle: CollaborationKernelLifecycle;
  host?: string;
  sessionId?: string;
  snapshotDigest: string;
  stateRoot?: string;
}>;

export type CollaborationKernelDelivery = Readonly<{
  host: string;
  sessionId: string;
  snapshotDigest: string;
  kernelDigest: string;
  stateRoot?: string;
}>;

export type CollaborationKernelReceipt = Readonly<{
  host: string;
  sessionId: string;
  snapshotDigest: string;
  kernelDigest: string;
  lifecycleGeneration: number;
}>;

type StoredKernelReceipt = {
  host: string;
  session_id: string;
  snapshot_digest: string;
  kernel_digest: string;
  lifecycle_generation: number;
};

function boundedIdentity(value: unknown): value is string {
  return typeof value === "string" && value.length > 0 && value.length <= IDENTITY_MAX_CHARS;
}

function validGeneration(value: unknown): value is number {
  return typeof value === "number" && Number.isSafeInteger(value) && value >= 0;
}

function validDigest(value: unknown): value is string {
  return typeof value === "string" && DIGEST_PATTERN.test(value);
}

function receiptPath(root: string | undefined, host: string, sessionId: string): string {
  const identityDigest = createHash("sha256").update(host).update("\0").update(sessionId).digest("hex");
  return join(resolveWorkContextStateRoot(root), "brain-context", "kernel-receipts", `${identityDigest}.json`);
}

function parseReceipt(value: unknown): StoredKernelReceipt | undefined {
  if (typeof value !== "object" || value === null || Array.isArray(value)) return undefined;
  const receipt = value as Record<string, unknown>;
  if (
    Object.keys(receipt).length !== 5 ||
    !boundedIdentity(receipt.host) ||
    !boundedIdentity(receipt.session_id) ||
    !validDigest(receipt.snapshot_digest) ||
    !validDigest(receipt.kernel_digest) ||
    !validGeneration(receipt.lifecycle_generation)
  ) {
    return undefined;
  }
  return receipt as StoredKernelReceipt;
}

async function readReceipt(path: string): Promise<StoredKernelReceipt | undefined> {
  try {
    const metadata = await stat(path);
    if (!metadata.isFile() || metadata.size > RECEIPT_MAX_BYTES) return undefined;
    return parseReceipt(JSON.parse(await readFile(path, "utf8")));
  } catch {
    return undefined;
  }
}

async function withReceiptLock<T>(path: string, operation: () => Promise<T>): Promise<T> {
  const lockPath = `${path}.lock`;
  const deadline = Date.now() + 2_000;
  await mkdir(dirname(path), { recursive: true, mode: 0o700 });
  while (true) {
    try {
      await mkdir(lockPath, { mode: 0o700 });
      break;
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code !== "EEXIST" || Date.now() >= deadline) throw error;
      await sleep(10);
    }
  }
  try {
    return await operation();
  } finally {
    await rm(lockPath, { recursive: true, force: true });
  }
}

export async function collaborationKernelRequired(
  input: CollaborationKernelDecision,
): Promise<boolean> {
  if (input.lifecycle !== "prompt") return true;
  if (
    !boundedIdentity(input.host) ||
    !boundedIdentity(input.sessionId) ||
    !validDigest(input.snapshotDigest)
  ) {
    return true;
  }
  const receipt = await readReceipt(receiptPath(input.stateRoot, input.host, input.sessionId));
  return !(
    receipt?.host === input.host &&
    receipt.session_id === input.sessionId &&
    receipt.snapshot_digest === input.snapshotDigest
  );
}

export async function recordCollaborationKernelDelivery(
  input: CollaborationKernelDelivery,
): Promise<CollaborationKernelReceipt> {
  if (!boundedIdentity(input.host) || !boundedIdentity(input.sessionId)) {
    throw new TypeError("Collaboration Kernel delivery requires bounded host and session identity.");
  }
  if (!validDigest(input.snapshotDigest) || !validDigest(input.kernelDigest)) {
    throw new TypeError("Collaboration Kernel delivery requires SHA-256 snapshot and kernel digests.");
  }
  const path = receiptPath(input.stateRoot, input.host, input.sessionId);
  const directory = dirname(path);
  await mkdir(directory, { recursive: true, mode: 0o700 });
  await chmod(directory, 0o700);
  return withReceiptLock(path, async () => {
    const previous = await readReceipt(path);
    const previousGeneration =
      previous?.host === input.host && previous.session_id === input.sessionId
        ? previous.lifecycle_generation
        : 0;
    if (previousGeneration === Number.MAX_SAFE_INTEGER) {
      throw new RangeError("Collaboration Kernel lifecycle generation is exhausted.");
    }
    const lifecycleGeneration = previousGeneration + 1;
    const stored: StoredKernelReceipt = {
      host: input.host,
      session_id: input.sessionId,
      snapshot_digest: input.snapshotDigest,
      kernel_digest: input.kernelDigest,
      lifecycle_generation: lifecycleGeneration,
    };
    const temporaryPath = `${path}.${process.pid}.${randomUUID()}.tmp`;
    try {
      await writeFile(temporaryPath, `${JSON.stringify(stored)}\n`, { encoding: "utf8", mode: 0o600 });
      await rename(temporaryPath, path);
    } finally {
      await rm(temporaryPath, { force: true });
    }
    return {
      host: stored.host,
      sessionId: stored.session_id,
      snapshotDigest: stored.snapshot_digest,
      kernelDigest: stored.kernel_digest,
      lifecycleGeneration: stored.lifecycle_generation,
    };
  });
}
