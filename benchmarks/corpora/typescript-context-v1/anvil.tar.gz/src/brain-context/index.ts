import { resolve } from "node:path";

import { bootstrapSession } from "../bootstrap/index.ts";
import {
  BrainContextError,
  loadBrainBootstrapManifest,
  type BrainContextDiagnosticCode,
} from "./manifest.ts";
import {
  inspectWorkspaceProject,
  selectBrainProject,
  toWorkspaceIdentityInputWithDiagnostics,
} from "./project.ts";
import {
  renderDegradedBrainContext,
  renderPromptEvidenceContext,
  compilerContextDiagnostics,
  compilerRetrievalLimits,
  MAX_RETRIEVAL_LIMIT_SUMMARY,
  type PromptBrainContextRender,
} from "./render.ts";
import {
  retrieveBrainContext,
  type BrainCompiledEvidence,
  type BrainProjectResolution,
  type BrainRetrievalResult,
} from "./retrieve.ts";
import {
  currentTemporalRequestTime,
  normalizeTemporalQuery,
  type TemporalQuery,
  type TemporalQueryInput,
} from "./temporal.ts";
import { resolveBrainSnapshot, type BrainSnapshot } from "./snapshot.ts";
import {
  compileCollaborationKernel,
  type CollaborationKernelProjection,
} from "./kernel.ts";

export type BrainContextEvent =
  | { type: "session_start"; cwd: string }
  | { type: "user_prompt_submit"; cwd: string; prompt: unknown; temporal?: unknown };

export type BrainContextOptions = {
  stateRoot?: string;
  anvilHome?: string;
  agentId?: string;
  env?: Record<string, string | undefined>;
  homeDir?: string;
  retrievalTimeoutMs?: number;
  reservedOutputBytes?: number;
};

export type BrainContextDiagnostic = {
  code: BrainContextDiagnosticCode;
  message: string;
  recovery: string;
};

export type BrainRecallObservation = {
  phase: "disabled" | "guidance_preflight" | "retrieval" | "render";
  timing: {
    total_ms: number;
    retrieval_ms?: number;
  };
  pages: {
    guidance_count: number;
    compiler_evidence_count?: number;
    candidate_count?: number;
    supporting_count?: number;
    selected_count?: number;
    filtered_count?: number;
  };
  bytes: {
    guidance: number;
    guidance_limit: number;
    guidance_headroom: number;
    retrieved_context?: number;
    framing?: number;
    attempted?: number;
    rendered: number;
    payload_limit: number;
    payload_headroom?: number;
  };
  selection_outcome: "not_run" | "unchanged" | "filtered";
  render_outcome: "disabled" | "guidance_rejected" | "within_limit" | "truncated" | "diagnostic";
  diagnostics: BrainContextDiagnosticCode[];
};

export type BrainContextResult = {
  status: "ready" | "degraded";
  markdown: string;
  diagnostics: BrainContextDiagnostic[];
  brainAgentId?: string;
  brainAlias?: string;
  matchedProject?: string;
  projectResolution?: BrainProjectResolution;
  selectedPages?: string[];
  renderedBytes: number;
  hardBytes: number;
  /** Prompt ceiling retained while preparing a Kernel for prompt delivery. */
  promptHardBytes?: number;
  recallObservation?: BrainRecallObservation;
  compiledContext?: BrainRetrievalResult;
  deliveredEvidence?: BrainCompiledEvidence[];
  kernelProjection?: CollaborationKernelProjection;
  snapshotDigest?: string;
};

export type { TemporalQuery, TemporalQueryInput } from "./temporal.ts";

const SESSION_START_QUESTION =
  "Provide the durable identity, collaboration, and current-project orientation required at session start.";
const DEFAULT_SESSION_START_HARD_BYTES = 24_576;
const DEFAULT_PROMPT_RECALL_HARD_BYTES = 16_384;
const MAX_PROMPT_BYTES = 256 * 1024;
const COLLABORATION_KERNEL_FRAMING_RESERVE_BYTES = 1_024;
const COLLABORATION_KERNEL_HARD_BYTES = 4_096;
const COMPILER_RESPONSE_OVERHEAD_BYTES = 16_384;

function diagnosticFromError(error: unknown): BrainContextDiagnostic {
  if (error instanceof BrainContextError) {
    return { code: error.code, message: error.message, recovery: error.recovery };
  }
  return {
    code: "BRAIN_RETRIEVAL_FAILED",
    message: "Brain context assembly failed unexpectedly.",
    recovery: "Run the Anvil Brain doctor and inspect the local runtime configuration.",
  };
}

function matchedProjectFromResolution(resolution: BrainProjectResolution | undefined): string | undefined {
  return resolution?.status === "matched" ? resolution.page : undefined;
}

function degradedResult(
  diagnostic: BrainContextDiagnostic,
  brainRoot?: string,
  renderedHardBytes = DEFAULT_SESSION_START_HARD_BYTES,
  mode: "bootstrap" | "recall" = "bootstrap",
  hardBytes = renderedHardBytes,
): BrainContextResult {
  const rendered = renderDegradedBrainContext(diagnostic, brainRoot, renderedHardBytes, mode);
  return {
    status: "degraded",
    markdown: rendered.markdown,
    diagnostics: [diagnostic],
    renderedBytes: rendered.renderedBytes,
    hardBytes,
  };
}

function availableOutputBytes(hardBytes: number, reservedOutputBytes: number): number {
  return Math.max(0, hardBytes - reservedOutputBytes);
}

export function isValidBrainPrompt(prompt: unknown): prompt is string {
  return typeof prompt === "string" && prompt.trim().length > 0 &&
    !prompt.includes("\0") && Buffer.byteLength(prompt, "utf8") <= MAX_PROMPT_BYTES;
}

function questionForEvent(event: BrainContextEvent): string {
  if (event.type === "session_start") return SESSION_START_QUESTION;
  const prompt = event.prompt;
  if (!isValidBrainPrompt(prompt)) {
    throw new BrainContextError(
      "BRAIN_PROMPT_INVALID",
      "UserPromptSubmit requires a non-empty text prompt within the local retrieval size limit.",
      "Retry with a text prompt no larger than 256 KiB.",
    );
  }
  return prompt;
}

type PromptRecallMeasurement = {
  phase: BrainRecallObservation["phase"];
  guidanceBytes: number;
  guidanceLimit: number;
  guidanceCount: number;
  payloadLimit: number;
  retrievalMs?: number;
  compilerEvidenceCount?: number;
  candidateCount?: number;
  supportingCount?: number;
  selectedCount?: number;
  filteredCount?: number;
  selectionOutcome: BrainRecallObservation["selection_outcome"];
};

function elapsedMilliseconds(startedAt: number): number {
  return Math.max(0, Math.round(performance.now() - startedAt));
}

function recallPages(measurement: PromptRecallMeasurement): BrainRecallObservation["pages"] {
  return {
    guidance_count: measurement.guidanceCount,
    ...(measurement.compilerEvidenceCount !== undefined
      ? { compiler_evidence_count: measurement.compilerEvidenceCount }
      : {}),
    ...(measurement.candidateCount !== undefined ? { candidate_count: measurement.candidateCount } : {}),
    ...(measurement.supportingCount !== undefined ? { supporting_count: measurement.supportingCount } : {}),
    ...(measurement.selectedCount !== undefined ? { selected_count: measurement.selectedCount } : {}),
    ...(measurement.filteredCount !== undefined ? { filtered_count: measurement.filteredCount } : {}),
  };
}

function degradedRecallObservation(
  measurement: PromptRecallMeasurement,
  diagnostic: BrainContextDiagnostic,
  renderedBytes: number,
  totalMs: number,
): BrainRecallObservation {
  return {
    phase: measurement.phase,
    timing: {
      total_ms: totalMs,
      ...(measurement.retrievalMs !== undefined ? { retrieval_ms: measurement.retrievalMs } : {}),
    },
    pages: recallPages(measurement),
    bytes: {
      guidance: measurement.guidanceBytes,
      guidance_limit: measurement.guidanceLimit,
      guidance_headroom: measurement.guidanceLimit - measurement.guidanceBytes,
      rendered: renderedBytes,
      payload_limit: measurement.payloadLimit,
    },
    selection_outcome: measurement.selectionOutcome,
    render_outcome:
      diagnostic.code === "BRAIN_PROMPT_GUIDANCE_TOO_LARGE" ? "guidance_rejected" : "diagnostic",
    diagnostics: [diagnostic.code],
  };
}

function readyRecallObservation(
  measurement: PromptRecallMeasurement,
  rendered: PromptBrainContextRender,
  diagnostics: BrainContextDiagnostic[],
  totalMs: number,
): BrainRecallObservation {
  return {
    phase: "render",
    timing: {
      total_ms: totalMs,
      ...(measurement.retrievalMs !== undefined ? { retrieval_ms: measurement.retrievalMs } : {}),
    },
    pages: recallPages(measurement),
    bytes: {
      guidance: measurement.guidanceBytes,
      guidance_limit: measurement.guidanceLimit,
      guidance_headroom: measurement.guidanceLimit - measurement.guidanceBytes,
      retrieved_context: rendered.retrievedContextBytes,
      framing: rendered.framingBytes,
      attempted: rendered.attemptedBytes,
      rendered: rendered.renderedBytes,
      payload_limit: measurement.payloadLimit,
      payload_headroom: measurement.payloadLimit - rendered.attemptedBytes,
    },
    selection_outcome: measurement.selectionOutcome,
    render_outcome: rendered.truncated ? "truncated" : "within_limit",
    diagnostics: diagnostics.map((diagnostic) => diagnostic.code),
  };
}

export async function buildBrainContext(
  event: BrainContextEvent,
  options: BrainContextOptions = {},
): Promise<BrainContextResult> {
  const startedAt = performance.now();
  const capturedRequestTime = event.type === "user_prompt_submit" ? currentTemporalRequestTime() : undefined;
  let brainRoot: string | undefined;
  let brainSnapshot: BrainSnapshot | undefined;
  let snapshotDigest: string | undefined;
  let snapshotDiagnostic: BrainContextDiagnostic | undefined;
  let promptRecallMeasurement: PromptRecallMeasurement | undefined;
  const mode = event.type === "session_start" ? "bootstrap" : "recall";
  const reservedOutputBytes = options.reservedOutputBytes ?? 0;
  let totalHardBytes =
    event.type === "session_start" ? DEFAULT_SESSION_START_HARD_BYTES : DEFAULT_PROMPT_RECALL_HARD_BYTES;
  let hardBytes = totalHardBytes;
  let promptHardBytes = DEFAULT_PROMPT_RECALL_HARD_BYTES;

  try {
    if (!Number.isSafeInteger(reservedOutputBytes) || reservedOutputBytes < 0) {
      throw new TypeError("reservedOutputBytes must be a non-negative safe integer.");
    }
    hardBytes = availableOutputBytes(totalHardBytes, reservedOutputBytes);
    const question = questionForEvent(event);
    const cwd = resolve(event.cwd);
    const bootstrap = await bootstrapSession({
      cwd,
      stateRoot: options.stateRoot,
      anvilHome: options.anvilHome,
      agentId: options.agentId,
      env: options.env,
      homeDir: options.homeDir,
      mode: "local_full",
    });

    if (!bootstrap.brain.configured || !bootstrap.brain.agent_id || !bootstrap.brain.brain_root || !bootstrap.brain.wiki_alias) {
      throw new BrainContextError(
        "BRAIN_NOT_CONFIGURED",
        "Anvil Brain configuration is unavailable for this agent runtime.",
        "Run anvil_brain_setup for the configured ANVIL_AGENT_ID.",
      );
    }
    brainRoot = bootstrap.brain.brain_root;
    if (bootstrap.brain.brain_root_status !== "exists") {
      throw new BrainContextError(
        "BRAIN_ROOT_MISSING",
        "The configured Brain root is missing or unusable.",
        "Restore the configured Brain workspace or repair the Anvil Brain config.",
      );
    }

    const snapshot = await resolveBrainSnapshot({
      brainRoot,
      wikiAlias: bootstrap.brain.wiki_alias,
      stateRoot: options.stateRoot,
      env: options.env,
      timeoutMs: options.retrievalTimeoutMs,
    });
    brainRoot = snapshot.wikiRoot;
    brainSnapshot = snapshot;
    snapshotDigest = snapshot.digest;
    if (snapshot.status === "last_known_good") {
      snapshotDiagnostic = {
        code: "BRAIN_SNAPSHOT_STALE",
        message: "Brain delivery is using the validated last-known-good snapshot because current publication failed.",
        recovery: "Repair the current Brain source and publish a new validated snapshot.",
      };
    }

    const manifest = await loadBrainBootstrapManifest(brainRoot);
    if (manifest.version === 1 && event.type === "user_prompt_submit" && event.temporal !== undefined) {
      throw new BrainContextError(
        "BRAIN_RETRIEVAL_INVALID",
        "Temporal queries are only supported by the project-aware contract-3 Brain manifest.",
        "Use a version 2 Brain manifest when supplying a temporal query.",
      );
    }
    const temporal = manifest.version === 2 && event.type === "user_prompt_submit"
      ? normalizeTemporalQuery(event.temporal, capturedRequestTime)
      : undefined;
    promptHardBytes = manifest.budgets.prompt_recall_hard_bytes;
    totalHardBytes =
      event.type === "session_start"
        ? Math.max(
            manifest.budgets.session_start_hard_bytes,
            COLLABORATION_KERNEL_HARD_BYTES + COLLABORATION_KERNEL_FRAMING_RESERVE_BYTES,
          )
        : manifest.budgets.prompt_recall_hard_bytes;
    hardBytes = availableOutputBytes(totalHardBytes, reservedOutputBytes);
    const renderedPromptGuidanceBytes = 0;
    if (event.type === "user_prompt_submit") {
      promptRecallMeasurement = {
        phase: "guidance_preflight",
        guidanceBytes: renderedPromptGuidanceBytes,
        guidanceLimit: manifest.budgets.prompt_guidance_hard_bytes,
        guidanceCount: 0,
        payloadLimit: totalHardBytes,
        selectionOutcome: "not_run",
      };
    }
    const identity = inspectWorkspaceProject(cwd);
    const workspaceIdentityConversion = manifest.version === 2
      ? toWorkspaceIdentityInputWithDiagnostics(identity)
      : undefined;
    const workspaceIdentity = workspaceIdentityConversion?.input;
    const localIdentityDiagnostics: BrainContextDiagnostic[] = workspaceIdentityConversion?.diagnostics.map((diagnostic) => ({
      code: diagnostic.code,
      message: diagnostic.message,
      recovery: diagnostic.recovery,
    })) ?? [];
    let matchedProject: string | undefined;
    if (manifest.version === 1) {
      const selection = selectBrainProject(manifest, identity);
      if (selection.kind === "ambiguous") {
        throw new BrainContextError(
          "BRAIN_PROJECT_AMBIGUOUS",
          `Workspace identity matches multiple Brain project pages: ${selection.pages.join(", ")}.`,
          "Remove duplicate project identifiers from brain-bootstrap.json.",
        );
      }
      matchedProject = selection.kind === "matched" ? selection.project.page : undefined;
    }
    if (event.type === "session_start") {
      if (!manifest.collaboration_kernel || !snapshotDigest || !brainSnapshot) {
        throw new BrainContextError(
          "BRAIN_MANIFEST_INVALID",
          "Brain bootstrap does not declare the reviewed Collaboration Kernel section sources.",
          "Add the approved collaboration_kernel manifest contract before enabling the Context Harness.",
        );
      }
      const kernelProjection = await compileCollaborationKernel({
        brainRoot,
        wikiAlias: bootstrap.brain.wiki_alias,
        snapshot: brainSnapshot,
        manifest: manifest.collaboration_kernel,
        env: options.env,
        timeoutMs: options.retrievalTimeoutMs,
      });
      const rendered = renderPromptEvidenceContext({
        ...(matchedProject ? { matchedProject } : {}),
        evidence: kernelProjection.evidence,
        hardBytes,
      });
      if (rendered.truncated) {
        throw new BrainContextError(
          "BRAIN_CONTEXT_BUDGET_VIOLATION",
          "The exact Collaboration Kernel cannot fit inside the reserved delivery envelope.",
          "Repair the kernel framing allowance; do not truncate mandatory collaboration doctrine.",
        );
      }
      const targetDiagnostic: BrainContextDiagnostic | undefined = kernelProjection.budget.targetExceeded
        ? {
            code: "BRAIN_KERNEL_TARGET_EXCEEDED",
            message: `The Collaboration Kernel uses ${kernelProjection.budget.contentBytes} content bytes, above its 3072-byte target and within its 4096-byte ceiling.`,
            recovery: "Keep the accepted overage visible and reconsider the source sections if the kernel grows.",
          }
        : undefined;
      return {
        status: "ready",
        markdown: rendered.markdown,
        diagnostics: [
          ...(snapshotDiagnostic ? [snapshotDiagnostic] : []),
          ...(targetDiagnostic ? [targetDiagnostic] : []),
        ],
        brainAgentId: bootstrap.brain.agent_id,
        brainAlias: bootstrap.brain.wiki_alias,
        ...(matchedProject ? { matchedProject } : {}),
        selectedPages: kernelProjection.sources.map((source) => source.page),
        renderedBytes: rendered.renderedBytes,
        hardBytes: totalHardBytes,
        deliveredEvidence: kernelProjection.evidence,
        kernelProjection,
        snapshotDigest,
        promptHardBytes,
      };
    }
    const seeds: string[] = [];
    if (promptRecallMeasurement !== undefined) promptRecallMeasurement.phase = "retrieval";
    // The closed compiler profile owns variable evidence and compiler-route
    // costs. Reserve only the local additions it cannot observe, measured by
    // the real renderer rather than a guessed per-response framing constant.
    const emptyProfileBytes = renderPromptEvidenceContext({ evidence: [], includeRoute: true, hardBytes }).attemptedBytes;
    const localProfileBytes = renderPromptEvidenceContext({
      evidence: [], includeRoute: true, hardBytes,
      matchedProject: manifest.version === 1 ? matchedProject : undefined,
      diagnostics: manifest.version === 2 ? localIdentityDiagnostics : [],
      retrievalLimits: MAX_RETRIEVAL_LIMIT_SUMMARY,
      includeRoleDisclaimer: true,
    }).attemptedBytes;
    const compilerDeliveryHardBytes = Math.max(0, hardBytes - Math.max(0, localProfileBytes - emptyProfileBytes));
    const compilerContentHardBytes = compilerDeliveryHardBytes;
    if (compilerContentHardBytes <= 0) {
      throw new BrainContextError(
        "BRAIN_CONTEXT_BUDGET_VIOLATION",
        "Required kernel, framing, diagnostics, and outer context leave no safe allowance for Prompt Evidence.",
        "Reduce reserved or kernel context before changing the reviewed envelope ceiling.",
      );
    }
    const compilerResponseHardBytes = compilerContentHardBytes + COMPILER_RESPONSE_OVERHEAD_BYTES;
    const retrieval = await retrieveBrainContext({
      brainRoot,
      wikiAlias: bootstrap.brain.wiki_alias,
      seeds,
      question,
      targetBytes: Math.min(
        manifest.budgets.prompt_recall_target_bytes,
        Math.max(1, compilerContentHardBytes),
      ),
      hardBytes: compilerResponseHardBytes,
      maxContentBytes: compilerContentHardBytes,
      maxDeliveryBytes: compilerDeliveryHardBytes,
      env: options.env,
      timeoutMs: options.retrievalTimeoutMs,
      compilerContractVersion: manifest.version === 2 ? "3" : "1",
      ...(workspaceIdentity ? { workspaceIdentity } : {}),
      ...(temporal ? { temporal } : {}),
      onRetrievalDuration: (durationMs) => {
        if (promptRecallMeasurement !== undefined) promptRecallMeasurement.retrievalMs = durationMs;
      },
    });
    const projectResolution = manifest.version === 2 ? retrieval.query.projectResolution : undefined;
    const compilerMatchedProject = manifest.version === 2
      ? matchedProjectFromResolution(projectResolution)
      : matchedProject;
    const resolutionDiagnostics = manifest.version === 2
      ? [
          ...localIdentityDiagnostics,
          ...compilerContextDiagnostics(retrieval).filter(
            (diagnostic) => !localIdentityDiagnostics.some((local) => local.code === diagnostic.code),
          ),
        ]
      : [];
    if (
      retrieval.budget.contentBytes !== null &&
      retrieval.budget.contentBytes > compilerContentHardBytes
    ) {
      const diagnostic: BrainContextDiagnostic = {
        code: "BRAIN_CONTEXT_BUDGET_VIOLATION",
        message: "llm-wiki returned evidence content beyond the reserved delivery allowance.",
        recovery: "Repair the compiler content-budget contract; do not truncate the returned evidence in Anvil.",
      };
      return {
        ...degradedResult(diagnostic, undefined, hardBytes, mode, totalHardBytes),
        ...(compilerMatchedProject ? { matchedProject: compilerMatchedProject } : {}),
        ...(projectResolution ? { projectResolution } : {}),
        selectedPages: retrieval.selectedPages,
        compiledContext: retrieval,
        deliveredEvidence: [],
        ...(snapshotDigest ? { snapshotDigest } : {}),
      };
    }

    const projectSet = new Set(
      manifest.version === 1 ? manifest.projects.map((project) => project.page) : [],
    );
    const supportingPaths = manifest.version === 1
      ? retrieval.selectedPages.filter((page) => page !== matchedProject && !projectSet.has(page))
      : retrieval.selectedPages;
    const supportingEvidence = manifest.version === 1
      ? retrieval.evidence.filter((evidence) => {
          if (evidence.page === null) return true;
          return evidence.page !== matchedProject && !projectSet.has(evidence.page);
        })
      : retrieval.evidence;
    if (event.type === "user_prompt_submit") {
      const filteredCount = retrieval.candidateCount - supportingPaths.length;
      promptRecallMeasurement = {
        ...promptRecallMeasurement!,
        phase: "render",
        compilerEvidenceCount: retrieval.evidenceCount,
        candidateCount: retrieval.candidateCount,
        supportingCount: supportingPaths.length,
        selectedCount: supportingPaths.length,
        filteredCount,
        selectionOutcome: filteredCount > 0 ? "filtered" : "unchanged",
      };
      const rendered = renderPromptEvidenceContext({
        ...(compilerMatchedProject ? { matchedProject: compilerMatchedProject } : {}),
        ...(manifest.version === 2 ? { includeRoute: true } : {}),
        ...(retrieval.query.temporal ? { temporal: retrieval.query.temporal } : {}),
        ...(resolutionDiagnostics.length > 0 ? { diagnostics: resolutionDiagnostics } : {}),
        retrievalLimits: compilerRetrievalLimits(retrieval),
        includeRoleDisclaimer: supportingEvidence.length > 0,
        evidence: supportingEvidence,
        hardBytes,
      });
      const diagnostics = [
        ...(snapshotDiagnostic ? [snapshotDiagnostic] : []),
        ...resolutionDiagnostics,
      ];
      if (rendered.truncated) {
        const diagnostic: BrainContextDiagnostic = {
          code: "BRAIN_CONTEXT_BUDGET_VIOLATION",
          message: `The compiled evidence rendered to ${rendered.attemptedBytes} bytes after a ${hardBytes}-byte delivery allowance was reserved.`,
          recovery: "Repair the compiler-to-envelope byte allowance; do not silently truncate compiled evidence.",
        };
        return {
          ...degradedResult(diagnostic, brainRoot, hardBytes, mode, totalHardBytes),
          ...(compilerMatchedProject ? { matchedProject: compilerMatchedProject } : {}),
          ...(projectResolution ? { projectResolution } : {}),
          selectedPages: [
            ...new Set(supportingEvidence.flatMap((evidence) => (evidence.page ? [evidence.page] : []))),
          ],
          compiledContext: retrieval,
          deliveredEvidence: [],
          ...(snapshotDigest ? { snapshotDigest } : {}),
        };
      }
      return {
        status: "ready",
        markdown: rendered.markdown,
        diagnostics,
        brainAgentId: bootstrap.brain.agent_id,
        brainAlias: bootstrap.brain.wiki_alias,
        ...(compilerMatchedProject ? { matchedProject: compilerMatchedProject } : {}),
        ...(projectResolution ? { projectResolution } : {}),
        selectedPages: [
          ...new Set(supportingEvidence.flatMap((evidence) => (evidence.page ? [evidence.page] : []))),
        ],
        renderedBytes: rendered.renderedBytes,
        hardBytes: totalHardBytes,
        compiledContext: retrieval,
        deliveredEvidence: supportingEvidence,
        ...(snapshotDigest ? { snapshotDigest } : {}),
        recallObservation: readyRecallObservation(
          promptRecallMeasurement,
          rendered,
          diagnostics,
          elapsedMilliseconds(startedAt),
        ),
      };
    }

    throw new Error("session_start must return the Collaboration Kernel before prompt retrieval");
  } catch (error) {
    const diagnostic = diagnosticFromError(error);
    const degraded = degradedResult(diagnostic, brainRoot, hardBytes, mode, totalHardBytes);
    if (promptRecallMeasurement === undefined) {
      return { ...degraded, promptHardBytes, ...(snapshotDigest ? { snapshotDigest } : {}) };
    }
    return {
      ...degraded,
      ...(snapshotDigest ? { snapshotDigest } : {}),
      recallObservation: degradedRecallObservation(
        promptRecallMeasurement,
        diagnostic,
        degraded.renderedBytes,
        elapsedMilliseconds(startedAt),
      ),
    };
  }
}
