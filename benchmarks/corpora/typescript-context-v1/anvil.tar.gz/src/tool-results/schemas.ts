import * as z from "zod/v4";

export const TOOL_RESULT_MAX_INLINE_BYTES = 4 * 1024;
export const TOOL_RESULT_MAX_SLICE_BYTES = 8 * 1024;

const resultIdSchema = z.string().regex(/^tr_[a-f0-9]{32}$/);
const artefactIdSchema = z.string().regex(/^ta_[a-f0-9]{32}$/);
const sha256Schema = z.string().regex(/^[a-f0-9]{64}$/);
const byteCountSchema = z.number().int().nonnegative();

const toolResultReceiptBaseSchema = z.object({
  schema_version: z.literal(1),
  result_id: resultIdSchema,
  status: z.enum(["succeeded", "failed"]),
  summary: z
    .object({
      exit_code: z.number().int().nullable(),
      producer: z.string().min(1).max(128),
    })
    .strict(),
});

export const toolResultReceiptSchema = z.discriminatedUnion("completeness", [
  toolResultReceiptBaseSchema
    .extend({
      completeness: z.literal("complete_inline"),
      inline: z
        .object({
          content_type: z.literal("text/plain; charset=utf-8"),
          byte_count: byteCountSchema,
          sha256: sha256Schema,
          text: z.string(),
        })
        .strict(),
    })
    .strict(),
  toolResultReceiptBaseSchema
    .extend({
      completeness: z.literal("complete_artefact_backed"),
      artefact: z
        .object({
          artefact_id: artefactIdSchema,
          content_type: z.literal("text/plain; charset=utf-8"),
          byte_count: byteCountSchema,
          sha256: sha256Schema,
          expires_at: z.iso.datetime(),
        })
        .strict(),
    })
    .strict(),
]);
export type ToolResultReceipt = z.infer<typeof toolResultReceiptSchema>;

export const toolResultManifestOutputSchema = z
  .object({
    schema_version: z.literal(1),
    result_id: resultIdSchema,
    status: z.enum(["succeeded", "failed"]),
    completeness: z.literal("complete_artefact_backed"),
    producer: z.string().min(1).max(128),
    operation: z.literal("command"),
    created_at: z.iso.datetime(),
    expires_at: z.iso.datetime(),
    exit_code: z.number().int().nullable(),
    exit_signal: z.string().min(1).nullable(),
    artefact: z
      .object({
        artefact_id: artefactIdSchema,
        content_type: z.literal("text/plain; charset=utf-8"),
        byte_count: byteCountSchema,
        sha256: sha256Schema,
      })
      .strict(),
    provenance: z
      .object({
        binding_id: z.string().regex(/^wctx_[a-f0-9]{32}$/),
        host: z.string().min(1),
        workspace_key: z.string().regex(/^sha256_[a-f0-9]{64}$/),
      })
      .strict(),
  })
  .strict();
export type ToolResultManifestOutput = z.infer<typeof toolResultManifestOutputSchema>;

export const toolResultSearchOutputSchema = z
  .object({
    schema_version: z.literal(1),
    result_id: resultIdSchema,
    query: z.string().min(1).max(1024),
    coverage: z
      .object({
        complete: z.boolean(),
        inspected_bytes: byteCountSchema,
        total_bytes: byteCountSchema,
      })
      .strict(),
    limits: z
      .object({
        max_matches: z.number().int().positive(),
        matches_truncated: z.boolean(),
      })
      .strict(),
    matches: z
      .array(
        z
          .object({
            byte_start: byteCountSchema,
            byte_end: byteCountSchema,
          })
          .strict(),
      )
      .max(100),
    source_sha256: sha256Schema,
  })
  .strict();
export type ToolResultSearchOutput = z.infer<typeof toolResultSearchOutputSchema>;

export const toolResultSliceOutputSchema = z
  .object({
    schema_version: z.literal(1),
    result_id: resultIdSchema,
    byte_start: byteCountSchema,
    byte_end: byteCountSchema,
    total_bytes: byteCountSchema,
    source_sha256: sha256Schema,
    text: z.string(),
  })
  .strict();
export type ToolResultSliceOutput = z.infer<typeof toolResultSliceOutputSchema>;

export const toolResultHealthOutputSchema = z
  .object({
    schema_version: z.literal(1),
    status: z.enum(["healthy", "degraded"]),
    limits: z
      .object({
        max_artefact_bytes: z.number().int().positive(),
        max_store_bytes: z.number().int().positive(),
        retention_ms: z.number().int().positive(),
      })
      .strict(),
    usage: z
      .object({
        artefacts: byteCountSchema,
        total_bytes: byteCountSchema,
        corrupt_entries: byteCountSchema,
      })
      .strict(),
    cleanup: z
      .object({
        removed_artefacts: byteCountSchema,
        removed_bytes: byteCountSchema,
      })
      .strict(),
  })
  .strict();
export type ToolResultHealthOutput = z.infer<typeof toolResultHealthOutputSchema>;

export type ToolResultErrorCode =
  | "TOOL_RESULT_INVALID_REQUEST"
  | "TOOL_RESULT_EXECUTION_FAILED"
  | "TOOL_RESULT_CAPTURE_FAILED"
  | "TOOL_RESULT_CAPTURE_OVERFLOW"
  | "TOOL_RESULT_CAPACITY_EXCEEDED"
  | "TOOL_RESULT_STORE_BUSY"
  | "TOOL_RESULT_NOT_FOUND"
  | "TOOL_RESULT_EXPIRED"
  | "TOOL_RESULT_CORRUPT"
  | "TOOL_RESULT_UNAUTHORIZED"
  | "TOOL_RESULT_UNSUPPORTED_CONTENT";

export class ToolResultError extends Error {
  readonly code: ToolResultErrorCode;

  constructor(code: ToolResultErrorCode, message: string, options?: ErrorOptions) {
    super(message, options);
    this.name = "ToolResultError";
    this.code = code;
  }
}
