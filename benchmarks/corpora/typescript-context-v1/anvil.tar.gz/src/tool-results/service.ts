import { spawn } from "node:child_process";
import { createHash, randomBytes, randomUUID } from "node:crypto";
import { constants as fsConstants } from "node:fs";
import {
  chmod,
  mkdir,
  open,
  readdir,
  readFile,
  rename,
  rm,
  stat,
} from "node:fs/promises";
import type { FileHandle } from "node:fs/promises";
import { join } from "node:path";
import { setTimeout as sleep } from "node:timers/promises";
import * as z from "zod/v4";

import {
  assertActiveWorkContextBinding,
  resolveWorkContextStateRoot,
} from "../work-context/index.ts";
import type { WorkContextBinding } from "../work-context/index.ts";
import {
  TOOL_RESULT_MAX_INLINE_BYTES,
  TOOL_RESULT_MAX_SLICE_BYTES,
  ToolResultError,
  toolResultHealthOutputSchema,
  toolResultManifestOutputSchema,
  toolResultReceiptSchema,
  toolResultSearchOutputSchema,
  toolResultSliceOutputSchema,
} from "./schemas.ts";
import type {
  ToolResultHealthOutput,
  ToolResultManifestOutput,
  ToolResultReceipt,
  ToolResultSearchOutput,
  ToolResultSliceOutput,
} from "./schemas.ts";

const MAX_ARTEFACT_BYTES = 64 * 1024 * 1024;
const MAX_STORE_BYTES = 512 * 1024 * 1024;
const RETENTION_MS = 24 * 60 * 60 * 1_000;
const MAX_SEARCH_MATCHES = 100;
const MAX_QUERY_BYTES = 1024;
const STORE_LOCK_TIMEOUT_MS = 5_000;
const STORE_LOCK_STALE_MS = 30_000;
const LOCK_RETRY_MS = 20;

type Clock = () => string;

type CaptureCommandResultOptions = {
  argv: string[];
  producer: string;
  binding: WorkContextBinding;
  stateRoot?: string;
  cwd?: string;
  now?: Clock;
};

type BoundResultOptions = {
  binding: WorkContextBinding;
  resultId: string;
  stateRoot?: string;
  now?: Clock;
};

type SearchToolResultOptions = BoundResultOptions & { query: string };
type ReadToolResultSliceOptions = BoundResultOptions & { byteStart: number; byteLength: number };
type ReadToolResultHealthOptions = {
  binding: WorkContextBinding;
  stateRoot?: string;
  now?: Clock;
};

const storedManifestSchema = toolResultManifestOutputSchema.extend({
  owner: z
    .object({
      session_id: z.string().min(1),
    })
    .strict(),
});
type StoredManifest = z.infer<typeof storedManifestSchema>;

type StorePaths = {
  root: string;
  temporary: string;
  results: string;
  lock: string;
};

type StoredEntry = {
  directory: string;
  manifest?: StoredManifest;
  corrupt: boolean;
};

function nowIso(): string {
  return new Date().toISOString();
}

function opaqueId(prefix: "tr" | "ta"): string {
  return `${prefix}_${randomBytes(16).toString("hex")}`;
}

function validateResultId(resultId: string): string {
  if (!/^tr_[a-f0-9]{32}$/.test(resultId)) {
    throw new ToolResultError("TOOL_RESULT_INVALID_REQUEST", "resultId is not a valid opaque tool-result identifier");
  }
  return resultId;
}

function validateProducer(producer: string): string {
  if (!producer || producer.length > 128 || !/^[A-Za-z0-9._:-]+$/.test(producer)) {
    throw new ToolResultError(
      "TOOL_RESULT_INVALID_REQUEST",
      "producer must contain only letters, numbers, dots, underscores, colons, or hyphens",
    );
  }
  return producer;
}

function validateBinding(binding: WorkContextBinding, now: Clock): WorkContextBinding {
  try {
    return assertActiveWorkContextBinding(binding, now);
  } catch (error) {
    throw new ToolResultError("TOOL_RESULT_UNAUTHORIZED", "An active trusted Work Context binding is required", {
      cause: error,
    });
  }
}

function storePaths(stateRoot?: string): StorePaths {
  const root = join(resolveWorkContextStateRoot(stateRoot), "tool-results");
  return {
    root,
    temporary: join(root, "temporary"),
    results: join(root, "results"),
    lock: join(root, ".publication-lock"),
  };
}

async function ensurePrivateDirectory(path: string): Promise<void> {
  await mkdir(path, { recursive: true, mode: 0o700 });
  await chmod(path, 0o700);
}

async function prepareStore(stateRoot?: string): Promise<StorePaths> {
  const paths = storePaths(stateRoot);
  await ensurePrivateDirectory(paths.root);
  await ensurePrivateDirectory(paths.temporary);
  await ensurePrivateDirectory(paths.results);
  return paths;
}

function workspaceDirectory(paths: StorePaths, binding: WorkContextBinding): string {
  const key = binding.collaboration_space.key;
  if (!/^sha256_[a-f0-9]{64}$/.test(key)) {
    throw new ToolResultError("TOOL_RESULT_UNAUTHORIZED", "Work Context workspace identity is malformed");
  }
  return join(paths.results, key);
}

function isNodeError(error: unknown): error is NodeJS.ErrnoException {
  return error instanceof Error && "code" in error;
}

async function writePrivateJson(path: string, value: unknown): Promise<void> {
  const handle = await open(path, fsConstants.O_CREAT | fsConstants.O_EXCL | fsConstants.O_WRONLY, 0o600);
  try {
    await handle.writeFile(`${JSON.stringify(value)}\n`, "utf8");
    await handle.sync();
  } finally {
    await handle.close();
  }
  await chmod(path, 0o600);
}

async function acquireStoreLock(paths: StorePaths): Promise<() => Promise<void>> {
  const deadline = Date.now() + STORE_LOCK_TIMEOUT_MS;
  while (true) {
    try {
      await mkdir(paths.lock, { mode: 0o700 });
      try {
        await writePrivateJson(join(paths.lock, "owner.json"), { pid: process.pid });
      } catch (error) {
        await rm(paths.lock, { recursive: true, force: true });
        throw error;
      }
      return async () => rm(paths.lock, { recursive: true, force: true });
    } catch (error) {
      if (!isNodeError(error) || error.code !== "EEXIST") throw error;
      try {
        const lockStat = await stat(paths.lock);
        if (Date.now() - lockStat.mtimeMs > STORE_LOCK_STALE_MS) {
          let ownerAlive = false;
          try {
            const owner = JSON.parse(await readFile(join(paths.lock, "owner.json"), "utf8")) as { pid?: unknown };
            if (typeof owner.pid === "number" && Number.isInteger(owner.pid) && owner.pid > 0) {
              try {
                process.kill(owner.pid, 0);
                ownerAlive = true;
              } catch (probeError) {
                ownerAlive = isNodeError(probeError) && probeError.code === "EPERM";
              }
            }
          } catch {
            // A stale lock without a readable live owner is abandoned publication state.
          }
          if (!ownerAlive) {
            await rm(paths.lock, { recursive: true, force: true });
            continue;
          }
        }
      } catch (statError) {
        if (!isNodeError(statError) || statError.code !== "ENOENT") throw statError;
      }
      if (Date.now() >= deadline) {
        throw new ToolResultError("TOOL_RESULT_STORE_BUSY", "Tool-result store publication lock timed out");
      }
      await sleep(LOCK_RETRY_MS);
    }
  }
}

async function writeAll(handle: FileHandle, chunk: Buffer): Promise<void> {
  let offset = 0;
  while (offset < chunk.byteLength) {
    const { bytesWritten } = await handle.write(chunk, offset, chunk.byteLength - offset, null);
    if (bytesWritten === 0) throw new Error("Tool-result payload write made no progress");
    offset += bytesWritten;
  }
}

async function listStoredEntries(paths: StorePaths): Promise<StoredEntry[]> {
  const entries: StoredEntry[] = [];
  const workspaces = await readdir(paths.results, { withFileTypes: true });
  for (const workspace of workspaces) {
    if (!workspace.isDirectory() || !/^sha256_[a-f0-9]{64}$/.test(workspace.name)) continue;
    const workspacePath = join(paths.results, workspace.name);
    const resultDirectories = await readdir(workspacePath, { withFileTypes: true });
    for (const resultDirectory of resultDirectories) {
      if (!resultDirectory.isDirectory() || !/^tr_[a-f0-9]{32}$/.test(resultDirectory.name)) continue;
      const directory = join(workspacePath, resultDirectory.name);
      try {
        const parsed: unknown = JSON.parse(await readFile(join(directory, "manifest.json"), "utf8"));
        const manifest = storedManifestSchema.parse(parsed);
        entries.push({ directory, manifest, corrupt: false });
      } catch {
        entries.push({ directory, corrupt: true });
      }
    }
  }
  return entries;
}

async function cleanupExpired(
  paths: StorePaths,
  observedAt: number,
  entries?: StoredEntry[],
): Promise<{ entries: StoredEntry[]; removedArtefacts: number; removedBytes: number }> {
  const current = entries ?? (await listStoredEntries(paths));
  const expired = current
    .filter((entry): entry is StoredEntry & { manifest: StoredManifest } =>
      Boolean(entry.manifest && Date.parse(entry.manifest.expires_at) <= observedAt),
    )
    .sort((left, right) => Date.parse(left.manifest.created_at) - Date.parse(right.manifest.created_at));
  let removedArtefacts = 0;
  let removedBytes = 0;
  const removed = new Set<string>();
  for (const entry of expired) {
    await rm(entry.directory, { recursive: true, force: true });
    removed.add(entry.directory);
    removedArtefacts += 1;
    removedBytes += entry.manifest.artefact.byte_count;
  }
  return {
    entries: current.filter((entry) => !removed.has(entry.directory)),
    removedArtefacts,
    removedBytes,
  };
}

async function syncDirectory(path: string): Promise<void> {
  let handle: FileHandle | undefined;
  try {
    handle = await open(path, fsConstants.O_RDONLY);
    await handle.sync();
  } finally {
    await handle?.close();
  }
}

async function captureChildOutput(
  argv: string[],
  cwd: string | undefined,
  payloadPath: string,
): Promise<{ byteCount: number; sha256: string; exitCode: number | null; exitSignal: string | null }> {
  if (argv.length === 0 || argv.some((argument) => typeof argument !== "string") || argv[0] === "") {
    throw new ToolResultError("TOOL_RESULT_INVALID_REQUEST", "argv must contain an executable and string arguments");
  }
  const payload = await open(payloadPath, fsConstants.O_CREAT | fsConstants.O_EXCL | fsConstants.O_WRONLY, 0o600);
  const digest = createHash("sha256");
  const utf8 = new TextDecoder("utf-8", { fatal: true });
  let byteCount = 0;
  let overflow = false;
  let invalidUtf8 = false;
  let writeFailure: unknown;
  let writeChain = Promise.resolve();
  let pendingWrites = 0;
  let child;
  try {
    child = spawn(argv[0], argv.slice(1), { cwd, shell: false, stdio: ["ignore", "pipe", "pipe"] });
  } catch (error) {
    await payload.close();
    throw new ToolResultError("TOOL_RESULT_EXECUTION_FAILED", `Unable to start command: ${argv[0]}`, { cause: error });
  }

  const observe = (chunk: Buffer): void => {
    if (overflow || invalidUtf8 || writeFailure !== undefined) return;
    if (byteCount + chunk.byteLength > MAX_ARTEFACT_BYTES) {
      overflow = true;
      child.kill("SIGKILL");
      return;
    }
    byteCount += chunk.byteLength;
    pendingWrites += 1;
    child.stdout.pause();
    child.stderr.pause();
    writeChain = writeChain
      .then(async () => {
        try {
          utf8.decode(chunk, { stream: true });
        } catch (error) {
          invalidUtf8 = true;
          child.kill("SIGKILL");
          throw error;
        }
        digest.update(chunk);
        await writeAll(payload, chunk);
      })
      .catch((error: unknown) => {
        writeFailure = error;
        child.kill("SIGKILL");
      })
      .finally(() => {
        pendingWrites -= 1;
        if (pendingWrites === 0 && !overflow && !invalidUtf8 && writeFailure === undefined) {
          child.stdout.resume();
          child.stderr.resume();
        }
      });
  };
  child.stdout.on("data", observe);
  child.stderr.on("data", observe);

  const outcome = await new Promise<{ exitCode: number | null; exitSignal: string | null; spawnError?: Error }>(
    (resolveOutcome) => {
      let spawnError: Error | undefined;
      child.once("error", (error) => {
        spawnError = error;
      });
      child.once("close", (exitCode, exitSignal) => {
        resolveOutcome({ exitCode, exitSignal, spawnError });
      });
    },
  );
  await writeChain;
  if (!invalidUtf8 && writeFailure === undefined) {
    try {
      utf8.decode();
    } catch (error) {
      invalidUtf8 = true;
      writeFailure = error;
    }
  }
  try {
    if (!overflow && !invalidUtf8 && writeFailure === undefined && outcome.spawnError === undefined) {
      await payload.sync();
    }
  } finally {
    await payload.close();
  }
  if (overflow) {
    throw new ToolResultError(
      "TOOL_RESULT_CAPTURE_OVERFLOW",
      `Command output exceeded the ${MAX_ARTEFACT_BYTES}-byte artefact limit`,
    );
  }
  if (invalidUtf8) {
    throw new ToolResultError("TOOL_RESULT_UNSUPPORTED_CONTENT", "Command output is not valid UTF-8 text", {
      cause: writeFailure,
    });
  }
  if (outcome.spawnError) {
    throw new ToolResultError("TOOL_RESULT_EXECUTION_FAILED", `Unable to execute command: ${argv[0]}`, {
      cause: outcome.spawnError,
    });
  }
  if (writeFailure !== undefined) {
    throw new ToolResultError("TOOL_RESULT_CAPTURE_FAILED", "Unable to durably capture command output", {
      cause: writeFailure,
    });
  }
  await chmod(payloadPath, 0o600);
  return { byteCount, sha256: digest.digest("hex"), ...outcome };
}

/** Capture is intentionally a CLI adapter primitive; MCP exposes no operation that calls it. */
export async function captureCommandResult(options: CaptureCommandResultOptions): Promise<ToolResultReceipt> {
  const clock = options.now ?? nowIso;
  const binding = validateBinding(options.binding, clock);
  const producer = validateProducer(options.producer);
  const createdAt = clock();
  const createdAtMs = Date.parse(createdAt);
  if (!Number.isFinite(createdAtMs)) {
    throw new ToolResultError("TOOL_RESULT_INVALID_REQUEST", "now must return an ISO date-time");
  }
  const expiresAt = new Date(createdAtMs + RETENTION_MS).toISOString();
  const paths = await prepareStore(options.stateRoot);
  const temporaryDirectory = join(paths.temporary, `.capture-${randomUUID()}`);
  await mkdir(temporaryDirectory, { mode: 0o700 });
  const payloadPath = join(temporaryDirectory, "payload.txt");
  try {
    const captured = await captureChildOutput(options.argv, options.cwd, payloadPath);
    const resultId = opaqueId("tr");
    const status = captured.exitCode === 0 ? "succeeded" : "failed";
    if (captured.byteCount <= TOOL_RESULT_MAX_INLINE_BYTES) {
      const inlineReceipt = toolResultReceiptSchema.parse({
        schema_version: 1,
        result_id: resultId,
        status,
        completeness: "complete_inline",
        summary: { exit_code: captured.exitCode, producer },
        inline: {
          content_type: "text/plain; charset=utf-8",
          byte_count: captured.byteCount,
          sha256: captured.sha256,
          text: await readFile(payloadPath, "utf8"),
        },
      });
      if (Buffer.byteLength(`${JSON.stringify(inlineReceipt)}\n`, "utf8") <= TOOL_RESULT_MAX_INLINE_BYTES) {
        await rm(temporaryDirectory, { recursive: true, force: true });
        return inlineReceipt;
      }
    }

    const artefactId = opaqueId("ta");
    const manifest: StoredManifest = storedManifestSchema.parse({
      schema_version: 1,
      result_id: resultId,
      status,
      completeness: "complete_artefact_backed",
      producer,
      operation: "command",
      created_at: createdAt,
      expires_at: expiresAt,
      exit_code: captured.exitCode,
      exit_signal: captured.exitSignal,
      artefact: {
        artefact_id: artefactId,
        content_type: "text/plain; charset=utf-8",
        byte_count: captured.byteCount,
        sha256: captured.sha256,
      },
      provenance: {
        binding_id: binding.id,
        host: binding.host,
        workspace_key: binding.collaboration_space.key,
      },
      owner: { session_id: binding.session_id },
    });
    await validatePayload(payloadPath, manifest);
    await writePrivateJson(join(temporaryDirectory, "manifest.json"), manifest);

    const release = await acquireStoreLock(paths);
    try {
      const cleanup = await cleanupExpired(paths, createdAtMs);
      const usedBytes = cleanup.entries.reduce(
        (total, entry) => total + (entry.manifest?.artefact.byte_count ?? 0),
        0,
      );
      if (usedBytes + captured.byteCount > MAX_STORE_BYTES) {
        throw new ToolResultError(
          "TOOL_RESULT_CAPACITY_EXCEEDED",
          `Tool-result store cannot accept ${captured.byteCount} bytes without evicting unexpired evidence`,
        );
      }
      const workspacePath = workspaceDirectory(paths, binding);
      await ensurePrivateDirectory(workspacePath);
      const publishedDirectory = join(workspacePath, resultId);
      await rename(temporaryDirectory, publishedDirectory);
      await syncDirectory(workspacePath);
    } finally {
      await release();
    }

    const receipt = toolResultReceiptSchema.parse({
      schema_version: 1,
      result_id: resultId,
      status,
      completeness: "complete_artefact_backed",
      summary: { exit_code: captured.exitCode, producer },
      artefact: {
        artefact_id: artefactId,
        content_type: "text/plain; charset=utf-8",
        byte_count: captured.byteCount,
        sha256: captured.sha256,
        expires_at: expiresAt,
      },
    });
    if (Buffer.byteLength(`${JSON.stringify(receipt)}\n`, "utf8") > TOOL_RESULT_MAX_INLINE_BYTES) {
      throw new ToolResultError("TOOL_RESULT_CAPTURE_FAILED", "Tool-result receipt exceeded the 4 KiB contract");
    }
    return receipt;
  } catch (error) {
    await rm(temporaryDirectory, { recursive: true, force: true });
    if (error instanceof ToolResultError) throw error;
    throw new ToolResultError("TOOL_RESULT_CAPTURE_FAILED", "Command result capture failed", { cause: error });
  }
}

async function loadBoundManifest(options: BoundResultOptions): Promise<{
  manifest: StoredManifest;
  directory: string;
  payloadPath: string;
}> {
  const clock = options.now ?? nowIso;
  const binding = validateBinding(options.binding, clock);
  const resultId = validateResultId(options.resultId);
  const paths = await prepareStore(options.stateRoot);
  const directory = join(workspaceDirectory(paths, binding), resultId);
  let parsed: unknown;
  try {
    parsed = JSON.parse(await readFile(join(directory, "manifest.json"), "utf8"));
  } catch (error) {
    if (isNodeError(error) && error.code === "ENOENT") {
      throw new ToolResultError("TOOL_RESULT_NOT_FOUND", `Tool result ${resultId} was not found`);
    }
    throw new ToolResultError("TOOL_RESULT_CORRUPT", `Tool result ${resultId} has an unreadable manifest`, {
      cause: error,
    });
  }
  const decoded = storedManifestSchema.safeParse(parsed);
  if (!decoded.success || decoded.data.result_id !== resultId) {
    throw new ToolResultError("TOOL_RESULT_CORRUPT", `Tool result ${resultId} has an invalid manifest`);
  }
  const manifest = decoded.data;
  if (
    manifest.provenance.binding_id !== binding.id ||
    manifest.provenance.host !== binding.host ||
    manifest.provenance.workspace_key !== binding.collaboration_space.key ||
    manifest.owner.session_id !== binding.session_id
  ) {
    throw new ToolResultError("TOOL_RESULT_UNAUTHORIZED", `Tool result ${resultId} belongs to another Work Context`);
  }
  const observedAt = Date.parse(clock());
  if (!Number.isFinite(observedAt)) {
    throw new ToolResultError("TOOL_RESULT_INVALID_REQUEST", "now must return an ISO date-time");
  }
  if (observedAt >= Date.parse(manifest.expires_at)) {
    await rm(directory, { recursive: true, force: true });
    throw new ToolResultError("TOOL_RESULT_EXPIRED", `Tool result ${resultId} has expired`);
  }
  return { manifest, directory, payloadPath: join(directory, "payload.txt") };
}

async function validatePayload(payloadPath: string, manifest: StoredManifest): Promise<void> {
  const handle = await open(payloadPath, "r").catch((error: unknown) => {
    throw new ToolResultError("TOOL_RESULT_CORRUPT", "Tool-result payload is missing", { cause: error });
  });
  const digest = createHash("sha256");
  let byteCount = 0;
  const buffer = Buffer.allocUnsafe(64 * 1024);
  try {
    while (true) {
      const { bytesRead } = await handle.read(buffer, 0, buffer.byteLength, null);
      if (bytesRead === 0) break;
      byteCount += bytesRead;
      digest.update(buffer.subarray(0, bytesRead));
    }
  } catch (error) {
    throw new ToolResultError("TOOL_RESULT_CORRUPT", "Tool-result payload could not be read", { cause: error });
  } finally {
    await handle.close();
  }
  const actualDigest = digest.digest("hex");
  if (byteCount !== manifest.artefact.byte_count || actualDigest !== manifest.artefact.sha256) {
    throw new ToolResultError("TOOL_RESULT_CORRUPT", "Tool-result payload failed byte-count or SHA-256 validation");
  }
}

export async function readToolResultManifest(options: BoundResultOptions): Promise<ToolResultManifestOutput> {
  const { manifest, payloadPath } = await loadBoundManifest(options);
  await validatePayload(payloadPath, manifest);
  const { owner: _owner, ...output } = manifest;
  return toolResultManifestOutputSchema.parse(output);
}

export async function searchToolResult(options: SearchToolResultOptions): Promise<ToolResultSearchOutput> {
  const queryBytes = Buffer.from(options.query, "utf8");
  if (!options.query || queryBytes.byteLength > MAX_QUERY_BYTES) {
    throw new ToolResultError(
      "TOOL_RESULT_INVALID_REQUEST",
      `query must contain between 1 and ${MAX_QUERY_BYTES} UTF-8 bytes`,
    );
  }
  const { manifest, payloadPath } = await loadBoundManifest(options);
  await validatePayload(payloadPath, manifest);
  const handle = await open(payloadPath, "r");
  const matches: Array<{ byte_start: number; byte_end: number }> = [];
  let matchesTruncated = false;
  let absoluteOffset = 0;
  let carry = Buffer.alloc(0);
  const buffer = Buffer.allocUnsafe(64 * 1024);
  try {
    while (true) {
      const { bytesRead } = await handle.read(buffer, 0, buffer.byteLength, null);
      if (bytesRead === 0) break;
      const chunk = buffer.subarray(0, bytesRead);
      const searchable = carry.length === 0 ? chunk : Buffer.concat([carry, chunk]);
      const searchableStart = absoluteOffset - carry.byteLength;
      let cursor = 0;
      while (cursor <= searchable.byteLength - queryBytes.byteLength) {
        const found = searchable.indexOf(queryBytes, cursor);
        if (found < 0) break;
        const byteStart = searchableStart + found;
        if (byteStart >= 0 && (matches.length === 0 || byteStart >= matches[matches.length - 1]!.byte_end)) {
          if (matches.length < MAX_SEARCH_MATCHES) {
            matches.push({ byte_start: byteStart, byte_end: byteStart + queryBytes.byteLength });
          } else {
            matchesTruncated = true;
          }
        }
        cursor = found + Math.max(1, queryBytes.byteLength);
      }
      absoluteOffset += bytesRead;
      const carryLength = Math.min(queryBytes.byteLength - 1, searchable.byteLength);
      carry = carryLength === 0 ? Buffer.alloc(0) : Buffer.from(searchable.subarray(searchable.byteLength - carryLength));
    }
  } finally {
    await handle.close();
  }
  return toolResultSearchOutputSchema.parse({
    schema_version: 1,
    result_id: manifest.result_id,
    query: options.query,
    coverage: {
      complete: true,
      inspected_bytes: manifest.artefact.byte_count,
      total_bytes: manifest.artefact.byte_count,
    },
    limits: { max_matches: MAX_SEARCH_MATCHES, matches_truncated: matchesTruncated },
    matches,
    source_sha256: manifest.artefact.sha256,
  });
}

export async function readToolResultSlice(options: ReadToolResultSliceOptions): Promise<ToolResultSliceOutput> {
  if (
    !Number.isSafeInteger(options.byteStart) ||
    options.byteStart < 0 ||
    !Number.isSafeInteger(options.byteLength) ||
    options.byteLength < 1 ||
    options.byteLength > TOOL_RESULT_MAX_SLICE_BYTES
  ) {
    throw new ToolResultError(
      "TOOL_RESULT_INVALID_REQUEST",
      `byteStart must be non-negative and byteLength must be between 1 and ${TOOL_RESULT_MAX_SLICE_BYTES}`,
    );
  }
  const { manifest, payloadPath } = await loadBoundManifest(options);
  if (options.byteStart + options.byteLength > manifest.artefact.byte_count) {
    throw new ToolResultError("TOOL_RESULT_INVALID_REQUEST", "Requested byte slice extends beyond the artefact");
  }
  await validatePayload(payloadPath, manifest);
  const handle = await open(payloadPath, "r");
  const bytes = Buffer.alloc(options.byteLength);
  try {
    let readOffset = 0;
    while (readOffset < bytes.byteLength) {
      const { bytesRead } = await handle.read(
        bytes,
        readOffset,
        bytes.byteLength - readOffset,
        options.byteStart + readOffset,
      );
      if (bytesRead === 0) break;
      readOffset += bytesRead;
    }
    if (readOffset !== bytes.byteLength) {
      throw new ToolResultError("TOOL_RESULT_CORRUPT", "Tool-result payload ended before the requested slice");
    }
  } finally {
    await handle.close();
  }
  let text: string;
  try {
    text = new TextDecoder("utf-8", { fatal: true }).decode(bytes);
  } catch (error) {
    throw new ToolResultError(
      "TOOL_RESULT_INVALID_REQUEST",
      "Requested byte slice does not align to valid UTF-8 text boundaries",
      { cause: error },
    );
  }
  return toolResultSliceOutputSchema.parse({
    schema_version: 1,
    result_id: manifest.result_id,
    byte_start: options.byteStart,
    byte_end: options.byteStart + options.byteLength,
    total_bytes: manifest.artefact.byte_count,
    source_sha256: manifest.artefact.sha256,
    text,
  });
}

export async function readToolResultHealth(options: ReadToolResultHealthOptions): Promise<ToolResultHealthOutput> {
  const clock = options.now ?? nowIso;
  validateBinding(options.binding, clock);
  const observedAt = Date.parse(clock());
  if (!Number.isFinite(observedAt)) {
    throw new ToolResultError("TOOL_RESULT_INVALID_REQUEST", "now must return an ISO date-time");
  }
  const paths = await prepareStore(options.stateRoot);
  const release = await acquireStoreLock(paths);
  try {
    const initial = await listStoredEntries(paths);
    const cleanup = await cleanupExpired(paths, observedAt, initial);
    const valid = cleanup.entries.filter(
      (entry): entry is StoredEntry & { manifest: StoredManifest } => Boolean(entry.manifest),
    );
    const corruptEntries = cleanup.entries.length - valid.length;
    const totalBytes = valid.reduce((total, entry) => total + entry.manifest.artefact.byte_count, 0);
    return toolResultHealthOutputSchema.parse({
      schema_version: 1,
      status: corruptEntries === 0 && totalBytes <= MAX_STORE_BYTES ? "healthy" : "degraded",
      limits: {
        max_artefact_bytes: MAX_ARTEFACT_BYTES,
        max_store_bytes: MAX_STORE_BYTES,
        retention_ms: RETENTION_MS,
      },
      usage: { artefacts: valid.length, total_bytes: totalBytes, corrupt_entries: corruptEntries },
      cleanup: {
        removed_artefacts: cleanup.removedArtefacts,
        removed_bytes: cleanup.removedBytes,
      },
    });
  } finally {
    await release();
  }
}
