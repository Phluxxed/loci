function normalizedRemoteParts(host: string, path: string): string {
  const normalizedHost = host.trim().toLowerCase();
  let normalizedPath = path.trim().replace(/^\/+|\/+$/g, "");
  normalizedPath = normalizedPath.replace(/\.git$/i, "").replace(/\/+$/g, "");
  if (!normalizedHost || !normalizedPath || normalizedPath.includes("\0")) {
    throw new Error("remote must contain a host and repository path");
  }
  return `${normalizedHost}/${normalizedPath.toLowerCase()}`;
}

/** Returns a credential-free, transport-neutral repository identity. */
export function normalizeGitRemote(value: string): string {
  const remote = value.trim().replace(/\/+$/g, "");
  if (!remote) throw new Error("remote must not be empty");

  const scp = /^(?:[^@\s]+@)?([^:/\s]+):(.+)$/.exec(remote);
  if (scp && !remote.includes("://")) return normalizedRemoteParts(scp[1], scp[2]);

  if (remote.includes("://")) {
    const parsed = new URL(remote);
    return normalizedRemoteParts(parsed.hostname, parsed.pathname);
  }

  const slash = remote.indexOf("/");
  if (slash <= 0) throw new Error("remote must contain a host and repository path");
  return normalizedRemoteParts(remote.slice(0, slash), remote.slice(slash + 1));
}
