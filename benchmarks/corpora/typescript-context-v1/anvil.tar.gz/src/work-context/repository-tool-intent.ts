export type RepositoryToolIntent = "observe" | "verify" | "mutate" | "unknown";

const MUTATING_COMMANDS = new Set([
  "chmod",
  "chown",
  "chgrp",
  "cp",
  "dd",
  "install",
  "ln",
  "mkdir",
  "mv",
  "patch",
  "rm",
  "rmdir",
  "tee",
  "touch",
  "truncate",
]);
const SAFE_SIMPLE_COMMANDS = new Set(["cat", "head", "ls", "pwd", "stat", "tail", "wc"]);
const SAFE_GIT_READS = new Set([
  "blame",
  "cat-file",
  "describe",
  "diff",
  "grep",
  "log",
  "ls-files",
  "name-rev",
  "rev-parse",
  "show",
  "status",
]);
const MUTATING_GIT_COMMANDS = new Set([
  "add",
  "am",
  "apply",
  "bisect",
  "checkout",
  "cherry-pick",
  "clean",
  "clone",
  "commit",
  "config",
  "fetch",
  "gc",
  "init",
  "merge",
  "mv",
  "pull",
  "push",
  "rebase",
  "reset",
  "restore",
  "revert",
  "rm",
  "stash",
  "switch",
]);
const UNSAFE_READ_FLAGS = /(?:^|\s)['"]?(?:--ext-diff|--output(?:=|\s)|--open-files-in-pager(?:=|\s)|--pre(?:=|\s)|--pre-glob(?:=|\s)|-o(?:\s|$))/;
const SAFE_SED_READ = /^sed\s+-n\s+(['"]?)(\d+)(?:,(\d+|\$))?p\1(?:\s+(?!-)\S+)+$/;
const SAFE_TEST_PATH = /^test\/[A-Za-z0-9._/-]+\.test\.ts$/;
const TEST_CONCURRENCY = /^--test-concurrency=([1-9]\d*)$/;

function startsShellExpansion(command: string, index: number): boolean {
  if (command[index] !== "$") return false;
  const next = command[index + 1];
  return next !== undefined && (next === "(" || next === "{" || /[A-Za-z0-9_?*@$!#-]/.test(next));
}

function splitReadOnlyConjunction(command: string): string[] | undefined {
  const segments: string[] = [];
  let quote: "'" | "\"" | undefined;
  let segmentStart = 0;

  for (let index = 0; index < command.length; index += 1) {
    const character = command[index]!;
    if (
      character === "\n" ||
      character === "\r" ||
      character === "\\" ||
      character === "`"
    ) {
      return undefined;
    }
    if (quote !== undefined) {
      if (character === quote) quote = undefined;
      else if (quote === "\"" && startsShellExpansion(command, index)) return undefined;
      continue;
    }
    if (character === "'" || character === "\"") {
      quote = character;
      continue;
    }
    if (startsShellExpansion(command, index)) return undefined;
    if (character === "&") {
      if (command[index + 1] !== "&") return undefined;
      const segment = command.slice(segmentStart, index).trim();
      if (segment.length === 0) return undefined;
      segments.push(segment);
      segmentStart = index + 2;
      index += 1;
      continue;
    }
    if (character === ";" || character === "|" || character === "<" || character === ">" || character === "(" || character === ")") {
      return undefined;
    }
  }

  if (quote !== undefined) return undefined;
  const finalSegment = command.slice(segmentStart).trim();
  if (finalSegment.length === 0) return undefined;
  segments.push(finalSegment);
  return segments;
}

function isBoundedNodeTest(words: readonly string[]): boolean {
  if (words[0] !== "node" || words[1] !== "--test") return false;
  let testPathCount = 0;
  let concurrencySeen = false;
  for (const word of words.slice(2)) {
    const concurrency = TEST_CONCURRENCY.exec(word);
    if (concurrency !== null) {
      if (concurrencySeen) return false;
      concurrencySeen = true;
      continue;
    }
    if (
      !SAFE_TEST_PATH.test(word) ||
      word.split("/").some((segment) => segment.length === 0 || segment === "." || segment === "..")
    ) {
      return false;
    }
    testPathCount += 1;
  }
  return testPathCount > 0;
}

function classifyGit(command: string, words: readonly string[]): RepositoryToolIntent {
  const subcommand = words[1];
  if (subcommand === undefined) return "unknown";
  if (MUTATING_GIT_COMMANDS.has(subcommand)) return "mutate";
  if (UNSAFE_READ_FLAGS.test(command)) return "unknown";
  if (SAFE_GIT_READS.has(subcommand)) return "observe";
  if (subcommand === "branch") {
    return command === "git branch" || command === "git branch --show-current" || command === "git branch --list"
      ? "observe"
      : "mutate";
  }
  if (subcommand === "remote") {
    return command === "git remote" || command === "git remote -v" ? "observe" : "mutate";
  }
  if (subcommand === "tag") {
    return command === "git tag" || command === "git tag --list" || command === "git tag -l" ? "observe" : "mutate";
  }
  if (subcommand === "worktree") return command === "git worktree list" ? "observe" : "mutate";
  return "unknown";
}

function classifySimpleCommand(command: string): RepositoryToolIntent {
  const words = command.split(/\s+/);
  const executable = words[0]!;
  if (MUTATING_COMMANDS.has(executable)) return "mutate";
  if (SAFE_SIMPLE_COMMANDS.has(executable)) return "observe";
  if (executable === "sed") return SAFE_SED_READ.test(command) ? "observe" : "unknown";
  if (executable === "rg") return UNSAFE_READ_FLAGS.test(command) ? "unknown" : "observe";
  if (executable === "git") return classifyGit(command, words);
  if (command === "npm test" || command === "npm run typecheck") return "observe";
  if (executable === "npm") return "mutate";
  if (executable === "node") return isBoundedNodeTest(words) ? "verify" : "unknown";
  return "unknown";
}

function classifyBash(input: unknown): RepositoryToolIntent {
  if (typeof input !== "object" || input === null || Array.isArray(input)) return "unknown";
  const commandValue = (input as Record<string, unknown>).command;
  if (typeof commandValue !== "string") return "unknown";
  const command = commandValue.trim();
  if (command.length === 0) return "unknown";

  const segments = splitReadOnlyConjunction(command);
  if (segments === undefined) return "unknown";
  const intents = segments.map(classifySimpleCommand);
  if (intents.includes("mutate")) return "mutate";
  if (segments.length === 1) return intents[0]!;
  return intents.every((intent) => intent === "observe") ? "observe" : "unknown";
}

export function classifyRepositoryToolUse(toolName: string | undefined, input: unknown): RepositoryToolIntent {
  if (toolName === "apply_patch") return "mutate";
  if (toolName === "Bash") return classifyBash(input);
  return "unknown";
}
