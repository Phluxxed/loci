import { randomUUID } from "node:crypto";
import { appendFile, mkdir, readFile } from "node:fs/promises";
import { dirname, join } from "node:path";

import { resolveWorkContextStateRoot } from "./binding.ts";
import type { WorkContextErrorCode } from "./binding.ts";

export type WorkContextRejection = {
  version: 1;
  id: string;
  created_at: string;
  code: WorkContextErrorCode;
  operation: string;
  binding_id?: string;
  host?: string;
};

type RejectionOptions = {
  code: WorkContextErrorCode;
  operation: string;
  bindingId?: string;
  host?: string;
  stateRoot?: string;
  now?: () => string;
  id?: () => string;
};

const SAFE_TEXT = /^[A-Za-z0-9._:-]+$/;

function boundedSafeText(value: string, field: string, max: number): string {
  if (!value || value.length > max || !SAFE_TEXT.test(value)) {
    throw new Error(`${field} must be a bounded safe identifier`);
  }
  return value;
}

export function workContextRejectionsPath(stateRoot?: string): string {
  return join(resolveWorkContextStateRoot(stateRoot), "work-context", "rejections.jsonl");
}

export async function recordWorkContextRejection(options: RejectionOptions): Promise<WorkContextRejection> {
  const record: WorkContextRejection = {
    version: 1,
    id: boundedSafeText((options.id ?? (() => `wctx_reject_${randomUUID().replaceAll("-", "")}`))(), "id", 96),
    created_at: (options.now ?? (() => new Date().toISOString()))(),
    code: options.code,
    operation: boundedSafeText(options.operation, "operation", 128),
    ...(options.bindingId
      ? { binding_id: boundedSafeText(options.bindingId, "bindingId", 96) }
      : {}),
    ...(options.host ? { host: boundedSafeText(options.host, "host", 64) } : {}),
  };
  if (Number.isNaN(Date.parse(record.created_at))) throw new Error("created_at must be an ISO timestamp");
  const path = workContextRejectionsPath(options.stateRoot);
  await mkdir(dirname(path), { recursive: true, mode: 0o700 });
  await appendFile(path, `${JSON.stringify(record)}\n`, { encoding: "utf8", mode: 0o600 });
  return record;
}

export async function readWorkContextRejections(
  options: { stateRoot?: string; bindingId?: string } = {},
): Promise<{ kind: "ok"; records: WorkContextRejection[] } | { kind: "missing" } | { kind: "malformed"; message: string }> {
  let text: string;
  try {
    text = await readFile(workContextRejectionsPath(options.stateRoot), "utf8");
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code === "ENOENT") return { kind: "missing" };
    return { kind: "malformed", message: error instanceof Error ? error.message : String(error) };
  }

  const records: WorkContextRejection[] = [];
  try {
    for (const line of text.split("\n")) {
      if (!line.trim()) continue;
      const value = JSON.parse(line) as WorkContextRejection;
      if (
        value.version !== 1 ||
        typeof value.id !== "string" ||
        typeof value.created_at !== "string" ||
        typeof value.code !== "string" ||
        typeof value.operation !== "string"
      ) {
        throw new Error("rejection record is malformed");
      }
      if (options.bindingId === undefined || value.binding_id === options.bindingId) records.push(value);
    }
  } catch (error) {
    return { kind: "malformed", message: error instanceof Error ? error.message : String(error) };
  }
  return { kind: "ok", records };
}
