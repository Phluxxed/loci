import { spawnSync } from "node:child_process";
import { createHash } from "node:crypto";
import { realpathSync } from "node:fs";
import { basename, resolve } from "node:path";
import * as z from "zod/v4";

export const collaborationSpaceKindSchema = z.enum(["git", "directory"]);
export type CollaborationSpaceKind = z.infer<typeof collaborationSpaceKindSchema>;

export const workspaceRefSchema = z
  .object({
    key: z.string().regex(/^sha256_[a-f0-9]{64}$/),
    kind: collaborationSpaceKindSchema,
    root: z.string().min(1),
    label: z.string().min(1).optional(),
  })
  .strict();
export type WorkspaceRef = z.infer<typeof workspaceRefSchema>;

export function normalizeWorkspaceRoot(root: string): string {
  const absolute = resolve(root);
  try {
    return realpathSync(absolute);
  } catch {
    return absolute;
  }
}

export function workspaceKeyForRoot(root: string): string {
  return `sha256_${createHash("sha256").update(normalizeWorkspaceRoot(root)).digest("hex")}`;
}

function workspaceRef(kind: CollaborationSpaceKind, root: string, label?: string): WorkspaceRef {
  const normalized = normalizeWorkspaceRoot(root);
  return {
    key: workspaceKeyForRoot(normalized),
    kind,
    root: normalized,
    label: label ?? basename(normalized) ?? normalized,
  };
}

export function gitWorkspaceRef(root: string, label?: string): WorkspaceRef {
  return workspaceRef("git", root, label);
}

export function directoryWorkspaceRef(root: string, label?: string): WorkspaceRef {
  return workspaceRef("directory", root, label);
}

export function resolveCollaborationSpace(cwd: string): WorkspaceRef {
  const canonicalCwd = realpathSync(resolve(cwd));
  const result = spawnSync("git", ["rev-parse", "--show-toplevel"], {
    cwd: canonicalCwd,
    encoding: "utf8",
    stdio: ["ignore", "pipe", "ignore"],
  });

  if (result.status === 0 && result.stdout.trim().length > 0) {
    return gitWorkspaceRef(realpathSync(result.stdout.trim()));
  }
  return directoryWorkspaceRef(canonicalCwd);
}
