import { stat } from "node:fs/promises";

import { readCurrent } from "../continuity/store.ts";
import { deriveContinuityPaths } from "../continuity/workspace.ts";
import {
  readStoredWorkContextBinding,
  resolveWorkContextStateRoot,
  workContextBindingView,
  WorkContextError,
} from "./binding.ts";
import { readWorkContextRejections } from "./rejections.ts";
import { resolveCollaborationSpace } from "./space.ts";
import type { WorkContextBindingView } from "./binding.ts";

export type WorkContextDoctorFinding = {
  code: string;
  severity: "info" | "warning" | "error";
  message: string;
};

export type WorkContextDoctorOutput = {
  status: "ok" | "warning" | "error";
  binding: {
    status: "active" | "missing" | "stale" | "superseded" | "mismatched" | "orphaned" | "malformed";
    value?: WorkContextBindingView;
  };
  continuity: {
    status: "ok" | "missing" | "malformed" | "not_checked";
    workspace_key?: string;
  };
  rejected_routing_attempts: number;
  findings: WorkContextDoctorFinding[];
};

export async function doctorWorkContext(input: {
  bindingId: string;
  stateRoot?: string;
  cwd?: string;
  now?: () => string;
}): Promise<WorkContextDoctorOutput> {
  const findings: WorkContextDoctorFinding[] = [];
  const stateRoot = resolveWorkContextStateRoot(input.stateRoot);
  let binding;
  try {
    binding = await readStoredWorkContextBinding({ bindingId: input.bindingId, stateRoot });
  } catch (error) {
    const code = error instanceof WorkContextError ? error.code : "WORK_CONTEXT_MALFORMED";
    findings.push({ code, severity: "error", message: error instanceof Error ? error.message : String(error) });
    return {
      status: "error",
      binding: { status: "malformed" },
      continuity: { status: "not_checked" },
      rejected_routing_attempts: 0,
      findings,
    };
  }

  const rejections = await readWorkContextRejections({ stateRoot, bindingId: input.bindingId });
  const rejectedRoutingAttempts = rejections.kind === "ok" ? rejections.records.length : 0;
  if (rejections.kind === "malformed") {
    findings.push({ code: "WORK_CONTEXT_REJECTIONS_MALFORMED", severity: "warning", message: rejections.message });
  }

  if (!binding) {
    findings.push({
      code: "WORK_CONTEXT_NOT_BOUND",
      severity: "warning",
      message: `Work Context binding ${input.bindingId} does not exist`,
    });
    return {
      status: "warning",
      binding: { status: "missing" },
      continuity: { status: "not_checked" },
      rejected_routing_attempts: rejectedRoutingAttempts,
      findings,
    };
  }

  let bindingStatus: WorkContextDoctorOutput["binding"]["status"] = "active";
  const observedAt = Date.parse((input.now ?? (() => new Date().toISOString()))());
  const expiresAt = Date.parse(binding.expires_at);
  if (binding.status === "superseded") {
    bindingStatus = "superseded";
    findings.push({ code: "WORK_CONTEXT_STALE", severity: "warning", message: `Binding was superseded by ${binding.superseded_by}` });
  } else if (!Number.isFinite(observedAt) || !Number.isFinite(expiresAt) || observedAt > expiresAt) {
    bindingStatus = "stale";
    findings.push({ code: "WORK_CONTEXT_STALE", severity: "warning", message: `Binding expired at ${binding.expires_at}` });
  }

  try {
    const item = await stat(binding.collaboration_space.root);
    if (!item.isDirectory()) throw new Error("collaboration space is not a directory");
  } catch {
    bindingStatus = "orphaned";
    findings.push({
      code: "WORK_CONTEXT_ORPHANED",
      severity: "error",
      message: `Collaboration space no longer exists at ${binding.collaboration_space.root}`,
    });
  }

  if (input.cwd !== undefined) {
    try {
      const observed = resolveCollaborationSpace(input.cwd);
      if (observed.key !== binding.collaboration_space.key) {
        bindingStatus = "mismatched";
        findings.push({
          code: "WORK_CONTEXT_MISMATCH",
          severity: "error",
          message: `Observed collaboration space ${observed.key} does not match binding ${binding.collaboration_space.key}`,
        });
      }
    } catch (error) {
      bindingStatus = "mismatched";
      findings.push({
        code: "WORK_CONTEXT_AMBIGUOUS",
        severity: "error",
        message: error instanceof Error ? error.message : String(error),
      });
    }
  }

  const paths = deriveContinuityPaths({ stateRoot, workspace: binding.collaboration_space });
  const current = await readCurrent(paths);
  const continuityStatus = current.kind;
  if (current.kind !== "ok") {
    findings.push({
      code: current.kind === "missing" ? "CONTINUITY_NOT_INITIALIZED" : "CONTINUITY_MALFORMED",
      severity: current.kind === "missing" ? "info" : "error",
      message: current.message,
    });
  }
  if (rejectedRoutingAttempts > 0) {
    findings.push({
      code: "WORK_CONTEXT_REJECTIONS_PRESENT",
      severity: "warning",
      message: `${rejectedRoutingAttempts} rejected routing attempt(s) were recorded without prompt content`,
    });
  }

  const status = findings.some((finding) => finding.severity === "error")
    ? "error"
    : findings.some((finding) => finding.severity === "warning")
      ? "warning"
      : "ok";
  return {
    status,
    binding: { status: bindingStatus, value: workContextBindingView(binding) },
    continuity: { status: continuityStatus, workspace_key: binding.collaboration_space.key },
    rejected_routing_attempts: rejectedRoutingAttempts,
    findings,
  };
}
