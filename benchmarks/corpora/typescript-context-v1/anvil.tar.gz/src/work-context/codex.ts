import {
  bindingIdForSession,
  bindWorkContext,
  requireWorkContextBinding,
  WorkContextError,
} from "./binding.ts";
import { resolveCollaborationSpace } from "./space.ts";
import type { WorkContextBinding } from "./binding.ts";
import type { WorkspaceRef } from "./space.ts";

export type CodexSessionStartSource = "startup" | "resume" | "clear" | "compact";

type CodexLifecycleOptions = {
  cwd: unknown;
  sessionId: unknown;
  stateRoot?: string;
};

export type BindCodexWorkContextOptions = CodexLifecycleOptions & {
  source?: unknown;
};

const SESSION_START_SOURCES = new Set<CodexSessionStartSource>(["startup", "resume", "clear", "compact"]);

function requireLifecycleString(value: unknown, name: string): string {
  if (typeof value !== "string" || value.trim().length === 0) {
    throw new WorkContextError("WORK_CONTEXT_NOT_BOUND", `Codex lifecycle input is missing ${name}`);
  }
  return value;
}

function sessionStartSource(value: unknown): CodexSessionStartSource {
  if (value === undefined) return "startup";
  if (typeof value === "string" && SESSION_START_SOURCES.has(value as CodexSessionStartSource)) {
    return value as CodexSessionStartSource;
  }
  throw new WorkContextError("WORK_CONTEXT_MISMATCH", "Codex SessionStart source is not recognized");
}

export async function bindCodexWorkContext(options: BindCodexWorkContextOptions): Promise<WorkContextBinding> {
  const cwd = requireLifecycleString(options.cwd, "cwd");
  const sessionId = requireLifecycleString(options.sessionId, "session_id");
  const source = sessionStartSource(options.source);
  try {
    const result = await bindWorkContext({
      host: "codex",
      sessionId,
      cwd,
      lifecycle: `SessionStart:${source}`,
      stateRoot: options.stateRoot,
    });
    return result.binding;
  } catch (error) {
    if (error instanceof WorkContextError) throw error;
    throw new WorkContextError(
      "WORK_CONTEXT_AMBIGUOUS",
      "Codex SessionStart could not establish one unambiguous collaboration space",
      { cause: error },
    );
  }
}

export async function requireCodexWorkContext(options: CodexLifecycleOptions): Promise<WorkContextBinding> {
  const cwd = requireLifecycleString(options.cwd, "cwd");
  const sessionId = requireLifecycleString(options.sessionId, "session_id");
  let binding: WorkContextBinding;
  let observedSpace: WorkspaceRef;
  try {
    binding = await requireWorkContextBinding({
      bindingId: bindingIdForSession("codex", sessionId),
      stateRoot: options.stateRoot,
    });
    observedSpace = resolveCollaborationSpace(cwd);
  } catch (error) {
    if (error instanceof WorkContextError) throw error;
    throw new WorkContextError(
      "WORK_CONTEXT_AMBIGUOUS",
      "Codex lifecycle validation could not resolve one unambiguous collaboration space",
      { cause: error },
    );
  }
  if (binding.host !== "codex" || binding.session_id !== sessionId || binding.collaboration_space.key !== observedSpace.key) {
    throw new WorkContextError(
      "WORK_CONTEXT_MISMATCH",
      `Codex session ${sessionId} does not match its active collaboration space`,
    );
  }
  return binding;
}

export async function refreshCodexWorkContext(options: CodexLifecycleOptions): Promise<WorkContextBinding> {
  const cwd = requireLifecycleString(options.cwd, "cwd");
  const sessionId = requireLifecycleString(options.sessionId, "session_id");
  try {
    await requireCodexWorkContext(options);
    const result = await bindWorkContext({
      host: "codex",
      sessionId,
      cwd,
      lifecycle: "PreToolUse",
      stateRoot: options.stateRoot,
    });
    return result.binding;
  } catch (error) {
    if (error instanceof WorkContextError) throw error;
    throw new WorkContextError(
      "WORK_CONTEXT_AMBIGUOUS",
      "Codex PreToolUse could not validate one unambiguous collaboration space",
      { cause: error },
    );
  }
}

export function renderWorkContext(binding: WorkContextBinding): string {
  const space = binding.collaboration_space;
  return [
    "## Anvil Work Context",
    "",
    `Binding: ${binding.id} (${binding.status})`,
    `Session host: ${binding.host}`,
    `Collaboration space: ${space.label ?? space.key} (${space.root})`,
    `Provenance: ${binding.provenance.kind} via ${binding.provenance.lifecycle}`,
  ].join("\n");
}

export function renderWorkContextDiagnostic(error: WorkContextError): string {
  return [
    "## Anvil Work Context Diagnostic",
    "",
    `${error.code}: ${error.message}`,
    "",
    "No Anvil mutation authority is available until the host lifecycle establishes one unambiguous binding.",
  ].join("\n");
}

export function writeWorkContextDiagnostic(error: WorkContextError): void {
  process.stderr.write(`[anvil work context] ${error.code}: ${error.message}\n`);
}
