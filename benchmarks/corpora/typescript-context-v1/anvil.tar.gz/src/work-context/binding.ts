import { createHash, randomUUID } from "node:crypto";
import { homedir } from "node:os";
import { realpathSync } from "node:fs";
import { mkdir, readFile, rename, rm, writeFile } from "node:fs/promises";
import { dirname, join, resolve } from "node:path";
import { setTimeout as sleep } from "node:timers/promises";
import * as z from "zod/v4";

import { resolveCollaborationSpace, workspaceKeyForRoot, workspaceRefSchema } from "./space.ts";
import type { WorkspaceRef } from "./space.ts";

export type WorkContextErrorCode =
  | "WORK_CONTEXT_NOT_BOUND"
  | "WORK_CONTEXT_STALE"
  | "WORK_CONTEXT_MISMATCH"
  | "WORK_CONTEXT_AMBIGUOUS";

export class WorkContextError extends Error {
  readonly code: WorkContextErrorCode;

  constructor(code: WorkContextErrorCode, message: string, options?: ErrorOptions) {
    super(message, options);
    this.name = "WorkContextError";
    this.code = code;
  }
}

export type WorkContextBinding = {
  version: 1;
  id: string;
  status: "active" | "superseded";
  host: string;
  session_id: string;
  bound_at: string;
  last_seen_at: string;
  expires_at: string;
  collaboration_space: WorkspaceRef;
  provenance: {
    kind: "host_lifecycle" | "operator_rebind";
    lifecycle: string;
    observed_cwd: string;
  };
  superseded_by?: string;
  superseded_at?: string;
};

export const workContextBindingViewSchema = z
  .object({
    version: z.literal(1),
    id: z.string().regex(/^wctx_[a-f0-9]{32}$/),
    status: z.enum(["active", "superseded"]),
    host: z.string().min(1),
    bound_at: z.iso.datetime(),
    last_seen_at: z.iso.datetime(),
    expires_at: z.iso.datetime(),
    collaboration_space: workspaceRefSchema,
    provenance: z
      .object({
        kind: z.enum(["host_lifecycle", "operator_rebind"]),
        lifecycle: z.string().min(1),
      })
      .strict(),
    superseded_by: z.string().regex(/^wctx_[a-f0-9]{32}$/).optional(),
    superseded_at: z.iso.datetime().optional(),
  })
  .strict();
export type WorkContextBindingView = z.infer<typeof workContextBindingViewSchema>;

type Clock = () => string;

export type BindWorkContextOptions = {
  host: string;
  sessionId: string;
  cwd: string;
  lifecycle: string;
  stateRoot?: string;
  now?: Clock;
  maxAgeMs?: number;
  provenanceKind?: WorkContextBinding["provenance"]["kind"];
};

export type RequireWorkContextBindingOptions = {
  bindingId: string;
  stateRoot?: string;
  now?: Clock;
};

export type SupersedeWorkContextBindingOptions = RequireWorkContextBindingOptions & {
  replacementBindingId: string;
};

const DEFAULT_MAX_AGE_MS = 24 * 60 * 60 * 1_000;
const LOCK_TIMEOUT_MS = 5_000;
const LOCK_RETRY_DELAY_MS = 20;
const IDENTIFIER_PATTERN = /^[A-Za-z0-9._:-]+$/;
const BINDING_ID_PATTERN = /^wctx_[a-f0-9]{32}$/;

function nowIso(): string {
  return new Date().toISOString();
}

function requireIdentifier(value: string, name: string): string {
  if (!value || !IDENTIFIER_PATTERN.test(value)) {
    throw new WorkContextError(
      "WORK_CONTEXT_MISMATCH",
      `${name} must contain only letters, numbers, dots, underscores, colons, or hyphens`,
    );
  }
  return value;
}

function requireBindingId(value: string): string {
  if (!BINDING_ID_PATTERN.test(value)) {
    throw new WorkContextError("WORK_CONTEXT_NOT_BOUND", `Work Context binding ${value || "<empty>"} is not valid`);
  }
  return value;
}

export function resolveWorkContextStateRoot(stateRoot?: string): string {
  return resolve(stateRoot ?? process.env.ANVIL_STATE_ROOT ?? join(homedir(), ".anvil", "state"));
}

export function bindingIdForSession(host: string, sessionId: string): string {
  const safeHost = requireIdentifier(host, "host");
  const safeSessionId = requireIdentifier(sessionId, "sessionId");
  const digest = createHash("sha256").update(`${safeHost}\0${safeSessionId}`).digest("hex").slice(0, 32);
  return `wctx_${digest}`;
}

export function workContextBindingView(binding: WorkContextBinding): WorkContextBindingView {
  const { session_id: _sessionId, provenance, ...publicBinding } = binding;
  return {
    ...publicBinding,
    provenance: {
      kind: provenance.kind,
      lifecycle: provenance.lifecycle,
    },
  };
}

export function assertActiveWorkContextBinding(binding: WorkContextBinding, now: Clock = nowIso): WorkContextBinding {
  if (
    !isWorkContextBinding(binding) ||
    !BINDING_ID_PATTERN.test(binding.id) ||
    binding.collaboration_space.key !== workspaceKeyForRoot(binding.collaboration_space.root)
  ) {
    throw new WorkContextError("WORK_CONTEXT_MISMATCH", "Work Context binding is malformed or internally inconsistent");
  }
  const observedAt = Date.parse(now());
  const expiration = Date.parse(binding.expires_at);
  if (
    binding.status !== "active" ||
    !Number.isFinite(observedAt) ||
    !Number.isFinite(expiration) ||
    observedAt > expiration
  ) {
    throw new WorkContextError("WORK_CONTEXT_STALE", `Work Context binding ${binding.id} is stale`);
  }
  return binding;
}

function bindingPath(stateRoot: string, bindingId: string): string {
  return join(resolveWorkContextStateRoot(stateRoot), "work-context", "bindings", `${bindingId}.json`);
}

function bindingLockPath(stateRoot: string, bindingId: string): string {
  return join(resolveWorkContextStateRoot(stateRoot), "work-context", "locks", `${bindingId}.lock`);
}

function isNodeError(error: unknown): error is NodeJS.ErrnoException {
  return typeof error === "object" && error !== null && "code" in error;
}

async function readBinding(stateRoot: string, bindingId: string): Promise<WorkContextBinding | undefined> {
  const path = bindingPath(stateRoot, bindingId);
  let text: string;
  try {
    text = await readFile(path, "utf8");
  } catch (error) {
    if (isNodeError(error) && error.code === "ENOENT") return undefined;
    throw error;
  }

  try {
    const parsed: unknown = JSON.parse(text);
    if (!isWorkContextBinding(parsed) || parsed.id !== bindingId) {
      throw new Error("stored binding does not match the Work Context schema");
    }
    return parsed;
  } catch (error) {
    throw new WorkContextError(
      "WORK_CONTEXT_MISMATCH",
      `Stored Work Context binding ${bindingId} is malformed`,
      { cause: error },
    );
  }
}

export async function readStoredWorkContextBinding(
  options: Pick<RequireWorkContextBindingOptions, "bindingId" | "stateRoot">,
): Promise<WorkContextBinding | undefined> {
  const bindingId = requireBindingId(options.bindingId);
  return readBinding(resolveWorkContextStateRoot(options.stateRoot), bindingId);
}

function isWorkspaceRef(value: unknown): value is WorkspaceRef {
  if (typeof value !== "object" || value === null) return false;
  const candidate = value as Partial<WorkspaceRef>;
  return (
    typeof candidate.key === "string" &&
    (candidate.kind === "git" || candidate.kind === "directory") &&
    typeof candidate.root === "string" &&
    (candidate.label === undefined || typeof candidate.label === "string")
  );
}

function isWorkContextBinding(value: unknown): value is WorkContextBinding {
  if (typeof value !== "object" || value === null) return false;
  const candidate = value as Partial<WorkContextBinding>;
  const provenance = candidate.provenance;
  return (
    candidate.version === 1 &&
    typeof candidate.id === "string" &&
    (candidate.status === "active" || candidate.status === "superseded") &&
    typeof candidate.host === "string" &&
    typeof candidate.session_id === "string" &&
    typeof candidate.bound_at === "string" &&
    typeof candidate.last_seen_at === "string" &&
    typeof candidate.expires_at === "string" &&
    isWorkspaceRef(candidate.collaboration_space) &&
    typeof provenance === "object" &&
    provenance !== null &&
    (provenance.kind === "host_lifecycle" || provenance.kind === "operator_rebind") &&
    typeof provenance.lifecycle === "string" &&
    typeof provenance.observed_cwd === "string" &&
    (candidate.superseded_by === undefined || typeof candidate.superseded_by === "string") &&
    (candidate.superseded_at === undefined || typeof candidate.superseded_at === "string")
  );
}

async function writeBindingAtomic(stateRoot: string, binding: WorkContextBinding): Promise<void> {
  const path = bindingPath(stateRoot, binding.id);
  await mkdir(dirname(path), { recursive: true, mode: 0o700 });
  const temporaryPath = `${path}.${process.pid}.${randomUUID()}.tmp`;
  await writeFile(temporaryPath, `${JSON.stringify(binding, null, 2)}\n`, { encoding: "utf8", mode: 0o600 });
  await rename(temporaryPath, path);
}

async function withBindingLock<T>(stateRoot: string, bindingId: string, mutation: () => Promise<T>): Promise<T> {
  const lockPath = bindingLockPath(stateRoot, bindingId);
  const deadline = Date.now() + LOCK_TIMEOUT_MS;
  await mkdir(dirname(lockPath), { recursive: true, mode: 0o700 });

  while (true) {
    try {
      await mkdir(lockPath, { mode: 0o700 });
      break;
    } catch (error) {
      if (!isNodeError(error) || error.code !== "EEXIST") throw error;
      if (Date.now() >= deadline) {
        throw new WorkContextError(
          "WORK_CONTEXT_AMBIGUOUS",
          `Timed out acquiring the lock for Work Context binding ${bindingId}`,
        );
      }
      await sleep(LOCK_RETRY_DELAY_MS);
    }
  }

  try {
    return await mutation();
  } finally {
    await rm(lockPath, { recursive: true, force: true });
  }
}

function expiresAt(observedAt: string, maxAgeMs: number): string {
  const timestamp = Date.parse(observedAt);
  if (!Number.isFinite(timestamp)) {
    throw new WorkContextError("WORK_CONTEXT_MISMATCH", `Clock returned an invalid timestamp: ${observedAt}`);
  }
  if (!Number.isFinite(maxAgeMs) || maxAgeMs <= 0) {
    throw new WorkContextError("WORK_CONTEXT_MISMATCH", "maxAgeMs must be a positive number");
  }
  return new Date(timestamp + maxAgeMs).toISOString();
}

export async function bindWorkContext(
  options: BindWorkContextOptions,
): Promise<{ binding: WorkContextBinding; created: boolean }> {
  const bindingId = bindingIdForSession(options.host, options.sessionId);
  const lifecycle = requireIdentifier(options.lifecycle, "lifecycle");
  const stateRoot = resolveWorkContextStateRoot(options.stateRoot);
  const collaborationSpace = resolveCollaborationSpace(options.cwd);
  const observedCwd = realpathSync(resolve(options.cwd));
  const observedAt = (options.now ?? nowIso)();
  const expiration = expiresAt(observedAt, options.maxAgeMs ?? DEFAULT_MAX_AGE_MS);

  return withBindingLock(stateRoot, bindingId, async () => {
    const existing = await readBinding(stateRoot, bindingId);
    if (existing) {
      if (
        existing.status !== "active" ||
        existing.host !== options.host ||
        existing.session_id !== options.sessionId ||
        existing.collaboration_space.key !== collaborationSpace.key
      ) {
        throw new WorkContextError(
          "WORK_CONTEXT_MISMATCH",
          `Session ${options.host}/${options.sessionId} is already bound to a different collaboration space or lifecycle`,
        );
      }

      const binding: WorkContextBinding = {
        ...existing,
        last_seen_at: observedAt,
        expires_at: expiration,
        provenance: {
          kind: options.provenanceKind ?? "host_lifecycle",
          lifecycle,
          observed_cwd: observedCwd,
        },
      };
      await writeBindingAtomic(stateRoot, binding);
      return { binding, created: false };
    }

    const binding: WorkContextBinding = {
      version: 1,
      id: bindingId,
      status: "active",
      host: options.host,
      session_id: options.sessionId,
      bound_at: observedAt,
      last_seen_at: observedAt,
      expires_at: expiration,
      collaboration_space: collaborationSpace,
      provenance: {
        kind: options.provenanceKind ?? "host_lifecycle",
        lifecycle,
        observed_cwd: observedCwd,
      },
    };
    await writeBindingAtomic(stateRoot, binding);
    return { binding, created: true };
  });
}

export async function requireWorkContextBinding(
  options: RequireWorkContextBindingOptions,
): Promise<WorkContextBinding> {
  const bindingId = requireBindingId(options.bindingId);
  const stateRoot = resolveWorkContextStateRoot(options.stateRoot);
  const binding = await readStoredWorkContextBinding({ bindingId, stateRoot });
  if (!binding) {
    throw new WorkContextError("WORK_CONTEXT_NOT_BOUND", `Work Context binding ${bindingId} does not exist`);
  }

  return assertActiveWorkContextBinding(binding, options.now);
}

export async function supersedeWorkContextBinding(
  options: SupersedeWorkContextBindingOptions,
): Promise<WorkContextBinding> {
  const bindingId = requireBindingId(options.bindingId);
  const replacementBindingId = requireBindingId(options.replacementBindingId);
  if (bindingId === replacementBindingId) {
    throw new WorkContextError("WORK_CONTEXT_MISMATCH", "A Work Context binding cannot supersede itself");
  }

  const stateRoot = resolveWorkContextStateRoot(options.stateRoot);
  const replacement = await requireWorkContextBinding({
    bindingId: replacementBindingId,
    stateRoot,
    now: options.now,
  });

  return withBindingLock(stateRoot, bindingId, async () => {
    const binding = await readBinding(stateRoot, bindingId);
    if (!binding) {
      throw new WorkContextError("WORK_CONTEXT_NOT_BOUND", `Work Context binding ${bindingId} does not exist`);
    }
    if (binding.status !== "active") {
      throw new WorkContextError("WORK_CONTEXT_STALE", `Work Context binding ${bindingId} is already stale`);
    }
    if (binding.collaboration_space.key !== replacement.collaboration_space.key) {
      throw new WorkContextError(
        "WORK_CONTEXT_MISMATCH",
        "A replacement Work Context binding must target the same collaboration space",
      );
    }

    const superseded: WorkContextBinding = {
      ...binding,
      status: "superseded",
      superseded_by: replacement.id,
      superseded_at: (options.now ?? nowIso)(),
    };
    await writeBindingAtomic(stateRoot, superseded);
    return superseded;
  });
}
