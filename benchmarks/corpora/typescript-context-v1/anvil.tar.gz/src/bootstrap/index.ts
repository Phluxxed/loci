import { spawnSync } from "node:child_process";
import { realpathSync } from "node:fs";
import { readFile, stat } from "node:fs/promises";
import { homedir } from "node:os";
import { basename, relative, resolve, sep } from "node:path";
import { z } from "zod";

import {
  agentConfigPath,
  defaultWikiAlias,
  resolveAgentIdentity,
  resolveAnvilHome,
  resolveBrainRoot,
} from "../config/index.ts";
import type { AgentIdStatus } from "../config/index.ts";
import { readContinuity } from "../continuity/index.ts";
import { readBrowserState } from "../browser/state.ts";
import {
  requireWorkContextBinding,
  workContextBindingView,
  workContextBindingViewSchema,
  WorkContextError,
} from "../work-context/index.ts";
import type { WorkContextBindingView } from "../work-context/index.ts";

export type BootstrapMode = "redacted" | "local_full";
export type IdentityConfidence = "high" | "medium" | "low" | "none" | "ambiguous";
export type GitRemoteStatus = "present" | "missing" | "multiple" | "unknown" | "not_checked";
export type BrainRootStatus = "missing_config" | "missing_workspace" | "exists" | "invalid" | "unsafe" | "unknown";
export type LlmWikiRegistrationStatus = "registered" | "not_registered" | "unknown" | "not_checked";
export type LlmWikiSetupStatus = "available" | "not_checked" | "unknown";
export type WarningSeverity = "info" | "warning" | "error";

const suggestedCallArgumentsSchema = z.union([
  z.object({}).strict(),
  z.object({ host: z.literal("codex") }).strict(),
  z.object({ json: z.literal(true) }).strict(),
  z.object({ agentId: z.string(), mode: z.literal("dry_run") }).strict(),
  z.object({ alias: z.string(), path: z.string(), created_by: z.literal("anvil") }).strict(),
  z.object({ alias: z.string() }).strict(),
  z.object({ alias: z.string(), include_conventions: z.literal(true), max_chars: z.literal(12_000) }).strict(),
]);

export const bootstrapSuggestedCallSchema = z
  .object({
    tool: z.string(),
    arguments: suggestedCallArgumentsSchema,
    reason: z.string(),
    precondition: z.string().optional(),
  })
  .strict();

export type SuggestedCall = z.infer<typeof bootstrapSuggestedCallSchema>;
type StrictBootstrapSuggestedCall = SuggestedCall;

export type BootstrapWarning = {
  code: string;
  severity: WarningSeverity;
  message: string;
  suggested_call?: string;
};

export type BootstrapInput = {
  cwd?: string;
  stateRoot?: string;
  anvilHome?: string;
  agentId?: string;
  mode?: BootstrapMode;
  env?: Record<string, string | undefined>;
  homeDir?: string;
  bindingId?: string;
};

export type BootstrapOutput = {
  work_context: {
    status: "active" | "not_requested" | "not_bound" | "stale" | "mismatch" | "ambiguous";
    binding?: WorkContextBindingView;
  };
  workspace: {
    cwd: string;
    inside_git: boolean;
    git_root: string | null;
    git_remote_status: GitRemoteStatus;
    project_id_guess: string;
    identity_confidence: IdentityConfidence;
  };
  continuity: {
    available: boolean;
    current_frame_status: "ok" | "missing" | "malformed";
    suggested_calls: SuggestedCall[];
  };
  brain: {
    configured: boolean;
    setup_required: boolean;
    agent_id?: string;
    agent_id_status: AgentIdStatus;
    anvil_home_status: "resolved" | "invalid";
    brain_root?: string;
    brain_root_status: BrainRootStatus;
    wiki_alias?: string;
    llm_wiki_setup_status: LlmWikiSetupStatus;
    llm_wiki_registration_status: LlmWikiRegistrationStatus;
    llm_wiki_registration_note: string;
    suggested_calls: SuggestedCall[];
  };
  loci: {
    suggested_calls: SuggestedCall[];
  };
  browser: {
    capability_status: "unconfigured" | "ready" | "degraded" | "unknown";
    local_profile_status: "unconfigured" | "configured_not_checked" | "ready" | "degraded";
    corporate_profile_status: "unconfigured" | "configured_not_checked" | "ready" | "degraded";
    default_tool_namespace: "agent-browser";
    corporate_tool_namespace: "agent-browser-corporate";
    suggested_calls: SuggestedCall[];
  };
  warnings: BootstrapWarning[];
  suggested_next_calls: SuggestedCall[];
};

export const bootstrapWarningSchema = z
  .object({
    code: z.string(),
    severity: z.enum(["info", "warning", "error"]),
    message: z.string(),
    suggested_call: z.string().optional(),
  })
  .strict();

export const sessionBootstrapOutputSchema = z
  .object({
    work_context: z
      .object({
        status: z.enum(["active", "not_requested", "not_bound", "stale", "mismatch", "ambiguous"]),
        binding: workContextBindingViewSchema.optional(),
      })
      .strict(),
    workspace: z
      .object({
        cwd: z.string(),
        inside_git: z.boolean(),
        git_root: z.string().nullable(),
        git_remote_status: z.enum(["present", "missing", "multiple", "unknown", "not_checked"]),
        project_id_guess: z.string(),
        identity_confidence: z.enum(["high", "medium", "low", "none", "ambiguous"]),
      })
      .strict(),
    continuity: z
      .object({
        available: z.boolean(),
        current_frame_status: z.enum(["ok", "missing", "malformed"]),
        suggested_calls: z.array(bootstrapSuggestedCallSchema),
      })
      .strict(),
    brain: z
      .object({
        configured: z.boolean(),
        setup_required: z.boolean(),
        agent_id: z.string().optional(),
        agent_id_status: z.enum(["configured", "input_matches_runtime", "missing", "mismatch"]),
        anvil_home_status: z.enum(["resolved", "invalid"]),
        brain_root: z.string().optional(),
        brain_root_status: z.enum(["missing_config", "missing_workspace", "exists", "invalid", "unsafe", "unknown"]),
        wiki_alias: z.string().optional(),
        llm_wiki_setup_status: z.enum(["available", "not_checked", "unknown"]),
        llm_wiki_registration_status: z.enum(["registered", "not_registered", "unknown", "not_checked"]),
        llm_wiki_registration_note: z.string(),
        suggested_calls: z.array(bootstrapSuggestedCallSchema),
      })
      .strict(),
    loci: z
      .object({
        suggested_calls: z.array(bootstrapSuggestedCallSchema),
      })
      .strict(),
    browser: z
      .object({
        capability_status: z.enum(["unconfigured", "ready", "degraded", "unknown"]),
        local_profile_status: z.enum(["unconfigured", "configured_not_checked", "ready", "degraded"]),
        corporate_profile_status: z.enum(["unconfigured", "configured_not_checked", "ready", "degraded"]),
        default_tool_namespace: z.literal("agent-browser"),
        corporate_tool_namespace: z.literal("agent-browser-corporate"),
        suggested_calls: z.array(bootstrapSuggestedCallSchema),
      })
      .strict(),
    warnings: z.array(bootstrapWarningSchema),
    suggested_next_calls: z.array(bootstrapSuggestedCallSchema),
  })
  .strict();

type Assert<T extends true> = T;
type SessionBootstrapSchemaProducesOutput = Assert<z.infer<typeof sessionBootstrapOutputSchema> extends BootstrapOutput ? true : false>;

type DisplayOptions = {
  homeDir: string;
  mode: BootstrapMode;
};

type GitInfo = {
  insideGit: boolean;
  root?: string;
  remoteStatus: GitRemoteStatus;
};

type BrainConfig = {
  schema_version: 1;
  agent_id: string;
  brain_root: string;
  wiki_alias: string;
};

type BrainConfigRead =
  | { kind: "missing" }
  | { kind: "ok"; config: BrainConfig }
  | { kind: "invalid"; message: string };

const MAX_WARNINGS = 10;
const MAX_SUGGESTED_CALLS = 10;
const MAX_MESSAGE_CHARS = 240;
const MAX_FIELD_CHARS = 120;
const BOOTSTRAP_RESPONSE_MAX_BYTES = 12_000;
const WIKI_ALIAS_PATTERN = /^[a-z0-9][a-z0-9_-]{0,95}$/;

function isNodeError(error: unknown): error is NodeJS.ErrnoException {
  return typeof error === "object" && error !== null && "code" in error;
}

function cap(value: string, max: number): string {
  if (value.length <= max) return value;
  if (max <= 3) return value.slice(0, max);
  return `${value.slice(0, max - 3)}...`;
}

function comparablePath(path: string): string {
  try {
    return realpathSync.native(path);
  } catch {
    return resolve(path);
  }
}

function displayPath(path: string, options: DisplayOptions): string {
  const absolute = resolve(path);
  if (options.mode === "local_full") return cap(absolute, MAX_FIELD_CHARS);

  const home = comparablePath(options.homeDir);
  const rel = relative(home, comparablePath(absolute));
  if (rel === "") return "~";
  if (!rel.startsWith("..") && !rel.includes(`..${sep}`) && rel.length > 0) return cap(`~/${rel}`, MAX_FIELD_CHARS);
  return cap(absolute, MAX_FIELD_CHARS);
}

function call(
  tool: string,
  args: StrictBootstrapSuggestedCall["arguments"],
  reason: string,
  precondition?: string,
): StrictBootstrapSuggestedCall {
  return {
    tool: cap(tool, MAX_FIELD_CHARS),
    arguments: args,
    reason: cap(reason, MAX_MESSAGE_CHARS),
    ...(precondition ? { precondition: cap(precondition, MAX_MESSAGE_CHARS) } : {}),
  };
}

function warning(code: string, severity: WarningSeverity, message: string, suggestedCall?: string): BootstrapWarning {
  return {
    code: cap(code, MAX_FIELD_CHARS),
    severity,
    message: cap(message, MAX_MESSAGE_CHARS),
    ...(suggestedCall ? { suggested_call: cap(suggestedCall, MAX_FIELD_CHARS) } : {}),
  };
}

function runGit(cwd: string, args: string[]): { status: number | null; stdout: string; stderr: string } {
  const result = spawnSync("git", args, {
    cwd,
    encoding: "utf8",
    stdio: ["ignore", "pipe", "pipe"],
  });
  return {
    status: result.status,
    stdout: result.stdout.trim(),
    stderr: result.stderr.trim(),
  };
}

function gitInfo(cwd: string): GitInfo {
  const rootResult = runGit(cwd, ["rev-parse", "--show-toplevel"]);
  if (rootResult.status !== 0 || rootResult.stdout.length === 0) {
    return { insideGit: false, remoteStatus: "not_checked" };
  }

  const remoteResult = runGit(cwd, ["remote", "-v"]);
  if (remoteResult.status !== 0) {
    return { insideGit: true, root: rootResult.stdout, remoteStatus: "unknown" };
  }

  const remoteNames = new Set(
    remoteResult.stdout
      .split("\n")
      .map((line) => line.trim().split(/\s+/)[0])
      .filter((name) => name.length > 0),
  );

  return {
    insideGit: true,
    root: rootResult.stdout,
    remoteStatus: remoteNames.size === 0 ? "missing" : remoteNames.size === 1 ? "present" : "multiple",
  };
}

function identityConfidence(info: GitInfo, projectIdGuess: string): IdentityConfidence {
  if (info.insideGit && info.remoteStatus === "present") return "high";
  if (info.insideGit) return "medium";
  if (projectIdGuess.length > 0) return "low";
  return "none";
}

function validateWikiAlias(value: unknown): string | undefined {
  if (typeof value !== "string" || value.length === 0) return undefined;
  if (!WIKI_ALIAS_PATTERN.test(value)) return undefined;
  return value;
}

function validateBrainConfig(value: unknown, expectedAgentId: string, homeDir: string): BrainConfigRead {
  if (typeof value !== "object" || value === null) return { kind: "invalid", message: "Brain config must be an object" };
  const record = value as Record<string, unknown>;
  if (record.schema_version !== 1) return { kind: "invalid", message: "Brain config schema_version must be 1" };
  if (record.agent_id !== expectedAgentId) return { kind: "invalid", message: "Brain config agent_id does not match runtime agent" };
  if (typeof record.brain_root !== "string") return { kind: "invalid", message: "Brain config brain_root must be a string" };
  const wikiAlias = validateWikiAlias(record.wiki_alias);
  if (!wikiAlias) return { kind: "invalid", message: "Brain config wiki_alias is invalid" };

  return {
    kind: "ok",
    config: {
      schema_version: 1,
      agent_id: expectedAgentId,
      brain_root: resolveBrainRoot({ agentId: expectedAgentId, brainRoot: record.brain_root, homeDir }),
      wiki_alias: wikiAlias,
    },
  };
}

async function readBrainConfig(path: string, expectedAgentId: string, homeDir: string): Promise<BrainConfigRead> {
  let text;
  try {
    text = await readFile(path, "utf8");
  } catch (error) {
    if (isNodeError(error) && error.code === "ENOENT") return { kind: "missing" };
    const message = error instanceof Error ? error.message : String(error);
    return { kind: "invalid", message };
  }

  try {
    return validateBrainConfig(JSON.parse(text), expectedAgentId, homeDir);
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    return { kind: "invalid", message };
  }
}

async function brainRootStatus(path: string): Promise<BrainRootStatus> {
  try {
    const item = await stat(path);
    return item.isDirectory() ? "exists" : "invalid";
  } catch (error) {
    if (isNodeError(error) && error.code === "ENOENT") return "missing_workspace";
    return "unknown";
  }
}

function boundedOutput(output: BootstrapOutput): BootstrapOutput {
  const bounded: BootstrapOutput = {
    ...output,
    warnings: output.warnings.slice(0, MAX_WARNINGS),
    suggested_next_calls: output.suggested_next_calls.slice(0, MAX_SUGGESTED_CALLS),
  };

  if (Buffer.byteLength(JSON.stringify(bounded), "utf8") <= BOOTSTRAP_RESPONSE_MAX_BYTES) return bounded;
  return {
    ...bounded,
    warnings: [
      warning("BOOTSTRAP_OUTPUT_TRUNCATED", "warning", "Bootstrap output exceeded the intended response cap and was truncated."),
    ],
    suggested_next_calls: bounded.suggested_next_calls.slice(0, 5),
  };
}

export async function bootstrapSession(input: BootstrapInput = {}): Promise<BootstrapOutput> {
  const mode = input.mode ?? "redacted";
  const cwd = resolve(input.cwd ?? process.cwd());
  const homeDir = input.homeDir ?? process.env.HOME ?? homedir();
  const display = { homeDir, mode };
  const git = gitInfo(cwd);
  const projectRoot = git.root ?? cwd;
  const projectIdGuess = basename(projectRoot) || projectRoot;

  const continuity = await readContinuity({
    cwd,
    stateRoot: input.stateRoot,
  });
  const continuityCalls = [
    call("anvil_continuity_read", {}, "Read the current compact continuity frame if orientation is needed."),
  ];

  const identity = resolveAgentIdentity({
    agentId: input.agentId,
    env: input.env,
  });
  const anvilHome = resolveAnvilHome({
    anvilHome: input.anvilHome,
    env: input.env,
    homeDir,
  });

  const warnings: BootstrapWarning[] = [];
  let workContext: BootstrapOutput["work_context"] = { status: "not_requested" };
  if (input.bindingId !== undefined) {
    try {
      const binding = workContextBindingView(
        await requireWorkContextBinding({ bindingId: input.bindingId, stateRoot: input.stateRoot }),
      );
      workContext = {
        status: "active",
        binding: {
          ...binding,
          collaboration_space: {
            ...binding.collaboration_space,
            root: displayPath(binding.collaboration_space.root, display),
          },
        },
      };
    } catch (error) {
      if (!(error instanceof WorkContextError)) throw error;
      const statusByCode: Record<WorkContextError["code"], BootstrapOutput["work_context"]["status"]> = {
        WORK_CONTEXT_NOT_BOUND: "not_bound",
        WORK_CONTEXT_STALE: "stale",
        WORK_CONTEXT_MISMATCH: "mismatch",
        WORK_CONTEXT_AMBIGUOUS: "ambiguous",
      };
      workContext = { status: statusByCode[error.code] };
      warnings.push(warning(error.code, "warning", error.message, "anvil_work_context_read"));
    }
  }
  const browserState = await readBrowserState(anvilHome);
  let browserCapabilityStatus: BootstrapOutput["browser"]["capability_status"] = "unconfigured";
  let localBrowserStatus: BootstrapOutput["browser"]["local_profile_status"] = "unconfigured";
  let corporateBrowserStatus: BootstrapOutput["browser"]["corporate_profile_status"] = "unconfigured";
  let browserCalls: StrictBootstrapSuggestedCall[] = [
    call(
      "anvil browser install",
      { host: "codex" },
      "Install the local-first Browser Eyes capability before using agent-browser tools.",
    ),
  ];
  if (browserState.kind === "ok") {
    browserCapabilityStatus = "unknown";
    localBrowserStatus = "configured_not_checked";
    corporateBrowserStatus = browserState.config.corporate.status === "configured" ? "configured_not_checked" : "unconfigured";
    browserCalls = [
      call("anvil browser status", { json: true }, "Check renderer and Codex registration state before browser work."),
    ];
  } else if (browserState.kind === "invalid") {
    browserCapabilityStatus = "degraded";
    localBrowserStatus = "degraded";
    corporateBrowserStatus = "degraded";
    warnings.push(warning("BROWSER_STATE_INVALID", "error", browserState.message, "anvil browser doctor"));
    browserCalls = [call("anvil browser doctor", { json: true }, "Diagnose invalid Browser Eyes state without mutating it.")];
  }
  let brainConfigured = false;
  let brainSetupRequired = true;
  let brainRoot: string | undefined;
  let brainRootState: BrainRootStatus = "missing_config";
  let wikiAlias: string | undefined;
  let registrationStatus: LlmWikiRegistrationStatus = "not_checked";
  let registrationNote = "Brain setup has not completed, so llm-wiki registration was not checked.";
  let brainCalls: StrictBootstrapSuggestedCall[] = [];

  if (identity.status === "missing") {
    warnings.push(
      warning(
        "MISSING_AGENT_ID",
        "warning",
        "Set ANVIL_AGENT_ID for this agent runtime before creating or using an agent-owned Brain.",
        "anvil_session_bootstrap",
      ),
    );
  } else if (identity.status === "mismatch") {
    warnings.push(
      warning(
        "RUNTIME_AGENT_ID_MISMATCH",
        "error",
        "Caller-supplied agentId does not match ANVIL_AGENT_ID; refusing to choose between identities.",
      ),
    );
  } else if (identity.resolvedAgentId) {
    wikiAlias = defaultWikiAlias(identity.resolvedAgentId);
    brainRoot = resolveBrainRoot({ agentId: identity.resolvedAgentId, homeDir });
    const configPath = agentConfigPath(anvilHome, identity.resolvedAgentId);
    const config = await readBrainConfig(configPath, identity.resolvedAgentId, homeDir);

    if (config.kind === "missing") {
      warnings.push(
        warning(
          "MISSING_BRAIN_CONFIG",
          "warning",
          "No Anvil Brain config exists for this agent runtime yet.",
          "anvil_brain_setup",
        ),
      );
      brainCalls = [
        call(
          "anvil_brain_setup",
          { agentId: identity.resolvedAgentId, mode: "dry_run" },
          "Plan creation of the agent-owned Brain wiki before any durable writes.",
          "Run after ANVIL_AGENT_ID is set for this agent runtime.",
        ),
      ];
    } else if (config.kind === "invalid") {
      brainRootState = "invalid";
      warnings.push(warning("INVALID_BRAIN_CONFIG", "error", config.message));
    } else {
      brainConfigured = true;
      brainRoot = config.config.brain_root;
      wikiAlias = config.config.wiki_alias;
      brainRootState = await brainRootStatus(brainRoot);
      brainSetupRequired = brainRootState !== "exists";
      registrationStatus = "unknown";
      registrationNote = `Call wiki_list through llm-wiki MCP and inspect structuredContent.wikis for the exact configured alias "${wikiAlias}" and path before inferring registration state; blank text content is not absence evidence.`;
      brainCalls = [
        call(
          "wiki_list",
          {},
          `Inspect structuredContent.wikis for the exact configured Brain alias "${wikiAlias}" and path before inferring registration state; blank text content is not absence evidence.`,
        ),
        call(
          "wiki_register",
          { alias: wikiAlias, path: displayPath(brainRoot, display), created_by: "anvil" },
          "Register the Brain wiki only after its exact alias/path pair is confirmed absent.",
          `Only after the Brain wiki scaffold exists and wiki_list structuredContent.wikis confirms the exact alias/path pair "${wikiAlias}" -> "${displayPath(brainRoot, display)}" is absent; blank text content is not absence evidence.`,
        ),
        call("wiki_doctor", { alias: wikiAlias }, "Validate the registered Brain wiki before relying on its context."),
        call(
          "wiki_agent_manual",
          { alias: wikiAlias, include_conventions: true, max_chars: 12_000 },
          "Load the Brain wiki operating manual before mutating wiki files.",
          "Only after wiki_doctor reports the wiki is usable.",
        ),
      ];
    }
  }

  if (brainRootState === "missing_workspace") {
    warnings.push(
      warning(
        "MISSING_BRAIN_WORKSPACE",
        "warning",
        "Brain config exists but the configured Brain workspace is missing.",
        "anvil_brain_setup",
      ),
    );
  }

  const output: BootstrapOutput = {
    work_context: workContext,
    workspace: {
      cwd: displayPath(cwd, display),
      inside_git: git.insideGit,
      git_root: git.root ? displayPath(git.root, display) : null,
      git_remote_status: git.remoteStatus,
      project_id_guess: cap(projectIdGuess, MAX_FIELD_CHARS),
      identity_confidence: identityConfidence(git, projectIdGuess),
    },
    continuity: {
      available: continuity.current.kind === "ok",
      current_frame_status: continuity.current.kind,
      suggested_calls: continuityCalls,
    },
    brain: {
      configured: brainConfigured,
      setup_required: brainSetupRequired,
      ...(identity.resolvedAgentId ? { agent_id: identity.resolvedAgentId } : {}),
      agent_id_status: identity.status,
      anvil_home_status: "resolved",
      ...(brainRoot ? { brain_root: displayPath(brainRoot, display) } : {}),
      brain_root_status: brainRootState,
      ...(wikiAlias ? { wiki_alias: wikiAlias } : {}),
      llm_wiki_setup_status: "available",
      llm_wiki_registration_status: registrationStatus,
      llm_wiki_registration_note: cap(registrationNote, MAX_MESSAGE_CHARS),
      suggested_calls: brainCalls.slice(0, MAX_SUGGESTED_CALLS),
    },
    loci: {
      suggested_calls: [],
    },
    browser: {
      capability_status: browserCapabilityStatus,
      local_profile_status: localBrowserStatus,
      corporate_profile_status: corporateBrowserStatus,
      default_tool_namespace: "agent-browser",
      corporate_tool_namespace: "agent-browser-corporate",
      suggested_calls: browserCalls,
    },
    warnings,
    suggested_next_calls: [...continuityCalls, ...brainCalls, ...browserCalls].slice(0, MAX_SUGGESTED_CALLS),
  };

  return boundedOutput(output);
}
