import { McpServer } from "@modelcontextprotocol/server";
import { StdioServerTransport } from "@modelcontextprotocol/server/stdio";

import {
  brainSetupInputSchema,
  brainSetupOutputSchema,
  brainUsageLogInputSchema,
  brainUsageLogOutputSchema,
  brainUsageMetricsInputSchema,
  brainUsageMetricsOutputSchema,
  brainUsageReadInputSchema,
  brainUsageReadOutputSchema,
  continuityCheckpointTaskInputSchema,
  continuityCheckpointTaskOutputSchema,
  continuityPromoteEventInputSchema,
  continuityPromoteEventOutputSchema,
  continuityReadInputSchema,
  continuityReadOutputSchema,
  continuityRecordEventInputSchema,
  continuityRecordEventOutputSchema,
  continuityRetireProjectionItemInputSchema,
  continuityRetireProjectionItemOutputSchema,
  handleBrainSetup,
  handleBrainUsageLog,
  handleBrainUsageMetrics,
  handleBrainUsageRead,
  handleSkillInvocationAuditSample,
  handleSkillInvocationLog,
  handleSkillInvocationRead,
  handleSessionBootstrap,
  handleWorkContextRead,
  handleContinuityPromoteEvent,
  handleContinuityCheckpointTask,
  handleContinuityRead,
  handleContinuityRecordEvent,
  handleContinuityRetireProjectionItem,
  handleToolResultHealth,
  handleToolResultManifest,
  handleToolResultReadSlice,
  handleToolResultSearch,
  sessionBootstrapInputSchema,
  sessionBootstrapOutputSchema,
  skillInvocationAuditSampleInputSchema,
  skillInvocationAuditSampleOutputSchema,
  skillInvocationLogInputSchema,
  skillInvocationLogOutputSchema,
  skillInvocationReadInputSchema,
  skillInvocationReadOutputSchema,
  workContextReadInputSchema,
  workContextReadOutputSchema,
  toolResultHealthInputSchema,
  toolResultHealthOutputSchema,
  toolResultManifestInputSchema,
  toolResultManifestOutputSchema,
  toolResultReadSliceInputSchema,
  toolResultSearchInputSchema,
  toolResultSearchOutputSchema,
  toolResultSliceOutputSchema,
} from "./tools.ts";
import {
  handleManifestChange,
  handleManifestCreate,
  handleManifestInquire,
  handleManifestOrient,
  manifestChangeInputSchema,
  manifestChangeOutputSchema,
  manifestCreateInputSchema,
  manifestCreateOutputSchema,
  manifestInquireInputSchema,
  manifestInquireOutputSchema,
  manifestOrientInputSchema,
  manifestOrientOutputSchema,
} from "./manifest.ts";
const ANVIL_MCP_INSTRUCTIONS = [
  "Anvil continuity is workspace continuity, not truth. Use current user instruction, current files, command output, tests, and live evidence as authoritative.",
  "Anvil mutation routing is host-bound. The Codex PreToolUse adapter supplies bindingId for Continuity, manual Brain usage, and skill invocation writes. Never invent a binding id or use a resource path to select the collaboration-space owner.",
  "Treat the compact frame as the current working set. When accepted work must survive the current conversation, use anvil_continuity_checkpoint_task to set, replace, wait, or clear the singular active task and verify the returned rendered frame. Use record/promote/retire for other durable decisions, questions, next actions, and compact-frame hygiene.",
  "Brain stand-up is host-neutral. When a user asks to turn the Brain on, stand the Brain up, or similar, run anvil_session_bootstrap first. If Brain setup is required, run anvil_brain_setup in dry_run mode, then apply the returned plan_hash and acknowledgement_token; the explicit stand-up request is sufficient approval for this routine Anvil-owned setup unless the tool reports a refusal or the action involves secrets, public commitments, shared-Brain identity changes, or other sensitive state.",
  "After Brain setup, route through llm-wiki rather than duplicating wiki scaffold rules: run the existing /wikime workflow for the target Brain root, register the wiki in the current agent runtime, run wiki_doctor, load wiki_agent_manual, then seed the first durable Brain pages from available bootstrap evidence. Update index/log, run lint/render, and commit the Brain repo when there is a meaningful Brain change.",
  "When durable learning, correction, work history, or wiki hygiene should be integrated into Brain, the current main agent acts as Brain Steward. Follow the standard Brain Steward workflow in the target Brain's wiki-agent.md: read and obey that manual, use llm-wiki's read-only maintenance proposal as evidence for Steward judgment, then author, verify, and commit any warranted Brain change.",
  "Brain usage is Anvil operational evidence. For each Brain-adjacent turn, record exactly one manual coverage outcome with anvil_brain_usage_log and add incident outcomes only when they occur; automatic recall events remain prompt-hook-owned. Use anvil_brain_usage_read or anvil_brain_usage_metrics for the canonical shared-state view.",
  "Skill invocation records are local operational evidence, not continuity or automatic Brain ingestion. Use anvil_skill_invocation_log with an explicit outcome and concrete reason, anvil_skill_invocation_read for filtered paginated review, and anvil_skill_invocation_audit_sample for a small reproducible independent-review sample.",
  "Verbose local command results may be captured through the sandbox-inherited anvil tool-result capture CLI. Use anvil_tool_result_manifest, anvil_tool_result_search, and anvil_tool_result_read_slice to inspect the complete bound artefact without rerunning its producer. structuredContent is authoritative; compatibility text is only a bounded marker.",
  "These stand-up rules belong to Anvil MCP and apply the same way from Codex, Claude, or another local agent host; host-specific MCP registration and ANVIL_AGENT_ID still have to exist before that host can execute them.",
].join(" ");

export function createAnvilMcpServer(): McpServer {
  const server = new McpServer(
    {
      name: "anvil",
      version: "0.0.0",
    },
    {
      instructions: ANVIL_MCP_INSTRUCTIONS,
    },
  );

  server.registerTool(
    "anvil_brain_setup",
    {
      title: "Set Up Anvil Brain",
      description: "Plan or apply Anvil-owned Brain setup metadata, then route the agent to the existing llm-wiki scaffold flow.",
      inputSchema: brainSetupInputSchema,
      outputSchema: brainSetupOutputSchema,
      annotations: {
        readOnlyHint: false,
        destructiveHint: false,
        idempotentHint: false,
        openWorldHint: false,
      },
    },
    handleBrainSetup,
  );

  server.registerTool(
    "anvil_session_bootstrap",
    {
      title: "Bootstrap Anvil Session",
      description: "Return compact, read-only Anvil routing/status for the current workspace, Brain, continuity, and Loci.",
      inputSchema: sessionBootstrapInputSchema,
      outputSchema: sessionBootstrapOutputSchema,
      annotations: {
        readOnlyHint: true,
        destructiveHint: false,
        idempotentHint: true,
        openWorldHint: false,
      },
    },
    handleSessionBootstrap,
  );

  server.registerTool(
    "anvil_work_context_read",
    {
      title: "Read Anvil Work Context",
      description: "Inspect one host-established Work Context binding without creating, repairing, or rebinding it.",
      inputSchema: workContextReadInputSchema,
      outputSchema: workContextReadOutputSchema,
      annotations: {
        readOnlyHint: true,
        destructiveHint: false,
        idempotentHint: true,
        openWorldHint: false,
      },
    },
    async (args) => handleWorkContextRead(args),
  );

  server.registerTool(
    "anvil_brain_usage_log",
    {
      title: "Log Brain Usage Outcome",
      description:
        "Record a manual Brain coverage or incident outcome in Anvil's canonical usage journal. Automatic prompt-recall events remain hook-owned.",
      inputSchema: brainUsageLogInputSchema,
      outputSchema: brainUsageLogOutputSchema,
      annotations: {
        readOnlyHint: false,
        destructiveHint: false,
        idempotentHint: false,
        openWorldHint: false,
      },
    },
    async (args) => handleBrainUsageLog(args),
  );

  server.registerTool(
    "anvil_brain_usage_metrics",
    {
      title: "Summarize Brain Usage Metrics",
      description: "Summarize the canonical Brain usage journal across all workspace partitions or the current workspace.",
      inputSchema: brainUsageMetricsInputSchema,
      outputSchema: brainUsageMetricsOutputSchema,
      annotations: {
        readOnlyHint: true,
        destructiveHint: false,
        idempotentHint: true,
        openWorldHint: false,
      },
    },
    (args) => handleBrainUsageMetrics(args),
  );

  server.registerTool(
    "anvil_brain_usage_read",
    {
      title: "Read Recent Brain Usage",
      description: "Read a bounded slice of the most recent canonical Brain usage records across all workspaces or the current workspace.",
      inputSchema: brainUsageReadInputSchema,
      outputSchema: brainUsageReadOutputSchema,
      annotations: {
        readOnlyHint: true,
        destructiveHint: false,
        idempotentHint: true,
        openWorldHint: false,
      },
    },
    handleBrainUsageRead,
  );

  server.registerTool(
    "anvil_skill_invocation_log",
    {
      title: "Log Skill Invocation Outcome",
      description: "Record concise skill selection evidence in Anvil's canonical workspace-local invocation journal.",
      inputSchema: skillInvocationLogInputSchema,
      outputSchema: skillInvocationLogOutputSchema,
      annotations: {
        readOnlyHint: false,
        destructiveHint: false,
        idempotentHint: false,
        openWorldHint: false,
      },
    },
    async (args) => handleSkillInvocationLog(args),
  );

  server.registerTool(
    "anvil_skill_invocation_read",
    {
      title: "Read Recent Skill Invocations",
      description: "Read a bounded slice of the current workspace's canonical skill invocation journal.",
      inputSchema: skillInvocationReadInputSchema,
      outputSchema: skillInvocationReadOutputSchema,
      annotations: {
        readOnlyHint: true,
        destructiveHint: false,
        idempotentHint: true,
        openWorldHint: false,
      },
    },
    handleSkillInvocationRead,
  );

  server.registerTool(
    "anvil_skill_invocation_audit_sample",
    {
      title: "Sample Skill Invocations For Audit",
      description: "Select a small reproducible sample of traceable skill invocation records for independent review.",
      inputSchema: skillInvocationAuditSampleInputSchema,
      outputSchema: skillInvocationAuditSampleOutputSchema,
      annotations: {
        readOnlyHint: true,
        destructiveHint: false,
        idempotentHint: true,
        openWorldHint: false,
      },
    },
    handleSkillInvocationAuditSample,
  );

  server.registerTool(
    "anvil_continuity_read",
    {
      title: "Read Anvil Continuity",
      description: "Read the current Anvil continuity frame and optional recent continuity events for the workspace.",
      inputSchema: continuityReadInputSchema,
      outputSchema: continuityReadOutputSchema,
      annotations: {
        readOnlyHint: true,
        destructiveHint: false,
        idempotentHint: true,
        openWorldHint: false,
      },
    },
    handleContinuityRead,
  );

  server.registerTool(
    "anvil_continuity_checkpoint_task",
    {
      title: "Checkpoint Active Continuity Task",
      description:
        "Atomically record and project the singular active task for cross-session Continuity. Reuse checkpointId to retry safely; replace the checkpoint when the task changes and clear it only when no active work remains.",
      inputSchema: continuityCheckpointTaskInputSchema,
      outputSchema: continuityCheckpointTaskOutputSchema,
      annotations: {
        readOnlyHint: false,
        destructiveHint: false,
        idempotentHint: true,
        openWorldHint: false,
      },
    },
    async (args) => handleContinuityCheckpointTask(args),
  );

  server.registerTool(
    "anvil_continuity_record_event",
    {
      title: "Record Anvil Continuity Event",
      description: "Append a validated Anvil continuity event to the workspace event log.",
      inputSchema: continuityRecordEventInputSchema,
      outputSchema: continuityRecordEventOutputSchema,
      annotations: {
        readOnlyHint: false,
        destructiveHint: false,
        idempotentHint: false,
        openWorldHint: false,
      },
    },
    async (args) => handleContinuityRecordEvent(args),
  );

  server.registerTool(
    "anvil_continuity_promote_event",
    {
      title: "Promote Anvil Continuity Event",
      description:
        "Promote an existing Anvil continuity event into the compact current continuity frame. Use this during a compact-frame hygiene pass after retiring stale projections so the frame reflects the current working set.",
      inputSchema: continuityPromoteEventInputSchema,
      outputSchema: continuityPromoteEventOutputSchema,
      annotations: {
        readOnlyHint: false,
        destructiveHint: false,
        idempotentHint: false,
        openWorldHint: false,
      },
    },
    async (args) => handleContinuityPromoteEvent(args),
  );

  server.registerTool(
    "anvil_continuity_retire_projection_item",
    {
      title: "Retire Anvil Continuity Projection Item",
      description:
        "Remove a stale item from the compact current continuity frame while preserving event history. Use before promotion when phase changes, next actions change, compaction is imminent, or projection caps make old context crowd out current work.",
      inputSchema: continuityRetireProjectionItemInputSchema,
      outputSchema: continuityRetireProjectionItemOutputSchema,
      annotations: {
        readOnlyHint: false,
        destructiveHint: false,
        idempotentHint: true,
        openWorldHint: false,
      },
    },
    async (args) => handleContinuityRetireProjectionItem(args),
  );

  server.registerTool(
    "anvil_manifest_create",
    {
      title: "Create Manifest Objective",
      description: "Create one Planning Objective in the supplied Git repository.",
      inputSchema: manifestCreateInputSchema,
      outputSchema: manifestCreateOutputSchema,
      annotations: { readOnlyHint: false, destructiveHint: false, idempotentHint: false, openWorldHint: false },
    },
    handleManifestCreate,
  );

  server.registerTool(
    "anvil_manifest_orient",
    {
      title: "Orient To Manifest Objective",
      description: "Load the current Objective graph and derive Current, Next, Available Work, blockers, and progress.",
      inputSchema: manifestOrientInputSchema,
      outputSchema: manifestOrientOutputSchema,
      annotations: { readOnlyHint: true, destructiveHint: false, idempotentHint: true, openWorldHint: false },
    },
    handleManifestOrient,
  );

  server.registerTool(
    "anvil_manifest_inquire",
    {
      title: "Inquire About Manifest Work",
      description: "Find current Objective Work by exact Stable Graph Identity or bounded literal text.",
      inputSchema: manifestInquireInputSchema,
      outputSchema: manifestInquireOutputSchema,
      annotations: { readOnlyHint: true, destructiveHint: false, idempotentHint: true, openWorldHint: false },
    },
    handleManifestInquire,
  );

  server.registerTool(
    "anvil_manifest_change",
    {
      title: "Change Manifest Objective",
      description: "Apply one atomic Work Evolution to the current Objective graph in the supplied Git repository.",
      inputSchema: manifestChangeInputSchema,
      outputSchema: manifestChangeOutputSchema,
      annotations: { readOnlyHint: false, destructiveHint: false, idempotentHint: false, openWorldHint: false },
    },
    handleManifestChange,
  );

  server.registerTool(
    "anvil_tool_result_manifest",
    {
      title: "Read Tool Result Manifest",
      description: "Read the compact typed manifest for one complete session-bound tool-result artefact.",
      inputSchema: toolResultManifestInputSchema,
      outputSchema: toolResultManifestOutputSchema,
      annotations: { readOnlyHint: true, destructiveHint: false, idempotentHint: true, openWorldHint: false },
    },
    async (args) => handleToolResultManifest(args),
  );

  server.registerTool(
    "anvil_tool_result_search",
    {
      title: "Search Tool Result",
      description: "Search one complete session-bound text artefact and return attributable bounded byte matches with explicit coverage.",
      inputSchema: toolResultSearchInputSchema,
      outputSchema: toolResultSearchOutputSchema,
      annotations: { readOnlyHint: true, destructiveHint: false, idempotentHint: true, openWorldHint: false },
    },
    async (args) => handleToolResultSearch(args),
  );

  server.registerTool(
    "anvil_tool_result_read_slice",
    {
      title: "Read Tool Result Slice",
      description: "Read one exact bounded UTF-8 byte slice from a complete session-bound tool-result artefact.",
      inputSchema: toolResultReadSliceInputSchema,
      outputSchema: toolResultSliceOutputSchema,
      annotations: { readOnlyHint: true, destructiveHint: false, idempotentHint: true, openWorldHint: false },
    },
    async (args) => handleToolResultReadSlice(args),
  );

  server.registerTool(
    "anvil_tool_result_health",
    {
      title: "Read Tool Result Store Health",
      description: "Return bounded capacity and lifecycle health for the current session's transient tool-result artefacts.",
      inputSchema: toolResultHealthInputSchema,
      outputSchema: toolResultHealthOutputSchema,
      annotations: { readOnlyHint: true, destructiveHint: false, idempotentHint: true, openWorldHint: false },
    },
    async (args) => handleToolResultHealth(args),
  );

  return server;
}

export async function runAnvilMcpServer(): Promise<McpServer> {
  const server = createAnvilMcpServer();
  const transport = new StdioServerTransport();

  process.on("SIGINT", async () => {
    await server.close();
    process.exit(0);
  });

  await server.connect(transport);
  return server;
}
