import type { CallToolResult } from "@modelcontextprotocol/server";
import * as z from "zod/v4";

import { BrainSetupError, brainSetupOutputSchema as brainSetupDomainOutputSchema, setupBrain } from "../brain/index.ts";
import {
  BRAIN_USAGE_COVERAGE_EVENTS,
  BRAIN_USAGE_INCIDENT_EVENTS,
  BRAIN_USAGE_SEVERITIES,
  MAX_BRAIN_NAME_CHARS,
  MAX_BRAIN_USAGE_LIMIT,
  MAX_LIST_ITEMS,
  MAX_OUTCOME_CHARS,
  MAX_PAGE_CHARS,
  MAX_RELATED_CHARS,
  MAX_TRACE_ID_CHARS,
  MAX_TRIGGER_BUCKET_CHARS,
  MAX_TRIGGER_CHARS,
  brainUsageMetricsOutputSchema as brainUsageMetricsDomainOutputSchema,
  readBrainUsageOutputSchema as brainUsageReadDomainOutputSchema,
  recordBoundBrainUsageOutputSchema,
  readBrainUsage,
  recordBoundBrainUsage,
  summarizeBrainUsage,
} from "../brain-usage/index.ts";
import { BrainUsageIdentityError } from "../brain-usage/identity.ts";
import type { BrainUsageInput, BrainUsageWorkspaceOptions, RecordBoundBrainUsageOutput } from "../brain-usage/index.ts";
import { bootstrapSession, sessionBootstrapOutputSchema as sessionBootstrapDomainOutputSchema } from "../bootstrap/index.ts";
import { AnvilConfigError } from "../config/index.ts";
import {
  ContinuityServiceError,
  MAX_ACTIVE_TASK_DETAILS_CHARS,
  MAX_ACTIVE_TASK_TEXT_CHARS,
  MAX_EVENT_DETAILS_CHARS,
  MAX_EVENT_SUMMARY_CHARS,
  checkpointActiveTaskOutputSchema as checkpointActiveTaskDomainOutputSchema,
  promoteContinuityEventOutputSchema as promoteContinuityEventDomainOutputSchema,
  readContinuityOutputSchema as readContinuityDomainOutputSchema,
  recordContinuityEventOutputSchema as recordContinuityEventDomainOutputSchema,
  retireContinuityProjectionItemOutputSchema as retireContinuityProjectionItemDomainOutputSchema,
  checkpointActiveTask,
  promoteContinuityEvent,
  readContinuity,
  recordContinuityEvent,
  retireContinuityProjectionItem,
} from "../continuity/index.ts";
import type {
  CheckpointActiveTaskOutput,
  EventInput,
  EventSource,
  PromoteContinuityEventOutput,
  PromoteContinuityMode,
  PromoteContinuityTarget,
  ReadContinuityOutput,
  RecordContinuityEventOutput,
  RetireContinuityProjectionItemOutput,
} from "../continuity/index.ts";
import {
  MAX_REASON_CHARS as MAX_SKILL_INVOCATION_REASON_CHARS,
  MAX_SKILL_INVOCATION_AUDIT_SAMPLE_SIZE,
  MAX_SKILL_INVOCATION_LIMIT,
  MAX_SKILL_NAME_CHARS,
  MAX_SKILL_INVOCATION_TRACE_ID_CHARS,
  MAX_TRIGGER_CHARS as MAX_SKILL_INVOCATION_TRIGGER_CHARS,
  readSkillInvocationsOutputSchema as skillInvocationReadDomainOutputSchema,
  recordBoundSkillInvocationOutputSchema,
  sampleSkillInvocationsOutputSchema as skillInvocationAuditSampleDomainOutputSchema,
  readSkillInvocations,
  recordBoundSkillInvocation,
  sampleSkillInvocations,
} from "../skill-invocations/index.ts";
import type { BoundSkillInvocationInput, RecordBoundSkillInvocationOutput } from "../skill-invocations/index.ts";
import {
  ToolResultError,
  readToolResultHealth,
  readToolResultManifest,
  readToolResultSlice,
  searchToolResult,
  toolResultHealthOutputSchema,
  toolResultManifestOutputSchema,
  toolResultSearchOutputSchema,
  toolResultSliceOutputSchema,
} from "../tool-results/index.ts";
import {
  requireWorkContextBinding,
  recordWorkContextRejection,
  workContextBindingViewSchema,
  workContextBindingView,
  WorkContextError,
} from "../work-context/index.ts";

const eventTypeSchema = z.enum(["decision", "hypothesis", "open_question", "next_action", "correction", "phase_change"]);
const eventStatusSchema = z.enum(["active", "superseded", "resolved", "deferred"]);
const promoteTargetSchema = z.enum(["active_decisions", "open_questions", "next_actions", "continuity_notes"]);
const promoteModeSchema = z.enum(["append", "replace_matching_event"]);
const activeTaskStateSchema = z.enum(["active", "waiting"]);
const bootstrapModeSchema = z.enum(["redacted", "local_full"]);
const brainSetupModeSchema = z.enum(["dry_run", "apply"]);
const brainUsageScopeSchema = z.enum(["workspace", "all"]);
const brainUsageManualEventSchema = z.enum([
  ...BRAIN_USAGE_COVERAGE_EVENTS,
  ...BRAIN_USAGE_INCIDENT_EVENTS,
]);
const brainUsageSeveritySchema = z.enum(BRAIN_USAGE_SEVERITIES);
const skillInvocationOutcomeSchema = z.enum(["used", "missed", "false_positive"]);

export const brainSetupInputSchema = {
  agentId: z.string().min(1).optional(),
  anvilHome: z.string().min(1).optional(),
  brainRoot: z.string().min(1).optional(),
  wikiAlias: z.string().min(1).optional(),
  mode: brainSetupModeSchema.optional(),
  planHash: z.string().min(1).optional(),
  acknowledgement: z.string().min(1).optional(),
};

export const brainUsageMetricsInputSchema = {
  cwd: z.string().min(1).optional(),
  stateRoot: z.string().min(1).optional(),
  scope: brainUsageScopeSchema.optional(),
};

export const brainUsageReadInputSchema = {
  ...brainUsageMetricsInputSchema,
  limit: z.number().int().min(0).max(MAX_BRAIN_USAGE_LIMIT).optional(),
};

export const brainUsageLogInputSchema = z.object({
  bindingId: z.string().regex(/^wctx_[a-f0-9]{32}$/),
  event: brainUsageManualEventSchema,
  trigger: z.string().trim().min(1).max(MAX_TRIGGER_CHARS),
  brain: z.string().trim().min(1).max(MAX_BRAIN_NAME_CHARS).optional().describe(
    "Deprecated compatibility hint only. Anvil resolves and records the configured Brain identity; this value cannot define identity.",
  ),
  pages: z.array(z.string().trim().min(1).max(MAX_PAGE_CHARS)).max(MAX_LIST_ITEMS).optional(),
  related: z.array(z.string().trim().min(1).max(MAX_RELATED_CHARS)).max(MAX_LIST_ITEMS).optional(),
  outcome: z.string().trim().min(1).max(MAX_OUTCOME_CHARS).optional(),
  severity: brainUsageSeveritySchema.optional(),
  triggerBucket: z.string().trim().min(1).max(MAX_TRIGGER_BUCKET_CHARS).optional(),
  turnId: z.string().trim().min(1).max(MAX_TRACE_ID_CHARS).optional(),
  messageId: z.string().trim().min(1).max(MAX_TRACE_ID_CHARS).optional(),
  mcpCallId: z.string().trim().min(1).max(MAX_TRACE_ID_CHARS).optional(),
}).passthrough();

export const skillInvocationReadInputSchema = {
  cwd: z.string().min(1).optional(),
  stateRoot: z.string().min(1).optional(),
  limit: z.number().int().min(0).max(MAX_SKILL_INVOCATION_LIMIT).optional(),
  offset: z.number().int().min(0).optional(),
  skill: z.string().trim().min(1).max(MAX_SKILL_NAME_CHARS).optional(),
  outcome: skillInvocationOutcomeSchema.optional(),
  sessionId: z.string().trim().min(1).max(MAX_SKILL_INVOCATION_TRACE_ID_CHARS).optional(),
};

export const skillInvocationAuditSampleInputSchema = {
  cwd: z.string().min(1).optional(),
  stateRoot: z.string().min(1).optional(),
  seed: z.string().trim().min(1).max(MAX_SKILL_INVOCATION_TRACE_ID_CHARS),
  size: z.number().int().min(0).max(MAX_SKILL_INVOCATION_AUDIT_SAMPLE_SIZE).optional(),
  skill: z.string().trim().min(1).max(MAX_SKILL_NAME_CHARS).optional(),
  outcome: skillInvocationOutcomeSchema.optional(),
  sessionId: z.string().trim().min(1).max(MAX_SKILL_INVOCATION_TRACE_ID_CHARS).optional(),
};

export const skillInvocationLogInputSchema = z.object({
  bindingId: z.string().regex(/^wctx_[a-f0-9]{32}$/),
  skill: z.string().trim().min(1).max(MAX_SKILL_NAME_CHARS),
  trigger: z.string().trim().min(1).max(MAX_SKILL_INVOCATION_TRIGGER_CHARS),
  outcome: skillInvocationOutcomeSchema,
  reason: z.string().trim().min(1).max(MAX_SKILL_INVOCATION_REASON_CHARS),
  turnId: z.string().trim().min(1).max(MAX_SKILL_INVOCATION_TRACE_ID_CHARS).optional(),
  messageId: z.string().trim().min(1).max(MAX_SKILL_INVOCATION_TRACE_ID_CHARS).optional(),
}).passthrough();

export const sessionBootstrapInputSchema = {
  cwd: z.string().min(1).optional(),
  stateRoot: z.string().min(1).optional(),
  anvilHome: z.string().min(1).optional(),
  agentId: z.string().min(1).optional(),
  mode: bootstrapModeSchema.optional(),
  bindingId: z.string().regex(/^wctx_[a-f0-9]{32}$/).optional(),
};

export const workContextReadInputSchema = {
  bindingId: z.string().regex(/^wctx_[a-f0-9]{32}$/),
};

export const continuityReadInputSchema = {
  cwd: z.string().min(1).optional(),
  stateRoot: z.string().min(1).optional(),
  includeEvents: z.boolean().optional(),
  eventLimit: z.number().int().min(0).optional(),
};

export const continuityRecordEventInputSchema = z.object({
  bindingId: z.string().regex(/^wctx_[a-f0-9]{32}$/),
  event: z.object({
    type: eventTypeSchema,
    status: eventStatusSchema.optional(),
    summary: z.string().min(1).max(MAX_EVENT_SUMMARY_CHARS),
    details: z.string().max(MAX_EVENT_DETAILS_CHARS).optional(),
    supersedes: z.array(z.string().min(1)).optional(),
    resolves: z.array(z.string().min(1)).optional(),
    relatedEvents: z.array(z.string().min(1)).optional(),
  }),
  source: z
    .object({
      turnId: z.string().min(1).optional(),
      description: z.string().min(1).optional(),
    })
    .optional(),
}).passthrough();

export const continuityCheckpointTaskInputSchema = z.object({
  bindingId: z.string().regex(/^wctx_[a-f0-9]{32}$/),
  checkpointId: z.string().trim().min(1).max(200),
  task: z.discriminatedUnion("state", [
    z.object({
      state: activeTaskStateSchema,
      summary: z.string().trim().min(1).max(MAX_ACTIVE_TASK_TEXT_CHARS),
      nextStep: z.string().trim().min(1).max(MAX_ACTIVE_TASK_TEXT_CHARS),
      details: z.string().max(MAX_ACTIVE_TASK_DETAILS_CHARS).optional(),
    }).strict(),
    z.object({
      state: z.literal("clear"),
      outcome: z.string().trim().min(1).max(MAX_ACTIVE_TASK_TEXT_CHARS),
      details: z.string().max(MAX_ACTIVE_TASK_DETAILS_CHARS).optional(),
    }).strict(),
  ]),
  source: z.object({
    turnId: z.string().min(1).optional(),
    description: z.string().min(1).optional(),
  }).optional(),
}).passthrough();

export const continuityPromoteEventInputSchema = z.object({
  bindingId: z.string().regex(/^wctx_[a-f0-9]{32}$/),
  eventId: z.string().min(1),
  target: promoteTargetSchema,
  mode: promoteModeSchema.optional(),
}).passthrough();

export const continuityRetireProjectionItemInputSchema = z.object({
  bindingId: z.string().regex(/^wctx_[a-f0-9]{32}$/),
  target: promoteTargetSchema,
  eventId: z.string().min(1).optional(),
  summary: z.string().min(1).optional(),
  correctionEventId: z.string().min(1).optional(),
}).passthrough();

const toolResultBindingIdSchema = z.string().regex(/^wctx_[a-f0-9]{32}$/);
const toolResultIdSchema = z.string().regex(/^tr_[a-f0-9]{32}$/);

export const toolResultManifestInputSchema = z.object({
  bindingId: toolResultBindingIdSchema,
  resultId: toolResultIdSchema,
}).strict();

export const toolResultSearchInputSchema = z.object({
  bindingId: toolResultBindingIdSchema,
  resultId: toolResultIdSchema,
  query: z.string().min(1).max(256),
}).strict();

export const toolResultReadSliceInputSchema = z.object({
  bindingId: toolResultBindingIdSchema,
  resultId: toolResultIdSchema,
  byteStart: z.number().int().min(0),
  byteLength: z.number().int().min(1).max(8 * 1024),
}).strict();

export const toolResultHealthInputSchema = z.object({
  bindingId: toolResultBindingIdSchema,
}).strict();

export {
  toolResultHealthOutputSchema,
  toolResultManifestOutputSchema,
  toolResultSearchOutputSchema,
  toolResultSliceOutputSchema,
};

export const brainSetupOutputSchema = brainSetupDomainOutputSchema;
export const sessionBootstrapOutputSchema = sessionBootstrapDomainOutputSchema;
export const workContextReadOutputSchema = z.object({ binding: workContextBindingViewSchema }).strict();
export const brainUsageLogOutputSchema = recordBoundBrainUsageOutputSchema
  .pick({ record: true, binding: true })
  .strict();
export const brainUsageMetricsOutputSchema = brainUsageMetricsDomainOutputSchema;
export const brainUsageReadOutputSchema = brainUsageReadDomainOutputSchema;
export const skillInvocationLogOutputSchema = recordBoundSkillInvocationOutputSchema
  .pick({ record: true, binding: true })
  .strict();
export const skillInvocationReadOutputSchema = skillInvocationReadDomainOutputSchema;
export const skillInvocationAuditSampleOutputSchema = skillInvocationAuditSampleDomainOutputSchema;
export const continuityReadOutputSchema = readContinuityDomainOutputSchema.omit({ paths: true }).strict();
export const continuityRecordEventOutputSchema = recordContinuityEventDomainOutputSchema.omit({ paths: true }).strict();
export const continuityCheckpointTaskOutputSchema = checkpointActiveTaskDomainOutputSchema.omit({ paths: true }).strict();
export const continuityPromoteEventOutputSchema = promoteContinuityEventDomainOutputSchema.omit({ paths: true }).strict();
export const continuityRetireProjectionItemOutputSchema = retireContinuityProjectionItemDomainOutputSchema
  .omit({ paths: true })
  .strict();

const readInputObject = z.object(continuityReadInputSchema);
const brainSetupInputObject = z.object(brainSetupInputSchema);
const brainUsageMetricsInputObject = z.object(brainUsageMetricsInputSchema);
const brainUsageReadInputObject = z.object(brainUsageReadInputSchema);
const brainUsageLogInputObject = brainUsageLogInputSchema;
const skillInvocationReadInputObject = z.object(skillInvocationReadInputSchema);
const skillInvocationAuditSampleInputObject = z.object(skillInvocationAuditSampleInputSchema);
const skillInvocationLogInputObject = skillInvocationLogInputSchema;
const sessionBootstrapInputObject = z.object(sessionBootstrapInputSchema);
const workContextReadInputObject = z.object(workContextReadInputSchema);
const recordEventInputObject = continuityRecordEventInputSchema;
const checkpointTaskInputObject = continuityCheckpointTaskInputSchema;
const promoteEventInputObject = continuityPromoteEventInputSchema;
const retireProjectionItemInputObject = continuityRetireProjectionItemInputSchema;
const toolResultManifestInputObject = toolResultManifestInputSchema;
const toolResultSearchInputObject = toolResultSearchInputSchema;
const toolResultReadSliceInputObject = toolResultReadSliceInputSchema;
const toolResultHealthInputObject = toolResultHealthInputSchema;

type BrainSetupArgs = z.infer<typeof brainSetupInputObject>;
type BrainUsageMetricsArgs = z.infer<typeof brainUsageMetricsInputObject>;
type BrainUsageReadArgs = z.infer<typeof brainUsageReadInputObject>;
type BrainUsageLogArgs = z.infer<typeof brainUsageLogInputObject>;
type BrainUsageRuntimeOptions = Pick<BrainUsageWorkspaceOptions, "anvilHome" | "env" | "homeDir">;
type SkillInvocationReadArgs = z.infer<typeof skillInvocationReadInputObject>;
type SkillInvocationAuditSampleArgs = z.infer<typeof skillInvocationAuditSampleInputObject>;
type SkillInvocationLogArgs = z.infer<typeof skillInvocationLogInputObject>;
type SessionBootstrapArgs = z.infer<typeof sessionBootstrapInputObject>;
type WorkContextReadArgs = z.infer<typeof workContextReadInputObject>;
type ContinuityReadArgs = z.infer<typeof readInputObject>;
type ContinuityRecordEventArgs = z.infer<typeof recordEventInputObject>;
type ContinuityCheckpointTaskArgs = z.infer<typeof checkpointTaskInputObject>;
type ContinuityPromoteEventArgs = z.infer<typeof promoteEventInputObject>;
type ContinuityRetireProjectionItemArgs = z.infer<typeof retireProjectionItemInputObject>;
type ToolResultManifestArgs = z.infer<typeof toolResultManifestInputObject>;
type ToolResultSearchArgs = z.infer<typeof toolResultSearchInputObject>;
type ToolResultReadSliceArgs = z.infer<typeof toolResultReadSliceInputObject>;
type ToolResultHealthArgs = z.infer<typeof toolResultHealthInputObject>;

type ToolErrorOutput = {
  error: {
    code: string;
    message: string;
  };
};

function jsonResult<Schema extends z.ZodType<Record<string, unknown>>>(
  schema: Schema,
  output: z.input<Schema>,
): CallToolResult {
  const parsed = schema.parse(output);
  return {
    content: [{ type: "text", text: JSON.stringify(parsed, null, 2) }],
    structuredContent: parsed,
  };
}

function boundedStructuredResult<Schema extends z.ZodType<Record<string, unknown>>>(
  schema: Schema,
  output: z.input<Schema>,
  summary: string,
): CallToolResult {
  const parsed = schema.parse(output);
  return {
    content: [{ type: "text", text: summary.slice(0, 512) }],
    structuredContent: parsed,
  };
}

function errorResult(error: unknown): CallToolResult {
  const isValidationError =
    error instanceof Error &&
    ["Invalid current frame input:", "Invalid event input:", "Invalid event source:"].some((prefix) =>
      error.message.startsWith(prefix),
    );
  const code =
    error instanceof ToolResultError
      ? error.code
      : error instanceof ContinuityServiceError
      ? error.code
      : error instanceof WorkContextError
        ? error.code
      : error instanceof BrainSetupError
        ? error.code
      : error instanceof BrainUsageIdentityError
        ? error.code
      : error instanceof AnvilConfigError
        ? error.code
        : isValidationError
          ? "VALIDATION_ERROR"
          : "INTERNAL_ERROR";
  const message = error instanceof Error ? error.message : String(error);
  const output: ToolErrorOutput = { error: { code, message } };
  return {
    content: [{ type: "text", text: `${code}: ${message}` }],
    structuredContent: output,
    isError: true,
  };
}

function eventInputFromArgs(args: ContinuityRecordEventArgs): EventInput {
  return {
    type: args.event.type,
    status: args.event.status ?? "active",
    summary: args.event.summary,
    ...(args.event.details !== undefined ? { details: args.event.details } : {}),
    supersedes: args.event.supersedes ?? [],
    resolves: args.event.resolves ?? [],
    related_events: args.event.relatedEvents ?? [],
  };
}

function eventSourceFromArgs(args: ContinuityRecordEventArgs): EventSource {
  return {
    kind: "codex_mcp",
    ...(args.source?.turnId !== undefined ? { turn_id: args.source.turnId } : {}),
    ...(args.source?.description !== undefined ? { description: args.source.description } : {}),
  };
}

function brainUsageInputFromArgs(args: BrainUsageLogArgs): BrainUsageInput {
  return {
    event: args.event,
    trigger: args.trigger,
    ...(args.brain !== undefined ? { brain: args.brain } : {}),
    ...(args.pages !== undefined ? { pages: args.pages } : {}),
    ...(args.related !== undefined ? { related: args.related } : {}),
    ...(args.outcome !== undefined ? { outcome: args.outcome } : {}),
    ...(args.severity !== undefined ? { severity: args.severity } : {}),
    ...(args.triggerBucket !== undefined ? { trigger_bucket: args.triggerBucket } : {}),
    ...(args.turnId !== undefined ? { turn_id: args.turnId } : {}),
    ...(args.messageId !== undefined ? { message_id: args.messageId } : {}),
    ...(args.mcpCallId !== undefined ? { mcp_call_id: args.mcpCallId } : {}),
  };
}

function skillInvocationInputFromArgs(args: SkillInvocationLogArgs): BoundSkillInvocationInput {
  return {
    skill: args.skill,
    trigger: args.trigger,
    outcome: args.outcome,
    reason: args.reason,
    ...(args.turnId !== undefined ? { turn_id: args.turnId } : {}),
    ...(args.messageId !== undefined ? { message_id: args.messageId } : {}),
  };
}

function brainUsageLogOutput(result: RecordBoundBrainUsageOutput): z.input<typeof brainUsageLogOutputSchema> {
  return { record: result.record, binding: result.binding };
}

function skillInvocationLogOutput(
  result: RecordBoundSkillInvocationOutput,
): z.input<typeof skillInvocationLogOutputSchema> {
  return { record: result.record, binding: result.binding };
}

function readOutput(result: ReadContinuityOutput): z.input<typeof continuityReadOutputSchema> {
  return {
    workspace: result.workspace,
    current: result.current,
    ...(result.events ? { events: result.events } : {}),
  };
}

function recordOutput(result: RecordContinuityEventOutput): z.input<typeof continuityRecordEventOutputSchema> {
  return {
    workspace: result.workspace,
    binding: result.binding,
    event: result.event,
    currentFrameInitialized: result.currentFrameInitialized,
  };
}

function checkpointTaskOutput(
  result: CheckpointActiveTaskOutput,
): z.input<typeof continuityCheckpointTaskOutputSchema> {
  return {
    workspace: result.workspace,
    binding: result.binding,
    event: result.event,
    frame: result.frame,
    rendered: result.rendered,
    changed: result.changed,
  };
}

function promoteOutput(result: PromoteContinuityEventOutput): z.input<typeof continuityPromoteEventOutputSchema> {
  return {
    workspace: result.workspace,
    binding: result.binding,
    event: result.event,
    frame: result.frame,
    changed: result.changed,
  };
}

function retireProjectionItemOutput(
  result: RetireContinuityProjectionItemOutput,
): z.input<typeof continuityRetireProjectionItemOutputSchema> {
  return {
    workspace: result.workspace,
    binding: result.binding,
    frame: result.frame,
    changed: result.changed,
    ...(result.removedItem ? { removedItem: result.removedItem } : {}),
    ...(result.correctionEvent ? { correctionEvent: result.correctionEvent } : {}),
  };
}

export async function handleBrainSetup(args: BrainSetupArgs): Promise<CallToolResult> {
  try {
    return jsonResult(brainSetupOutputSchema, await setupBrain(args));
  } catch (error) {
    return errorResult(error);
  }
}

export async function handleBrainUsageMetrics(
  args: BrainUsageMetricsArgs,
  runtime: BrainUsageRuntimeOptions = {},
): Promise<CallToolResult> {
  try {
    return jsonResult(
      brainUsageMetricsOutputSchema,
      await summarizeBrainUsage({ ...args, ...runtime, scope: args.scope ?? "all" }),
    );
  } catch (error) {
    return errorResult(error);
  }
}

export async function handleBrainUsageRead(args: BrainUsageReadArgs): Promise<CallToolResult> {
  try {
    return jsonResult(brainUsageReadOutputSchema, await readBrainUsage({ ...args, scope: args.scope ?? "all" }));
  } catch (error) {
    return errorResult(error);
  }
}

export async function handleBrainUsageLog(
  args: BrainUsageLogArgs,
  dependencies: BoundHandlerDependencies = {},
): Promise<CallToolResult> {
  try {
    const binding = await requireMutationBinding(args, dependencies, "anvil_brain_usage_log");
    const result = await recordBoundBrainUsage({
      binding,
      stateRoot: dependencies.stateRoot,
      bindingNow: dependencies.now,
      anvilHome: dependencies.anvilHome,
      env: dependencies.env,
      homeDir: dependencies.homeDir,
      usage: brainUsageInputFromArgs(args),
    });
    return jsonResult(brainUsageLogOutputSchema, brainUsageLogOutput(result));
  } catch (error) {
    return errorResult(error);
  }
}

export async function handleSkillInvocationRead(args: SkillInvocationReadArgs): Promise<CallToolResult> {
  try {
    return jsonResult(
      skillInvocationReadOutputSchema,
      await readSkillInvocations({
        cwd: args.cwd,
        stateRoot: args.stateRoot,
        limit: args.limit,
        offset: args.offset,
        skill: args.skill,
        outcome: args.outcome,
        ...(args.sessionId !== undefined ? { session_id: args.sessionId } : {}),
      }),
    );
  } catch (error) {
    return errorResult(error);
  }
}

export async function handleSkillInvocationAuditSample(
  args: SkillInvocationAuditSampleArgs,
): Promise<CallToolResult> {
  try {
    return jsonResult(
      skillInvocationAuditSampleOutputSchema,
      await sampleSkillInvocations({
        cwd: args.cwd,
        stateRoot: args.stateRoot,
        seed: args.seed,
        size: args.size,
        skill: args.skill,
        outcome: args.outcome,
        ...(args.sessionId !== undefined ? { session_id: args.sessionId } : {}),
      }),
    );
  } catch (error) {
    return errorResult(error);
  }
}

export async function handleSkillInvocationLog(
  args: SkillInvocationLogArgs,
  dependencies: BoundHandlerDependencies = {},
): Promise<CallToolResult> {
  try {
    const binding = await requireMutationBinding(args, dependencies, "anvil_skill_invocation_log");
    const result = await recordBoundSkillInvocation({
      binding,
      stateRoot: dependencies.stateRoot,
      bindingNow: dependencies.now,
      invocation: skillInvocationInputFromArgs(args),
    });
    return jsonResult(skillInvocationLogOutputSchema, skillInvocationLogOutput(result));
  } catch (error) {
    return errorResult(error);
  }
}

export async function handleSessionBootstrap(args: SessionBootstrapArgs): Promise<CallToolResult> {
  try {
    return jsonResult(sessionBootstrapOutputSchema, await bootstrapSession(args));
  } catch (error) {
    return errorResult(error);
  }
}

export async function handleWorkContextRead(
  args: WorkContextReadArgs,
  dependencies: { stateRoot?: string; now?: () => string } = {},
): Promise<CallToolResult> {
  try {
    const binding = await requireWorkContextBinding({
      bindingId: args.bindingId,
      stateRoot: dependencies.stateRoot,
      now: dependencies.now,
    });
    return jsonResult(workContextReadOutputSchema, { binding: workContextBindingView(binding) });
  } catch (error) {
    return errorResult(error);
  }
}

export async function handleContinuityRead(args: ContinuityReadArgs): Promise<CallToolResult> {
  try {
    return jsonResult(continuityReadOutputSchema, readOutput(await readContinuity(args)));
  } catch (error) {
    return errorResult(error);
  }
}

type ToolResultHandlerDependencies = { stateRoot?: string; now?: () => string };

async function toolResultBinding(bindingId: string, dependencies: ToolResultHandlerDependencies) {
  return requireWorkContextBinding({
    bindingId,
    ...(dependencies.stateRoot !== undefined ? { stateRoot: dependencies.stateRoot } : {}),
    ...(dependencies.now !== undefined ? { now: dependencies.now } : {}),
  });
}

export async function handleToolResultManifest(
  args: ToolResultManifestArgs,
  dependencies: ToolResultHandlerDependencies = {},
): Promise<CallToolResult> {
  try {
    const binding = await toolResultBinding(args.bindingId, dependencies);
    const output = await readToolResultManifest({
      binding,
      resultId: args.resultId,
      ...dependencies,
    });
    return boundedStructuredResult(toolResultManifestOutputSchema, output, "OK: tool-result manifest available in structuredContent.");
  } catch (error) {
    return errorResult(error);
  }
}

export async function handleToolResultSearch(
  args: ToolResultSearchArgs,
  dependencies: ToolResultHandlerDependencies = {},
): Promise<CallToolResult> {
  try {
    const binding = await toolResultBinding(args.bindingId, dependencies);
    const output = await searchToolResult({
      binding,
      resultId: args.resultId,
      query: args.query,
      ...dependencies,
    });
    return boundedStructuredResult(
      toolResultSearchOutputSchema,
      output,
      `OK: ${output.matches.length} bounded tool-result match${output.matches.length === 1 ? "" : "es"} available in structuredContent.`,
    );
  } catch (error) {
    return errorResult(error);
  }
}

export async function handleToolResultReadSlice(
  args: ToolResultReadSliceArgs,
  dependencies: ToolResultHandlerDependencies = {},
): Promise<CallToolResult> {
  try {
    const binding = await toolResultBinding(args.bindingId, dependencies);
    const output = await readToolResultSlice({
      binding,
      resultId: args.resultId,
      byteStart: args.byteStart,
      byteLength: args.byteLength,
      ...dependencies,
    });
    return boundedStructuredResult(toolResultSliceOutputSchema, output, "OK: exact tool-result slice available in structuredContent.");
  } catch (error) {
    return errorResult(error);
  }
}

export async function handleToolResultHealth(
  args: ToolResultHealthArgs,
  dependencies: ToolResultHandlerDependencies = {},
): Promise<CallToolResult> {
  try {
    const binding = await toolResultBinding(args.bindingId, dependencies);
    const output = await readToolResultHealth({ binding, ...dependencies });
    return boundedStructuredResult(toolResultHealthOutputSchema, output, "OK: tool-result store health available in structuredContent.");
  } catch (error) {
    return errorResult(error);
  }
}

type BoundHandlerDependencies = BrainUsageRuntimeOptions & { stateRoot?: string; cwd?: string; now?: () => string };

async function recordMutationRejection(
  error: WorkContextError,
  args: Record<string, unknown>,
  dependencies: BoundHandlerDependencies,
  operation: string,
): Promise<void> {
  try {
    await recordWorkContextRejection({
      code: error.code,
      operation,
      stateRoot: dependencies.stateRoot,
      host: "anvil_mcp",
      ...(typeof args.bindingId === "string" ? { bindingId: args.bindingId } : {}),
    });
  } catch {
    // Rejection telemetry must never turn a fail-closed mutation into a process failure.
  }
}

async function requireMutationBinding(
  args: Record<string, unknown> & { bindingId: string },
  dependencies: BoundHandlerDependencies,
  operation: string,
) {
  const field = ["cwd", "stateRoot", "state_root"].find((key) => Object.hasOwn(args, key));
  if (field) {
    const error = new WorkContextError(
      "WORK_CONTEXT_MISMATCH",
      `Anvil mutation routing field ${field} is forbidden; use the active Work Context binding`,
    );
    await recordMutationRejection(error, args, dependencies, operation);
    throw error;
  }
  try {
    return await requireWorkContextBinding({
      bindingId: args.bindingId,
      stateRoot: dependencies.stateRoot,
      now: dependencies.now,
    });
  } catch (error) {
    if (error instanceof WorkContextError) await recordMutationRejection(error, args, dependencies, operation);
    throw error;
  }
}

export async function handleContinuityRecordEvent(
  args: ContinuityRecordEventArgs,
  dependencies: BoundHandlerDependencies = {},
): Promise<CallToolResult> {
  try {
    const binding = await requireMutationBinding(args, dependencies, "anvil_continuity_record_event");
    return jsonResult(
      continuityRecordEventOutputSchema,
      recordOutput(
        await recordContinuityEvent({
          binding,
          stateRoot: dependencies.stateRoot,
          bindingNow: dependencies.now,
          event: eventInputFromArgs(args),
          source: eventSourceFromArgs(args),
        }),
      ),
    );
  } catch (error) {
    return errorResult(error);
  }
}

export async function handleContinuityCheckpointTask(
  args: ContinuityCheckpointTaskArgs,
  dependencies: BoundHandlerDependencies = {},
): Promise<CallToolResult> {
  try {
    const binding = await requireMutationBinding(args, dependencies, "anvil_continuity_checkpoint_task");
    return jsonResult(
      continuityCheckpointTaskOutputSchema,
      checkpointTaskOutput(
        await checkpointActiveTask({
          binding,
          stateRoot: dependencies.stateRoot,
          bindingNow: dependencies.now,
          checkpointId: args.checkpointId,
          task: args.task,
          source: {
            kind: "codex_mcp",
            ...(args.source?.turnId !== undefined ? { turn_id: args.source.turnId } : {}),
            ...(args.source?.description !== undefined ? { description: args.source.description } : {}),
          },
        }),
      ),
    );
  } catch (error) {
    return errorResult(error);
  }
}

export async function handleContinuityPromoteEvent(
  args: ContinuityPromoteEventArgs,
  dependencies: BoundHandlerDependencies = {},
): Promise<CallToolResult> {
  try {
    const binding = await requireMutationBinding(args, dependencies, "anvil_continuity_promote_event");
    return jsonResult(
      continuityPromoteEventOutputSchema,
      promoteOutput(
        await promoteContinuityEvent({
          binding,
          stateRoot: dependencies.stateRoot,
          bindingNow: dependencies.now,
          eventId: args.eventId,
          target: args.target as PromoteContinuityTarget,
          mode: args.mode as PromoteContinuityMode | undefined,
        }),
      ),
    );
  } catch (error) {
    return errorResult(error);
  }
}

export async function handleContinuityRetireProjectionItem(
  args: ContinuityRetireProjectionItemArgs,
  dependencies: BoundHandlerDependencies = {},
): Promise<CallToolResult> {
  try {
    const binding = await requireMutationBinding(args, dependencies, "anvil_continuity_retire_projection_item");
    return jsonResult(
      continuityRetireProjectionItemOutputSchema,
      retireProjectionItemOutput(
        await retireContinuityProjectionItem({
          binding,
          stateRoot: dependencies.stateRoot,
          bindingNow: dependencies.now,
          target: args.target as PromoteContinuityTarget,
          ...(args.eventId !== undefined ? { eventId: args.eventId } : {}),
          ...(args.summary !== undefined ? { summary: args.summary } : {}),
          ...(args.correctionEventId !== undefined ? { correctionEventId: args.correctionEventId } : {}),
        }),
      ),
    );
  } catch (error) {
    return errorResult(error);
  }
}
