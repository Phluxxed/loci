import type { CallToolResult } from "@modelcontextprotocol/server";
import * as z from "zod/v4";

import {
  changeObjective,
  createObjective,
  inquireCurrentObjective,
  orientObjective,
} from "../manifest/service.ts";
import type { SemanticGraphChange } from "../manifest/service.ts";
import { ManifestFileError } from "../manifest/files.ts";
import {
  implementationPlanSchema,
  objectiveIdSchema,
  taskIdSchema,
  workstreamIdSchema,
} from "../manifest/model.ts";

const graphIdSchema = z.union([objectiveIdSchema, workstreamIdSchema, taskIdSchema]);
const requiredTextSchema = z.string().trim().min(1);
const detailsSchema = z.string().trim();
const localRefSchema = z.string().trim().min(1);
const newRefSchema = z.string().regex(/^@.+/);
const workstreamRefSchema = z.union([workstreamIdSchema, newRefSchema]);
const taskRefSchema = z.union([taskIdSchema, newRefSchema]);

const completionEvidenceSchema = z.object({
  criterion: requiredTextSchema,
  summary: requiredTextSchema,
  references: z.array(requiredTextSchema).min(1),
}).strict();

const completionSchema = z.object({ evidence: z.array(completionEvidenceSchema).min(1) }).strict();
const discontinuedSchema = z.object({ reason: requiredTextSchema }).strict();

const updateSetSchema = z.object({
  title: requiredTextSchema.optional(),
  outcome: requiredTextSchema.optional(),
  details: detailsSchema.optional(),
  phase: z.literal("implementation").optional(),
  implementation: implementationPlanSchema.optional(),
  decompositionComplete: z.boolean().optional(),
  completionCriteria: z.array(requiredTextSchema).optional(),
  externalBlocker: requiredTextSchema.nullable().optional(),
  completion: completionSchema.nullable().optional(),
  discontinued: discontinuedSchema.nullable().optional(),
}).strict();

export const semanticGraphChangeSchema = z.object({
  addWorkstreams: z.array(z.object({
    ref: localRefSchema,
    title: requiredTextSchema,
    outcome: requiredTextSchema,
    details: detailsSchema.optional(),
    after: workstreamRefSchema.nullable(),
  }).strict()).optional(),
  addTasks: z.array(z.object({
    ref: localRefSchema,
    workstream: z.union([workstreamRefSchema, taskRefSchema]),
    title: requiredTextSchema,
    outcome: requiredTextSchema,
    details: detailsSchema.optional(),
    decompositionComplete: z.boolean().optional(),
    completionCriteria: z.array(requiredTextSchema),
    after: taskRefSchema.nullable(),
    dependencies: z.array(taskRefSchema).optional(),
  }).strict()).optional(),
  update: z.array(z.object({
    id: graphIdSchema,
    set: updateSetSchema,
  }).strict()).optional(),
  place: z.array(z.object({
    id: z.union([workstreamIdSchema, taskIdSchema, newRefSchema]),
    parent: z.union([workstreamRefSchema, taskRefSchema]).optional(),
    after: z.union([workstreamRefSchema, taskRefSchema]).nullable(),
  }).strict()).optional(),
  setDependencies: z.array(z.object({
    task: taskRefSchema,
    prerequisites: z.array(taskRefSchema),
  }).strict()).optional(),
  removeEmptyWorkstreams: z.array(workstreamIdSchema).optional(),
}).strict();

export const manifestCreateInputSchema = z.object({
  repository: requiredTextSchema,
  title: requiredTextSchema,
  outcome: requiredTextSchema,
  details: detailsSchema.optional(),
}).strict();

export const manifestOrientInputSchema = z.object({
  repository: requiredTextSchema,
  objectiveId: objectiveIdSchema,
  currentTaskId: taskIdSchema.optional(),
}).strict();

export const manifestInquireInputSchema = z.object({
  repository: requiredTextSchema,
  objectiveId: objectiveIdSchema,
  currentTaskId: taskIdSchema.optional(),
  id: graphIdSchema.optional(),
  text: requiredTextSchema.optional(),
  limit: z.number().int().min(1).max(50).optional(),
}).strict().superRefine((value, context) => {
  if ((value.id === undefined) === (value.text === undefined)) {
    context.addIssue({
      code: "custom",
      path: ["id"],
      message: "Provide exactly one of id or text.",
    });
  }
  if (value.id !== undefined && value.limit !== undefined) {
    context.addIssue({ code: "custom", path: ["limit"], message: "limit applies only to text inquiry." });
  }
});

export const manifestChangeInputSchema = z.object({
  repository: requiredTextSchema,
  objectiveId: objectiveIdSchema,
  currentTaskId: taskIdSchema.optional(),
  change: semanticGraphChangeSchema,
}).strict();

const prerequisiteSchema = z.object({ taskId: taskIdSchema, complete: z.boolean() }).strict();
const positionSchema = z.object({ workstreamIndex: z.number().int().nonnegative(), siblingIndex: z.number().int().nonnegative() }).strict();
const derivedTaskSchema = z.object({
  id: taskIdSchema,
  title: z.string(),
  workstreamId: workstreamIdSchema,
  position: positionSchema,
  complete: z.boolean(),
  discontinued: z.boolean(),
  current: z.boolean(),
  available: z.boolean(),
  phase: z.enum(["planning", "implementation"]),
  prerequisites: z.array(prerequisiteSchema),
  externalBlocker: z.string().nullable(),
  reasons: z.array(z.string()),
}).strict();

const workstreamProgressSchema = z.object({
  id: workstreamIdSchema,
  total: z.number().int().nonnegative(),
  required: z.number().int().nonnegative(),
  completed: z.number().int().nonnegative(),
  discontinued: z.number().int().nonnegative(),
  complete: z.boolean(),
}).strict();

const objectiveViewSchema = z.object({
  objectiveId: objectiveIdSchema,
  phase: z.enum(["planning", "implementation"]),
  tasks: z.array(derivedTaskSchema),
  current: derivedTaskSchema.nullable(),
  available: z.array(derivedTaskSchema),
  next: z.object({ task: derivedTaskSchema, reason: z.string(), candidateCount: z.number().int().nonnegative() }).strict().nullable(),
  choices: z.array(derivedTaskSchema),
  blockers: z.array(z.object({ taskId: taskIdSchema, reason: z.string() }).strict()),
  progress: z.object({ complete: z.boolean(), workstreams: z.array(workstreamProgressSchema) }).strict(),
}).strict();

const graphEntitySummarySchema = z.object({
  kind: z.enum(["objective", "workstream", "task"]),
  id: graphIdSchema,
  title: z.string(),
  outcome: z.string(),
  details: z.string(),
}).strict();

const connectedEntitySchema = graphEntitySummarySchema.extend({
  parent: graphEntitySummarySchema.nullable(),
  children: z.array(graphEntitySummarySchema),
  prerequisites: z.array(graphEntitySummarySchema),
  dependents: z.array(graphEntitySummarySchema),
  completionCriteria: z.array(z.string()),
  decompositionComplete: z.boolean().nullable(),
  externalBlocker: z.string().nullable(),
  completion: completionSchema.nullable(),
  discontinued: discontinuedSchema.nullable(),
  execution: derivedTaskSchema.nullable(),
}).strict();

const inquiryResultSchema = z.discriminatedUnion("outcome", [
  z.object({ outcome: z.literal("found"), entity: connectedEntitySchema }).strict(),
  z.object({ outcome: z.literal("not_found"), matches: z.array(graphEntitySummarySchema) }).strict(),
  z.object({
    outcome: z.literal("multiple"),
    matches: z.array(graphEntitySummarySchema),
    matchCount: z.number().int().nonnegative(),
    limit: z.number().int().min(1).max(50),
  }).strict(),
]);

const graphSummarySchema = z.object({
  id: objectiveIdSchema,
  title: z.string(),
  outcome: z.string(),
  phase: z.enum(["planning", "implementation"]),
}).strict();

const problemSchema = z.object({ path: z.string(), message: z.string() }).strict();

export const manifestCreateOutputSchema = z.object({
  objectiveId: objectiveIdSchema,
  path: z.string(),
  view: objectiveViewSchema,
}).strict();

export const manifestOrientOutputSchema = z.object({
  path: z.string(),
  view: objectiveViewSchema,
  implementation: implementationPlanSchema.nullable(),
}).strict();

export const manifestInquireOutputSchema = z.object({
  path: z.string(),
  result: inquiryResultSchema,
}).strict();

export const manifestChangeOutputSchema = z.object({
  applied: z.boolean(),
  path: z.string(),
  graph: graphSummarySchema.optional(),
  created: z.array(z.object({ ref: z.string(), id: z.union([workstreamIdSchema, taskIdSchema]) }).strict()).optional(),
  view: objectiveViewSchema.optional(),
  problems: z.array(problemSchema).optional(),
}).strict().superRefine((value, context) => {
  const successFieldsPresent = value.graph !== undefined && value.created !== undefined && value.view !== undefined;
  if (value.applied && (!successFieldsPresent || value.problems !== undefined)) {
    context.addIssue({ code: "custom", message: "An applied change requires graph, created, and view only." });
  }
  if (!value.applied && (value.problems === undefined || successFieldsPresent)) {
    context.addIssue({ code: "custom", message: "A rejected change requires problems only." });
  }
});

export type ManifestCreateArgs = z.infer<typeof manifestCreateInputSchema>;
export type ManifestOrientArgs = z.infer<typeof manifestOrientInputSchema>;
export type ManifestInquireArgs = z.infer<typeof manifestInquireInputSchema>;
export type ManifestChangeArgs = z.infer<typeof manifestChangeInputSchema>;

export async function handleManifestCreate(args: ManifestCreateArgs): Promise<CallToolResult> {
  try {
    const result = await createObjective(args.repository, {
      title: args.title,
      outcome: args.outcome,
      ...(args.details !== undefined ? { details: args.details } : {}),
    });
    return jsonResult(manifestCreateOutputSchema, {
      objectiveId: result.objectiveId,
      path: result.path,
      view: result.view,
    }, `Created Planning Objective ${result.objectiveId}.`);
  } catch (error) {
    return manifestErrorResult(error);
  }
}

export async function handleManifestOrient(args: ManifestOrientArgs): Promise<CallToolResult> {
  try {
    const result = await orientObjective(args.repository, args.objectiveId, args.currentTaskId);
    return jsonResult(manifestOrientOutputSchema, {
      path: result.path,
      view: result.view,
      implementation: result.graph.implementation ?? null,
    }, `Oriented to ${args.objectiveId}.`);
  } catch (error) {
    return manifestErrorResult(error);
  }
}

export async function handleManifestInquire(args: ManifestInquireArgs): Promise<CallToolResult> {
  try {
    const inquiry = args.id !== undefined ? { id: args.id } : { text: args.text!, ...(args.limit ? { limit: args.limit } : {}) };
    const result = await inquireCurrentObjective(
      args.repository,
      args.objectiveId,
      inquiry,
      args.currentTaskId,
    );
    return jsonResult(
      manifestInquireOutputSchema,
      { path: result.path, result: result.result },
      `Manifest inquiry returned ${result.result.outcome}.`,
    );
  } catch (error) {
    return manifestErrorResult(error);
  }
}

export async function handleManifestChange(args: ManifestChangeArgs): Promise<CallToolResult> {
  try {
    const result = await changeObjective(
      args.repository,
      args.objectiveId,
      args.change as SemanticGraphChange,
      args.currentTaskId,
    );
    const output = result.applied
      ? {
          applied: true as const,
          path: result.path,
          graph: {
            id: result.graph.id,
            title: result.graph.title,
            outcome: result.graph.outcome,
            phase: result.graph.phase,
          },
          created: result.created,
          view: result.view,
        }
      : { applied: false as const, path: result.path, problems: result.problems };
    return jsonResult(
      manifestChangeOutputSchema,
      output,
      result.applied ? `Applied Work Evolution to ${args.objectiveId}.` : `Work Evolution was not applied.`,
    );
  } catch (error) {
    return manifestErrorResult(error);
  }
}

function jsonResult<Schema extends z.ZodType>(
  schema: Schema,
  output: unknown,
  summary: string,
): CallToolResult {
  const parsed = schema.parse(output);
  return { content: [{ type: "text", text: summary.slice(0, 512) }], structuredContent: parsed };
}

function manifestErrorResult(error: unknown): CallToolResult {
  const code = error instanceof ManifestFileError
    ? error.code
    : error instanceof Error && "code" in error && typeof error.code === "string"
      ? error.code
      : "INTERNAL_ERROR";
  const message = error instanceof Error ? error.message : String(error);
  return {
    content: [{ type: "text", text: `${code}: ${message}` }],
    structuredContent: { error: { code, message } },
    isError: true,
  };
}
