import { createHash, randomUUID } from "node:crypto";
import { appendFile, mkdir, readFile } from "node:fs/promises";
import { dirname, join } from "node:path";

import * as z from "zod/v4";

import { resolveContinuityWorkspace } from "../continuity/index.ts";
import type { ContinuityWorkspaceOptions, WorkspaceRef } from "../continuity/index.ts";
import {
  assertActiveWorkContextBinding,
  resolveWorkContextStateRoot,
  workspaceRefSchema,
  workContextBindingView,
  workContextBindingViewSchema,
} from "../work-context/index.ts";
import type { WorkContextBinding, WorkContextBindingView } from "../work-context/index.ts";

const LEGACY_SKILL_INVOCATION_SCHEMA_VERSION = 1 as const;
export const SKILL_INVOCATION_SCHEMA_VERSION = 2 as const;
export const MAX_SKILL_NAME_CHARS = 128;
export const MAX_TRIGGER_CHARS = 500;
export const MAX_REASON_CHARS = 500;
export const MAX_SKILL_INVOCATION_HOST_CHARS = 100;
export const MAX_SKILL_INVOCATION_TRACE_ID_CHARS = 200;
export const DEFAULT_SKILL_INVOCATION_LIMIT = 20;
export const MAX_SKILL_INVOCATION_LIMIT = 200;
export const DEFAULT_SKILL_INVOCATION_AUDIT_SAMPLE_SIZE = 10;
export const MAX_SKILL_INVOCATION_AUDIT_SAMPLE_SIZE = 25;
export const SKILL_INVOCATION_OUTCOMES = ["used", "missed", "false_positive"] as const;

export const skillInvocationOutcomeSchema = z.enum(SKILL_INVOCATION_OUTCOMES);

const skillNameSchema = z.string().trim().min(1).max(MAX_SKILL_NAME_CHARS);
const triggerSchema = z.string().trim().min(1).max(MAX_TRIGGER_CHARS);
const reasonSchema = z.string().trim().min(1).max(MAX_REASON_CHARS);
const hostSchema = z.string().trim().min(1).max(MAX_SKILL_INVOCATION_HOST_CHARS);
const traceIdSchema = z.string().trim().min(1).max(MAX_SKILL_INVOCATION_TRACE_ID_CHARS);

const skillInvocationRecordEnvelopeShape = {
  id: z.string().trim().min(1),
  created_at: z.string().trim().min(1),
  workspace: workspaceRefSchema,
  skill: skillNameSchema,
  trigger: triggerSchema,
  outcome: skillInvocationOutcomeSchema,
};

export const legacySkillInvocationRecordSchema = z
  .object({
    version: z.literal(LEGACY_SKILL_INVOCATION_SCHEMA_VERSION),
    ...skillInvocationRecordEnvelopeShape,
    reason: reasonSchema.optional(),
  })
  .strict();

export const currentSkillInvocationRecordSchema = z
  .object({
    version: z.literal(SKILL_INVOCATION_SCHEMA_VERSION),
    ...skillInvocationRecordEnvelopeShape,
    reason: reasonSchema,
    host: hostSchema,
    session_id: traceIdSchema,
    turn_id: traceIdSchema.optional(),
    message_id: traceIdSchema.optional(),
  })
  .strict();

export const skillInvocationRecordSchema = z.discriminatedUnion("version", [
  legacySkillInvocationRecordSchema,
  currentSkillInvocationRecordSchema,
]);

export const skillInvocationPathsSchema = z
  .object({
    workspace: workspaceRefSchema,
    stateRoot: z.string().min(1),
    skillInvocationsRoot: z.string().min(1),
    workspaceDir: z.string().min(1),
    invocationsPath: z.string().min(1),
  })
  .strict();

export const skillInvocationOutcomeCountsSchema = z
  .object({
    used: z.number().int().nonnegative(),
    missed: z.number().int().nonnegative(),
    false_positive: z.number().int().nonnegative(),
  })
  .strict();

export const skillInvocationSummarySchema = z
  .object({
    total: z.number().int().nonnegative(),
    matching: z.number().int().nonnegative(),
    outcomes: skillInvocationOutcomeCountsSchema,
  })
  .strict();

export const skillInvocationPaginationSchema = z
  .object({
    offset: z.number().int().nonnegative(),
    limit: z.number().int().min(0).max(MAX_SKILL_INVOCATION_LIMIT),
    returned: z.number().int().nonnegative(),
    next_offset: z.number().int().nonnegative().nullable(),
  })
  .strict();

const skillInvocationReadFailureShape = {
  path: z.string().min(1),
  message: z.string().min(1),
};

export const readSkillInvocationsOutputSchema = z.discriminatedUnion("kind", [
  z
    .object({
      kind: z.literal("ok"),
      path: z.string().min(1),
      items: z.array(skillInvocationRecordSchema),
      total: z.number().int().nonnegative(),
      truncated: z.boolean(),
      summary: skillInvocationSummarySchema,
      pagination: skillInvocationPaginationSchema,
    })
    .strict(),
  z.object({ kind: z.literal("missing"), ...skillInvocationReadFailureShape }).strict(),
  z.object({ kind: z.literal("malformed"), ...skillInvocationReadFailureShape }).strict(),
]);

export const sampleSkillInvocationsOutputSchema = z.discriminatedUnion("kind", [
  z
    .object({
      kind: z.literal("ok"),
      path: z.string().min(1),
      items: z.array(currentSkillInvocationRecordSchema),
      total: z.number().int().nonnegative(),
      matching: z.number().int().nonnegative(),
      eligible: z.number().int().nonnegative(),
      excluded_untraceable: z.number().int().nonnegative(),
      seed: traceIdSchema,
      requested_size: z.number().int().min(0).max(MAX_SKILL_INVOCATION_AUDIT_SAMPLE_SIZE),
    })
    .strict(),
  z.object({ kind: z.literal("missing"), ...skillInvocationReadFailureShape }).strict(),
  z.object({ kind: z.literal("malformed"), ...skillInvocationReadFailureShape }).strict(),
]);

export type SkillInvocationOutcome = (typeof SKILL_INVOCATION_OUTCOMES)[number];

export type SkillInvocationInput = {
  skill: string;
  trigger: string;
  outcome: SkillInvocationOutcome;
  reason: string;
  host: string;
  session_id: string;
  turn_id?: string;
  message_id?: string;
};

export type BoundSkillInvocationInput = Omit<SkillInvocationInput, "host" | "session_id">;

export type LegacySkillInvocationRecord = {
  version: typeof LEGACY_SKILL_INVOCATION_SCHEMA_VERSION;
  id: string;
  created_at: string;
  workspace: WorkspaceRef;
  skill: string;
  trigger: string;
  outcome: SkillInvocationOutcome;
  reason?: string;
};

export type CurrentSkillInvocationRecord = SkillInvocationInput & {
  version: typeof SKILL_INVOCATION_SCHEMA_VERSION;
  id: string;
  created_at: string;
  workspace: WorkspaceRef;
};

export type SkillInvocationRecord = LegacySkillInvocationRecord | CurrentSkillInvocationRecord;

export type SkillInvocationPaths = {
  workspace: WorkspaceRef;
  stateRoot: string;
  skillInvocationsRoot: string;
  workspaceDir: string;
  invocationsPath: string;
};

type Clock = () => string;
type IdGenerator = () => string;

export type RecordSkillInvocationInput = ContinuityWorkspaceOptions & {
  invocation: SkillInvocationInput;
  now?: Clock;
  id?: IdGenerator;
};

export type RecordSkillInvocationOutput = {
  paths: SkillInvocationPaths;
  record: CurrentSkillInvocationRecord;
};

export type RecordBoundSkillInvocationInput = {
  binding: WorkContextBinding;
  stateRoot?: string;
  bindingNow?: Clock;
  invocation: BoundSkillInvocationInput;
  now?: Clock;
  id?: IdGenerator;
};

export type RecordBoundSkillInvocationOutput = RecordSkillInvocationOutput & {
  binding: WorkContextBindingView;
};

export const recordSkillInvocationOutputSchema = z
  .object({
    paths: skillInvocationPathsSchema,
    record: currentSkillInvocationRecordSchema,
  })
  .strict();

export const recordBoundSkillInvocationOutputSchema = z
  .object({
    paths: skillInvocationPathsSchema,
    record: currentSkillInvocationRecordSchema,
    binding: workContextBindingViewSchema,
  })
  .strict();

export type SkillInvocationFilters = {
  skill?: string;
  outcome?: SkillInvocationOutcome;
  session_id?: string;
};

export type SkillInvocationOutcomeCounts = Record<SkillInvocationOutcome, number>;

export type ReadSkillInvocationsInput = ContinuityWorkspaceOptions &
  SkillInvocationFilters & {
    limit?: number;
    offset?: number;
  };

export type ReadSkillInvocationsOutput =
  | {
      kind: "ok";
      path: string;
      items: SkillInvocationRecord[];
      total: number;
      truncated: boolean;
      summary: {
        total: number;
        matching: number;
        outcomes: SkillInvocationOutcomeCounts;
      };
      pagination: {
        offset: number;
        limit: number;
        returned: number;
        next_offset: number | null;
      };
    }
  | { kind: "missing"; path: string; message: string }
  | { kind: "malformed"; path: string; message: string };

export type SampleSkillInvocationsInput = ContinuityWorkspaceOptions &
  SkillInvocationFilters & {
    seed: string;
    size?: number;
  };

export type SampleSkillInvocationsOutput =
  | {
      kind: "ok";
      path: string;
      items: CurrentSkillInvocationRecord[];
      total: number;
      matching: number;
      eligible: number;
      excluded_untraceable: number;
      seed: string;
      requested_size: number;
    }
  | { kind: "missing"; path: string; message: string }
  | { kind: "malformed"; path: string; message: string };

type SchemaExactlyMatches<TSchema extends z.ZodType, TDomain> =
  z.output<TSchema> extends TDomain ? (TDomain extends z.output<TSchema> ? true : false) : false;
type AssertSchemaMatch<T extends true> = T;

type _LegacySkillInvocationRecordSchemaMatch = AssertSchemaMatch<
  SchemaExactlyMatches<typeof legacySkillInvocationRecordSchema, LegacySkillInvocationRecord>
>;
type _CurrentSkillInvocationRecordSchemaMatch = AssertSchemaMatch<
  SchemaExactlyMatches<typeof currentSkillInvocationRecordSchema, CurrentSkillInvocationRecord>
>;
type _SkillInvocationRecordSchemaMatch = AssertSchemaMatch<
  SchemaExactlyMatches<typeof skillInvocationRecordSchema, SkillInvocationRecord>
>;
type _SkillInvocationPathsSchemaMatch = AssertSchemaMatch<
  SchemaExactlyMatches<typeof skillInvocationPathsSchema, SkillInvocationPaths>
>;
type _RecordSkillInvocationOutputSchemaMatch = AssertSchemaMatch<
  SchemaExactlyMatches<typeof recordSkillInvocationOutputSchema, RecordSkillInvocationOutput>
>;
type _RecordBoundSkillInvocationOutputSchemaMatch = AssertSchemaMatch<
  SchemaExactlyMatches<typeof recordBoundSkillInvocationOutputSchema, RecordBoundSkillInvocationOutput>
>;
type _ReadSkillInvocationsOutputSchemaMatch = AssertSchemaMatch<
  SchemaExactlyMatches<typeof readSkillInvocationsOutputSchema, ReadSkillInvocationsOutput>
>;
type _SampleSkillInvocationsOutputSchemaMatch = AssertSchemaMatch<
  SchemaExactlyMatches<typeof sampleSkillInvocationsOutputSchema, SampleSkillInvocationsOutput>
>;

type SkillInvocationRecordReadOutput =
  | { kind: "ok"; path: string; records: SkillInvocationRecord[] }
  | { kind: "missing"; path: string; message: string }
  | { kind: "malformed"; path: string; message: string };

function nowIso(): string {
  return new Date().toISOString();
}

function newInvocationId(): string {
  const stamp = new Date().toISOString().slice(0, 10).replace(/-/g, "");
  return `skill_inv_${stamp}_${randomUUID().replace(/-/g, "").slice(0, 12)}`;
}

function boundedString(value: unknown, field: string, maxChars: number): string {
  if (typeof value !== "string" || value.trim().length === 0) {
    throw new Error(`${field} must be a non-empty string`);
  }
  const trimmed = value.trim();
  if (trimmed.length > maxChars) throw new Error(`${field} must be ${maxChars} characters or fewer`);
  return trimmed;
}

function optionalBoundedString(value: unknown, field: string, maxChars: number): string | undefined {
  return value === undefined ? undefined : boundedString(value, field, maxChars);
}

function validateOutcome(value: unknown): SkillInvocationOutcome {
  if (SKILL_INVOCATION_OUTCOMES.some((outcome) => outcome === value)) return value as SkillInvocationOutcome;
  throw new Error("outcome must be one of used, missed, false_positive");
}

function validateLegacyOutcome(value: unknown): SkillInvocationOutcome {
  return value === undefined ? "used" : validateOutcome(value);
}

function normalizeLimit(value: number | undefined): number {
  if (value === undefined) return DEFAULT_SKILL_INVOCATION_LIMIT;
  if (!Number.isInteger(value) || value < 0) throw new Error("limit must be a non-negative integer");
  return Math.min(MAX_SKILL_INVOCATION_LIMIT, value);
}

function normalizeOffset(value: number | undefined): number {
  if (value === undefined) return 0;
  if (!Number.isInteger(value) || value < 0) throw new Error("offset must be a non-negative integer");
  return value;
}

function normalizeAuditSampleSize(value: number | undefined): number {
  if (value === undefined) return DEFAULT_SKILL_INVOCATION_AUDIT_SAMPLE_SIZE;
  if (!Number.isInteger(value) || value < 0) throw new Error("size must be a non-negative integer");
  return Math.min(MAX_SKILL_INVOCATION_AUDIT_SAMPLE_SIZE, value);
}

function validateInvocationInput(input: SkillInvocationInput): SkillInvocationInput {
  const turnId = optionalBoundedString(input.turn_id, "turn_id", MAX_SKILL_INVOCATION_TRACE_ID_CHARS);
  const messageId = optionalBoundedString(input.message_id, "message_id", MAX_SKILL_INVOCATION_TRACE_ID_CHARS);
  return {
    skill: boundedString(input.skill, "skill", MAX_SKILL_NAME_CHARS),
    trigger: boundedString(input.trigger, "trigger", MAX_TRIGGER_CHARS),
    outcome: validateOutcome(input.outcome),
    reason: boundedString(input.reason, "reason", MAX_REASON_CHARS),
    host: boundedString(input.host, "host", MAX_SKILL_INVOCATION_HOST_CHARS),
    session_id: boundedString(input.session_id, "session_id", MAX_SKILL_INVOCATION_TRACE_ID_CHARS),
    ...(turnId ? { turn_id: turnId } : {}),
    ...(messageId ? { message_id: messageId } : {}),
  };
}

function validateLegacyInvocationBody(record: Record<string, unknown>): Omit<LegacySkillInvocationRecord, "version" | "id" | "created_at" | "workspace"> {
  const reason = optionalBoundedString(record.reason, "reason", MAX_REASON_CHARS);
  return {
    skill: boundedString(record.skill, "skill", MAX_SKILL_NAME_CHARS),
    trigger: boundedString(record.trigger, "trigger", MAX_TRIGGER_CHARS),
    outcome: validateLegacyOutcome(record.outcome),
    ...(reason ? { reason } : {}),
  };
}

function validateRecordEnvelope(
  record: Record<string, unknown>,
  lineNumber: number,
  path: string,
): Pick<SkillInvocationRecord, "id" | "created_at" | "workspace"> {
  if (typeof record.id !== "string" || record.id.trim().length === 0) {
    throw new Error(`Invalid invocation on line ${lineNumber} in ${path}: id must be a non-empty string`);
  }
  if (typeof record.created_at !== "string" || Number.isNaN(Date.parse(record.created_at))) {
    throw new Error(`Invalid invocation on line ${lineNumber} in ${path}: created_at must be an ISO timestamp`);
  }
  if (typeof record.workspace !== "object" || record.workspace === null || Array.isArray(record.workspace)) {
    throw new Error(`Invalid invocation on line ${lineNumber} in ${path}: workspace must be an object`);
  }
  const workspace = record.workspace as Record<string, unknown>;
  if (typeof workspace.key !== "string" || workspace.key.trim().length === 0) {
    throw new Error(`Invalid invocation on line ${lineNumber} in ${path}: workspace.key must be a non-empty string`);
  }
  if (workspace.kind !== "git" && workspace.kind !== "directory") {
    throw new Error(`Invalid invocation on line ${lineNumber} in ${path}: workspace.kind must be git or directory`);
  }
  if (typeof workspace.root !== "string" || workspace.root.trim().length === 0) {
    throw new Error(`Invalid invocation on line ${lineNumber} in ${path}: workspace.root must be a non-empty string`);
  }
  return {
    id: record.id,
    created_at: record.created_at,
    workspace: {
      key: workspace.key,
      kind: workspace.kind,
      root: workspace.root,
      ...(typeof workspace.label === "string" ? { label: workspace.label } : {}),
    },
  };
}

export function validateSkillInvocationRecord(value: unknown, lineNumber: number, path: string): SkillInvocationRecord {
  if (typeof value !== "object" || value === null || Array.isArray(value)) {
    throw new Error(`Invalid invocation on line ${lineNumber} in ${path}: record must be an object`);
  }
  const record = value as Record<string, unknown>;
  if (record.version !== LEGACY_SKILL_INVOCATION_SCHEMA_VERSION && record.version !== SKILL_INVOCATION_SCHEMA_VERSION) {
    throw new Error(
      `Invalid invocation on line ${lineNumber} in ${path}: version must be ${LEGACY_SKILL_INVOCATION_SCHEMA_VERSION} or ${SKILL_INVOCATION_SCHEMA_VERSION}`,
    );
  }
  const envelope = validateRecordEnvelope(record, lineNumber, path);
  if (record.version === LEGACY_SKILL_INVOCATION_SCHEMA_VERSION) {
    return { version: LEGACY_SKILL_INVOCATION_SCHEMA_VERSION, ...envelope, ...validateLegacyInvocationBody(record) };
  }
  return {
    version: SKILL_INVOCATION_SCHEMA_VERSION,
    ...envelope,
    ...validateInvocationInput({
      skill: record.skill as string,
      trigger: record.trigger as string,
      outcome: record.outcome as SkillInvocationOutcome,
      reason: record.reason as string,
      host: record.host as string,
      session_id: record.session_id as string,
      turn_id: record.turn_id as string | undefined,
      message_id: record.message_id as string | undefined,
    }),
  };
}

function filterSkillInvocations(records: SkillInvocationRecord[], filters: SkillInvocationFilters): SkillInvocationRecord[] {
  return records.filter((record) => {
    if (filters.skill !== undefined && record.skill !== filters.skill) return false;
    if (filters.outcome !== undefined && record.outcome !== filters.outcome) return false;
    if (filters.session_id !== undefined && (record.version !== 2 || record.session_id !== filters.session_id)) return false;
    return true;
  });
}

function countOutcomes(records: SkillInvocationRecord[]): SkillInvocationOutcomeCounts {
  const counts: SkillInvocationOutcomeCounts = { used: 0, missed: 0, false_positive: 0 };
  for (const record of records) counts[record.outcome] += 1;
  return counts;
}

function compareSkillInvocationRecords(left: SkillInvocationRecord, right: SkillInvocationRecord): number {
  return left.created_at.localeCompare(right.created_at) || left.id.localeCompare(right.id);
}

function auditRank(seed: string, record: SkillInvocationRecord): string {
  return createHash("sha256").update(seed).update("\0").update(record.id).digest("hex");
}

export function resolveSkillInvocationWorkspace(options: ContinuityWorkspaceOptions = {}): SkillInvocationPaths {
  const continuityPaths = resolveContinuityWorkspace(options);
  const skillInvocationsRoot = join(continuityPaths.stateRoot, "skill-invocations");
  const workspaceDir = join(skillInvocationsRoot, "workspaces", continuityPaths.workspace.key);
  return {
    workspace: continuityPaths.workspace,
    stateRoot: continuityPaths.stateRoot,
    skillInvocationsRoot,
    workspaceDir,
    invocationsPath: join(workspaceDir, "invocations.jsonl"),
  };
}

export async function recordSkillInvocation(input: RecordSkillInvocationInput): Promise<RecordSkillInvocationOutput> {
  const paths = resolveSkillInvocationWorkspace(input);
  const now = (input.now ?? nowIso)();
  const record: CurrentSkillInvocationRecord = {
    version: SKILL_INVOCATION_SCHEMA_VERSION,
    id: (input.id ?? newInvocationId)(),
    created_at: now,
    workspace: paths.workspace,
    ...validateInvocationInput(input.invocation),
  };

  await mkdir(dirname(paths.invocationsPath), { recursive: true });
  await appendFile(paths.invocationsPath, `${JSON.stringify(record)}\n`, "utf8");
  return { paths, record };
}

export async function recordBoundSkillInvocation(
  input: RecordBoundSkillInvocationInput,
): Promise<RecordBoundSkillInvocationOutput> {
  const binding = assertActiveWorkContextBinding(input.binding, input.bindingNow);
  const result = await recordSkillInvocation({
    cwd: binding.collaboration_space.root,
    stateRoot: resolveWorkContextStateRoot(input.stateRoot),
    invocation: {
      ...input.invocation,
      host: binding.host,
      session_id: binding.session_id,
    },
    ...(input.now ? { now: input.now } : {}),
    ...(input.id ? { id: input.id } : {}),
  });
  return { ...result, binding: workContextBindingView(binding) };
}

async function readSkillInvocationRecords(
  input: ContinuityWorkspaceOptions = {},
): Promise<SkillInvocationRecordReadOutput> {
  const paths = resolveSkillInvocationWorkspace(input);
  let text;
  try {
    text = await readFile(paths.invocationsPath, "utf8");
  } catch (error) {
    if (typeof error === "object" && error !== null && "code" in error && error.code === "ENOENT") {
      return { kind: "missing", path: paths.invocationsPath, message: `${paths.invocationsPath} does not exist` };
    }
    const message = error instanceof Error ? error.message : String(error);
    return { kind: "malformed", path: paths.invocationsPath, message };
  }

  const records: SkillInvocationRecord[] = [];
  const lines = text.split("\n").filter((line) => line.trim().length > 0);
  for (const [index, line] of lines.entries()) {
    try {
      records.push(validateSkillInvocationRecord(JSON.parse(line), index + 1, paths.invocationsPath));
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      return { kind: "malformed", path: paths.invocationsPath, message };
    }
  }
  return { kind: "ok", path: paths.invocationsPath, records };
}

export async function readSkillInvocations(input: ReadSkillInvocationsInput = {}): Promise<ReadSkillInvocationsOutput> {
  const limit = normalizeLimit(input.limit);
  const offset = normalizeOffset(input.offset);
  const result = await readSkillInvocationRecords(input);
  if (result.kind !== "ok") return result;

  const matching = filterSkillInvocations(result.records, input);
  const end = Math.max(0, matching.length - offset);
  const start = Math.max(0, end - limit);
  const items = limit === 0 ? [] : matching.slice(start, end);
  return {
    kind: "ok",
    path: result.path,
    items,
    total: result.records.length,
    truncated: matching.length > items.length,
    summary: {
      total: result.records.length,
      matching: matching.length,
      outcomes: countOutcomes(matching),
    },
    pagination: {
      offset,
      limit,
      returned: items.length,
      next_offset: limit > 0 && start > 0 ? offset + items.length : null,
    },
  };
}

export async function sampleSkillInvocations(
  input: SampleSkillInvocationsInput,
): Promise<SampleSkillInvocationsOutput> {
  const seed = boundedString(input.seed, "seed", MAX_SKILL_INVOCATION_TRACE_ID_CHARS);
  const size = normalizeAuditSampleSize(input.size);
  const result = await readSkillInvocationRecords(input);
  if (result.kind !== "ok") return result;

  const matching = filterSkillInvocations(result.records, input);
  const eligible = matching.filter((record): record is CurrentSkillInvocationRecord => record.version === 2);
  const items = eligible
    .map((record) => ({ record, rank: auditRank(seed, record) }))
    .sort((left, right) => left.rank.localeCompare(right.rank) || left.record.id.localeCompare(right.record.id))
    .slice(0, size)
    .map(({ record }) => record)
    .sort(compareSkillInvocationRecords);
  return {
    kind: "ok",
    path: result.path,
    items,
    total: result.records.length,
    matching: matching.length,
    eligible: eligible.length,
    excluded_untraceable: matching.length - eligible.length,
    seed,
    requested_size: size,
  };
}
