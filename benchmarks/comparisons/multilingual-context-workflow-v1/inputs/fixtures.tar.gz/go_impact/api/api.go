package api

type Request struct { ID int64 }

func Handle(req Request) {}
