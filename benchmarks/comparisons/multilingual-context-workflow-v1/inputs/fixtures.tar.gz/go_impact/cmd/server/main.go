package main

import "example.com/acme/api"

func Serve(req api.Request) { api.Handle(req) }
