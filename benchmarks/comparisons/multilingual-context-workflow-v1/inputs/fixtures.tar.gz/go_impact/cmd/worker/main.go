package main

import service "example.com/acme/api"

func Work(req service.Request) { service.Handle(req) }
