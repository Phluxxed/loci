export class Thing {}
