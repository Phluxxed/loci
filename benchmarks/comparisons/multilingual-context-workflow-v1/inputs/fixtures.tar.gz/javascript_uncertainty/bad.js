import Factory, { Thing } from "./barrel.js";
import * as model from "./left.js";
import { External } from "uninstalled-package";

export function unproven() { return [Thing, Factory, External]; }
export function shadowed(Thing) { return Thing(); }
export function computed(key) { return model[key](); }
export function legacy() { const loaded = require("./left.js"); return loaded.Thing; }
export function dynamic(path) { return import(path); }
export class Dynamic extends chooseBase() {}
/** @param {Thing} value */
export function documented(value) { return value; }
