export class Thing {}
export default function Factory() {}
