from lib import target as alias

def caller():
    return alias()
