package shared

func Open() {}
