package main

import (
    api "example.com/acme/model"
    "example.com/acme/one"
    "example.com/acme/two"
    "fmt"
)

func Keep(req api.Request) {}

func Probe(api int) {
    api.Handle()
    shared.Open()
    fmt.Println(api)
}

func Missing() { api.Absent() }
