package model

type Request struct{}
func Handle() {}
func Absent() {}
