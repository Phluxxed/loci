class Missing:
    pass
