class Payload:
    pass
