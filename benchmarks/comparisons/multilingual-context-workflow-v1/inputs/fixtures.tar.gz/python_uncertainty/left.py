class Choice:
    pass
