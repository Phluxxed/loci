from model import Missing
from absent import External
from left import *
from right import *
from model import Payload as P

def unknown(value: Missing, other: External, choice: Choice):
    return value

def shadowed():
    P = object()
    def nested(value: P):
        return value
    return nested

def generic[P](value: P) -> P:
    return value

def computed(value: make_type()) -> "list[P]":
    return value

class Dynamic(make_base()):
    pass
