# Context guide

Use exact source.

## Limits

Budget: 8,192 UTF-8 bytes; café remains intact.

### Omissions

Report missing evidence explicitly.

## Ownership

Keep the original declaration owner.
