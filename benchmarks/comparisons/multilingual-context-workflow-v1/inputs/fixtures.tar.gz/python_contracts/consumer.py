from typing import TypeAlias
from barrel import Exported as P
from schema import Base

Alias: TypeAlias = P

def decode(value: Alias) -> list[P]:
    return [value]

class Child(Base):
    pass

def later(value: "P") -> "P":
    return value
