class Payload:
    request_id: str

class Base:
    enabled: bool
