class Payload:
    wrong: int
