package main

import "example.com/acme/model"

func Build(id model.AliasID) model.Page[model.UserID] {
    return model.Page[model.UserID]{Value: id}
}
