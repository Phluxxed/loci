package model

type UserID int64
type AliasID = UserID

type Number interface { ~int | ~int64 }

type Page[T Number] struct { Value T }
