pub struct Thing;

pub trait Shared {}
pub const Shared: usize = 1;

#[cfg(feature = "one")]
pub use crate::a::Value as Choice;

#[cfg(feature = "two")]
pub use crate::b::Value as Choice;
