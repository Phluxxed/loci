pub mod model;
mod a;
mod b;
mod private_api;

use crate::model::{Thing, Shared, Choice};
use crate::private_api::Hidden;
use std::fmt::Display;

pub fn probe(value: Thing) {
    let _: Thing = value;
    Shared;
    Generated!();
    let _: Choice;
    let _: Hidden;
    let _: Display;
}

pub fn generic<Thing>(value: Thing) -> Thing { value }
