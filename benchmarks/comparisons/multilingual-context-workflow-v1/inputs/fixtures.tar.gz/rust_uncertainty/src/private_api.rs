struct Hidden;
