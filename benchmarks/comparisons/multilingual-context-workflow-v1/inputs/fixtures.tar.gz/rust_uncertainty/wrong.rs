pub struct Thing;
pub struct Hidden;
