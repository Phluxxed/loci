pub type UserId = u64;

pub trait Format {}

pub trait Render: Format { fn render(&self) -> String; }

pub struct Receipt { pub id: UserId }

impl Format for Receipt {}

impl Render for Receipt {
    fn render(&self) -> String { format!("{}", self.id) }
}

pub struct Envelope<T: Render> { pub id: UserId, pub body: T }

pub fn build<T: Render>(id: UserId, body: T) -> Envelope<T> {
    Envelope { id, body }
}
