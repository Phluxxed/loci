use core_api::PublicThing;

pub fn use_it(value: PublicThing) -> PublicThing { value }
