pub struct Thing { pub id: u64 }
