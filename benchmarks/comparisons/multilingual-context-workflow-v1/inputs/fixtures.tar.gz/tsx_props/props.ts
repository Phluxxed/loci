export interface Props { label: string; tone: "quiet" | "loud" }
