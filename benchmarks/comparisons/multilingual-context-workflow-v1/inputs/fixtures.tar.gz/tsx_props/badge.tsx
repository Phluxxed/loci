import type { Props } from "./props";
export function Badge(props: Props) { return <span>{props.label}</span>; }
