import { make, add, Parent } from "./barrel.js";
export function run() { return make() + add(1); }
export class Worker extends Parent { work() { return add(2); } }
