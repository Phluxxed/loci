export class Base { enabled() { return true; } }
