export const add = (value) => value + 1;
function make() { return add(0); }
export default make;
