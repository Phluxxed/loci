package model

type Audit struct { Created int64 }
func (Audit) Stamp() {}

type Entity struct { Audit }

type Runner interface { Run() error }
type Combined interface { Runner }
