package main

import "example.com/acme/model"

func Start(e model.Entity, r model.Combined) {
    e.Stamp()
    _ = r
}
