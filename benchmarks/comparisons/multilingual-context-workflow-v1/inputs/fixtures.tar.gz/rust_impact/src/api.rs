pub struct Config { pub strict: bool }

pub fn parse(config: Config) -> bool { config.strict }
