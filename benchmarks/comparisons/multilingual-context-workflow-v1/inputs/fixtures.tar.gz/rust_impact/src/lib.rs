pub mod api;
use crate::api::{parse, Config};

pub fn caller(config: Config) -> bool { parse(config) }
